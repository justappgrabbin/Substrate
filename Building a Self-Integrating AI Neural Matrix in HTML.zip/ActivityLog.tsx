import { AlertCircle, CheckCircle2, Clock, Zap } from 'lucide-react';

interface Activity {
  id: number;
  type: string;
  prompt: string;
  status: 'success' | 'error' | 'pending';
  duration?: number;
  createdAt: Date;
  metadata?: Record<string, any>;
}

interface ActivityLogProps {
  activities: Activity[];
  isLoading?: boolean;
  maxItems?: number;
}

export function ActivityLog({ activities, isLoading = false, maxItems = 20 }: ActivityLogProps) {
  const displayActivities = activities.slice(0, maxItems);

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'chat':
        return '💬';
      case 'codegen':
        return '⚙️';
      case 'analysis':
        return '🔍';
      case 'integration':
        return '🔗';
      default:
        return '📝';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success':
        return <CheckCircle2 className="w-4 h-4 text-acid-green" />;
      case 'error':
        return <AlertCircle className="w-4 h-4 text-red-500" />;
      case 'pending':
        return <Clock className="w-4 h-4 text-yellow-500 animate-spin" />;
      default:
        return <Zap className="w-4 h-4 text-muted-foreground" />;
    }
  };

  const formatDuration = (ms?: number) => {
    if (!ms) return '';
    if (ms < 1000) return `${ms}ms`;
    return `${(ms / 1000).toFixed(1)}s`;
  };

  return (
    <div className="flex flex-col h-full gap-3">
      <div className="flex items-center justify-between">
        <h3 className="cyber-text text-sm">Activity Log</h3>
        <span className="text-xs text-muted-foreground">{displayActivities.length} items</span>
      </div>

      <div className="flex-1 overflow-y-auto space-y-2">
        {isLoading ? (
          <div className="text-center py-8 text-muted-foreground text-xs">
            Loading activities...
          </div>
        ) : displayActivities.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground text-xs">
            No activities yet
          </div>
        ) : (
          displayActivities.map((activity) => (
            <div
              key={activity.id}
              className="p-2 bg-muted/10 border border-border rounded-sm hover:border-cyan-neon/30 transition-colors group"
            >
              {/* Header with icon and status */}
              <div className="flex items-start gap-2">
                <span className="text-sm mt-0.5">{getActivityIcon(activity.type)}</span>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono capitalize text-foreground group-hover:text-cyan-neon transition-colors">
                      {activity.type}
                    </span>
                    {getStatusIcon(activity.status)}
                    {activity.duration && (
                      <span className="text-xs text-muted-foreground">
                        {formatDuration(activity.duration)}
                      </span>
                    )}
                  </div>

                  {/* Prompt snippet */}
                  <div className="text-xs text-muted-foreground truncate mt-1">
                    {activity.prompt.substring(0, 60)}
                    {activity.prompt.length > 60 ? '...' : ''}
                  </div>
                </div>
              </div>

              {/* Metadata */}
              {activity.metadata && Object.keys(activity.metadata).length > 0 && (
                <div className="text-xs text-muted-foreground mt-1 ml-6 space-y-0.5">
                  {Object.entries(activity.metadata).map(([key, value]) => (
                    <div key={key} className="flex gap-2">
                      <span className="text-muted-foreground/60">{key}:</span>
                      <span>{String(value)}</span>
                    </div>
                  ))}
                </div>
              )}

              {/* Timestamp */}
              <div className="text-xs text-muted-foreground/50 mt-1 ml-6">
                {new Date(activity.createdAt).toLocaleTimeString()}
              </div>
            </div>
          ))
        )}
      </div>

      {/* Footer stats */}
      {displayActivities.length > 0 && (
        <div className="border-t border-border pt-2 text-xs text-muted-foreground space-y-1">
          <div>
            Success rate:{' '}
            {(
              (displayActivities.filter((a) => a.status === 'success').length /
                displayActivities.length) *
              100
            ).toFixed(0)}
            %
          </div>
          <div>
            Avg duration:{' '}
            {(
              displayActivities.reduce((sum, a) => sum + (a.duration || 0), 0) /
              displayActivities.filter((a) => a.duration).length
            ).toFixed(0)}
            ms
          </div>
        </div>
      )}
    </div>
  );
}
