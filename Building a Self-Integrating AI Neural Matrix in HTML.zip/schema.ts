import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const artifacts = mysqlTable("artifacts", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  filename: varchar("filename", { length: 255 }).notNull(),
  fileType: varchar("fileType", { length: 50 }).notNull(),
  fileSize: int("fileSize").notNull(),
  fileKey: varchar("fileKey", { length: 255 }).notNull(),
  fileUrl: text("fileUrl").notNull(),
  extractedText: text("extractedText"),
  metadata: text("metadata"),
  uploadedAt: timestamp("uploadedAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Artifact = typeof artifacts.$inferSelect;
export type InsertArtifact = typeof artifacts.$inferInsert;

export const knowledgeBase = mysqlTable("knowledgeBase", {
  id: int("id").autoincrement().primaryKey(),
  artifactId: int("artifactId").notNull().references(() => artifacts.id),
  userId: int("userId").notNull().references(() => users.id),
  content: text("content").notNull(),
  contentType: varchar("contentType", { length: 50 }).notNull(),
  embedding: text("embedding"),
  tags: varchar("tags", { length: 500 }),
  summary: text("summary"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type KnowledgeEntry = typeof knowledgeBase.$inferSelect;
export type InsertKnowledgeEntry = typeof knowledgeBase.$inferInsert;

export const integrationConfigs = mysqlTable("integrationConfigs", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  service: mysqlEnum("service", ["github", "supabase", "huggingface"]).notNull(),
  isConnected: int("isConnected").default(0).notNull(),
  configData: text("configData").notNull(),
  lastSync: timestamp("lastSync"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type IntegrationConfig = typeof integrationConfigs.$inferSelect;
export type InsertIntegrationConfig = typeof integrationConfigs.$inferInsert;

export const aiActivityLog = mysqlTable("aiActivityLog", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  activityType: varchar("activityType", { length: 50 }).notNull(),
  prompt: text("prompt"),
  response: text("response"),
  tokensUsed: int("tokensUsed"),
  duration: int("duration"),
  status: varchar("status", { length: 20 }).notNull(),
  metadata: text("metadata"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AIActivity = typeof aiActivityLog.$inferSelect;
export type InsertAIActivity = typeof aiActivityLog.$inferInsert;

export const modificationHistory = mysqlTable("modificationHistory", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  modificationType: varchar("modificationType", { length: 50 }).notNull(),
  originalCode: text("originalCode"),
  newCode: text("newCode").notNull(),
  codeDiff: text("codeDiff"),
  reason: text("reason"),
  isApproved: int("isApproved").default(0).notNull(),
  isRolledBack: int("isRolledBack").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  rolledBackAt: timestamp("rolledBackAt"),
});

export type ModificationRecord = typeof modificationHistory.$inferSelect;
export type InsertModificationRecord = typeof modificationHistory.$inferInsert;
