import { useState, useMemo } from 'react';
import { Search, Filter, X } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

interface Artifact {
  id: number;
  filename: string;
  fileType: string;
  fileSize: number;
  fileUrl: string;
  uploadedAt: Date;
  metadata?: Record<string, any>;
}

interface ArtifactLibraryProps {
  artifacts: Artifact[];
  onArtifactSelect?: (artifact: Artifact) => void;
  isLoading?: boolean;
}

export function ArtifactLibrary({
  artifacts,
  onArtifactSelect,
  isLoading = false,
}: ArtifactLibraryProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<string | null>(null);
  const [sortBy, setSortBy] = useState<'date' | 'size' | 'name'>('date');

  // Get unique file types
  const fileTypes = useMemo(() => {
    return Array.from(new Set(artifacts.map((a) => a.fileType)));
  }, [artifacts]);

  // Filter and sort artifacts
  const filteredArtifacts = useMemo(() => {
    let result = artifacts;

    // Filter by search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(
        (a) =>
          a.filename.toLowerCase().includes(query) ||
          a.fileType.toLowerCase().includes(query)
      );
    }

    // Filter by type
    if (selectedType) {
      result = result.filter((a) => a.fileType === selectedType);
    }

    // Sort
    switch (sortBy) {
      case 'date':
        result.sort((a, b) => new Date(b.uploadedAt).getTime() - new Date(a.uploadedAt).getTime());
        break;
      case 'size':
        result.sort((a, b) => b.fileSize - a.fileSize);
        break;
      case 'name':
        result.sort((a, b) => a.filename.localeCompare(b.filename));
        break;
    }

    return result;
  }, [artifacts, searchQuery, selectedType, sortBy]);

  return (
    <div className="flex flex-col h-full gap-4">
      {/* Search and Filter Bar */}
      <div className="space-y-3">
        {/* Search Input */}
        <div className="relative">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search artifacts..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="input-cyber pl-9"
          />
        </div>

        {/* Filter Controls */}
        <div className="flex gap-2 flex-wrap">
          {/* Type Filter */}
          <div className="flex gap-1 flex-wrap">
            <Button
              size="sm"
              variant={selectedType === null ? 'default' : 'outline'}
              onClick={() => setSelectedType(null)}
              className="text-xs"
            >
              <Filter className="w-3 h-3 mr-1" />
              All
            </Button>
            {fileTypes.map((type) => (
              <Button
                key={type}
                size="sm"
                variant={selectedType === type ? 'default' : 'outline'}
                onClick={() => setSelectedType(type)}
                className="text-xs"
              >
                {type.split('/')[1] || type}
              </Button>
            ))}
          </div>

          {/* Sort Dropdown */}
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as 'date' | 'size' | 'name')}
            className="input-cyber text-xs px-2 py-1"
          >
            <option value="date">Sort by Date</option>
            <option value="size">Sort by Size</option>
            <option value="name">Sort by Name</option>
          </select>
        </div>
      </div>

      {/* Active Filters Display */}
      {(searchQuery || selectedType) && (
        <div className="flex gap-2 flex-wrap">
          {searchQuery && (
            <div className="px-2 py-1 bg-muted/20 border border-border rounded-sm text-xs flex items-center gap-1">
              <span>Search: {searchQuery}</span>
              <button
                onClick={() => setSearchQuery('')}
                className="hover:text-foreground transition-colors"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
          )}
          {selectedType && (
            <div className="px-2 py-1 bg-muted/20 border border-border rounded-sm text-xs flex items-center gap-1">
              <span>Type: {selectedType}</span>
              <button
                onClick={() => setSelectedType(null)}
                className="hover:text-foreground transition-colors"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
          )}
        </div>
      )}

      {/* Artifacts List */}
      <div className="flex-1 overflow-y-auto space-y-1">
        {isLoading ? (
          <div className="text-center py-8 text-muted-foreground text-sm">
            Loading artifacts...
          </div>
        ) : filteredArtifacts.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground text-sm">
            {artifacts.length === 0
              ? 'No artifacts uploaded yet'
              : 'No artifacts match your filters'}
          </div>
        ) : (
          filteredArtifacts.map((artifact) => (
            <div
              key={artifact.id}
              onClick={() => onArtifactSelect?.(artifact)}
              className="p-3 bg-muted/10 border border-border rounded-sm hover:border-cyan-neon/50 hover:bg-muted/20 transition-all cursor-pointer group"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <div className="font-mono text-xs truncate text-foreground group-hover:text-cyan-neon transition-colors">
                    {artifact.filename}
                  </div>
                  <div className="text-xs text-muted-foreground mt-1 flex gap-2">
                    <span>{(artifact.fileSize / 1024).toFixed(1)}KB</span>
                    <span>•</span>
                    <span>{artifact.fileType}</span>
                    <span>•</span>
                    <span>{new Date(artifact.uploadedAt).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>

              {/* Metadata Tags */}
              {artifact.metadata?.tags && artifact.metadata.tags.length > 0 && (
                <div className="flex gap-1 flex-wrap mt-2">
                  {artifact.metadata.tags.slice(0, 3).map((tag: string, idx: number) => (
                    <span
                      key={idx}
                      className="px-1.5 py-0.5 bg-accent/20 border border-accent/30 rounded text-xs text-accent"
                    >
                      {tag}
                    </span>
                  ))}
                  {artifact.metadata.tags.length > 3 && (
                    <span className="px-1.5 py-0.5 text-xs text-muted-foreground">
                      +{artifact.metadata.tags.length - 3} more
                    </span>
                  )}
                </div>
              )}
            </div>
          ))
        )}
      </div>

      {/* Summary Stats */}
      {filteredArtifacts.length > 0 && (
        <div className="border-t border-border pt-2 text-xs text-muted-foreground space-y-1">
          <div>
            Showing {filteredArtifacts.length} of {artifacts.length} artifacts
          </div>
          <div>
            Total size:{' '}
            {(
              filteredArtifacts.reduce((sum, a) => sum + a.fileSize, 0) /
              1024 /
              1024
            ).toFixed(2)}
            MB
          </div>
        </div>
      )}
    </div>
  );
}
