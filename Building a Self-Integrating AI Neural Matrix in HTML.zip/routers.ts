import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { artifactsRouter } from "./routers/artifacts";
import { aiRouter } from "./routers/ai";
import { integrationsRouter } from "./routers/integrations";
import { terminalRouter } from "./routers/terminal";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),
  artifacts: artifactsRouter,
  ai: aiRouter,
  integrations: integrationsRouter,
  terminal: terminalRouter,
});

export type AppRouter = typeof appRouter;

