import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { saveIntegrationConfig, getIntegrationConfig } from "../db";

export const integrationsRouter = router({
  /**
   * Connect GitHub integration
   */
  connectGitHub: protectedProcedure
    .input(
      z.object({
        accessToken: z.string(),
        username: z.string(),
        repoName: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const config = {
        accessToken: input.accessToken,
        username: input.username,
        repoName: input.repoName,
        connectedAt: new Date().toISOString(),
      };

      await saveIntegrationConfig({
        userId: ctx.user.id,
        service: "github",
        isConnected: 1,
        configData: JSON.stringify(config),
      });

      return {
        success: true,
        message: `Connected to GitHub repo: ${input.username}/${input.repoName}`,
      };
    }),

  /**
   * Get GitHub integration status
   */
  getGitHubStatus: protectedProcedure.query(async ({ ctx }) => {
    const config = await getIntegrationConfig(ctx.user.id, "github");
    if (!config) {
      return { connected: false };
    }

    const data = JSON.parse(config.configData);
    return {
      connected: config.isConnected === 1,
      username: data.username,
      repoName: data.repoName,
      lastSync: config.lastSync,
    };
  }),

  /**
   * Connect Supabase integration
   */
  connectSupabase: protectedProcedure
    .input(
      z.object({
        projectUrl: z.string().url(),
        apiKey: z.string(),
        projectId: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const config = {
        projectUrl: input.projectUrl,
        apiKey: input.apiKey,
        projectId: input.projectId,
        connectedAt: new Date().toISOString(),
      };

      await saveIntegrationConfig({
        userId: ctx.user.id,
        service: "supabase",
        isConnected: 1,
        configData: JSON.stringify(config),
      });

      return {
        success: true,
        message: `Connected to Supabase project: ${input.projectId}`,
      };
    }),

  /**
   * Get Supabase integration status
   */
  getSupabaseStatus: protectedProcedure.query(async ({ ctx }) => {
    const config = await getIntegrationConfig(ctx.user.id, "supabase");
    if (!config) {
      return { connected: false };
    }

    const data = JSON.parse(config.configData);
    return {
      connected: config.isConnected === 1,
      projectId: data.projectId,
      projectUrl: data.projectUrl,
      lastSync: config.lastSync,
    };
  }),

  /**
   * Connect Hugging Face integration
   */
  connectHuggingFace: protectedProcedure
    .input(
      z.object({
        apiKey: z.string(),
        defaultModel: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const config = {
        apiKey: input.apiKey,
        defaultModel: input.defaultModel || "meta-llama/Llama-2-7b-chat",
        connectedAt: new Date().toISOString(),
      };

      await saveIntegrationConfig({
        userId: ctx.user.id,
        service: "huggingface",
        isConnected: 1,
        configData: JSON.stringify(config),
      });

      return {
        success: true,
        message: `Connected to Hugging Face with model: ${config.defaultModel}`,
      };
    }),

  /**
   * Get Hugging Face integration status
   */
  getHuggingFaceStatus: protectedProcedure.query(async ({ ctx }) => {
    const config = await getIntegrationConfig(ctx.user.id, "huggingface");
    if (!config) {
      return { connected: false };
    }

    const data = JSON.parse(config.configData);
    return {
      connected: config.isConnected === 1,
      defaultModel: data.defaultModel,
      lastSync: config.lastSync,
    };
  }),

  /**
   * Get all integration statuses
   */
  getAllStatus: protectedProcedure.query(async ({ ctx }) => {
    const github = await getIntegrationConfig(ctx.user.id, "github");
    const supabase = await getIntegrationConfig(ctx.user.id, "supabase");
    const huggingface = await getIntegrationConfig(ctx.user.id, "huggingface");

    return {
      github: {
        connected: github?.isConnected === 1,
        data: github ? JSON.parse(github.configData) : null,
      },
      supabase: {
        connected: supabase?.isConnected === 1,
        data: supabase ? JSON.parse(supabase.configData) : null,
      },
      huggingface: {
        connected: huggingface?.isConnected === 1,
        data: huggingface ? JSON.parse(huggingface.configData) : null,
      },
    };
  }),
});
