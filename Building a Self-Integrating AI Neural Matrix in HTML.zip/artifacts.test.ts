import { describe, it, expect, vi, beforeEach } from "vitest";
import { artifactsRouter } from "./artifacts";
import * as db from "../db";
import * as storage from "../storage";

vi.mock("../db");
vi.mock("../storage");

describe("artifactsRouter", () => {
  let caller: ReturnType<typeof artifactsRouter.createCaller>;

  beforeEach(() => {
    vi.clearAllMocks();

    const mockContext = {
      user: {
        id: 1,
        openId: "test-user",
        email: "test@example.com",
        name: "Test User",
        loginMethod: "oauth",
        role: "user" as const,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
      },
      req: {} as any,
      res: {} as any,
    };

    caller = artifactsRouter.createCaller(mockContext);
  });

  it("should upload and store artifact", async () => {
    const mockStoragePut = vi.mocked(storage.storagePut);
    mockStoragePut.mockResolvedValue({
      url: "https://cdn.example.com/artifacts/1/test.pdf",
      key: "artifacts/1/test.pdf",
    });

    const mockCreateArtifact = vi.mocked(db.createArtifact);
    mockCreateArtifact.mockResolvedValue(undefined as any);

    const result = await caller.upload({
      filename: "test.pdf",
      fileType: "application/pdf",
      fileSize: 1024,
      fileContent: "base64encodedcontent",
    });

    expect(result.success).toBe(true);
    expect(result.fileUrl).toBe("https://cdn.example.com/artifacts/1/test.pdf");
    expect(mockStoragePut).toHaveBeenCalled();
    expect(mockCreateArtifact).toHaveBeenCalledWith(
      1,
      expect.objectContaining({
        filename: "test.pdf",
        fileType: "application/pdf",
        fileSize: 1024,
      })
    );
  });

  it("should list user artifacts", async () => {
    const mockArtifacts = [
      {
        id: 1,
        userId: 1,
        filename: "test.pdf",
        fileType: "application/pdf",
        fileSize: 1024,
        fileKey: "artifacts/1/test.pdf",
        fileUrl: "https://cdn.example.com/artifacts/1/test.pdf",
        extractedText: "Sample text",
        metadata: '{"tags": ["important"]}',
        uploadedAt: new Date(),
        updatedAt: new Date(),
      },
    ];

    vi.mocked(db.getArtifactsByUser).mockResolvedValue(mockArtifacts as any);

    const result = await caller.list();

    expect(result).toHaveLength(1);
    expect(result[0]).toMatchObject({
      filename: "test.pdf",
      fileType: "application/pdf",
      fileSize: 1024,
    });
  });

  it("should add knowledge entry", async () => {
    const mockAddKnowledge = vi.mocked(db.addKnowledgeEntry);
    mockAddKnowledge.mockResolvedValue(undefined as any);

    const result = await caller.addKnowledge({
      artifactId: 1,
      content: "function hello() {}",
      contentType: "code",
      tags: ["javascript", "function"],
      summary: "A simple hello function",
    });

    expect(result.success).toBe(true);
    expect(mockAddKnowledge).toHaveBeenCalledWith(
      expect.objectContaining({
        artifactId: 1,
        userId: 1,
        content: "function hello() {}",
        contentType: "code",
        tags: "javascript,function",
      })
    );
  });

  it("should retrieve knowledge from artifact", async () => {
    const mockKnowledge = [
      {
        id: 1,
        artifactId: 1,
        userId: 1,
        content: "function hello() {}",
        contentType: "code",
        embedding: null,
        tags: "javascript,function",
        summary: "A simple hello function",
        createdAt: new Date(),
      },
    ];

    vi.mocked(db.getKnowledgeByArtifact).mockResolvedValue(mockKnowledge as any);

    const result = await caller.getKnowledge({ artifactId: 1 });

    expect(result).toHaveLength(1);
    expect(result[0]).toMatchObject({
      content: "function hello() {}",
      contentType: "code",
      tags: ["javascript", "function"],
    });
  });
});
