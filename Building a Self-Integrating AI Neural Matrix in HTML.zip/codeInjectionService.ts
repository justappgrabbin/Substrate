/**
 * Code injection and self-assembly service for dynamic code execution and DOM modification
 * Handles code validation, sandboxing, and safe injection patterns
 */

export interface CodeInjectionPayload {
  code: string;
  language: string;
  targetSelector?: string;
  injectionType: 'append' | 'replace' | 'prepend' | 'execute';
  metadata?: Record<string, any>;
}

export interface InjectionResult {
  success: boolean;
  injectionId: string;
  timestamp: Date;
  code: string;
  error?: string;
}

/**
 * Validate code for safety before injection
 */
export function validateCode(code: string, language: string): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  // Check for dangerous patterns
  const dangerousPatterns = [
    /eval\s*\(/gi,
    /Function\s*\(/gi,
    /setTimeout\s*\(\s*['"`]/gi,
    /setInterval\s*\(\s*['"`]/gi,
    /document\.write/gi,
    /innerHTML\s*=/gi,
    /process\.exit/gi,
    /require\s*\(\s*['"`]child_process/gi,
    /exec\s*\(/gi,
    /spawn\s*\(/gi,
  ];

  for (const pattern of dangerousPatterns) {
    if (pattern.test(code)) {
      errors.push(`Dangerous pattern detected: ${pattern.source}`);
    }
  }

  // Language-specific validation
  if (language === 'javascript' || language === 'typescript') {
    // Check for unbalanced brackets
    const brackets = code.match(/[{}[\]()]/g) || [];
    let balance = 0;
    for (const char of brackets) {
      if (char === '{' || char === '[' || char === '(') balance++;
      else balance--;
      if (balance < 0) {
        errors.push('Unbalanced brackets detected');
        break;
      }
    }
    if (balance !== 0) {
      errors.push('Unbalanced brackets detected');
    }
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

/**
 * Wrap code in a safe execution context
 */
export function wrapCodeInSandbox(code: string, language: string): string {
  if (language === 'javascript' || language === 'typescript') {
    return `
(function() {
  'use strict';
  try {
    ${code}
  } catch (error) {
    console.error('[Neural Matrix] Code execution error:', error);
    throw error;
  }
})();
    `.trim();
  }

  return code;
}

/**
 * Generate DOM injection script
 */
export function generateDOMInjection(
  code: string,
  targetSelector?: string,
  injectionType: 'append' | 'replace' | 'prepend' | 'execute' = 'execute'
): string {
  if (injectionType === 'execute') {
    return wrapCodeInSandbox(code, 'javascript');
  }

  if (!targetSelector) {
    throw new Error('targetSelector required for DOM injection');
  }

  const escapedCode = code.replace(/`/g, '\\`').replace(/\$/g, '\\$');

  switch (injectionType) {
    case 'append':
      return `
const target = document.querySelector('${targetSelector}');
if (target) {
  const wrapper = document.createElement('div');
  wrapper.innerHTML = \`${escapedCode}\`;
  target.appendChild(wrapper);
}
      `.trim();

    case 'replace':
      return `
const target = document.querySelector('${targetSelector}');
if (target) {
  target.innerHTML = \`${escapedCode}\`;
}
      `.trim();

    case 'prepend':
      return `
const target = document.querySelector('${targetSelector}');
if (target) {
  const wrapper = document.createElement('div');
  wrapper.innerHTML = \`${escapedCode}\`;
  target.insertBefore(wrapper, target.firstChild);
}
      `.trim();

    default:
      return code;
  }
}

/**
 * Create an injection record with metadata
 */
export function createInjectionRecord(
  payload: CodeInjectionPayload
): InjectionResult {
  const validation = validateCode(payload.code, payload.language);

  if (!validation.valid) {
    return {
      success: false,
      injectionId: '',
      timestamp: new Date(),
      code: payload.code,
      error: `Code validation failed: ${validation.errors.join(', ')}`,
    };
  }

  const injectionId = `inj_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

  return {
    success: true,
    injectionId,
    timestamp: new Date(),
    code: payload.code,
  };
}

/**
 * Generate rollback code to undo an injection
 */
export function generateRollbackCode(injectionId: string, targetSelector?: string): string {
  return `
// Rollback for injection: ${injectionId}
if (window.__neuralMatrix && window.__neuralMatrix.injections) {
  const injection = window.__neuralMatrix.injections['${injectionId}'];
  if (injection && injection.previousState) {
    const target = document.querySelector('${targetSelector || 'body'}');
    if (target) {
      target.innerHTML = injection.previousState;
    }
  }
  delete window.__neuralMatrix.injections['${injectionId}'];
}
  `.trim();
}

/**
 * Analyze code to extract dependencies
 */
export function analyzeDependencies(code: string, language: string): string[] {
  const dependencies: Set<string> = new Set();

  if (language === 'javascript' || language === 'typescript') {
    // Extract imports
    const importMatches = code.match(/import\s+.*?\s+from\s+['"`]([^'"`]+)['"`]/g) || [];
    importMatches.forEach((match) => {
      const module = match.match(/['"`]([^'"`]+)['"`]/)?.[1];
      if (module) dependencies.add(module);
    });

    // Extract requires
    const requireMatches = code.match(/require\s*\(\s*['"`]([^'"`]+)['"`]\s*\)/g) || [];
    requireMatches.forEach((match) => {
      const module = match.match(/['"`]([^'"`]+)['"`]/)?.[1];
      if (module) dependencies.add(module);
    });
  } else if (language === 'python') {
    // Extract imports: "import numpy" or "from sklearn import metrics"
    const importMatches = code.match(/^import\s+([\w.]+)|^from\s+([\w.]+)\s+import/gm) || [];
    importMatches.forEach((match) => {
      let module = '';
      if (match.startsWith('import')) {
        module = match.replace(/^import\s+/, '').split(/[\s,]/)[0];
      } else {
        module = match.replace(/^from\s+/, '').split(/\s+import/)[0];
      }
      if (module) dependencies.add(module);
    });
  }

  return Array.from(dependencies);
}

/**
 * Generate modification history entry
 */
export function createModificationEntry(
  injectionId: string,
  code: string,
  language: string,
  status: 'success' | 'error' | 'pending',
  error?: string
): Record<string, any> {
  return {
    id: injectionId,
    timestamp: new Date().toISOString(),
    code,
    language,
    status,
    error,
    dependencies: analyzeDependencies(code, language),
    codeLength: code.length,
    lineCount: code.split('\n').length,
  };
}
