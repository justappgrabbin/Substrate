# Artificial Neural Matrix Architecture

## Overview
The Artificial Neural Matrix is a single-page HTML application designed to be self-evolving, capable of file ingestion (PDFs, code), learning, and code injection. It integrates with GitHub, Supabase, and Hugging Face.

## Core Components
1. **UI Layer**: A responsive, single-page interface built with HTML/CSS/JS. It includes an upload zone, a chat/interaction interface, a code editor/viewer, and a system status dashboard.
2. **Ingestion Engine**: Handles file uploads (PDF parsing via pdf.js, code analysis). Extracts text and structure to feed into the AI.
3. **AI Core (The Brain)**: Connects to Hugging Face Inference APIs for natural language processing, code generation, and reasoning. It analyzes ingested artifacts and determines how to integrate them.
4. **Integration Hooks**:
   - **GitHub**: For fetching repositories, committing code, and managing versions.
   - **Supabase**: For persistent storage of ingested data, vectors (if using pgvector), and user state.
   - **Hugging Face**: For executing models (LLMs, embedding models).
5. **Self-Assembly & Orchestration Layer**: A dynamic script injection system. When the AI generates new code (HTML/CSS/JS) based on ingested artifacts, this layer safely evaluates and injects it into the DOM, allowing the application to "grow" and modify itself.

## Workflow
1. User uploads a file (e.g., a PDF or a JS script).
2. The Ingestion Engine parses the file.
3. The AI Core analyzes the content, identifying gaps, making suggestions, and generating integration code.
4. The Self-Assembly Layer injects the new capabilities into the live application.
5. State and artifacts are synced to Supabase and/or GitHub.

## Future Path
While initially a single HTML file, the architecture is designed to be easily portable to a React Native/Expo app for mobile deployment later.
