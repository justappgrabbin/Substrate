import { useState, useRef, useEffect } from 'react';
import { Send, Loader2, Copy, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Streamdown } from 'streamdown';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  isStreaming?: boolean;
}

interface AIChatProps {
  onSendMessage?: (message: string) => Promise<string>;
  isLoading?: boolean;
}

export function AIChat({ onSendMessage, isLoading = false }: AIChatProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: '**Neural Matrix Online** 🧠\n\nI am ready to analyze your artifacts, generate code, and evolve. Upload files to begin.',
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState('');
  const [isWaiting, setIsWaiting] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async () => {
    if (!input.trim() || isWaiting || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsWaiting(true);

    try {
      let assistantContent = '';

      if (onSendMessage) {
        assistantContent = await onSendMessage(input);
      } else {
        // Mock response for demo
        assistantContent = `Analyzing: "${input}"\n\nI've processed your request. This is a placeholder response. Connect the LLM integration to enable real AI responses.`;
      }

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: assistantContent,
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (error) {
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: `**Error**: ${error instanceof Error ? error.message : 'Failed to process request'}`,
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsWaiting(false);
    }
  };

  const copyToClipboard = (id: string, content: string) => {
    navigator.clipboard.writeText(content);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="flex flex-col h-full bg-card border border-border rounded-sm neon-border">
      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex gap-3 animate-in fade-in slide-in-from-bottom-2 ${
              message.role === 'user' ? 'justify-end' : 'justify-start'
            }`}
          >
            <div
              className={`max-w-xs lg:max-w-md xl:max-w-lg px-4 py-3 rounded-sm border ${
                message.role === 'user'
                  ? 'bg-accent/10 border-accent text-foreground ml-auto'
                  : 'bg-muted/30 border-border text-foreground'
              }`}
            >
              {message.role === 'assistant' ? (
                <Streamdown className="text-sm">{message.content}</Streamdown>
              ) : (
                <p className="text-sm whitespace-pre-wrap break-words">{message.content}</p>
              )}

              {message.role === 'assistant' && (
                <button
                  onClick={() => copyToClipboard(message.id, message.content)}
                  className="mt-2 text-xs text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1"
                >
                  {copiedId === message.id ? (
                    <>
                      <Check className="w-3 h-3" />
                      Copied
                    </>
                  ) : (
                    <>
                      <Copy className="w-3 h-3" />
                      Copy
                    </>
                  )}
                </button>
              )}
            </div>
          </div>
        ))}

        {isWaiting && (
          <div className="flex gap-3 justify-start animate-in fade-in">
            <div className="bg-muted/30 border border-border rounded-sm px-4 py-3 flex items-center gap-2">
              <Loader2 className="w-4 h-4 animate-spin text-cyan-neon" />
              <span className="text-sm text-muted-foreground">Thinking...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="border-t border-border p-4 space-y-3">
        <div className="flex gap-2">
          <Textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && e.ctrlKey) {
                handleSendMessage();
              }
            }}
            placeholder="Ask me to analyze files, write code, or suggest improvements..."
            className="input-cyber resize-none"
            rows={3}
            disabled={isWaiting || isLoading}
          />
          <Button
            onClick={handleSendMessage}
            disabled={isWaiting || isLoading || !input.trim()}
            className="btn-cyber h-full"
          >
            {isWaiting ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Send className="w-4 h-4" />
            )}
          </Button>
        </div>
        <p className="text-xs text-muted-foreground">
          Ctrl+Enter to send • Upload files to provide context
        </p>
      </div>
    </div>
  );
}
