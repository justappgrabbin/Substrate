'use client';

import { useState } from 'react';
import { Menu, X } from 'lucide-react';
import { NeuralBackground } from '@/components/NeuralBackground';
import { FileUploadZone } from '@/components/FileUploadZone';
import { AIChat } from '@/components/AIChat';
import { SystemStatus } from '@/components/SystemStatus';
import { Button } from '@/components/ui/button';
import { useNeuralMatrix } from '@/hooks/useNeuralMatrix';
import { ArtifactLibrary } from '@/components/ArtifactLibrary';
import { ActivityLog } from '@/components/ActivityLog';
import { IntegrationModal } from '@/components/IntegrationModal';
import { Terminal } from '@/components/Terminal';
import { toast } from 'sonner';

export default function Home() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  const [activeIntegrationModal, setActiveIntegrationModal] = useState<'github' | 'supabase' | 'huggingface' | null>(null);
  const [activeTab, setActiveTab] = useState<'upload' | 'chat' | 'terminal' | 'artifacts' | 'activity'>('upload');
  const neuralMatrix = useNeuralMatrix();

  const handleFilesSelected = async (files: File[]) => {
    setUploadedFiles(files);
    try {
      await neuralMatrix.uploadArtifact(files);
      toast.success(`Uploaded ${files.length} artifact(s)`);
    } catch (error) {
      toast.error('Failed to upload artifacts');
      console.error(error);
    }
  };

  const handleChatMessage = async (message: string) => {
    try {
      const response = await neuralMatrix.chat(message);
      return response;
    } catch (error) {
      toast.error('Failed to process message');
      throw error;
    }
  };

  const handleConnectGitHub = async (config: Record<string, string>) => {
    await neuralMatrix.connectGitHub.mutateAsync({
      accessToken: config.accessToken,
      username: config.username,
      repoName: config.repoName,
    });
  };

  const handleConnectSupabase = async (config: Record<string, string>) => {
    await neuralMatrix.connectSupabase.mutateAsync({
      projectUrl: config.projectUrl,
      apiKey: config.apiKey,
      projectId: config.projectId,
    });
  };

  const handleConnectHuggingFace = async (config: Record<string, string>) => {
    await neuralMatrix.connectHuggingFace.mutateAsync({
      apiKey: config.apiKey,
      defaultModel: config.defaultModel,
    });
  };

  const artifacts = uploadedFiles.map((f, i) => ({
    id: i,
    filename: f.name,
    fileType: f.type,
    fileSize: f.size,
    fileUrl: '',
    uploadedAt: new Date(),
  }));

  return (
    <div className="min-h-screen bg-background text-foreground overflow-hidden">
      <NeuralBackground />

      <div className="relative z-10 flex flex-col lg:flex-row h-screen">
        {/* Mobile Header */}
        <div className="lg:hidden flex items-center justify-between bg-card border-b border-border px-4 py-3 sticky top-0 z-50">
          <h1 className="cyber-text text-lg cyber-glow">NEURAL MATRIX</h1>
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-2 hover:bg-accent rounded transition-colors"
            aria-label="Toggle menu"
          >
            {sidebarOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Sidebar - Desktop Fixed, Mobile Overlay */}
        <aside
          className={`${
            sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
          } fixed lg:relative top-0 left-0 w-72 lg:w-80 h-screen lg:h-auto bg-card border-r border-border transition-transform duration-300 overflow-y-auto z-40 lg:z-0 flex flex-col`}
        >
          <div className="p-4 border-b border-border hidden lg:block">
            <h1 className="cyber-text text-xl cyber-glow">NEURAL MATRIX</h1>
            <p className="text-xs text-muted-foreground mt-1">v2.0 • Self-Evolving AI</p>
          </div>

          {/* System Status */}
          <div className="p-4 border-b border-border">
            <SystemStatus />
          </div>

          {/* Integration Hooks */}
          <div className="p-4 border-b border-border space-y-2">
            <h3 className="text-xs font-mono text-cyan-400 mb-3">INTEGRATION HOOKS</h3>
            <Button
              onClick={() => {
                setActiveIntegrationModal('github');
                setSidebarOpen(false);
              }}
              className="w-full justify-start text-xs h-9"
              variant="outline"
            >
              ⚡ GitHub
            </Button>
            <Button
              onClick={() => {
                setActiveIntegrationModal('supabase');
                setSidebarOpen(false);
              }}
              className="w-full justify-start text-xs h-9"
              variant="outline"
            >
              ◼ Supabase
            </Button>
            <Button
              onClick={() => {
                setActiveIntegrationModal('huggingface');
                setSidebarOpen(false);
              }}
              className="w-full justify-start text-xs h-9"
              variant="outline"
            >
              🤗 Hugging Face
            </Button>
          </div>

          {/* Quick Actions */}
          <div className="p-4 border-b border-border space-y-2">
            <h3 className="text-xs font-mono text-magenta-400 mb-3">QUICK ACTIONS</h3>
            <Button 
              onClick={() => {
                setActiveTab('chat');
                setSidebarOpen(false);
                toast.info('Generate Code - Ask the AI to write code for your task');
              }}
              className="w-full text-xs h-9" 
              variant="default"
            >
              GENERATE CODE
            </Button>
            <Button 
              onClick={() => {
                setActiveTab('chat');
                setSidebarOpen(false);
                toast.info('Fill Gaps - Ask the AI to complete missing parts');
              }}
              className="w-full text-xs h-9" 
              variant="default"
            >
              FILL GAPS
            </Button>
            <Button 
              onClick={() => {
                setActiveTab('terminal');
                setSidebarOpen(false);
                toast.info('Self-Modify - Execute code to evolve the system');
              }}
              className="w-full text-xs h-9" 
              variant="default"
            >
              SELF-MODIFY
            </Button>
          </div>

          {/* Mobile Tab Navigation */}
          <div className="lg:hidden p-4 border-b border-border space-y-2">
            <h3 className="text-xs font-mono text-cyan-400 mb-3">SECTIONS</h3>
            {(['upload', 'chat', 'terminal', 'artifacts', 'activity'] as const).map((tab) => (
              <Button
                key={tab}
                onClick={() => {
                  setActiveTab(tab);
                  setSidebarOpen(false);
                }}
                className={`w-full justify-start text-xs h-9 ${activeTab === tab ? 'bg-cyan-500' : ''}`}
                variant={activeTab === tab ? 'default' : 'outline'}
              >
                {tab.toUpperCase()}
              </Button>
            ))}
          </div>

          {/* Settings & Docs */}
          <div className="mt-auto p-4 border-t border-border space-y-2">
            <Button 
              onClick={() => toast.info('Settings coming soon')}
              className="w-full text-xs h-9" 
              variant="outline"
            >
              ⚙ SETTINGS
            </Button>
            <Button 
              onClick={() => toast.info('Documentation: Use the AI chat to ask questions about how to use Neural Matrix')}
              className="w-full text-xs h-9" 
              variant="outline"
            >
              📖 DOCUMENTATION
            </Button>
          </div>
        </aside>

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto">
          {/* Desktop: Multi-column layout */}
          <div className="hidden lg:grid grid-cols-3 gap-4 p-6 h-full">
            {/* Left Column: Upload & Chat */}
            <div className="col-span-1 space-y-4 overflow-y-auto">
              <div className="bg-card border border-cyan-500/30 rounded-lg p-4">
                <h2 className="cyber-text text-sm cyber-glow mb-3">ARTIFACT INGESTION</h2>
                <FileUploadZone onFilesSelected={handleFilesSelected} />
              </div>
              <div className="bg-card border border-cyan-500/30 rounded-lg p-4 flex-1 overflow-hidden">
                <h2 className="cyber-text text-sm cyber-glow mb-3">AI NEURAL INTERFACE</h2>
                <AIChat onSendMessage={handleChatMessage} isLoading={false} />
              </div>
            </div>

            {/* Middle Column: Terminal & Activity */}
            <div className="col-span-1 space-y-4 overflow-y-auto">
              <div className="bg-card border border-magenta-500/30 rounded-lg p-4 flex-1 overflow-hidden">
                <h2 className="cyber-text text-sm cyber-glow mb-3">TERMINAL EXECUTOR</h2>
                <Terminal />
              </div>
              <div className="bg-card border border-cyan-500/30 rounded-lg p-4">
                <h2 className="cyber-text text-sm cyber-glow mb-3">ACTIVITY LOG</h2>
                <ActivityLog activities={[]} />
              </div>
            </div>

            {/* Right Column: Artifacts */}
            <div className="col-span-1 bg-card border border-cyan-500/30 rounded-lg p-4 overflow-hidden flex flex-col">
              <h2 className="cyber-text text-sm cyber-glow mb-3">ARTIFACT LIBRARY</h2>
              <ArtifactLibrary artifacts={artifacts} />
            </div>
          </div>

          {/* Mobile: Tab-based layout */}
          <div className="lg:hidden p-4 pb-20">
            {activeTab === 'upload' && (
              <div className="space-y-4">
                <div className="bg-card border border-cyan-500/30 rounded-lg p-4">
                  <h2 className="cyber-text text-sm cyber-glow mb-3">UPLOAD ARTIFACTS</h2>
                  <FileUploadZone onFilesSelected={handleFilesSelected} />
                </div>
              </div>
            )}

            {activeTab === 'chat' && (
              <div className="bg-card border border-cyan-500/30 rounded-lg p-4 h-[calc(100vh-180px)]">
                <h2 className="cyber-text text-sm cyber-glow mb-3">AI CHAT</h2>
                <AIChat onSendMessage={handleChatMessage} isLoading={false} />
              </div>
            )}

            {activeTab === 'terminal' && (
              <div className="bg-card border border-magenta-500/30 rounded-lg p-4 h-[calc(100vh-180px)]">
                <h2 className="cyber-text text-sm cyber-glow mb-3">TERMINAL</h2>
                <Terminal />
              </div>
            )}

            {activeTab === 'artifacts' && (
              <div className="bg-card border border-cyan-500/30 rounded-lg p-4">
                <h2 className="cyber-text text-sm cyber-glow mb-3">ARTIFACTS</h2>
                <ArtifactLibrary artifacts={artifacts} />
              </div>
            )}

            {activeTab === 'activity' && (
              <div className="bg-card border border-cyan-500/30 rounded-lg p-4">
                <h2 className="cyber-text text-sm cyber-glow mb-3">ACTIVITY</h2>
                <ActivityLog activities={[]} />
              </div>
            )}
          </div>
        </main>
      </div>

      {/* Integration Modals */}
      {activeIntegrationModal && (
        <IntegrationModal
          isOpen={true}
          service={activeIntegrationModal}
          onClose={() => setActiveIntegrationModal(null)}
          onConnect={
            activeIntegrationModal === 'github'
              ? handleConnectGitHub
              : activeIntegrationModal === 'supabase'
                ? handleConnectSupabase
                : handleConnectHuggingFace
          }
        />
      )}
    </div>
  );
}
