import { useState, useRef, useEffect } from 'react';
import { Play, Trash2, Copy, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';

export interface TerminalOutput {
  id: string;
  type: 'input' | 'output' | 'error' | 'info';
  content: string;
  timestamp: Date;
}

interface TerminalProps {
  onExecuteCode?: (code: string) => Promise<string>;
  isLoading?: boolean;
}

export function Terminal({ onExecuteCode, isLoading = false }: TerminalProps) {
  const [code, setCode] = useState('');
  const [output, setOutput] = useState<TerminalOutput[]>([]);
  const [copied, setCopied] = useState(false);
  const [isExecuting, setIsExecuting] = useState(false);
  const outputRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom when new output arrives
  useEffect(() => {
    if (outputRef.current) {
      outputRef.current.scrollTop = outputRef.current.scrollHeight;
    }
  }, [output]);

  const handleExecute = async () => {
    if (!code.trim()) {
      toast.error('Please enter code to execute');
      return;
    }

    // Add input to output
    const inputEntry: TerminalOutput = {
      id: `input_${Date.now()}`,
      type: 'input',
      content: code,
      timestamp: new Date(),
    };

    setOutput((prev) => [...prev, inputEntry]);
    setIsExecuting(true);

    try {
      if (onExecuteCode) {
        const result = await onExecuteCode(code);
        const outputEntry: TerminalOutput = {
          id: `output_${Date.now()}`,
          type: 'output',
          content: result,
          timestamp: new Date(),
        };
        setOutput((prev) => [...prev, outputEntry]);
      } else {
        // Fallback: try to execute JavaScript in browser
        try {
          const result = eval(code);
          const outputEntry: TerminalOutput = {
            id: `output_${Date.now()}`,
            type: 'output',
            content: String(result),
            timestamp: new Date(),
          };
          setOutput((prev) => [...prev, outputEntry]);
        } catch (error) {
          const errorEntry: TerminalOutput = {
            id: `error_${Date.now()}`,
            type: 'error',
            content: `Error: ${error instanceof Error ? error.message : String(error)}`,
            timestamp: new Date(),
          };
          setOutput((prev) => [...prev, errorEntry]);
        }
      }
    } catch (error) {
      const errorEntry: TerminalOutput = {
        id: `error_${Date.now()}`,
        type: 'error',
        content: `Execution failed: ${error instanceof Error ? error.message : String(error)}`,
        timestamp: new Date(),
      };
      setOutput((prev) => [...prev, errorEntry]);
    } finally {
      setIsExecuting(false);
      setCode('');
    }
  };

  const handleClear = () => {
    setOutput([]);
    setCode('');
  };

  const handleCopyOutput = async () => {
    const fullOutput = output.map((o) => o.content).join('\n');
    try {
      await navigator.clipboard.writeText(fullOutput);
      setCopied(true);
      toast.success('Output copied to clipboard');
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      toast.error('Failed to copy output');
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      handleExecute();
    }
  };

  return (
    <div className="flex flex-col h-full bg-card border border-border rounded-sm overflow-hidden neon-border">
      {/* Header */}
      <div className="border-b border-border p-3 flex items-center justify-between bg-muted/5">
        <h3 className="cyber-text text-sm">Neural Terminal</h3>
        <div className="flex gap-2">
          <Button
            size="sm"
            variant="outline"
            onClick={handleCopyOutput}
            disabled={output.length === 0}
            className="text-xs"
          >
            {copied ? (
              <>
                <Check className="w-3 h-3 mr-1" />
                Copied
              </>
            ) : (
              <>
                <Copy className="w-3 h-3 mr-1" />
                Copy
              </>
            )}
          </Button>
          <Button
            size="sm"
            variant="outline"
            onClick={handleClear}
            disabled={output.length === 0 && !code}
            className="text-xs"
          >
            <Trash2 className="w-3 h-3 mr-1" />
            Clear
          </Button>
        </div>
      </div>

      {/* Output Display */}
      <div
        ref={outputRef}
        className="flex-1 overflow-y-auto p-4 bg-muted/5 font-mono text-sm space-y-1 min-h-0"
      >
        {output.length === 0 ? (
          <div className="text-muted-foreground text-xs">
            <div>$ Neural Terminal Ready</div>
            <div className="mt-2">Enter code below and press Ctrl+Enter to execute</div>
            <div className="mt-4 text-muted-foreground/60">
              Tip: Use the AI chat to generate code, then paste it here!
            </div>
          </div>
        ) : (
          output.map((entry) => (
            <div
              key={entry.id}
              className={`whitespace-pre-wrap break-words ${
                entry.type === 'input'
                  ? 'text-cyan-neon'
                  : entry.type === 'error'
                    ? 'text-red-500'
                    : entry.type === 'info'
                      ? 'text-yellow-500'
                      : 'text-foreground/80'
              }`}
            >
              {entry.type === 'input' && <span className="text-muted-foreground">$ </span>}
              {entry.type === 'error' && <span className="text-red-500">✗ </span>}
              {entry.type === 'info' && <span className="text-yellow-500">ℹ </span>}
              {entry.content}
            </div>
          ))
        )}
      </div>

      {/* Code Input */}
      <div className="border-t border-border p-3 bg-muted/5 space-y-2">
        <textarea
          value={code}
          onChange={(e) => setCode(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Enter code here... (Ctrl+Enter to execute)"
          className="w-full h-20 p-2 bg-background border border-border rounded-sm font-mono text-sm resize-none focus:outline-none focus:border-cyan-neon/50 text-foreground placeholder-muted-foreground"
        />

        {/* Execute Button */}
        <Button
          onClick={handleExecute}
          disabled={isExecuting || isLoading || !code.trim()}
          className="w-full btn-cyber text-xs"
          size="sm"
        >
          <Play className="w-3 h-3 mr-2" />
          {isExecuting ? 'Executing...' : 'Execute (Ctrl+Enter)'}
        </Button>

        {/* Help Text */}
        <div className="text-xs text-muted-foreground/60 space-y-1">
          <div>💡 Tip: Ask the AI to generate code, then paste it here</div>
          <div>⌨️ Keyboard: Ctrl+Enter to execute</div>
        </div>
      </div>
    </div>
  );
}
