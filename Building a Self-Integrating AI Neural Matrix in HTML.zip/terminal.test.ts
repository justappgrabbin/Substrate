import { describe, it, expect } from 'vitest';
import { appRouter } from '../routers';
import type { TrpcContext } from '../_core/context';

type AuthenticatedUser = NonNullable<TrpcContext['user']>;

function createAuthContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: 'test-user',
    email: 'test@example.com',
    name: 'Test User',
    loginMethod: 'test',
    role: 'user',
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: 'https',
      headers: {},
    } as TrpcContext['req'],
    res: {
      clearCookie: () => {},
    } as TrpcContext['res'],
  };

  return ctx;
}

describe('Terminal Router', () => {
  describe('executeCode', () => {
    it('should execute simple JavaScript code', async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.terminal.executeCode({
        code: 'const x = 42; console.log(x * 2)',
        language: 'javascript',
      });

      expect(result.success).toBe(true);
      expect(result.output).toContain('84');
    });

    it('should handle console.log in JavaScript', async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.terminal.executeCode({
        code: 'console.log("Hello, Neural Matrix!")',
        language: 'javascript',
      });

      expect(result.success).toBe(true);
      expect(result.output.length).toBeGreaterThan(0);
      expect(result.output).toContain('Hello');
    });

    it('should handle array operations', async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.terminal.executeCode({
        code: 'console.log([1, 2, 3].map(x => x * 2))',
        language: 'javascript',
      });

      expect(result.success).toBe(true);
      expect(result.output.length).toBeGreaterThan(0);
    });

    it('should handle errors gracefully', async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.terminal.executeCode({
        code: 'throw new Error("Test error")',
        language: 'javascript',
      });

      expect(result.success).toBe(false);
      expect(result.output.toLowerCase()).toContain('error');
    });

    it('should return error for unsupported languages', async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.terminal.executeCode({
        code: 'print("hello")',
        language: 'python',
      });

      expect(result.success).toBe(false);
      expect(result.output.toLowerCase()).toContain('not yet implemented');
    });
  });

  describe('generateCode', () => {
    it('should generate code from description', async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.terminal.generateCode({
        description: 'Create a function that adds two numbers',
        language: 'javascript',
      });

      expect(result.success).toBe(true);
      expect(result.code).toBeDefined();
      expect(result.code.length).toBeGreaterThan(0);
    });

    it('should include language in response', async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.terminal.generateCode({
        description: 'Create a loop',
        language: 'javascript',
      });

      expect(result.language).toBe('javascript');
    });
  });

  describe('getSuggestions', () => {
    it('should return code suggestions', async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const suggestions = await caller.terminal.getSuggestions({});

      expect(Array.isArray(suggestions)).toBe(true);
      expect(suggestions.length).toBeGreaterThan(0);
    });

    it('should include required fields in suggestions', async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const suggestions = await caller.terminal.getSuggestions({});

      suggestions.forEach((suggestion) => {
        expect(suggestion).toHaveProperty('id');
        expect(suggestion).toHaveProperty('title');
        expect(suggestion).toHaveProperty('description');
        expect(suggestion).toHaveProperty('code');
        expect(suggestion).toHaveProperty('language');
      });
    });
  });
});
