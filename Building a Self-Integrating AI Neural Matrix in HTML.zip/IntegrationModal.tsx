import { useState } from 'react';
import { X, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';

interface IntegrationModalProps {
  isOpen: boolean;
  onClose: () => void;
  service: 'github' | 'supabase' | 'huggingface';
  onConnect: (config: Record<string, string>) => Promise<void>;
  isLoading?: boolean;
}

export function IntegrationModal({
  isOpen,
  onClose,
  service,
  onConnect,
  isLoading = false,
}: IntegrationModalProps) {
  const [formData, setFormData] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const getServiceConfig = () => {
    switch (service) {
      case 'github':
        return {
          title: 'Connect GitHub',
          description: 'Link your GitHub repository for code sync and version control',
          fields: [
            { name: 'accessToken', label: 'GitHub Access Token', type: 'password', required: true },
            { name: 'username', label: 'GitHub Username', type: 'text', required: true },
            { name: 'repoName', label: 'Repository Name', type: 'text', required: true },
          ],
          helpText: 'Create a personal access token at github.com/settings/tokens',
        };
      case 'supabase':
        return {
          title: 'Connect Supabase',
          description: 'Link your Supabase project for data persistence and vector storage',
          fields: [
            { name: 'projectUrl', label: 'Project URL', type: 'url', required: true },
            { name: 'apiKey', label: 'API Key', type: 'password', required: true },
            { name: 'projectId', label: 'Project ID', type: 'text', required: true },
          ],
          helpText: 'Find these in your Supabase project settings',
        };
      case 'huggingface':
        return {
          title: 'Connect Hugging Face',
          description: 'Link your Hugging Face account for model inference and embeddings',
          fields: [
            { name: 'apiKey', label: 'API Key', type: 'password', required: true },
            {
              name: 'defaultModel',
              label: 'Default Model (optional)',
              type: 'text',
              required: false,
              placeholder: 'meta-llama/Llama-2-7b-chat',
            },
          ],
          helpText: 'Get your API key from huggingface.co/settings/tokens',
        };
      default:
        return {
          title: 'Connect Service',
          description: '',
          fields: [],
          helpText: '',
        };
    }
  };

  const config = getServiceConfig();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validate required fields
    const missingFields = config.fields
      .filter((f) => f.required && !formData[f.name])
      .map((f) => f.label);

    if (missingFields.length > 0) {
      toast.error(`Missing required fields: ${missingFields.join(', ')}`);
      return;
    }

    setIsSubmitting(true);
    try {
      await onConnect(formData);
      toast.success(`Connected to ${service}!`);
      setFormData({});
      onClose();
    } catch (error) {
      toast.error(`Failed to connect to ${service}`);
      console.error(error);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
      <div className="bg-card border border-border rounded-sm max-w-md w-full p-6 neon-border">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <h2 className="cyber-text text-lg">{config.title}</h2>
          <button
            onClick={onClose}
            className="p-1 hover:bg-muted rounded transition-colors"
            disabled={isSubmitting}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Description */}
        <p className="text-sm text-muted-foreground mb-4">{config.description}</p>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {config.fields.map((field) => (
            <div key={field.name}>
              <label className="block text-sm font-medium mb-1">
                {field.label}
                {field.required && <span className="text-red-500">*</span>}
              </label>
              <Input
                type={field.type}
                placeholder={field.placeholder}
                value={formData[field.name] || ''}
                onChange={(e) =>
                  setFormData({ ...formData, [field.name]: e.target.value })
                }
                disabled={isSubmitting}
                className="input-cyber"
              />
            </div>
          ))}

          {/* Help text */}
          <div className="p-3 bg-muted/10 border border-border rounded-sm text-xs text-muted-foreground">
            {config.helpText}
          </div>

          {/* Actions */}
          <div className="flex gap-2 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={isSubmitting}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="flex-1 btn-cyber"
              disabled={isSubmitting || isLoading}
            >
              {isSubmitting || isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Connecting...
                </>
              ) : (
                'Connect'
              )}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
