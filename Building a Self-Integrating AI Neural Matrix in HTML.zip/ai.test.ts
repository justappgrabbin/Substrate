import { describe, it, expect, vi, beforeEach } from "vitest";
import { aiRouter } from "./ai";
import * as db from "../db";

vi.mock("../db");
vi.mock("../_core/llm");

describe("aiRouter", () => {
  let caller: ReturnType<typeof aiRouter.createCaller>;

  beforeEach(() => {
    vi.clearAllMocks();

    const mockContext = {
      user: {
        id: 1,
        openId: "test-user",
        email: "test@example.com",
        name: "Test User",
        loginMethod: "oauth",
        role: "user" as const,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
      },
      req: {} as any,
      res: {} as any,
    };

    caller = aiRouter.createCaller(mockContext);
  });

  it("should log AI activity on successful chat", async () => {
    const mockLogAIActivity = vi.spyOn(db, "logAIActivity").mockResolvedValue(undefined as any);

    // Mock the LLM response
    const { invokeLLM } = await import("../_core/llm");
    vi.mocked(invokeLLM).mockResolvedValue({
      choices: [
        {
          message: {
            content: "Test response",
          },
        },
      ],
    } as any);

    const result = await caller.chat({
      message: "Hello Neural Matrix",
      context: [],
    });

    expect(result.success).toBe(true);
    expect(result.response).toBe("Test response");
    expect(mockLogAIActivity).toHaveBeenCalledWith(
      expect.objectContaining({
        userId: 1,
        activityType: "chat",
        prompt: "Hello Neural Matrix",
        status: "success",
      })
    );
  });

  it("should handle LLM errors gracefully", async () => {
    const mockLogAIActivity = vi.spyOn(db, "logAIActivity").mockResolvedValue(undefined as any);

    const { invokeLLM } = await import("../_core/llm");
    vi.mocked(invokeLLM).mockRejectedValue(new Error("LLM Error"));

    await expect(
      caller.chat({
        message: "Hello",
        context: [],
      })
    ).rejects.toThrow();

    expect(mockLogAIActivity).toHaveBeenCalledWith(
      expect.objectContaining({
        status: "error",
        activityType: "chat",
      })
    );
  });

  it("should generate code with specified language", async () => {
    const mockLogAIActivity = vi.spyOn(db, "logAIActivity").mockResolvedValue(undefined as any);

    const { invokeLLM } = await import("../_core/llm");
    vi.mocked(invokeLLM).mockResolvedValue({
      choices: [
        {
          message: {
            content: "function hello() { return 'world'; }",
          },
        },
      ],
    } as any);

    const result = await caller.generateCode({
      requirement: "Write a hello function",
      language: "javascript",
      context: [],
    });

    expect(result.success).toBe(true);
    expect(result.language).toBe("javascript");
    expect(result.code).toContain("function hello");
    expect(mockLogAIActivity).toHaveBeenCalledWith(
      expect.objectContaining({
        activityType: "codegen",
        metadata: expect.stringContaining("javascript"),
      })
    );
  });

  it("should retrieve activity log", async () => {
    const mockActivities = [
      {
        id: 1,
        userId: 1,
        activityType: "chat",
        prompt: "Test prompt",
        response: "Test response",
        tokensUsed: 100,
        duration: 1000,
        status: "success",
        metadata: '{"model": "default"}',
        createdAt: new Date(),
      },
    ];

    vi.mocked(db.getAIActivityLog).mockResolvedValue(mockActivities as any);

    const result = await caller.getActivityLog({ limit: 50 });

    expect(result).toHaveLength(1);
    expect(result[0]).toMatchObject({
      type: "chat",
      prompt: "Test prompt",
      status: "success",
    });
  });
});
