import { describe, it, expect } from 'vitest';
import {
  validateCode,
  wrapCodeInSandbox,
  generateDOMInjection,
  createInjectionRecord,
  analyzeDependencies,
  createModificationEntry,
} from './codeInjectionService';

describe('Code Injection Service', () => {
  describe('validateCode', () => {
    it('should pass valid JavaScript code', () => {
      const code = 'const x = 42; console.log(x);';
      const result = validateCode(code, 'javascript');
      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    it('should reject code with eval', () => {
      const code = 'eval("malicious code")';
      const result = validateCode(code, 'javascript');
      expect(result.valid).toBe(false);
      expect(result.errors.length).toBeGreaterThan(0);
    });

    it('should reject code with Function constructor', () => {
      const code = 'new Function("return this")()';
      const result = validateCode(code, 'javascript');
      expect(result.valid).toBe(false);
    });

    it('should detect unbalanced brackets', () => {
      const code = 'const x = { a: 1';
      const result = validateCode(code, 'javascript');
      expect(result.valid).toBe(false);
    });

    it('should reject innerHTML assignment', () => {
      const code = 'document.body.innerHTML = "<h1>test</h1>"';
      const result = validateCode(code, 'javascript');
      expect(result.valid).toBe(false);
    });
  });

  describe('wrapCodeInSandbox', () => {
    it('should wrap JavaScript code in IIFE', () => {
      const code = 'console.log("hello")';
      const wrapped = wrapCodeInSandbox(code, 'javascript');
      expect(wrapped).toContain('(function()');
      expect(wrapped).toContain("'use strict'");
      expect(wrapped).toContain('try {');
      expect(wrapped).toContain(code);
    });

    it('should include error handling', () => {
      const code = 'throw new Error("test")';
      const wrapped = wrapCodeInSandbox(code, 'javascript');
      expect(wrapped).toContain('catch');
      expect(wrapped).toContain('console.error');
    });
  });

  describe('generateDOMInjection', () => {
    it('should generate execute injection', () => {
      const code = 'console.log("test")';
      const injection = generateDOMInjection(code, undefined, 'execute');
      expect(injection).toContain('(function()');
      expect(injection).toContain(code);
    });

    it('should generate append injection', () => {
      const code = '<div>Test</div>';
      const injection = generateDOMInjection(code, '#target', 'append');
      expect(injection).toContain('querySelector');
      expect(injection).toContain('#target');
      expect(injection).toContain('appendChild');
    });

    it('should generate replace injection', () => {
      const code = '<h1>New Content</h1>';
      const injection = generateDOMInjection(code, '#target', 'replace');
      expect(injection).toContain('innerHTML');
      expect(injection).toContain('#target');
    });

    it('should throw error if targetSelector missing for DOM injection', () => {
      const code = '<div>Test</div>';
      expect(() => generateDOMInjection(code, undefined, 'append')).toThrow();
    });
  });

  describe('createInjectionRecord', () => {
    it('should create successful injection record', () => {
      const payload = {
        code: 'console.log("test")',
        language: 'javascript',
        injectionType: 'execute' as const,
      };
      const result = createInjectionRecord(payload);
      expect(result.success).toBe(true);
      expect(result.injectionId).toMatch(/^inj_/);
      expect(result.code).toBe(payload.code);
    });

    it('should reject invalid code', () => {
      const payload = {
        code: 'eval("bad")',
        language: 'javascript',
        injectionType: 'execute' as const,
      };
      const result = createInjectionRecord(payload);
      expect(result.success).toBe(false);
      expect(result.error).toBeDefined();
    });
  });

  describe('analyzeDependencies', () => {
    it('should extract ES6 imports', () => {
      const code = "import React from 'react';\nimport { useState } from 'react';\nimport axios from 'axios';";
      const deps = analyzeDependencies(code, 'javascript');
      expect(deps).toContain('react');
      expect(deps).toContain('axios');
    });

    it('should extract CommonJS requires', () => {
      const code = "const express = require('express');\nconst fs = require('fs');";
      const deps = analyzeDependencies(code, 'javascript');
      expect(deps).toContain('express');
      expect(deps).toContain('fs');
    });

    it('should extract Python imports', () => {
      const code = 'import numpy as np\nfrom sklearn import metrics\nimport pandas';
      const deps = analyzeDependencies(code, 'python');
      expect(deps).toContain('numpy');
      expect(deps).toContain('sklearn');
      expect(deps).toContain('pandas');
    });

    it('should return empty array for code with no imports', () => {
      const code = 'const x = 42; console.log(x);';
      const deps = analyzeDependencies(code, 'javascript');
      expect(deps).toHaveLength(0);
    });
  });

  describe('createModificationEntry', () => {
    it('should create modification entry with metadata', () => {
      const code = 'console.log("test")';
      const entry = createModificationEntry('inj_123', code, 'javascript', 'success');
      expect(entry.id).toBe('inj_123');
      expect(entry.code).toBe(code);
      expect(entry.language).toBe('javascript');
      expect(entry.status).toBe('success');
      expect(entry.timestamp).toBeDefined();
      expect(entry.codeLength).toBe(code.length);
      expect(entry.lineCount).toBe(1);
    });

    it('should include error in entry', () => {
      const entry = createModificationEntry('inj_123', '', 'javascript', 'error', 'Test error');
      expect(entry.error).toBe('Test error');
      expect(entry.status).toBe('error');
    });

    it('should count multiple lines correctly', () => {
      const code = 'line1\nline2\nline3';
      const entry = createModificationEntry('inj_123', code, 'javascript', 'success');
      expect(entry.lineCount).toBe(3);
    });
  });
});
