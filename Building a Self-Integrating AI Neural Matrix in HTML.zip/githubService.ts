/**
 * GitHub integration service for OAuth, repo management, and file operations
 */

import axios from 'axios';

const GITHUB_API_BASE = 'https://api.github.com';
const GITHUB_OAUTH_AUTHORIZE = 'https://github.com/login/oauth/authorize';
const GITHUB_OAUTH_TOKEN = 'https://github.com/login/oauth/access_token';

export interface GitHubConfig {
  accessToken: string;
  username: string;
  repoName: string;
}

export interface GitHubFile {
  name: string;
  path: string;
  type: 'file' | 'dir';
  size?: number;
  url?: string;
  content?: string;
}

export class GitHubService {
  private accessToken: string;
  private username: string;
  private repoName: string;

  constructor(config: GitHubConfig) {
    this.accessToken = config.accessToken;
    this.username = config.username;
    this.repoName = config.repoName;
  }

  /**
   * Verify the access token is valid
   */
  async verifyToken(): Promise<boolean> {
    try {
      const response = await axios.get(`${GITHUB_API_BASE}/user`, {
        headers: {
          Authorization: `Bearer ${this.accessToken}`,
          'X-GitHub-Api-Version': '2022-11-28',
        },
      });
      return response.status === 200;
    } catch (error) {
      console.error('[GitHub] Token verification failed:', error);
      return false;
    }
  }

  /**
   * Get repository information
   */
  async getRepoInfo(): Promise<Record<string, any> | null> {
    try {
      const response = await axios.get(`${GITHUB_API_BASE}/repos/${this.username}/${this.repoName}`, {
        headers: {
          Authorization: `Bearer ${this.accessToken}`,
          'X-GitHub-Api-Version': '2022-11-28',
        },
      });
      return response.data;
    } catch (error) {
      console.error('[GitHub] Failed to get repo info:', error);
      return null;
    }
  }

  /**
   * List files in repository
   */
  async listFiles(path: string = ''): Promise<GitHubFile[]> {
    try {
      const response = await axios.get(
        `${GITHUB_API_BASE}/repos/${this.username}/${this.repoName}/contents/${path}`,
        {
          headers: {
            Authorization: `Bearer ${this.accessToken}`,
            'X-GitHub-Api-Version': '2022-11-28',
          },
        }
      );

      const items = Array.isArray(response.data) ? response.data : [response.data];

      return items.map((item: any) => ({
        name: item.name,
        path: item.path,
        type: item.type,
        size: item.size,
        url: item.html_url,
      }));
    } catch (error) {
      console.error('[GitHub] Failed to list files:', error);
      return [];
    }
  }

  /**
   * Get file content
   */
  async getFileContent(path: string): Promise<string | null> {
    try {
      const response = await axios.get(
        `${GITHUB_API_BASE}/repos/${this.username}/${this.repoName}/contents/${path}`,
        {
          headers: {
            Authorization: `Bearer ${this.accessToken}`,
            'X-GitHub-Api-Version': '2022-11-28',
            Accept: 'application/vnd.github.v3.raw',
          },
        }
      );
      return response.data;
    } catch (error) {
      console.error('[GitHub] Failed to get file content:', error);
      return null;
    }
  }

  /**
   * Create or update a file
   */
  async createOrUpdateFile(
    path: string,
    content: string,
    message: string,
    sha?: string
  ): Promise<boolean> {
    try {
      const payload: Record<string, any> = {
        message,
        content: Buffer.from(content).toString('base64'),
      };

      if (sha) {
        payload.sha = sha;
      }

      const response = await axios.put(
        `${GITHUB_API_BASE}/repos/${this.username}/${this.repoName}/contents/${path}`,
        payload,
        {
          headers: {
            Authorization: `Bearer ${this.accessToken}`,
            'X-GitHub-Api-Version': '2022-11-28',
          },
        }
      );

      return response.status === 201 || response.status === 200;
    } catch (error) {
      console.error('[GitHub] Failed to create/update file:', error);
      return false;
    }
  }

  /**
   * Get file SHA (needed for updates)
   */
  async getFileSha(path: string): Promise<string | null> {
    try {
      const response = await axios.get(
        `${GITHUB_API_BASE}/repos/${this.username}/${this.repoName}/contents/${path}`,
        {
          headers: {
            Authorization: `Bearer ${this.accessToken}`,
            'X-GitHub-Api-Version': '2022-11-28',
          },
        }
      );
      return response.data.sha;
    } catch (error) {
      console.error('[GitHub] Failed to get file SHA:', error);
      return null;
    }
  }

  /**
   * Create a commit
   */
  async createCommit(message: string, files: Array<{ path: string; content: string }>): Promise<boolean> {
    try {
      // Get current tree
      const repoInfo = await this.getRepoInfo();
      if (!repoInfo) return false;

      const treeItems = await Promise.all(
        files.map(async (file) => ({
          path: file.path,
          mode: '100644',
          type: 'blob',
          content: file.content,
        }))
      );

      const createTreeResponse = await axios.post(
        `${GITHUB_API_BASE}/repos/${this.username}/${this.repoName}/git/trees`,
        {
          tree: treeItems,
          base_tree: repoInfo.default_branch,
        },
        {
          headers: {
            Authorization: `Bearer ${this.accessToken}`,
            'X-GitHub-Api-Version': '2022-11-28',
          },
        }
      );

      const treeSha = createTreeResponse.data.sha;

      // Get current commit
      const refResponse = await axios.get(
        `${GITHUB_API_BASE}/repos/${this.username}/${this.repoName}/git/refs/heads/${repoInfo.default_branch}`,
        {
          headers: {
            Authorization: `Bearer ${this.accessToken}`,
            'X-GitHub-Api-Version': '2022-11-28',
          },
        }
      );

      const parentSha = refResponse.data.object.sha;

      // Create commit
      const commitResponse = await axios.post(
        `${GITHUB_API_BASE}/repos/${this.username}/${this.repoName}/git/commits`,
        {
          message,
          tree: treeSha,
          parents: [parentSha],
        },
        {
          headers: {
            Authorization: `Bearer ${this.accessToken}`,
            'X-GitHub-Api-Version': '2022-11-28',
          },
        }
      );

      const commitSha = commitResponse.data.sha;

      // Update ref
      await axios.patch(
        `${GITHUB_API_BASE}/repos/${this.username}/${this.repoName}/git/refs/heads/${repoInfo.default_branch}`,
        { sha: commitSha },
        {
          headers: {
            Authorization: `Bearer ${this.accessToken}`,
            'X-GitHub-Api-Version': '2022-11-28',
          },
        }
      );

      return true;
    } catch (error) {
      console.error('[GitHub] Failed to create commit:', error);
      return false;
    }
  }
}

/**
 * Generate GitHub OAuth authorization URL
 */
export function getGitHubOAuthUrl(clientId: string, redirectUri: string, state: string): string {
  const params = new URLSearchParams({
    client_id: clientId,
    redirect_uri: redirectUri,
    scope: 'repo,user',
    state,
  });
  return `${GITHUB_OAUTH_AUTHORIZE}?${params.toString()}`;
}

/**
 * Exchange OAuth code for access token
 */
export async function exchangeGitHubOAuthCode(
  clientId: string,
  clientSecret: string,
  code: string,
  redirectUri: string
): Promise<string | null> {
  try {
    const response = await axios.post(
      GITHUB_OAUTH_TOKEN,
      {
        client_id: clientId,
        client_secret: clientSecret,
        code,
        redirect_uri: redirectUri,
      },
      {
        headers: {
          Accept: 'application/json',
        },
      }
    );

    return response.data.access_token;
  } catch (error) {
    console.error('[GitHub OAuth] Failed to exchange code:', error);
    return null;
  }
}
