import { z } from 'zod';
import { protectedProcedure, router } from '../_core/trpc';
import { invokeLLM } from '../_core/llm';

export const terminalRouter = router({
  /**
   * Execute JavaScript code safely in a sandboxed context
   */
  executeCode: protectedProcedure
    .input(
      z.object({
        code: z.string(),
        language: z.enum(['javascript', 'python', 'bash']).default('javascript'),
      })
    )
    .mutation(async ({ ctx, input }) => {
      try {
        // For JavaScript, we can safely execute in Node.js context
        if (input.language === 'javascript') {
          // Create a safe execution context with output capture
          let capturedOutput = '';
          const sandbox = {
            console: {
              log: (...args: any[]) => {
                const output = args.map((a) => String(a)).join(' ');
                capturedOutput += output + '\n';
                return output;
              },
              error: (...args: any[]) => {
                const output = `Error: ${args.map((a) => String(a)).join(' ')}`;
                capturedOutput += output + '\n';
                return output;
              },
              warn: (...args: any[]) => {
                const output = `Warning: ${args.map((a) => String(a)).join(' ')}`;
                capturedOutput += output + '\n';
                return output;
              },
            },
            Math,
            Date,
            JSON,
            Array,
            Object,
            String,
            Number,
            Boolean,
          };

          // Execute the code
          const result = new Function(...Object.keys(sandbox), input.code)(
            ...Object.values(sandbox)
          );

          // Use captured console output if available, otherwise use return value
          const output = capturedOutput.trim() || String(result);

          return {
            success: true,
            output,
            language: 'javascript',
          };
        }

        // For Python and Bash, we'd need external execution (not implemented in this example)
        return {
          success: false,
          output: `${input.language} execution not yet implemented. Use JavaScript or ask the AI to generate JavaScript code.`,
          language: input.language,
        };
      } catch (error) {
        return {
          success: false,
          output: `Execution error: ${error instanceof Error ? error.message : String(error)}`,
          language: input.language,
        };
      }
    }),

  /**
   * Generate code using LLM based on natural language description
   */
  generateCode: protectedProcedure
    .input(
      z.object({
        description: z.string(),
        language: z.enum(['javascript', 'python', 'bash']).default('javascript'),
      })
    )
    .mutation(async ({ ctx, input }) => {
      try {
        const systemPrompt = `You are a code generation expert. Generate clean, safe, and efficient ${input.language} code based on the user's description.
        
Guidelines:
- Keep code concise and focused
- Add comments for clarity
- Use best practices for the language
- Avoid dangerous operations (file system access, network calls without context)
- Return ONLY the code, no markdown formatting or explanation`;

        const response = await invokeLLM({
          messages: [
            {
              role: 'system',
              content: systemPrompt,
            },
            {
              role: 'user',
              content: input.description,
            },
          ],
        });

        const code =
          response.choices[0]?.message?.content || 'Failed to generate code';

        return {
          success: true,
          code,
          language: input.language,
        };
      } catch (error) {
        return {
          success: false,
          code: `Error generating code: ${error instanceof Error ? error.message : String(error)}`,
          language: input.language,
        };
      }
    }),

  /**
   * Get code suggestions for common tasks
   */
  getSuggestions: protectedProcedure
    .input(z.object({ category: z.string().optional() }))
    .query(async () => {
      const suggestions = [
        {
          id: 'array-map',
          title: 'Transform Array',
          description: 'Map over array and transform elements',
          code: 'const arr = [1, 2, 3];\nconst doubled = arr.map(x => x * 2);\nconsole.log(doubled);',
          language: 'javascript',
        },
        {
          id: 'object-keys',
          title: 'Get Object Keys',
          description: 'Extract all keys from an object',
          code: 'const obj = { a: 1, b: 2, c: 3 };\nconst keys = Object.keys(obj);\nconsole.log(keys);',
          language: 'javascript',
        },
        {
          id: 'string-split',
          title: 'Split String',
          description: 'Split a string by delimiter',
          code: 'const text = "hello,world,javascript";\nconst parts = text.split(",");\nconsole.log(parts);',
          language: 'javascript',
        },
        {
          id: 'filter-array',
          title: 'Filter Array',
          description: 'Filter array elements by condition',
          code: 'const nums = [1, 2, 3, 4, 5];\nconst evens = nums.filter(n => n % 2 === 0);\nconsole.log(evens);',
          language: 'javascript',
        },
        {
          id: 'json-parse',
          title: 'Parse JSON',
          description: 'Parse JSON string to object',
          code: 'const json = \'{"name": "Neural Matrix", "version": "1.0"}\';\nconst obj = JSON.parse(json);\nconsole.log(obj.name);',
          language: 'javascript',
        },
        {
          id: 'math-calc',
          title: 'Math Calculation',
          description: 'Perform mathematical calculations',
          code: 'const a = 10, b = 20;\nconst sum = a + b;\nconst product = a * b;\nconsole.log(`Sum: ${sum}, Product: ${product}`);',
          language: 'javascript',
        },
      ];

      return suggestions;
    }),
});
