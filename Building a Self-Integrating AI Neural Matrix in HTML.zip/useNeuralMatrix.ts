import { useState, useCallback } from 'react';
import { trpc } from '@/lib/trpc';

export function useNeuralMatrix() {
  const [isProcessing, setIsProcessing] = useState(false);

  // Artifacts
  const uploadArtifact = trpc.artifacts.upload.useMutation();
  const listArtifacts = trpc.artifacts.list.useQuery();
  const addKnowledge = trpc.artifacts.addKnowledge.useMutation();
  const getKnowledge = trpc.artifacts.getKnowledge.useQuery;

  // AI Operations
  const chatWithAI = trpc.ai.chat.useMutation();
  const generateCode = trpc.ai.generateCode.useMutation();
  const getActivityLog = trpc.ai.getActivityLog.useQuery({});

  // Integrations
  const connectGitHub = trpc.integrations.connectGitHub.useMutation();
  const getGitHubStatus = trpc.integrations.getGitHubStatus.useQuery();
  const connectSupabase = trpc.integrations.connectSupabase.useMutation();
  const getSupabaseStatus = trpc.integrations.getSupabaseStatus.useQuery();
  const connectHuggingFace = trpc.integrations.connectHuggingFace.useMutation();
  const getHuggingFaceStatus = trpc.integrations.getHuggingFaceStatus.useQuery();
  const getAllIntegrationStatus = trpc.integrations.getAllStatus.useQuery();

  // Handle file upload
  const handleFileUpload = useCallback(
    async (files: File[]) => {
      setIsProcessing(true);
      try {
        for (const file of files) {
          const reader = new FileReader();
          reader.onload = async (e) => {
            const content = e.target?.result as string;
            const base64 = content.split(',')[1] || content;

            await uploadArtifact.mutateAsync({
              filename: file.name,
              fileType: file.type,
              fileSize: file.size,
              fileContent: base64,
            });
          };
          reader.readAsDataURL(file);
        }
      } finally {
        setIsProcessing(false);
      }
    },
    [uploadArtifact]
  );

  // Handle AI chat
  const handleChat = useCallback(
    async (message: string, contextArtifactIds?: number[]) => {
      try {
        const result = await chatWithAI.mutateAsync({
          message,
          context: contextArtifactIds,
        });
        return result.response;
      } catch (error) {
        throw error;
      }
    },
    [chatWithAI]
  );

  // Handle code generation
  const handleGenerateCode = useCallback(
    async (requirement: string, language: 'javascript' | 'typescript' | 'python' | 'java' | 'c', contextArtifactIds?: number[]) => {
      try {
        const result = await generateCode.mutateAsync({
          requirement,
          language,
          context: contextArtifactIds,
        });
        return result.code;
      } catch (error) {
        throw error;
      }
    },
    [generateCode]
  );

  return {
    // State
    isProcessing,

    // Artifacts
    uploadArtifact: handleFileUpload,
    artifacts: listArtifacts.data || [],
    artifactsLoading: listArtifacts.isLoading,
    addKnowledge,
    getKnowledge,

    // AI
    chat: handleChat,
    generateCode: handleGenerateCode,
    activityLog: getActivityLog.data || [],
    activityLogLoading: getActivityLog.isLoading,

    // Integrations
    connectGitHub,
    gitHubStatus: getGitHubStatus.data,
    connectSupabase,
    supabaseStatus: getSupabaseStatus.data,
    connectHuggingFace,
    huggingFaceStatus: getHuggingFaceStatus.data,
    allIntegrations: getAllIntegrationStatus.data,
  };
}
