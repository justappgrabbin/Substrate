import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { logAIActivity, getAIActivityLog, getKnowledgeByArtifact } from "../db";
import { invokeLLM } from "../_core/llm";

export const aiRouter = router({
  /**
   * Chat with the Neural Matrix AI
   */
  chat: protectedProcedure
    .input(
      z.object({
        message: z.string(),
        context: z.array(z.number()).optional(), // Artifact IDs for context
      })
    )
    .mutation(async ({ ctx, input }) => {
      const startTime = Date.now();

      try {
        // Gather context from artifacts if provided
        let contextText = "";
        if (input.context && input.context.length > 0) {
          for (const artifactId of input.context) {
            const knowledge = await getKnowledgeByArtifact(artifactId);
            contextText += knowledge.map((k) => k.content).join("\n\n");
          }
        }

        // Build system prompt
        const systemPrompt = `You are the Neural Matrix, a self-evolving AI system designed to analyze code, PDFs, and artifacts. 
You can:
- Analyze uploaded files and extract knowledge
- Generate code snippets and suggest improvements
- Identify gaps and fill them with implementations
- Orchestrate self-modifications and code injection
- Integrate with GitHub, Supabase, and Hugging Face

Be concise, technical, and focus on actionable insights.
${contextText ? `\n\nContext from uploaded artifacts:\n${contextText}` : ""}`;

        // Call LLM
        const response = await invokeLLM({
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: input.message },
          ],
        });

        const content = response.choices[0]?.message?.content;
        const aiResponse = typeof content === "string" ? content : "No response generated";
        const duration = Date.now() - startTime;

        // Log activity
        await logAIActivity({
          userId: ctx.user.id,
          activityType: "chat",
          prompt: input.message,
          response: aiResponse,
          duration,
          status: "success",
          metadata: JSON.stringify({
            model: "default",
            contextArtifacts: input.context?.length || 0,
          }),
        });

        return {
          success: true,
          response: aiResponse,
          duration,
        };
      } catch (error) {
        const duration = Date.now() - startTime;
        const errorMessage = error instanceof Error ? error.message : "Unknown error";

        await logAIActivity({
          userId: ctx.user.id,
          activityType: "chat",
          prompt: input.message,
          response: errorMessage,
          duration,
          status: "error",
          metadata: JSON.stringify({ error: true }),
        });

        throw error;
      }
    }),

  /**
   * Generate code based on requirements
   */
  generateCode: protectedProcedure
    .input(
      z.object({
        requirement: z.string(),
        language: z.enum(["javascript", "typescript", "python", "java", "c"]),
        context: z.array(z.number()).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const startTime = Date.now();

      try {
        let contextText = "";
        if (input.context && input.context.length > 0) {
          for (const artifactId of input.context) {
            const knowledge = await getKnowledgeByArtifact(artifactId);
            contextText += knowledge.map((k) => k.content).join("\n\n");
          }
        }

        const prompt = `Generate ${input.language} code for the following requirement:

${input.requirement}

${contextText ? `\n\nContext from artifacts:\n${contextText}` : ""}

Provide clean, production-ready code with comments.`;

        const response = await invokeLLM({
          messages: [
            {
              role: "system",
              content:
                "You are an expert code generator. Generate clean, well-commented, production-ready code.",
            },
            { role: "user", content: prompt },
          ],
        });

        const content = response.choices[0]?.message?.content;
        const generatedCode = typeof content === "string" ? content : "";
        const duration = Date.now() - startTime;

        await logAIActivity({
          userId: ctx.user.id,
          activityType: "codegen",
          prompt: input.requirement,
          response: generatedCode,
          duration,
          status: "success",
          metadata: JSON.stringify({
            language: input.language,
            contextArtifacts: input.context?.length || 0,
          }),
        });

        return {
          success: true,
          code: generatedCode,
          language: input.language,
          duration,
        };
      } catch (error) {
        const duration = Date.now() - startTime;
        await logAIActivity({
          userId: ctx.user.id,
          activityType: "codegen",
          prompt: input.requirement,
          response: error instanceof Error ? error.message : "Unknown error",
          duration,
          status: "error",
          metadata: JSON.stringify({ language: input.language }),
        });
        throw error;
      }
    }),

  /**
   * Get AI activity log
   */
  getActivityLog: protectedProcedure
    .input(z.object({ limit: z.number().default(50) }))
    .query(async ({ ctx, input }) => {
      const activities = await getAIActivityLog(ctx.user.id, input.limit);
      return activities.map((a) => ({
        id: a.id,
        type: a.activityType,
        prompt: a.prompt,
        status: a.status,
        duration: a.duration,
        createdAt: a.createdAt,
        metadata: a.metadata ? JSON.parse(a.metadata) : {},
      }));
    }),
});
