import { useState } from 'react';
import { Copy, Check, AlertCircle, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

interface CodePreviewProps {
  code: string;
  language?: string;
  title?: string;
  onInject?: () => Promise<void>;
  isLoading?: boolean;
}

export function CodePreview({
  code,
  language = 'javascript',
  title = 'Generated Code',
  onInject,
  isLoading = false,
}: CodePreviewProps) {
  const [copied, setCopied] = useState(false);
  const [isInjecting, setIsInjecting] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      toast.success('Code copied to clipboard');
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      toast.error('Failed to copy code');
    }
  };

  const handleInject = async () => {
    if (!onInject) return;

    setIsInjecting(true);
    try {
      await onInject();
      toast.success('Code injected successfully');
    } catch (error) {
      toast.error('Failed to inject code');
      console.error(error);
    } finally {
      setIsInjecting(false);
    }
  };

  // Simple syntax highlighting for display
  const highlightCode = (code: string, lang: string) => {
    // This is a simplified version - in production, use a library like highlight.js
    return code;
  };

  const lineCount = code.split('\n').length;

  return (
    <div className="flex flex-col h-full bg-card border border-border rounded-sm overflow-hidden neon-border">
      {/* Header */}
      <div className="border-b border-border p-3 flex items-center justify-between bg-muted/5">
        <div>
          <h3 className="cyber-text text-sm">{title}</h3>
          <p className="text-xs text-muted-foreground mt-1">
            {language} • {lineCount} lines
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            size="sm"
            variant="outline"
            onClick={handleCopy}
            className="text-xs"
          >
            {copied ? (
              <>
                <Check className="w-3 h-3 mr-1" />
                Copied
              </>
            ) : (
              <>
                <Copy className="w-3 h-3 mr-1" />
                Copy
              </>
            )}
          </Button>
          {onInject && (
            <Button
              size="sm"
              className="btn-cyber text-xs"
              onClick={handleInject}
              disabled={isInjecting || isLoading}
            >
              <Zap className="w-3 h-3 mr-1" />
              {isInjecting ? 'Injecting...' : 'Inject'}
            </Button>
          )}
        </div>
      </div>

      {/* Code Display */}
      <div className="flex-1 overflow-auto p-4 bg-muted/5 font-mono text-sm">
        <pre className="text-foreground/80 whitespace-pre-wrap break-words">
          <code>{highlightCode(code, language)}</code>
        </pre>
      </div>

      {/* Footer with warning */}
      <div className="border-t border-border p-3 bg-muted/5 flex items-start gap-2 text-xs text-muted-foreground">
        <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
        <div>
          <p className="font-medium">Review before injection</p>
          <p className="mt-1">
            Always review generated code for security and correctness before injecting into your
            system.
          </p>
        </div>
      </div>
    </div>
  );
}
