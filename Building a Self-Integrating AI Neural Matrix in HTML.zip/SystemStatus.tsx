import { useState, useEffect } from 'react';
import { Github, Database, Zap, Activity, AlertCircle, CheckCircle2 } from 'lucide-react';

interface Integration {
  name: string;
  icon: React.ReactNode;
  status: 'connected' | 'disconnected' | 'error';
  lastSync?: Date;
}

interface SystemStatusProps {
  artifactCount?: number;
  integrations?: Integration[];
  recentActivity?: string[];
}

export function SystemStatus({
  artifactCount = 0,
  integrations = [],
  recentActivity = [],
}: SystemStatusProps) {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const defaultIntegrations: Integration[] = [
    {
      name: 'GitHub',
      icon: <Github className="w-4 h-4" />,
      status: 'disconnected',
    },
    {
      name: 'Supabase',
      icon: <Database className="w-4 h-4" />,
      status: 'disconnected',
    },
    {
      name: 'Hugging Face',
      icon: <Zap className="w-4 h-4" />,
      status: 'disconnected',
    },
  ];

  const displayIntegrations = integrations.length > 0 ? integrations : defaultIntegrations;

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'connected':
        return 'text-acid-green';
      case 'error':
        return 'text-destructive';
      default:
        return 'text-muted-foreground';
    }
  };

  const getStatusBg = (status: string) => {
    switch (status) {
      case 'connected':
        return 'bg-acid-green/10';
      case 'error':
        return 'bg-destructive/10';
      default:
        return 'bg-muted/10';
    }
  };

  return (
    <div className="space-y-4">
      {/* System Time */}
      <div className="p-3 bg-card border border-border rounded-sm">
        <div className="flex items-center justify-between">
          <span className="text-xs text-muted-foreground cyber-text">System Time</span>
          <span className="text-sm font-mono text-cyan-neon pulse-neon">
            {time.toLocaleTimeString()}
          </span>
        </div>
      </div>

      {/* Artifact Count */}
      <div className="p-3 bg-card border border-border rounded-sm">
        <div className="flex items-center justify-between">
          <span className="text-xs text-muted-foreground cyber-text">Artifacts Ingested</span>
          <span className="text-sm font-mono text-magenta-neon">{artifactCount}</span>
        </div>
      </div>

      {/* Integrations Status */}
      <div className="space-y-2">
        <h4 className="cyber-text text-xs text-muted-foreground px-1">Integrations</h4>
        <div className="space-y-1">
          {displayIntegrations.map((integration) => (
            <div
              key={integration.name}
              className={`p-2 rounded-sm border border-border flex items-center justify-between transition-all ${getStatusBg(
                integration.status
              )}`}
            >
              <div className="flex items-center gap-2">
                <div className={getStatusColor(integration.status)}>
                  {integration.status === 'connected' ? (
                    <CheckCircle2 className="w-4 h-4" />
                  ) : integration.status === 'error' ? (
                    <AlertCircle className="w-4 h-4" />
                  ) : (
                    integration.icon
                  )}
                </div>
                <span className="text-xs font-mono">{integration.name}</span>
              </div>
              <span className={`text-xs cyber-text ${getStatusColor(integration.status)}`}>
                {integration.status.toUpperCase()}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Activity */}
      {recentActivity.length > 0 && (
        <div className="space-y-2">
          <h4 className="cyber-text text-xs text-muted-foreground px-1 flex items-center gap-1">
            <Activity className="w-3 h-3" />
            Recent Activity
          </h4>
          <div className="space-y-1 max-h-32 overflow-y-auto">
            {recentActivity.map((activity, idx) => (
              <div
                key={idx}
                className="p-2 bg-muted/10 border border-border rounded-sm text-xs text-muted-foreground hover:border-cyan-neon/50 transition-colors"
              >
                {activity}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Neural Status Indicator */}
      <div className="p-3 bg-card border border-border rounded-sm">
        <div className="flex items-center justify-between">
          <span className="text-xs text-muted-foreground cyber-text">Neural Status</span>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-acid-green rounded-full neural-pulse" />
            <span className="text-xs font-mono text-acid-green">ACTIVE</span>
          </div>
        </div>
      </div>
    </div>
  );
}
