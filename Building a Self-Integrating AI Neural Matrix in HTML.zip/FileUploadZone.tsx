import { useState, useRef } from 'react';
import { Upload, File, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface FileUploadZoneProps {
  onFilesSelected: (files: File[]) => void;
  isLoading?: boolean;
}

export function FileUploadZone({ onFilesSelected, isLoading = false }: FileUploadZoneProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [error, setError] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const acceptedFileTypes = [
    'application/pdf',
    'text/plain',
    'text/javascript',
    'text/typescript',
    'application/json',
    'text/x-python',
    'text/x-c',
    'text/x-java',
  ];

  const validateFiles = (files: File[]): boolean => {
    setError('');

    for (const file of files) {
      if (!acceptedFileTypes.includes(file.type) && !file.name.match(/\.(pdf|js|ts|py|json|txt|c|java|jsx|tsx)$/i)) {
        setError(`Invalid file type: ${file.name}. Accepted: PDF, JS, TS, Python, JSON, TXT`);
        return false;
      }

      if (file.size > 50 * 1024 * 1024) {
        setError(`File too large: ${file.name}. Max 50MB`);
        return false;
      }
    }

    return true;
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    const files = Array.from(e.dataTransfer.files);
    if (validateFiles(files)) {
      setSelectedFiles(files);
      onFilesSelected(files);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (validateFiles(files)) {
      setSelectedFiles(files);
      onFilesSelected(files);
    }
  };

  const handleClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="w-full">
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={handleClick}
        className={`relative border-2 border-dashed rounded-sm p-8 transition-all duration-300 cursor-pointer ${
          isDragging
            ? 'border-cyan-neon bg-cyan-neon/5 shadow-lg neon-border'
            : 'border-border hover:border-cyan-neon/50'
        }`}
      >
        <input
          ref={fileInputRef}
          type="file"
          multiple
          onChange={handleFileSelect}
          accept=".pdf,.js,.ts,.py,.json,.txt,.jsx,.tsx,.c,.java"
          className="hidden"
          disabled={isLoading}
        />

        <div className="flex flex-col items-center justify-center gap-4">
          <div className={`transition-all duration-300 ${isDragging ? 'scale-110' : 'scale-100'}`}>
            <Upload className={`w-12 h-12 ${isDragging ? 'text-cyan-neon' : 'text-muted-foreground'}`} />
          </div>

          <div className="text-center">
            <h3 className="cyber-text text-lg mb-2">
              {isDragging ? 'Drop Files Here' : 'Upload Artifacts'}
            </h3>
            <p className="text-sm text-muted-foreground">
              Drag and drop PDFs, code files, or JSON here
            </p>
            <p className="text-xs text-muted-foreground mt-2">
              Supported: PDF, JS, TS, Python, JSON, TXT (Max 50MB each)
            </p>
          </div>

          <Button
            onClick={handleClick}
            disabled={isLoading}
            className="btn-cyber"
          >
            {isLoading ? 'Processing...' : 'Select Files'}
          </Button>
        </div>
      </div>

      {error && (
        <div className="mt-4 p-3 bg-destructive/10 border border-destructive rounded-sm flex items-start gap-2">
          <AlertCircle className="w-5 h-5 text-destructive flex-shrink-0 mt-0.5" />
          <p className="text-sm text-destructive">{error}</p>
        </div>
      )}

      {selectedFiles.length > 0 && (
        <div className="mt-4 space-y-2">
          <h4 className="cyber-text text-sm">Selected Files ({selectedFiles.length})</h4>
          <div className="space-y-1 max-h-48 overflow-y-auto">
            {selectedFiles.map((file, idx) => (
              <div
                key={idx}
                className="flex items-center gap-2 p-2 bg-card border border-border rounded-sm hover:border-cyan-neon/50 transition-colors"
              >
                <File className="w-4 h-4 text-cyan-neon flex-shrink-0" />
                <span className="text-xs truncate flex-1">{file.name}</span>
                <span className="text-xs text-muted-foreground">
                  {(file.size / 1024).toFixed(1)}KB
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
