/**
 * Hugging Face integration service for model inference and embeddings
 */

import axios from 'axios';

const HF_API_BASE = 'https://api-inference.huggingface.co';

export interface HFConfig {
  apiKey: string;
  defaultModel?: string;
}

export interface HFInferenceResponse {
  generated_text?: string;
  score?: number;
  token?: { id: number; text: string; logprob: number; special: boolean };
  tokens?: Array<{ id: number; text: string; logprob: number; special: boolean }>;
  error?: string;
}

export class HuggingFaceService {
  private apiKey: string;
  private defaultModel: string;

  constructor(config: HFConfig) {
    this.apiKey = config.apiKey;
    this.defaultModel = config.defaultModel || 'meta-llama/Llama-2-7b-chat-hf';
  }

  /**
   * Verify the API key is valid
   */
  async verifyKey(): Promise<boolean> {
    try {
      const response = await axios.get(`${HF_API_BASE}/models`, {
        headers: {
          Authorization: `Bearer ${this.apiKey}`,
        },
        timeout: 5000,
      });
      return response.status === 200;
    } catch (error) {
      console.error('[Hugging Face] Key verification failed:', error);
      return false;
    }
  }

  /**
   * Generate text using a model
   */
  async generateText(
    prompt: string,
    options?: {
      model?: string;
      maxTokens?: number;
      temperature?: number;
      topP?: number;
    }
  ): Promise<string | null> {
    try {
      const model = options?.model || this.defaultModel;

      const response = await axios.post(
        `${HF_API_BASE}/models/${model}`,
        {
          inputs: prompt,
          parameters: {
            max_new_tokens: options?.maxTokens || 512,
            temperature: options?.temperature || 0.7,
            top_p: options?.topP || 0.9,
            do_sample: true,
          },
        },
        {
          headers: {
            Authorization: `Bearer ${this.apiKey}`,
          },
          timeout: 30000,
        }
      );

      if (Array.isArray(response.data) && response.data[0]?.generated_text) {
        return response.data[0].generated_text;
      }

      return null;
    } catch (error) {
      console.error('[Hugging Face] Text generation failed:', error);
      return null;
    }
  }

  /**
   * Generate embeddings for text
   */
  async generateEmbeddings(text: string, model?: string): Promise<number[] | null> {
    try {
      const embeddingModel = model || 'sentence-transformers/all-MiniLM-L6-v2';

      const response = await axios.post(
        `${HF_API_BASE}/models/${embeddingModel}`,
        {
          inputs: text,
        },
        {
          headers: {
            Authorization: `Bearer ${this.apiKey}`,
          },
          timeout: 15000,
        }
      );

      if (Array.isArray(response.data) && Array.isArray(response.data[0])) {
        return response.data[0];
      }

      return null;
    } catch (error) {
      console.error('[Hugging Face] Embedding generation failed:', error);
      return null;
    }
  }

  /**
   * Classify text
   */
  async classifyText(
    text: string,
    model?: string
  ): Promise<Array<{ label: string; score: number }> | null> {
    try {
      const classificationModel = model || 'distilbert-base-uncased-finetuned-sst-2-english';

      const response = await axios.post(
        `${HF_API_BASE}/models/${classificationModel}`,
        {
          inputs: text,
        },
        {
          headers: {
            Authorization: `Bearer ${this.apiKey}`,
          },
          timeout: 15000,
        }
      );

      if (Array.isArray(response.data) && Array.isArray(response.data[0])) {
        return response.data[0];
      }

      return null;
    } catch (error) {
      console.error('[Hugging Face] Classification failed:', error);
      return null;
    }
  }

  /**
   * Summarize text
   */
  async summarizeText(text: string, model?: string): Promise<string | null> {
    try {
      const summaryModel = model || 'facebook/bart-large-cnn';

      const response = await axios.post(
        `${HF_API_BASE}/models/${summaryModel}`,
        {
          inputs: text,
          parameters: {
            max_length: 150,
            min_length: 50,
          },
        },
        {
          headers: {
            Authorization: `Bearer ${this.apiKey}`,
          },
          timeout: 20000,
        }
      );

      if (Array.isArray(response.data) && response.data[0]?.summary_text) {
        return response.data[0].summary_text;
      }

      return null;
    } catch (error) {
      console.error('[Hugging Face] Summarization failed:', error);
      return null;
    }
  }

  /**
   * Code generation (specialized for code)
   */
  async generateCode(
    prompt: string,
    language?: string,
    model?: string
  ): Promise<string | null> {
    try {
      const codeModel = model || 'Salesforce/codegen-350M-mono';

      const enhancedPrompt = language
        ? `# Language: ${language}\n# Task: ${prompt}`
        : prompt;

      const response = await axios.post(
        `${HF_API_BASE}/models/${codeModel}`,
        {
          inputs: enhancedPrompt,
          parameters: {
            max_new_tokens: 256,
            temperature: 0.5,
            top_p: 0.95,
          },
        },
        {
          headers: {
            Authorization: `Bearer ${this.apiKey}`,
          },
          timeout: 30000,
        }
      );

      if (Array.isArray(response.data) && response.data[0]?.generated_text) {
        return response.data[0].generated_text;
      }

      return null;
    } catch (error) {
      console.error('[Hugging Face] Code generation failed:', error);
      return null;
    }
  }

  /**
   * Get model information
   */
  async getModelInfo(model: string): Promise<Record<string, any> | null> {
    try {
      const response = await axios.get(`${HF_API_BASE}/models/${model}`, {
        headers: {
          Authorization: `Bearer ${this.apiKey}`,
        },
        timeout: 5000,
      });

      return response.data;
    } catch (error) {
      console.error('[Hugging Face] Failed to get model info:', error);
      return null;
    }
  }

  /**
   * List available models (limited to user's models)
   */
  async listModels(): Promise<Array<{ id: string; name: string }> | null> {
    try {
      const response = await axios.get(`${HF_API_BASE}/models`, {
        headers: {
          Authorization: `Bearer ${this.apiKey}`,
        },
        timeout: 10000,
      });

      if (Array.isArray(response.data)) {
        return response.data.map((model: any) => ({
          id: model.id,
          name: model.id.split('/')[1] || model.id,
        }));
      }

      return null;
    } catch (error) {
      console.error('[Hugging Face] Failed to list models:', error);
      return null;
    }
  }
}
