/**
 * File parser utility for extracting content and metadata from uploaded artifacts
 */

export interface ParsedContent {
  text: string;
  language?: string;
  lines?: number;
  functions?: string[];
  imports?: string[];
  tags?: string[];
}

/**
 * Parse JavaScript/TypeScript code
 */
export function parseJavaScript(content: string): ParsedContent {
  const lines = content.split('\n');
  const imports = lines
    .filter((line) => line.match(/^import\s+|^require\s*\(/))
    .map((line) => line.trim());

  const functions = lines
    .filter((line) => line.match(/^(export\s+)?(async\s+)?function\s+|const\s+\w+\s*=\s*(async\s*)?\(/))
    .map((line) => line.trim().split('(')[0]);

  const tags = ['javascript'];
  if (content.includes('async')) tags.push('async');
  if (content.includes('class ')) tags.push('oop');
  if (content.includes('=>')) tags.push('arrow-functions');

  return {
    text: content,
    language: 'javascript',
    lines: lines.length,
    functions,
    imports,
    tags,
  };
}

/**
 * Parse Python code
 */
export function parsePython(content: string): ParsedContent {
  const lines = content.split('\n');
  const imports = lines
    .filter((line) => line.match(/^import\s+|^from\s+\w+\s+import/))
    .map((line) => line.trim());

  const functions = lines
    .filter((line) => line.match(/^def\s+\w+\s*\(/))
    .map((line) => line.trim().split('(')[0].replace('def ', ''));

  const tags = ['python'];
  if (content.includes('async def')) tags.push('async');
  if (content.includes('class ')) tags.push('oop');
  if (content.includes('def __')) tags.push('dunder-methods');

  return {
    text: content,
    language: 'python',
    lines: lines.length,
    functions,
    imports,
    tags,
  };
}

/**
 * Parse JSON content
 */
export function parseJSON(content: string): ParsedContent {
  try {
    const parsed = JSON.parse(content);
    const keys = Object.keys(parsed);
    const tags = ['json', `keys:${keys.length}`];

    if (Array.isArray(parsed)) {
      tags.push(`array:${parsed.length}`);
    }

    return {
      text: content,
      language: 'json',
      tags,
    };
  } catch (error) {
    return {
      text: content,
      language: 'json',
      tags: ['json', 'invalid'],
    };
  }
}

/**
 * Parse plain text (extract key phrases)
 */
export function parseText(content: string): ParsedContent {
  const lines = content.split('\n').filter((line) => line.trim().length > 0);
  const words = content.split(/\s+/).length;

  // Extract potential keywords (capitalized words or common technical terms)
  const keywords = content.match(/\b[A-Z][a-z]+\b/g) || [];
  const uniqueKeywords = Array.from(new Set(keywords)).slice(0, 10);

  return {
    text: content,
    language: 'text',
    lines: lines.length,
    tags: ['text', `words:${words}`, ...uniqueKeywords],
  };
}

/**
 * Detect file type and parse accordingly
 */
export function parseFile(filename: string, content: string): ParsedContent {
  const ext = filename.split('.').pop()?.toLowerCase();

  switch (ext) {
    case 'js':
    case 'jsx':
    case 'mjs':
      return parseJavaScript(content);
    case 'ts':
    case 'tsx':
      return { ...parseJavaScript(content), language: 'typescript', tags: ['typescript'] };
    case 'py':
      return parsePython(content);
    case 'json':
      return parseJSON(content);
    case 'txt':
    case 'md':
      return parseText(content);
    default:
      return parseText(content);
  }
}

/**
 * Extract summary from content
 */
export function generateSummary(content: string, maxLength: number = 200): string {
  const lines = content.split('\n').filter((line) => line.trim().length > 0);
  const firstNonEmptyLines = lines.slice(0, 5).join(' ');

  if (firstNonEmptyLines.length > maxLength) {
    return firstNonEmptyLines.substring(0, maxLength) + '...';
  }

  return firstNonEmptyLines;
}
