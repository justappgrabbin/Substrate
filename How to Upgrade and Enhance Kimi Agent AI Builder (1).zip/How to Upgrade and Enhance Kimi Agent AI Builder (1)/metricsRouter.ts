/**
 * Metrics Router: Real-time metrics procedures for dashboard
 */

import { protectedProcedure, router } from "../_core/trpc";
import { GNNAnalyzer } from "../gnn/core";
import { getDb } from "../db";
import { gnnSessions } from "../../drizzle/schema";
import { eq, desc } from "drizzle-orm";

export const metricsRouter = router({
  /**
   * Get current metrics and training history
   */
  getCurrent: protectedProcedure.query(async ({ ctx }) => {
    try {
      const db = await getDb();
      const gnn = new GNNAnalyzer();
      const history = gnn.getTrainingHistory();

      if (!db || history.length === 0) {
        return {
          lastSession: null,
          totalSessions: history.length,
          averageLoss: 0,
          averageConfidence: 0,
          history: [],
        };
      }

      // Get last session from database
      const lastSession = await db
        .select()
        .from(gnnSessions)
        .where(eq(gnnSessions.userId, ctx.user.id))
        .orderBy(desc(gnnSessions.createdAt))
        .limit(1);

      // Calculate averages
      const avgLoss = history.reduce((sum: number, h: any) => sum + h.loss, 0) / history.length;
      const avgConfidence =
        history.reduce((sum: number, h: any) => sum + h.confidence, 0) / history.length;

      // Parse metrics from last session
      let lastSessionMetrics = null;
      if (lastSession[0]) {
        try {
          const metricsData = typeof lastSession[0].metrics === "string"
            ? JSON.parse(lastSession[0].metrics)
            : lastSession[0].metrics;
          lastSessionMetrics = {
            loss: metricsData?.lastLoss || 0,
            confidence: metricsData?.lastConfidence || 0,
            nodeCount: metricsData?.nodeCount || 0,
            timestamp: lastSession[0].createdAt?.getTime() || Date.now(),
          };
        } catch (e) {
          console.error("Error parsing metrics:", e);
        }
      }

      return {
        lastSession: lastSessionMetrics,
        totalSessions: history.length,
        averageLoss: avgLoss,
        averageConfidence: avgConfidence,
        history: history.map((h: any) => ({
          loss: h.loss,
          confidence: h.confidence,
          nodeCount: h.nodeCount,
          edgeCount: h.edgeCount,
          timestamp: h.timestamp,
        })),
      };
    } catch (error) {
      console.error("Error getting metrics:", error);
      return {
        lastSession: null,
        totalSessions: 0,
        averageLoss: 0,
        averageConfidence: 0,
        history: [],
      };
    }
  }),

  /**
   * Get metrics history for a specific time range
   */
  getHistory: protectedProcedure
    .input((val: unknown) => {
      const input = val as { limit?: number; offset?: number };
      return {
        limit: Math.min(input.limit || 50, 500),
        offset: input.offset || 0,
      };
    })
    .query(async ({ ctx, input }) => {
      try {
        const db = await getDb();
        if (!db) return { sessions: [], total: 0 };

        const sessions = await db
          .select()
          .from(gnnSessions)
          .where(eq(gnnSessions.userId, ctx.user.id))
          .orderBy(desc(gnnSessions.createdAt))
          .limit(input.limit)
          .offset(input.offset);

        return {
          sessions: sessions.map((s: any) => {
            const metricsData = typeof s.metrics === "string"
              ? JSON.parse(s.metrics)
              : s.metrics;
            return {
              id: s.id,
              loss: metricsData?.lastLoss || 0,
              confidence: metricsData?.lastConfidence || 0,
              nodeCount: metricsData?.nodeCount || 0,
              timestamp: s.createdAt?.getTime() || Date.now(),
              sessionId: s.sessionId,
            };
          }),
          total: sessions.length,
        };
      } catch (error) {
        console.error("Error getting history:", error);
        return { sessions: [], total: 0 };
      }
    }),

  /**
   * Get aggregated statistics
   */
  getStatistics: protectedProcedure.query(async ({ ctx }) => {
    try {
      const db = await getDb();
      const gnn = new GNNAnalyzer();
      const history = gnn.getTrainingHistory();

      if (history.length === 0) {
        return {
          totalSessions: 0,
          minLoss: 0,
          maxLoss: 0,
          avgLoss: 0,
          minConfidence: 0,
          maxConfidence: 0,
          avgConfidence: 0,
          improvementRate: 0,
          totalNodesAnalyzed: 0,
          totalEdgesAnalyzed: 0,
        };
      }

      const losses = history.map((h: any) => h.loss);
      const confidences = history.map((h: any) => h.confidence);

      const minLoss = Math.min(...losses);
      const maxLoss = Math.max(...losses);
      const avgLoss = losses.reduce((a: number, b: number) => a + b, 0) / losses.length;

      const minConfidence = Math.min(...confidences);
      const maxConfidence = Math.max(...confidences);
      const avgConfidence =
        confidences.reduce((a: number, b: number) => a + b, 0) / confidences.length;

      const firstLoss = history[history.length - 1].loss;
      const lastLoss = history[0].loss;
      const improvementRate =
        firstLoss > 0 ? ((firstLoss - lastLoss) / firstLoss) * 100 : 0;

      const totalNodes = history.reduce((sum: number, h: any) => sum + h.nodeCount, 0);
      const totalEdges = history.reduce((sum: number, h: any) => sum + h.edgeCount, 0);

      return {
        totalSessions: history.length,
        minLoss,
        maxLoss,
        avgLoss,
        minConfidence,
        maxConfidence,
        avgConfidence,
        improvementRate,
        totalNodesAnalyzed: totalNodes,
        totalEdgesAnalyzed: totalEdges,
      };
    } catch (error) {
      console.error("Error getting statistics:", error);
      return {
        totalSessions: 0,
        minLoss: 0,
        maxLoss: 0,
        avgLoss: 0,
        minConfidence: 0,
        maxConfidence: 0,
        avgConfidence: 0,
        improvementRate: 0,
        totalNodesAnalyzed: 0,
        totalEdgesAnalyzed: 0,
      };
    }
  }),

  /**
   * Export metrics as JSON
   */
  exportMetrics: protectedProcedure.query(async ({ ctx }) => {
    try {
      const db = await getDb();
      const gnn = new GNNAnalyzer();
      const history = gnn.getTrainingHistory();

      if (!db) {
        return {
          success: false,
          data: null,
          error: "Database not available",
        };
      }

      const sessions = await db
        .select()
        .from(gnnSessions)
        .where(eq(gnnSessions.userId, ctx.user.id))
        .orderBy(desc(gnnSessions.createdAt));

      const exportData = {
        exportedAt: new Date().toISOString(),
        userId: ctx.user.id,
        totalSessions: history.length,
        metrics: history,
        sessions: sessions.map((s: any) => ({
          id: s.id,
          sessionId: s.sessionId,
          metrics: s.metrics,
          createdAt: s.createdAt,
        })),
      };

      return {
        success: true,
        data: exportData,
        error: null,
      };
    } catch (error) {
      console.error("Error exporting metrics:", error);
      return {
        success: false,
        data: null,
        error: error instanceof Error ? error.message : "Unknown error",
      };
    }
  }),
});
