/**
 * EnhancedDiffViewer: Professional diff viewer with syntax highlighting
 */

import { useMemo, useRef, useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Plus, Minus, Copy, ChevronDown, ChevronUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import Editor from "@monaco-editor/react";

interface DiffLine {
  type: "add" | "remove" | "context";
  content: string;
  lineNumber?: number;
}

interface EnhancedDiffViewerProps {
  before: string;
  after: string;
  language?: string;
  title?: string;
  onCopy?: () => void;
  compact?: boolean;
}

function generateDiff(before: string, after: string): DiffLine[] {
  const beforeLines = before.split("\n");
  const afterLines = after.split("\n");
  const diff: DiffLine[] = [];

  const maxLength = Math.max(beforeLines.length, afterLines.length);

  for (let i = 0; i < maxLength; i++) {
    const beforeLine = beforeLines[i];
    const afterLine = afterLines[i];

    if (beforeLine === afterLine) {
      diff.push({
        type: "context",
        content: beforeLine || "",
        lineNumber: i + 1,
      });
    } else {
      if (beforeLine !== undefined) {
        diff.push({
          type: "remove",
          content: beforeLine,
          lineNumber: i + 1,
        });
      }
      if (afterLine !== undefined) {
        diff.push({
          type: "add",
          content: afterLine,
          lineNumber: i + 1,
        });
      }
    }
  }

  return diff;
}

export function EnhancedDiffViewer({
  before,
  after,
  language = "typescript",
  title,
  onCopy,
  compact = false,
}: EnhancedDiffViewerProps) {
  const diff = useMemo(() => generateDiff(before, after), [before, after]);
  const [expanded, setExpanded] = useState(!compact);

  const stats = useMemo(() => {
    const added = diff.filter((d) => d.type === "add").length;
    const removed = diff.filter((d) => d.type === "remove").length;
    return { added, removed };
  }, [diff]);

  const handleCopy = () => {
    navigator.clipboard.writeText(after);
    toast.success("Code copied to clipboard");
    onCopy?.();
  };

  return (
    <Card className="bg-slate-900/50 border-slate-800 overflow-hidden">
      <CardContent className="p-0">
        {/* Header */}
        {title && (
          <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between bg-slate-950/50">
            <div className="flex items-center gap-3 flex-1">
              <h3 className="font-semibold text-slate-200">{title}</h3>
              <div className="flex items-center gap-2">
                <Badge
                  variant="outline"
                  className="bg-emerald-500/10 text-emerald-400 border-emerald-500/30"
                >
                  <Plus className="w-3 h-3 mr-1" />
                  {stats.added}
                </Badge>
                <Badge
                  variant="outline"
                  className="bg-red-500/10 text-red-400 border-red-500/30"
                >
                  <Minus className="w-3 h-3 mr-1" />
                  {stats.removed}
                </Badge>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button
                size="sm"
                variant="ghost"
                onClick={handleCopy}
                className="text-slate-400 hover:text-slate-200"
              >
                <Copy className="w-4 h-4" />
              </Button>
              {compact && (
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setExpanded(!expanded)}
                  className="text-slate-400 hover:text-slate-200"
                >
                  {expanded ? (
                    <ChevronUp className="w-4 h-4" />
                  ) : (
                    <ChevronDown className="w-4 h-4" />
                  )}
                </Button>
              )}
            </div>
          </div>
        )}

        {/* Diff Content */}
        {expanded && (
          <div className="overflow-x-auto max-h-96">
            <pre className="p-4 text-xs font-mono text-slate-300 bg-slate-950/50">
              {diff.map((line, idx) => (
                <div
                  key={idx}
                  className={`whitespace-pre-wrap break-words ${
                    line.type === "add"
                      ? "bg-emerald-500/10 text-emerald-300"
                      : line.type === "remove"
                        ? "bg-red-500/10 text-red-300"
                        : "text-slate-400"
                  }`}
                >
                  <span className="inline-block w-8 text-right pr-2 text-slate-500 select-none">
                    {line.type === "add" ? "+" : line.type === "remove" ? "-" : " "}
                  </span>
                  <span className="inline-block w-12 text-right pr-3 text-slate-600 select-none">
                    {line.lineNumber || ""}
                  </span>
                  {line.content}
                </div>
              ))}
            </pre>
          </div>
        )}

        {compact && !expanded && (
          <div className="p-4 text-sm text-slate-400">
            {stats.added} additions, {stats.removed} deletions
          </div>
        )}
      </CardContent>
    </Card>
  );
}

/**
 * Side-by-side diff viewer with Monaco editors
 */
export function MonacoDiffViewer({
  before,
  after,
  language = "typescript",
  title,
  readOnly = true,
}: Omit<EnhancedDiffViewerProps, "onCopy" | "compact"> & { readOnly?: boolean }) {
  return (
    <Card className="bg-slate-900/50 border-slate-800 overflow-hidden">
      <CardContent className="p-4 space-y-4">
        {title && <h4 className="text-sm font-semibold text-slate-200">{title}</h4>}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Before */}
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Badge
                variant="outline"
                className="bg-red-500/10 text-red-400 border-red-500/30"
              >
                Before
              </Badge>
            </div>
            <div className="border border-slate-700 rounded-lg overflow-hidden bg-slate-950">
              <Editor
                height="300px"
                language={language}
                value={before}
                theme="vs-dark"
                options={{
                  readOnly,
                  minimap: { enabled: false },
                  scrollBeyondLastLine: false,
                  fontSize: 12,
                  fontFamily: "Fira Code, monospace",
                }}
              />
            </div>
          </div>

          {/* After */}
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Badge
                variant="outline"
                className="bg-emerald-500/10 text-emerald-400 border-emerald-500/30"
              >
                After
              </Badge>
            </div>
            <div className="border border-slate-700 rounded-lg overflow-hidden bg-slate-950">
              <Editor
                height="300px"
                language={language}
                value={after}
                theme="vs-dark"
                options={{
                  readOnly,
                  minimap: { enabled: false },
                  scrollBeyondLastLine: false,
                  fontSize: 12,
                  fontFamily: "Fira Code, monospace",
                }}
              />
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
