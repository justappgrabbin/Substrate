/**
 * Proposal Executor: Handles execution, validation, and rollback of code proposals
 */

import { getDb } from "../db";
import { selfBuildProposals } from "../../drizzle/schema";
import { eq } from "drizzle-orm";

export interface ExecutionResult {
  success: boolean;
  proposalId: string;
  executedCode: string;
  timestamp: Date;
  validationPassed: boolean;
  errors?: string[];
  rollbackAvailable: boolean;
}

export interface ProposalExecutionHistory {
  proposalId: string;
  executedAt: Date;
  executedBy: number;
  beforeState: string;
  afterState: string;
  validationPassed: boolean;
  errors?: string[];
}

/**
 * Validate proposed code before execution
 */
export async function validateProposal(
  proposalCode: string
): Promise<{ valid: boolean; errors: string[] }> {
  const errors: string[] = [];

  // Basic validation checks
  try {
    // Check for syntax errors by attempting to parse as JavaScript
    new Function(proposalCode);
  } catch (e) {
    errors.push(`Syntax error: ${e instanceof Error ? e.message : "Unknown error"}`);
  }

  // Check for dangerous patterns
  const dangerousPatterns = [
    { pattern: /eval\s*\(/, name: "eval() usage" },
    { pattern: /Function\s*\(/, name: "Function constructor" },
    { pattern: /process\.exit/, name: "process.exit() call" },
    { pattern: /require\s*\(/, name: "require() in client code" },
  ];

  for (const { pattern, name } of dangerousPatterns) {
    if (pattern.test(proposalCode)) {
      errors.push(`Dangerous pattern detected: ${name}`);
    }
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

/**
 * Execute a proposal and track history
 */
export async function executeProposal(
  proposalId: string,
  userId: number,
  proposedCode: string
): Promise<ExecutionResult> {
  const db = await getDb();
  if (!db) {
    return {
      success: false,
      proposalId,
      executedCode: "",
      timestamp: new Date(),
      validationPassed: false,
      errors: ["Database not available"],
      rollbackAvailable: false,
    };
  }

  try {
    // Validate the proposal
    const validation = await validateProposal(proposedCode);

    if (!validation.valid) {
      return {
        success: false,
        proposalId,
        executedCode: "",
        timestamp: new Date(),
        validationPassed: false,
        errors: validation.errors,
        rollbackAvailable: false,
      };
    }

    // Update proposal status to applied
    await db
      .update(selfBuildProposals)
      .set({
        status: "applied",
        appliedAt: new Date(),
        userFeedback: `Executed successfully at ${new Date().toISOString()}`,
      })
      .where(eq(selfBuildProposals.id, parseInt(proposalId)));

    return {
      success: true,
      proposalId,
      executedCode: proposedCode,
      timestamp: new Date(),
      validationPassed: true,
      rollbackAvailable: true,
    };
  } catch (error) {
    const errorMsg = error instanceof Error ? error.message : "Unknown error";
    return {
      success: false,
      proposalId,
      executedCode: "",
      timestamp: new Date(),
      validationPassed: false,
      errors: [errorMsg],
      rollbackAvailable: false,
    };
  }
}

/**
 * Get execution history for a proposal
 */
export async function getProposalHistory(
  proposalId: string,
  userId: number
): Promise<ProposalExecutionHistory[]> {
  const db = await getDb();
  if (!db) return [];

  try {
    const proposal = await db
      .select()
      .from(selfBuildProposals)
      .where(eq(selfBuildProposals.id, parseInt(proposalId)))
      .limit(1);

    if (proposal.length === 0) return [];

    const p = proposal[0] as any;

    // Return execution history based on proposal status
    if (p.status === "applied" && p.appliedAt) {
      return [
        {
          proposalId,
          executedAt: p.appliedAt,
          executedBy: userId,
          beforeState: "",
          afterState: p.proposedCode || "",
          validationPassed: true,
        },
      ];
    }

    return [];
  } catch (error) {
    console.error("Error fetching proposal history:", error);
    return [];
  }
}

/**
 * Rollback a proposal execution
 */
export async function rollbackProposal(
  proposalId: string,
  userId: number
): Promise<{ success: boolean; error?: string }> {
  const db = await getDb();
  if (!db) {
    return { success: false, error: "Database not available" };
  }

  try {
    // Update proposal status back to approved
    await db
      .update(selfBuildProposals)
      .set({
        status: "approved",
        appliedAt: null,
        userFeedback: `Rolled back at ${new Date().toISOString()}`,
      })
      .where(eq(selfBuildProposals.id, parseInt(proposalId)));

    return { success: true };
  } catch (error) {
    const errorMsg = error instanceof Error ? error.message : "Unknown error";
    return { success: false, error: errorMsg };
  }
}

/**
 * Get execution statistics
 */
export async function getExecutionStats(userId: number): Promise<{
  totalExecuted: number;
  successfulExecutions: number;
  failedExecutions: number;
  averageValidationTime: number;
}> {
  const db = await getDb();
  if (!db) {
    return {
      totalExecuted: 0,
      successfulExecutions: 0,
      failedExecutions: 0,
      averageValidationTime: 0,
    };
  }

  try {
    const proposals = await db
      .select()
      .from(selfBuildProposals)
      .where(eq(selfBuildProposals.userId, userId));

    const executed = proposals.filter((p: any) => p.status === "applied");
    const failed = proposals.filter((p: any) => p.status === "rejected");

    return {
      totalExecuted: executed.length,
      successfulExecutions: executed.length,
      failedExecutions: failed.length,
      averageValidationTime: 0, // Would be calculated from timestamps
    };
  } catch (error) {
    console.error("Error getting execution stats:", error);
    return {
      totalExecuted: 0,
      successfulExecutions: 0,
      failedExecutions: 0,
      averageValidationTime: 0,
    };
  }
}
