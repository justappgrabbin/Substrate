/**
 * LLM Settings Panel: Toggle and configure LLM proposal generation
 */

import { useLLMSettings } from "@/contexts/LLMSettingsContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Zap, AlertCircle } from "lucide-react";

export function LLMSettingsPanel() {
  const { settings, updateSettings, toggleLLM } = useLLMSettings();

  return (
    <Card className="bg-slate-900/50 border-slate-800">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Zap className="w-5 h-5 text-violet-400" />
          LLM Integration Settings
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Main Toggle */}
        <div className="flex items-center justify-between p-4 bg-slate-950/50 rounded-lg border border-slate-800">
          <div className="flex-1">
            <Label className="text-base font-semibold text-slate-200 cursor-pointer">
              Enable LLM Proposal Generation
            </Label>
            <p className="text-sm text-slate-400 mt-1">
              {settings.enabled
                ? "LLM will generate code improvement proposals"
                : "GNN-only mode: No LLM calls, neural net analysis only"}
            </p>
          </div>
          <Switch
            checked={settings.enabled}
            onCheckedChange={toggleLLM}
            className="ml-4"
          />
        </div>

        {settings.enabled && (
          <>
            <Separator className="bg-slate-800" />

            {/* Auto-Generate Toggle */}
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-sm font-medium text-slate-200 cursor-pointer">
                  Auto-Generate Proposals
                </Label>
                <p className="text-xs text-slate-400 mt-1">
                  Automatically generate proposals after analysis
                </p>
              </div>
              <Switch
                checked={settings.autoGenerate}
                onCheckedChange={(checked) =>
                  updateSettings({ autoGenerate: checked })
                }
              />
            </div>

            {/* Require Approval Toggle */}
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-sm font-medium text-slate-200 cursor-pointer">
                  Require Approval Before Execution
                </Label>
                <p className="text-xs text-slate-400 mt-1">
                  Review and approve proposals before applying changes
                </p>
              </div>
              <Switch
                checked={settings.requireApproval}
                onCheckedChange={(checked) =>
                  updateSettings({ requireApproval: checked })
                }
              />
            </div>

            <Separator className="bg-slate-800" />

            {/* Max Proposals Slider */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <Label className="text-sm font-medium text-slate-200">
                  Max Proposals Per Session
                </Label>
                <Badge className="bg-violet-600">{settings.maxProposalsPerSession}</Badge>
              </div>
              <Slider
                value={[settings.maxProposalsPerSession]}
                onValueChange={(value) =>
                  updateSettings({ maxProposalsPerSession: value[0] })
                }
                min={1}
                max={20}
                step={1}
                className="w-full"
              />
              <p className="text-xs text-slate-400 mt-2">
                Limit number of proposals generated per analysis session
              </p>
            </div>

            {/* Info Box */}
            <div className="p-3 bg-blue-500/10 border border-blue-500/30 rounded-lg flex gap-3">
              <AlertCircle className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
              <div className="text-xs text-blue-300">
                <p className="font-semibold mb-1">LLM as Translation Layer</p>
                <p>
                  The LLM only generates human-readable summaries and code proposals based on GNN
                  analysis. The neural network remains the decision engine.
                </p>
              </div>
            </div>
          </>
        )}

        {!settings.enabled && (
          <div className="p-3 bg-slate-800/50 border border-slate-700 rounded-lg flex gap-3">
            <AlertCircle className="w-5 h-5 text-slate-400 flex-shrink-0 mt-0.5" />
            <div className="text-xs text-slate-400">
              <p className="font-semibold mb-1">GNN-Only Mode</p>
              <p>
                Running in neural network only mode. You'll see GNN analysis and metrics, but no
                LLM-generated proposals.
              </p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
