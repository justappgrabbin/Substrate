/**
 * LLM Settings Context: Manage LLM toggle and proposal generation settings
 */

import { createContext, useContext, useState, ReactNode, useEffect } from "react";

interface LLMSettings {
  enabled: boolean;
  autoGenerate: boolean;
  requireApproval: boolean;
  maxProposalsPerSession: number;
}

interface LLMSettingsContextType {
  settings: LLMSettings;
  updateSettings: (settings: Partial<LLMSettings>) => void;
  toggleLLM: () => void;
}

const LLMSettingsContext = createContext<LLMSettingsContextType | undefined>(undefined);

const DEFAULT_SETTINGS: LLMSettings = {
  enabled: true,
  autoGenerate: false,
  requireApproval: true,
  maxProposalsPerSession: 5,
};

export function LLMSettingsProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<LLMSettings>(DEFAULT_SETTINGS);

  // Load settings from localStorage on mount
  useEffect(() => {
    const stored = localStorage.getItem("kimi-llm-settings");
    if (stored) {
      try {
        setSettings(JSON.parse(stored));
      } catch (e) {
        console.error("Failed to load LLM settings:", e);
      }
    }
  }, []);

  // Save settings to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem("kimi-llm-settings", JSON.stringify(settings));
  }, [settings]);

  const updateSettings = (newSettings: Partial<LLMSettings>) => {
    setSettings((prev) => ({ ...prev, ...newSettings }));
  };

  const toggleLLM = () => {
    setSettings((prev) => ({ ...prev, enabled: !prev.enabled }));
  };

  return (
    <LLMSettingsContext.Provider value={{ settings, updateSettings, toggleLLM }}>
      {children}
    </LLMSettingsContext.Provider>
  );
}

export function useLLMSettings() {
  const context = useContext(LLMSettingsContext);
  if (!context) {
    throw new Error("useLLMSettings must be used within LLMSettingsProvider");
  }
  return context;
}
