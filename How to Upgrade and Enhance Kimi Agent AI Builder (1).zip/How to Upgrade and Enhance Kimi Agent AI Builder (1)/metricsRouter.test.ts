/**
 * Metrics Router Tests: Verify real-time metrics procedures
 */

import { describe, it, expect, beforeEach } from "vitest";
import { metricsRouter } from "./metricsRouter";
import type { TrpcContext } from "../_core/context";

function createMockContext(): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "test-user",
      email: "test@example.com",
      name: "Test User",
      loginMethod: "test",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("Metrics Router", () => {
  let ctx: TrpcContext;
  let caller: ReturnType<typeof metricsRouter.createCaller>;

  beforeEach(() => {
    ctx = createMockContext();
    caller = metricsRouter.createCaller(ctx);
  });

  it("should get current metrics", async () => {
    const result = await caller.getCurrent();

    expect(result).toBeDefined();
    expect(result).toHaveProperty("lastSession");
    expect(result).toHaveProperty("totalSessions");
    expect(result).toHaveProperty("averageLoss");
    expect(result).toHaveProperty("averageConfidence");
    expect(result).toHaveProperty("history");
    expect(Array.isArray(result.history)).toBe(true);
  });

  it("should return valid metrics structure", async () => {
    const result = await caller.getCurrent();

    expect(typeof result.totalSessions).toBe("number");
    expect(typeof result.averageLoss).toBe("number");
    expect(typeof result.averageConfidence).toBe("number");
    expect(result.averageLoss).toBeGreaterThanOrEqual(0);
    expect(result.averageConfidence).toBeGreaterThanOrEqual(0);
    expect(result.averageConfidence).toBeLessThanOrEqual(1);
  });

  it("should get history with pagination", async () => {
    const result = await caller.getHistory({ limit: 10, offset: 0 });

    expect(result).toBeDefined();
    expect(result).toHaveProperty("sessions");
    expect(result).toHaveProperty("total");
    expect(Array.isArray(result.sessions)).toBe(true);
    expect(typeof result.total).toBe("number");
  });

  it("should enforce history limit", async () => {
    const result = await caller.getHistory({ limit: 1000, offset: 0 });

    expect(result.sessions.length).toBeLessThanOrEqual(500);
  });

  it("should get statistics", async () => {
    const result = await caller.getStatistics();

    expect(result).toBeDefined();
    expect(result).toHaveProperty("totalSessions");
    expect(result).toHaveProperty("minLoss");
    expect(result).toHaveProperty("maxLoss");
    expect(result).toHaveProperty("avgLoss");
    expect(result).toHaveProperty("minConfidence");
    expect(result).toHaveProperty("maxConfidence");
    expect(result).toHaveProperty("avgConfidence");
    expect(result).toHaveProperty("improvementRate");
    expect(result).toHaveProperty("totalNodesAnalyzed");
    expect(result).toHaveProperty("totalEdgesAnalyzed");
  });

  it("should return valid statistics", async () => {
    const result = await caller.getStatistics();

    expect(typeof result.totalSessions).toBe("number");
    expect(typeof result.minLoss).toBe("number");
    expect(typeof result.maxLoss).toBe("number");
    expect(typeof result.avgLoss).toBe("number");
    expect(result.minLoss).toBeGreaterThanOrEqual(0);
    expect(result.maxLoss).toBeGreaterThanOrEqual(result.minLoss);
  });

  it("should export metrics", async () => {
    const result = await caller.exportMetrics();

    expect(result).toBeDefined();
    expect(result).toHaveProperty("success");
    expect(result).toHaveProperty("data");
    expect(result).toHaveProperty("error");

    if (result.success) {
      expect(result.data).toHaveProperty("exportedAt");
      expect(result.data).toHaveProperty("userId");
      expect(result.data).toHaveProperty("totalSessions");
      expect(result.data).toHaveProperty("metrics");
      expect(result.data).toHaveProperty("sessions");
    }
  });

  it("should handle empty metrics gracefully", async () => {
    const result = await caller.getCurrent();

    expect(result.totalSessions).toBeGreaterThanOrEqual(0);
    expect(result.averageLoss).toBeGreaterThanOrEqual(0);
    expect(result.averageConfidence).toBeGreaterThanOrEqual(0);
  });

  it("should return consistent metric types", async () => {
    const current = await caller.getCurrent();
    const stats = await caller.getStatistics();

    expect(typeof current.averageLoss).toBe("number");
    expect(typeof stats.avgLoss).toBe("number");
    expect(typeof current.averageConfidence).toBe("number");
    expect(typeof stats.avgConfidence).toBe("number");
  });
});
