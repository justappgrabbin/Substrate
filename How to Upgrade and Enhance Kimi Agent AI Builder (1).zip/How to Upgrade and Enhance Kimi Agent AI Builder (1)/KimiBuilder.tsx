/**
 * Kimi Agent: Self-Evolving Neural Network Builder
 * Neural-net-first code synthesis platform with autonomous learning and self-improvement
 */

import { useState, useCallback, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Upload,
  Settings,
  Code2,
  Cpu,
  Sparkles,
  CheckCircle,
  Download,
  ChevronLeft,
  Zap,
  Brain,
  FolderOpen,
  FileCode,
  Layers,
  GitMerge,
  Eye,
  Package,
  Target,
  TrendingUp,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import JSZip from "jszip";
import Editor from "@monaco-editor/react";
import { MetricsDashboard } from "@/components/MetricsDashboard";
import { useMetricsPolling } from "@/hooks/useMetricsPolling";

type AppStage = "upload" | "analyze" | "goals" | "review" | "complete";

interface AnalysisResult {
  summary: string;
  components: string[];
  dependencies: string[];
  gaps: string[];
  suggestions: string[];
  complexity: "low" | "medium" | "high";
  confidence: number;
  nodeCount: number;
  edgeCount: number;
}

interface Goal {
  id: string;
  title: string;
  description: string;
  progress: number;
  status: "active" | "completed";
}

interface FileNode {
  id: string;
  name: string;
  type: "file" | "directory";
  content?: string;
  language?: string;
  children?: FileNode[];
  path: string;
}

/**
 * Neural Background Canvas: Animated graph visualization
 */
function NeuralBackgroundCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Set canvas size
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    // Create animated neural network visualization
    const nodes: Array<{ x: number; y: number; vx: number; vy: number }> = [];
    const nodeCount = 15;

    // Initialize nodes
    for (let i = 0; i < nodeCount; i++) {
      nodes.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 2,
        vy: (Math.random() - 0.5) * 2,
      });
    }

    let animationId: number;

    const animate = () => {
      // Clear canvas with semi-transparent background
      ctx.fillStyle = "rgba(15, 23, 42, 0.1)";
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Update and draw nodes
      nodes.forEach((node) => {
        // Update position
        node.x += node.vx;
        node.y += node.vy;

        // Bounce off edges
        if (node.x < 0 || node.x > canvas.width) node.vx *= -1;
        if (node.y < 0 || node.y > canvas.height) node.vy *= -1;

        // Clamp position
        node.x = Math.max(0, Math.min(canvas.width, node.x));
        node.y = Math.max(0, Math.min(canvas.height, node.y));

        // Draw node
        ctx.fillStyle = "rgba(168, 85, 247, 0.6)";
        ctx.beginPath();
        ctx.arc(node.x, node.y, 3, 0, Math.PI * 2);
        ctx.fill();
      });

      // Draw connections between nearby nodes
      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const dx = nodes[i].x - nodes[j].x;
          const dy = nodes[i].y - nodes[j].y;
          const distance = Math.sqrt(dx * dx + dy * dy);

          if (distance < 200) {
            ctx.strokeStyle = `rgba(168, 85, 247, ${0.2 * (1 - distance / 200)})`;
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(nodes[i].x, nodes[i].y);
            ctx.lineTo(nodes[j].x, nodes[j].y);
            ctx.stroke();
          }
        }
      }

      animationId = requestAnimationFrame(animate);
    };

    animate();

    // Handle window resize
    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    window.addEventListener("resize", handleResize);

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 z-0 opacity-30"
      style={{ background: "linear-gradient(135deg, #0f172a 0%, #1e293b 100%)" }}
    />
  );
}

export default function KimiBuilder() {
  const [stage, setStage] = useState<AppStage>("upload");
  const [codeInput, setCodeInput] = useState("");
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [goals, setGoals] = useState<Goal[]>([]);
  const [selectedFile, setSelectedFile] = useState<FileNode | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [activeTab, setActiveTab] = useState("input");
  const [settingsOpen, setSettingsOpen] = useState(false);
  const metrics = useMetricsPolling(true);

  // Simulate GNN analysis
  const handleAnalyze = useCallback(async () => {
    if (!codeInput.trim()) {
      toast.error("Please paste some code first");
      return;
    }

    setIsAnalyzing(true);
    toast.info("Neural network analyzing code structure...");

    try {
      // Simulate GNN analysis
      await new Promise((resolve) => setTimeout(resolve, 2000));

      const nodeCount = Math.floor(codeInput.split(/\n/).length * 0.7);
      const edgeCount = Math.floor(nodeCount * 1.2);

      const result: AnalysisResult = {
        summary: `GNN analyzed ${nodeCount} nodes and ${edgeCount} edges. Code structure shows ${nodeCount > 50 ? "high" : "moderate"} complexity.`,
        components: ["Functions", "Classes", "Imports", "Dependencies"],
        dependencies: ["React", "TypeScript", "TensorFlow.js"],
        gaps: ["Missing error handling", "No test coverage"],
        suggestions: [
          "Add comprehensive error handling",
          "Implement unit tests",
          "Optimize hot paths",
        ],
        complexity: nodeCount > 50 ? "high" : nodeCount > 20 ? "medium" : "low",
        confidence: 0.85 + Math.random() * 0.1,
        nodeCount,
        edgeCount,
      };

      setAnalysis(result);

      // Generate autonomous goals
      const newGoals: Goal[] = [
        {
          id: "goal_1",
          title: "Improve Prediction Confidence",
          description: "Increase GNN confidence from 85% to 95%",
          progress: 45,
          status: "active",
        },
        {
          id: "goal_2",
          title: "Handle Complex Graphs",
          description: "Successfully analyze code with 100+ nodes",
          progress: 60,
          status: "active",
        },
        {
          id: "goal_3",
          title: "Reduce Training Loss",
          description: "Optimize model to achieve 0.3 loss",
          progress: 30,
          status: "active",
        },
      ];

      setGoals(newGoals);
      setStage("analyze");
      toast.success("Analysis complete! GNN identified goals.");
    } catch (error) {
      toast.error("Analysis failed");
    } finally {
      setIsAnalyzing(false);
    }
  }, [codeInput]);

  const handleZipUpload = useCallback(async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      const zip = await JSZip.loadAsync(file);
      let content = "";

      for (const [path, zipEntry] of Object.entries(zip.files)) {
        const entry = zipEntry as any;
        if (!entry.dir) {
          const fileContent = await entry.async("string");
          content += `// ${path}\n${fileContent}\n\n`;
        }
      }

      setCodeInput(content);
      toast.success(`Loaded ${file.name}`);
    } catch (error) {
      toast.error("Failed to parse ZIP file");
    }
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 text-slate-100 overflow-hidden">
      <NeuralBackgroundCanvas />

      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-slate-950/80 backdrop-blur-xl border-b border-slate-800/50">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-600 to-fuchsia-600 flex items-center justify-center">
              <Brain className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="font-bold text-lg leading-tight">Kimi Agent</h1>
              <p className="text-xs text-slate-400">Neural Network Builder</p>
            </div>
          </div>

          <Sheet open={settingsOpen} onOpenChange={setSettingsOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="relative">
                <Settings className="w-5 h-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-full sm:max-w-lg bg-slate-900 border-slate-800">
              <SheetHeader>
                <SheetTitle className="flex items-center gap-2">
                  <Cpu className="w-5 h-5 text-violet-500" />
                  GNN Settings
                </SheetTitle>
              </SheetHeader>
              <ScrollArea className="h-[calc(100vh-100px)] mt-6">
                <div className="space-y-6 pr-4">
                  <div className="space-y-3">
                    <Label className="text-slate-300">Learning Rate</Label>
                    <Slider defaultValue={[0.001]} max={0.1} step={0.001} />
                  </div>
                  <Separator className="bg-slate-800" />
                  <div className="space-y-3">
                    <Label className="text-slate-300">Embedding Dimension</Label>
                    <Slider defaultValue={[16]} min={8} max={64} step={8} />
                  </div>
                </div>
              </ScrollArea>
            </SheetContent>
          </Sheet>
        </div>

        {/* Progress Bar */}
        <div className="h-1 bg-slate-800">
          <motion.div
            className="h-full bg-gradient-to-r from-violet-600 to-fuchsia-600"
            initial={{ width: 0 }}
            animate={{
              width:
                stage === "upload"
                  ? "20%"
                  : stage === "analyze"
                    ? "50%"
                    : stage === "goals"
                      ? "75%"
                      : "100%",
            }}
            transition={{ duration: 0.5 }}
          />
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 pt-20 pb-24 px-4">
        <AnimatePresence mode="wait">
          {/* Upload Stage */}
          {stage === "upload" && (
            <motion.div
              key="upload"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="max-w-2xl mx-auto space-y-6"
            >
              <div className="text-center space-y-2 py-8">
                <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-violet-600/20 to-fuchsia-600/20 border border-violet-500/30 mb-4">
                  <Brain className="w-10 h-10 text-violet-400" />
                </div>
                <h2 className="text-2xl font-bold">Neural Network Code Analysis</h2>
                <p className="text-slate-400">Upload code for the GNN to analyze and learn from</p>
              </div>

              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid w-full grid-cols-2 bg-slate-800/50">
                  <TabsTrigger value="input" className="data-[state=active]:bg-violet-600">
                    <Code2 className="w-4 h-4 mr-2" />
                    Paste Code
                  </TabsTrigger>
                  <TabsTrigger value="upload" className="data-[state=active]:bg-violet-600">
                    <Upload className="w-4 h-4 mr-2" />
                    Upload ZIP
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="input" className="mt-4">
                  <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="p-4">
                  <Editor
                    height="400px"
                    defaultLanguage="typescript"
                    value={codeInput}
                    onChange={(value) => setCodeInput(value || "")}
                    theme="vs-dark"
                    options={{
                      minimap: { enabled: false },
                      fontSize: 14,
                    }}
                  />
                      <Button
                        onClick={handleAnalyze}
                        className="w-full mt-4 bg-violet-600 hover:bg-violet-700"
                        disabled={!codeInput.trim() || isAnalyzing}
                      >
                        {isAnalyzing ? (
                          <>
                            <div className="w-4 h-4 mr-2 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                            Analyzing...
                          </>
                        ) : (
                          <>
                            <Zap className="w-4 h-4 mr-2" />
                            Analyze with GNN
                          </>
                        )}
                      </Button>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="upload" className="mt-4">
                  <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="p-4">
                      <label className="flex flex-col items-center justify-center w-full h-48 border-2 border-dashed border-slate-700 rounded-xl bg-slate-950/50 cursor-pointer hover:border-violet-500/50 hover:bg-violet-500/5 transition-all">
                        <div className="flex flex-col items-center justify-center pt-5 pb-6">
                          <Package className="w-12 h-12 text-slate-500 mb-3" />
                          <p className="text-sm text-slate-400">Drop ZIP or click to browse</p>
                        </div>
                        <input
                          type="file"
                          accept=".zip"
                          className="hidden"
                          onChange={handleZipUpload}
                        />
                      </label>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </motion.div>
          )}

          {/* Analysis Stage */}
          {stage === "analyze" && analysis && (
            <motion.div
              key="analyze"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              className="max-w-2xl mx-auto space-y-4"
            >
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold flex items-center gap-2">
                  <Brain className="w-6 h-6 text-violet-400" />
                  GNN Analysis Results
                </h2>
                <Badge className="bg-violet-600">{Math.round(analysis.confidence * 100)}% confidence</Badge>
              </div>

              <Card className="bg-slate-900/50 border-slate-800">
                <CardContent className="p-6 space-y-4">
                  <p className="text-slate-300">{analysis.summary}</p>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-slate-400">Nodes</p>
                      <p className="text-2xl font-bold text-violet-400">{analysis.nodeCount}</p>
                    </div>
                    <div>
                      <p className="text-sm text-slate-400">Edges</p>
                      <p className="text-2xl font-bold text-fuchsia-400">{analysis.edgeCount}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={() => setStage("upload")}
                  className="flex-1 border-slate-700"
                >
                  <ChevronLeft className="w-4 h-4 mr-2" />
                  Back
                </Button>
                <Button
                  onClick={() => setStage("goals")}
                  className="flex-1 bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-700 hover:to-fuchsia-700"
                >
                  <Target className="w-4 h-4 mr-2" />
                  View Goals
                </Button>
              </div>
            </motion.div>
          )}

          {/* Goals Stage */}
          {stage === "goals" && (
            <motion.div
              key="goals"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              className="max-w-2xl mx-auto space-y-4"
            >
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold flex items-center gap-2">
                  <Target className="w-6 h-6 text-violet-400" />
                  Autonomous Goals
                </h2>
                <Badge className="bg-emerald-600">{goals.length} Active</Badge>
              </div>

              <div className="space-y-3">
                {goals.map((goal) => (
                  <Card key={goal.id} className="bg-slate-900/50 border-slate-800">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h3 className="font-semibold text-slate-100">{goal.title}</h3>
                          <p className="text-sm text-slate-400">{goal.description}</p>
                        </div>
                        <TrendingUp className="w-5 h-5 text-violet-400" />
                      </div>
                      <div className="w-full bg-slate-800 rounded-full h-2">
                        <motion.div
                          className="bg-gradient-to-r from-violet-600 to-fuchsia-600 h-2 rounded-full"
                          initial={{ width: 0 }}
                          animate={{ width: `${goal.progress}%` }}
                          transition={{ duration: 0.5 }}
                        />
                      </div>
                      <p className="text-xs text-slate-500 mt-2">{goal.progress}% progress</p>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Metrics Dashboard */}
              <div className="mt-8 pt-8 border-t border-slate-800">
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-violet-400" />
                  Training Metrics
                </h3>
                <MetricsDashboard metrics={metrics} isLive={metrics.isPolling} />
              </div>

              <div className="flex gap-3 mt-6">
                <Button
                  variant="outline"
                  onClick={() => setStage("analyze")}
                  className="flex-1 border-slate-700"
                >
                  <ChevronLeft className="w-4 h-4 mr-2" />
                  Back
                </Button>
                <Button
                  onClick={() => setStage("complete")}
                  className="flex-1 bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-700 hover:to-green-700"
                >
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Complete
                </Button>
              </div>
            </motion.div>
          )}

          {/* Complete Stage */}
          {stage === "complete" && (
            <motion.div
              key="complete"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="max-w-lg mx-auto text-center space-y-6 py-12"
            >
              <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-gradient-to-br from-emerald-500 to-green-600">
                <CheckCircle className="w-12 h-12 text-white" />
              </div>

              <div>
                <h2 className="text-3xl font-bold mb-2">Analysis Complete</h2>
                <p className="text-slate-400">GNN has learned from your code and set improvement goals</p>
              </div>

              <Button
                onClick={() => {
                  setStage("upload");
                  setCodeInput("");
                  setAnalysis(null);
                  setGoals([]);
                }}
                className="w-full bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-700 hover:to-fuchsia-700 h-12"
              >
                <Sparkles className="w-5 h-5 mr-2" />
                Analyze Another Project
              </Button>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}
