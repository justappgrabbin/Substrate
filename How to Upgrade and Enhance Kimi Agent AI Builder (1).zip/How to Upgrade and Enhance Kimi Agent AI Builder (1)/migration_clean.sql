CREATE TABLE `gnn_model_state` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`weights` text NOT NULL,
	`nodeEmbeddings` text NOT NULL,
	`lastLoss` varchar(64),
	`lastConfidence` varchar(64),
	`totalTrainingSteps` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `gnn_model_state_id` PRIMARY KEY(`id`),
	CONSTRAINT `gnn_model_state_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action
);

CREATE TABLE `gnn_sessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`sessionId` varchar(64) NOT NULL,
	`codeInput` text,
	`graphStructure` text,
	`predictions` text,
	`metrics` text,
	`goalsSet` int DEFAULT 0,
	`proposalsGenerated` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `gnn_sessions_id` PRIMARY KEY(`id`),
	CONSTRAINT `gnn_sessions_sessionId_unique` UNIQUE(`sessionId`),
	CONSTRAINT `gnn_sessions_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action
);

CREATE TABLE `self_build_proposals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`weakness` text NOT NULL,
	`proposedCode` text,
	`explanation` text,
	`status` enum('pending','approved','rejected','applied') DEFAULT 'pending',
	`userFeedback` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`appliedAt` timestamp,
	CONSTRAINT `self_build_proposals_id` PRIMARY KEY(`id`),
	CONSTRAINT `self_build_proposals_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action
);

CREATE TABLE `self_improvement_goals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`title` text NOT NULL,
	`description` text,
	`targetMetric` varchar(64) NOT NULL,
	`baselineValue` varchar(64) NOT NULL,
	`targetValue` varchar(64) NOT NULL,
	`currentValue` varchar(64),
	`status` enum('active','completed','abandoned') DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`completedAt` timestamp,
	CONSTRAINT `self_improvement_goals_id` PRIMARY KEY(`id`),
	CONSTRAINT `self_improvement_goals_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action
);

CREATE TABLE `training_history` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`codeHash` varchar(64) NOT NULL,
	`loss` varchar(64) NOT NULL,
	`confidence` varchar(64) NOT NULL,
	`nodeCount` int,
	`edgeCount` int,
	`analysisOutput` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `training_history_id` PRIMARY KEY(`id`),
	CONSTRAINT `training_history_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action
);
