/**
 * useMetricsPolling: Real-time metrics polling from GNN training
 * Polls server at regular intervals for live loss, confidence, and training data
 */

import { useEffect, useRef, useState, useCallback } from "react";
import { trpc } from "@/lib/trpc";

export interface MetricsSnapshot {
  timestamp: number;
  loss: number;
  confidence: number;
  nodeCount: number;
  edgeCount: number;
  sessionCount: number;
}

export interface MetricsState {
  current: MetricsSnapshot | null;
  history: MetricsSnapshot[];
  isPolling: boolean;
  trend: "improving" | "degrading" | "stable" | "none";
  averageLoss: number;
  averageConfidence: number;
}

const POLLING_INTERVAL = 2000; // Poll every 2 seconds
const MAX_HISTORY = 100; // Keep last 100 data points

export function useMetricsPolling(enabled: boolean = true) {
  const [metricsState, setMetricsState] = useState<MetricsState>({
    current: null,
    history: [],
    isPolling: false,
    trend: "none",
    averageLoss: 0,
    averageConfidence: 0,
  });

  const pollingIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const lastUpdateRef = useRef<number>(0);

  const metricsQuery = trpc.gnnEnhanced.getMetrics.useQuery(undefined, {
    enabled: false, // Manual control
    refetchInterval: false,
  });

  const updateMetrics = useCallback(async () => {
    if (!enabled) return;

    try {
      const data = await metricsQuery.refetch();

      if (data.data) {
        const metrics = data.data;
        const newSnapshot: MetricsSnapshot = {
          timestamp: Date.now(),
          loss: metrics.lastSession?.loss || metrics.averageLoss || 0,
          confidence: metrics.lastSession?.confidence || metrics.averageConfidence || 0,
          nodeCount: metrics.lastSession?.nodeCount || 0,
          edgeCount: 0,
          sessionCount: metrics.totalSessions || 0,
        };

        setMetricsState((prev) => {
          const updatedHistory = [newSnapshot, ...prev.history].slice(0, MAX_HISTORY);

          // Calculate trend
          let trend: "improving" | "degrading" | "stable" | "none" = "none";
          if (updatedHistory.length >= 3) {
            const recent = updatedHistory.slice(0, 3);
            const avgRecent = recent.reduce((sum, m) => sum + m.loss, 0) / recent.length;
            const avgPrevious = updatedHistory
              .slice(3, 6)
              .reduce((sum, m) => sum + m.loss, 0) / Math.min(3, updatedHistory.length - 3);

            if (avgRecent < avgPrevious * 0.95) trend = "improving";
            else if (avgRecent > avgPrevious * 1.05) trend = "degrading";
            else trend = "stable";
          }

          // Calculate averages
          const avgLoss = updatedHistory.reduce((sum, m) => sum + m.loss, 0) / updatedHistory.length;
          const avgConfidence =
            updatedHistory.reduce((sum, m) => sum + m.confidence, 0) / updatedHistory.length;

          return {
            current: newSnapshot,
            history: updatedHistory,
            isPolling: true,
            trend,
            averageLoss: avgLoss,
            averageConfidence: avgConfidence,
          };
        });

        lastUpdateRef.current = Date.now();
      }
    } catch (error) {
      console.error("Error polling metrics:", error);
    }
  }, [enabled, metricsQuery]);

  // Start polling
  useEffect(() => {
    if (!enabled) {
      if (pollingIntervalRef.current) {
        clearInterval(pollingIntervalRef.current);
        pollingIntervalRef.current = null;
      }
      return;
    }

    // Initial fetch
    updateMetrics();

    // Set up polling interval
    pollingIntervalRef.current = setInterval(() => {
      updateMetrics();
    }, POLLING_INTERVAL);

    return () => {
      if (pollingIntervalRef.current) {
        clearInterval(pollingIntervalRef.current);
        pollingIntervalRef.current = null;
      }
    };
  }, [enabled, updateMetrics]);

  const stopPolling = useCallback(() => {
    if (pollingIntervalRef.current) {
      clearInterval(pollingIntervalRef.current);
      pollingIntervalRef.current = null;
    }
    setMetricsState((prev) => ({ ...prev, isPolling: false }));
  }, []);

  const startPolling = useCallback(() => {
    updateMetrics();
  }, [updateMetrics]);

  const clearHistory = useCallback(() => {
    setMetricsState((prev) => ({
      ...prev,
      history: [],
      current: null,
      trend: "none",
      averageLoss: 0,
      averageConfidence: 0,
    }));
  }, []);

  return {
    ...metricsState,
    stopPolling,
    startPolling,
    clearHistory,
    isLoading: metricsQuery.isLoading,
    error: metricsQuery.error,
  };
}
