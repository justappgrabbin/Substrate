import { useEffect, useState } from 'react';
import { Copy, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

interface CodeEditorProps {
  code: string;
  language?: string;
  readOnly?: boolean;
  onChange?: (value: string) => void;
}

export function CodeEditor({ code, language = 'typescript', readOnly = false, onChange }: CodeEditorProps) {
  const [copied, setCopied] = useState(false);
  const [displayCode, setDisplayCode] = useState(code);

  useEffect(() => {
    setDisplayCode(code);
  }, [code]);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(displayCode);
    setCopied(true);
    toast.success('Copied to clipboard');
    setTimeout(() => setCopied(false), 2000);
  };

  const highlightSyntax = (code: string): string => {
    // Simple syntax highlighting for common patterns
    let highlighted = code
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');

    // Keywords
    const keywords = ['const', 'let', 'var', 'function', 'class', 'interface', 'type', 'import', 'export', 'from', 'return', 'if', 'else', 'for', 'while', 'async', 'await', 'try', 'catch', 'new', 'this', 'extends', 'implements'];
    keywords.forEach(kw => {
      const regex = new RegExp(`\\b${kw}\\b`, 'g');
      highlighted = highlighted.replace(regex, `<span class="text-violet-400">${kw}</span>`);
    });

    // Strings
    highlighted = highlighted.replace(
      /(['"`])([^'"`]*)(['"`])/g,
      '<span class="text-emerald-400">$1$2$3</span>'
    );

    // Comments
    highlighted = highlighted.replace(
      /(\/\/.*$)/gm,
      '<span class="text-slate-500">$1</span>'
    );

    // Numbers
    highlighted = highlighted.replace(
      /\b(\d+)\b/g,
      '<span class="text-amber-400">$1</span>'
    );

    // Functions
    highlighted = highlighted.replace(
      /(\w+)(\s*\()/g,
      '<span class="text-fuchsia-400">$1</span>$2'
    );

    return highlighted;
  };

  const lines = displayCode.split('\n');

  return (
    <div className="relative h-full min-h-[300px] bg-slate-950 rounded-lg overflow-hidden">
      {/* Toolbar */}
      <div className="flex items-center justify-between px-3 py-2 bg-slate-900 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <div className="flex gap-1.5">
            <div className="w-3 h-3 rounded-full bg-red-500/80" />
            <div className="w-3 h-3 rounded-full bg-amber-500/80" />
            <div className="w-3 h-3 rounded-full bg-green-500/80" />
          </div>
          <span className="ml-3 text-xs text-slate-500 uppercase">{language}</span>
        </div>
        <Button 
          variant="ghost" 
          size="icon" 
          className="h-7 w-7"
          onClick={handleCopy}
        >
          {copied ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
        </Button>
      </div>

      {/* Editor */}
      <div className="relative flex h-[calc(100%-40px)] overflow-auto">
        {/* Line Numbers */}
        <div className="flex-shrink-0 py-4 px-3 bg-slate-900/50 text-right select-none">
          {lines.map((_, i) => (
            <div key={i} className="text-xs text-slate-600 leading-6">
              {i + 1}
            </div>
          ))}
        </div>

        {/* Code Area */}
        <div className="flex-1 relative min-w-0">
          {readOnly ? (
            <pre 
              className="absolute inset-0 p-4 text-sm font-mono leading-6 whitespace-pre-wrap break-all"
              dangerouslySetInnerHTML={{ __html: highlightSyntax(displayCode) }}
            />
          ) : (
            <textarea
              value={displayCode}
              onChange={(e) => {
                setDisplayCode(e.target.value);
                onChange?.(e.target.value);
              }}
              className="absolute inset-0 w-full h-full p-4 bg-transparent text-sm font-mono leading-6 text-slate-300 resize-none outline-none"
              spellCheck={false}
            />
          )}
        </div>
      </div>
    </div>
  );
}
