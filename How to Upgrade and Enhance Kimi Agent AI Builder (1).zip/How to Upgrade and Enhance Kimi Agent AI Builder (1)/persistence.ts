/**
 * GNN Persistence Layer: Handle weight serialization and database storage
 */

import * as tf from "@tensorflow/tfjs";
import { getDb } from "../db";
import { gnnModelState } from "../../drizzle/schema";
import { eq } from "drizzle-orm";

export interface SerializedWeights {
  nodeEmbeddingWeights: {
    data: number[];
    shape: [number, number];
  };
  messagePassingWeights: {
    data: number[];
    shape: [number, number];
  };
  aggregationWeights: {
    data: number[];
    shape: [number, number];
  };
  outputWeights: {
    data: number[];
    shape: [number, number];
  };
}

/**
 * Serialize tensor weights to JSON-safe format
 */
export async function serializeWeights(weights: {
  nodeEmbeddingWeights: tf.Variable;
  messagePassingWeights: tf.Variable;
  aggregationWeights: tf.Variable;
  outputWeights: tf.Variable;
}): Promise<SerializedWeights> {
  const nodeEmbData = await weights.nodeEmbeddingWeights.data();
  const msgPassData = await weights.messagePassingWeights.data();
  const aggData = await weights.aggregationWeights.data();
  const outData = await weights.outputWeights.data();

  return {
    nodeEmbeddingWeights: {
      data: Array.from(nodeEmbData),
      shape: weights.nodeEmbeddingWeights.shape as [number, number],
    },
    messagePassingWeights: {
      data: Array.from(msgPassData),
      shape: weights.messagePassingWeights.shape as [number, number],
    },
    aggregationWeights: {
      data: Array.from(aggData),
      shape: weights.aggregationWeights.shape as [number, number],
    },
    outputWeights: {
      data: Array.from(outData),
      shape: weights.outputWeights.shape as [number, number],
    },
  };
}

/**
 * Deserialize JSON weights back to tensors
 */
export function deserializeWeights(serialized: SerializedWeights): {
  nodeEmbeddingWeights: tf.Tensor2D;
  messagePassingWeights: tf.Tensor2D;
  aggregationWeights: tf.Tensor2D;
  outputWeights: tf.Tensor2D;
} {
  return {
    nodeEmbeddingWeights: tf.tensor2d(
      serialized.nodeEmbeddingWeights.data,
      serialized.nodeEmbeddingWeights.shape
    ),
    messagePassingWeights: tf.tensor2d(
      serialized.messagePassingWeights.data,
      serialized.messagePassingWeights.shape
    ),
    aggregationWeights: tf.tensor2d(
      serialized.aggregationWeights.data,
      serialized.aggregationWeights.shape
    ),
    outputWeights: tf.tensor2d(
      serialized.outputWeights.data,
      serialized.outputWeights.shape
    ),
  };
}

/**
 * Save model state to database
 */
export async function saveModelState(
  userId: number,
  weights: SerializedWeights,
  metrics: {
    lastLoss: number;
    lastConfidence: number;
    totalTrainingSteps: number;
  }
): Promise<boolean> {
  try {
    const db = await getDb();
    if (!db) return false;

    const existing = await db
      .select()
      .from(gnnModelState)
      .where(eq(gnnModelState.userId, userId))
      .limit(1);

    const weightsJson = JSON.stringify(weights);
    const nodeEmbedJson = JSON.stringify(weights.nodeEmbeddingWeights);

    if (existing.length > 0) {
      await db
        .update(gnnModelState)
        .set({
          weights: weightsJson,
          nodeEmbeddings: nodeEmbedJson,
          lastLoss: metrics.lastLoss.toString(),
          lastConfidence: metrics.lastConfidence.toString(),
          totalTrainingSteps: metrics.totalTrainingSteps,
        })
        .where(eq(gnnModelState.userId, userId));
    } else {
      await db.insert(gnnModelState).values({
        userId,
        weights: weightsJson,
        nodeEmbeddings: nodeEmbedJson,
        lastLoss: metrics.lastLoss.toString(),
        lastConfidence: metrics.lastConfidence.toString(),
        totalTrainingSteps: metrics.totalTrainingSteps,
      });
    }

    return true;
  } catch (error) {
    console.error("Error saving model state:", error);
    return false;
  }
}

/**
 * Load model state from database
 */
export async function loadModelState(userId: number): Promise<{
  weights: SerializedWeights | null;
  metrics: {
    lastLoss: number;
    lastConfidence: number;
    totalTrainingSteps: number;
  } | null;
}> {
  try {
    const db = await getDb();
    if (!db) return { weights: null, metrics: null };

    const state = await db
      .select()
      .from(gnnModelState)
      .where(eq(gnnModelState.userId, userId))
      .limit(1);

    if (state.length === 0) {
      return { weights: null, metrics: null };
    }

    const record = state[0];
    const weights = record.weights ? JSON.parse(record.weights) : null;

    return {
      weights,
      metrics: {
        lastLoss: record.lastLoss ? parseFloat(record.lastLoss) : 0,
        lastConfidence: record.lastConfidence ? parseFloat(record.lastConfidence) : 0,
        totalTrainingSteps: record.totalTrainingSteps || 0,
      },
    };
  } catch (error) {
    console.error("Error loading model state:", error);
    return { weights: null, metrics: null };
  }
}
