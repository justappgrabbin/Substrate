export interface FileNode {
  id: string;
  name: string;
  type: 'file' | 'directory';
  content?: string;
  language?: string;
  children?: FileNode[];
  path: string;
}

export interface AnalysisResult {
  summary: string;
  components: string[];
  dependencies: string[];
  gaps: string[];
  suggestions: string[];
  complexity: 'low' | 'medium' | 'high';
}

export interface MorphPlan {
  id: string;
  name: string;
  description: string;
  steps: PlanStep[];
  files: FileNode[];
  estimatedTime: string;
  confidence: number;
}

export interface PlanStep {
  id: string;
  title: string;
  description: string;
  status: 'pending' | 'in-progress' | 'completed';
  files: string[];
}

export interface TransformerConfig {
  model: string;
  temperature: number;
  maxTokens: number;
  topP: number;
  frequencyPenalty: number;
  presencePenalty: number;
  systemPrompt: string;
}

export interface UploadedProject {
  id: string;
  name: string;
  files: FileNode[];
  rawContent: string;
  source: 'paste' | 'zip';
  timestamp: number;
}

export type AppStage = 'upload' | 'analyze' | 'plan' | 'review' | 'officialize';

export interface GeneratedApp {
  id: string;
  name: string;
  files: FileNode[];
  plan: MorphPlan;
  timestamp: number;
  status: 'draft' | 'official';
}
