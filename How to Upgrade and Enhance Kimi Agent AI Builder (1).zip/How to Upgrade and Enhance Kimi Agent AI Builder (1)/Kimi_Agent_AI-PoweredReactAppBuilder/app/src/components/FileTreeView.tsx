import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Folder, File, ChevronRight, ChevronDown } from 'lucide-react';
import type { FileNode } from '@/types';
import { cn } from '@/lib/utils';

interface FileTreeViewProps {
  files: FileNode[];
  onSelect: (file: FileNode) => void;
  selectedId?: string;
  level?: number;
}

export function FileTreeView({ files, onSelect, selectedId, level = 0 }: FileTreeViewProps) {
  return (
    <div className="space-y-0.5">
      {files.map((file) => (
        <FileTreeItem 
          key={file.id} 
          file={file} 
          onSelect={onSelect}
          selectedId={selectedId}
          level={level}
        />
      ))}
    </div>
  );
}

interface FileTreeItemProps {
  file: FileNode;
  onSelect: (file: FileNode) => void;
  selectedId?: string;
  level: number;
}

function FileTreeItem({ file, onSelect, selectedId, level }: FileTreeItemProps) {
  const [isExpanded, setIsExpanded] = useState(true);
  const isSelected = selectedId === file.id;
  const hasChildren = file.type === 'directory' && file.children && file.children.length > 0;

  return (
    <div>
      <motion.button
        whileTap={{ scale: 0.98 }}
        onClick={() => {
          if (file.type === 'directory') {
            setIsExpanded(!isExpanded);
          } else {
            onSelect(file);
          }
        }}
        className={cn(
          'w-full flex items-center gap-2 px-3 py-2 rounded-lg text-left transition-all',
          'hover:bg-slate-800/50',
          isSelected && 'bg-violet-600/20 hover:bg-violet-600/30',
          level > 0 && 'ml-4'
        )}
        style={{ paddingLeft: `${12 + level * 12}px` }}
      >
        {file.type === 'directory' && hasChildren && (
          <span className="text-slate-500">
            {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
          </span>
        )}
        
        {file.type === 'directory' ? (
          <Folder className={cn(
            'w-4 h-4',
            isSelected ? 'text-violet-400' : 'text-amber-400'
          )} />
        ) : (
          <File className={cn(
            'w-4 h-4',
            isSelected ? 'text-violet-400' : 'text-slate-400'
          )} />
        )}
        
        <span className={cn(
          'text-sm truncate',
          isSelected ? 'text-violet-200 font-medium' : 'text-slate-300'
        )}>
          {file.name}
        </span>
        
        {file.type === 'file' && file.language && (
          <span className="ml-auto text-[10px] text-slate-600 uppercase">
            {file.language}
          </span>
        )}
      </motion.button>

      <AnimatePresence>
        {hasChildren && isExpanded && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2 }}
          >
            <FileTreeView 
              files={file.children!} 
              onSelect={onSelect}
              selectedId={selectedId}
              level={level + 1}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
