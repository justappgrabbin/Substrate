import { motion } from 'framer-motion';
import { 
  Puzzle, Package, AlertTriangle, Lightbulb, 
  TrendingUp, Zap 
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import type { AnalysisResult } from '@/types';

interface AnalysisPanelProps {
  analysis: AnalysisResult;
}

export function AnalysisPanel({ analysis }: AnalysisPanelProps) {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <motion.div 
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-3"
    >
      {/* Summary Card */}
      <motion.div variants={itemVariants}>
        <Card className="bg-slate-900/50 border-slate-800">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-lg bg-violet-600/20 flex items-center justify-center flex-shrink-0">
                <TrendingUp className="w-5 h-5 text-violet-400" />
              </div>
              <div>
                <h3 className="font-medium mb-1">Analysis Summary</h3>
                <p className="text-sm text-slate-400">{analysis.summary}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Components Found */}
      <motion.div variants={itemVariants}>
        <Card className="bg-slate-900/50 border-slate-800">
          <CardHeader className="p-3 pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Puzzle className="w-4 h-4 text-fuchsia-400" />
              Components Detected
              <Badge variant="secondary" className="ml-auto">
                {analysis.components.length}
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-3 pt-0">
            <div className="flex flex-wrap gap-2">
              {analysis.components.map((component, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: i * 0.05 }}
                >
                  <Badge 
                    variant="outline" 
                    className="bg-fuchsia-600/10 border-fuchsia-500/30 text-fuchsia-300"
                  >
                    {component}
                  </Badge>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Dependencies */}
      <motion.div variants={itemVariants}>
        <Card className="bg-slate-900/50 border-slate-800">
          <CardHeader className="p-3 pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Package className="w-4 h-4 text-emerald-400" />
              Dependencies
              <Badge variant="secondary" className="ml-auto">
                {analysis.dependencies.length}
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-3 pt-0">
            <div className="flex flex-wrap gap-2">
              {analysis.dependencies.map((dep, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: i * 0.05 }}
                >
                  <Badge 
                    variant="outline" 
                    className="bg-emerald-600/10 border-emerald-500/30 text-emerald-300"
                  >
                    {dep}
                  </Badge>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Gaps */}
      {analysis.gaps.length > 0 && (
        <motion.div variants={itemVariants}>
          <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader className="p-3 pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-400" />
                Identified Gaps
                <Badge variant="secondary" className="ml-auto">
                  {analysis.gaps.length}
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-3 pt-0">
              <ul className="space-y-2">
                {analysis.gaps.map((gap, i) => (
                  <motion.li 
                    key={i}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.05 }}
                    className="flex items-start gap-2 text-sm text-slate-400"
                  >
                    <span className="text-amber-500 mt-1">•</span>
                    {gap}
                  </motion.li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </motion.div>
      )}

      {/* Suggestions */}
      <motion.div variants={itemVariants}>
        <Card className="bg-slate-900/50 border-slate-800">
          <CardHeader className="p-3 pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Lightbulb className="w-4 h-4 text-yellow-400" />
              AI Suggestions
              <Badge variant="secondary" className="ml-auto">
                {analysis.suggestions.length}
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-3 pt-0">
            <ul className="space-y-2">
              {analysis.suggestions.map((suggestion, i) => (
                <motion.li 
                  key={i}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className="flex items-start gap-2 text-sm text-slate-400"
                >
                  <Zap className="w-4 h-4 text-yellow-500 mt-0.5 flex-shrink-0" />
                  {suggestion}
                </motion.li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  );
}
