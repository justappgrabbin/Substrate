import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  CheckCircle2, Circle, Clock, FileCode, 
  ChevronDown, ChevronUp, GitBranch 
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import type { MorphPlan, PlanStep } from '@/types';

interface PlanViewerProps {
  plan: MorphPlan;
}

export function PlanViewer({ plan }: PlanViewerProps) {
  const [expandedSteps, setExpandedSteps] = useState<string[]>([plan.steps[0]?.id]);

  const toggleStep = (stepId: string) => {
    setExpandedSteps(prev => 
      prev.includes(stepId) 
        ? prev.filter(id => id !== stepId)
        : [...prev, stepId]
    );
  };

  const getStatusIcon = (status: PlanStep['status']) => {
    switch (status) {
      case 'completed':
        return <CheckCircle2 className="w-5 h-5 text-emerald-400" />;
      case 'in-progress':
        return <Clock className="w-5 h-5 text-amber-400 animate-pulse" />;
      default:
        return <Circle className="w-5 h-5 text-slate-600" />;
    }
  };

  return (
    <div className="space-y-4">
      {/* Plan Overview */}
      <Card className="bg-gradient-to-br from-violet-900/30 to-fuchsia-900/30 border-violet-500/30">
        <CardContent className="p-4">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-xl bg-violet-600/30 flex items-center justify-center flex-shrink-0">
              <GitBranch className="w-6 h-6 text-violet-400" />
            </div>
            <div className="flex-1">
              <h3 className="font-bold text-lg mb-1">{plan.name}</h3>
              <p className="text-sm text-slate-400 mb-3">{plan.description}</p>
              <div className="flex items-center gap-4 text-xs">
                <span className="flex items-center gap-1 text-slate-500">
                  <Clock className="w-3 h-3" />
                  {plan.estimatedTime}
                </span>
                <span className="flex items-center gap-1 text-slate-500">
                  <FileCode className="w-3 h-3" />
                  {plan.files.length} files
                </span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Steps Timeline */}
      <Card className="bg-slate-900/50 border-slate-800">
        <CardHeader className="p-3 pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <GitBranch className="w-4 h-4 text-violet-400" />
            Execution Steps
          </CardTitle>
        </CardHeader>
        <CardContent className="p-3 pt-0">
          <div className="space-y-2">
            {plan.steps.map((step, index) => (
              <motion.div
                key={step.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <div 
                  className="border border-slate-800 rounded-lg overflow-hidden bg-slate-950/50"
                >
                  <button
                    onClick={() => toggleStep(step.id)}
                    className="w-full flex items-center gap-3 p-3 hover:bg-slate-800/50 transition-colors"
                  >
                    <span className="flex-shrink-0">
                      {getStatusIcon(step.status)}
                    </span>
                    <div className="flex-1 text-left">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-sm">{step.title}</span>
                        {step.files.length > 0 && (
                          <Badge variant="secondary" className="text-[10px]">
                            {step.files.length} files
                          </Badge>
                        )}
                      </div>
                    </div>
                    <span className="text-slate-500">
                      {expandedSteps.includes(step.id) ? (
                        <ChevronUp className="w-4 h-4" />
                      ) : (
                        <ChevronDown className="w-4 h-4" />
                      )}
                    </span>
                  </button>

                  <AnimatePresence>
                    {expandedSteps.includes(step.id) && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.2 }}
                      >
                        <div className="px-3 pb-3 pl-11">
                          <p className="text-sm text-slate-400 mb-2">
                            {step.description}
                          </p>
                          {step.files.length > 0 && (
                            <div className="flex flex-wrap gap-1">
                              {step.files.map((file, i) => (
                                <Badge 
                                  key={i}
                                  variant="outline" 
                                  className="text-[10px] bg-slate-800/50 border-slate-700"
                                >
                                  {file}
                                </Badge>
                              ))}
                            </div>
                          )}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </motion.div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Generated Files Preview */}
      <Card className="bg-slate-900/50 border-slate-800">
        <CardHeader className="p-3 pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <FileCode className="w-4 h-4 text-emerald-400" />
            Generated Files
          </CardTitle>
        </CardHeader>
        <CardContent className="p-3 pt-0">
          <ScrollArea className="h-48">
            <div className="space-y-1">
              {plan.files.map((file, index) => (
                <motion.div
                  key={file.id}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.03 }}
                  className="flex items-center gap-2 p-2 rounded-lg hover:bg-slate-800/50"
                >
                  <FileCode className="w-4 h-4 text-slate-500" />
                  <span className="text-sm text-slate-300">{file.path}</span>
                  {file.language && (
                    <Badge variant="secondary" className="ml-auto text-[10px]">
                      {file.language}
                    </Badge>
                  )}
                </motion.div>
              ))}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}
