/**
 * TensorFlow.js Graph Neural Network Core
 * Real neural network engine for code analysis
 * Analyzes code structure as a graph and learns incrementally
 */

import * as tf from "@tensorflow/tfjs";
import "@tensorflow/tfjs-backend-webgl";
import "@tensorflow/tfjs-backend-cpu";

export interface GraphNode {
  id: string;
  type: string; // 'function', 'class', 'variable', 'import', etc.
  features: number[]; // Encoded features for the node
  label?: string;
}

export interface GraphEdge {
  source: string;
  target: string;
  type: string; // 'calls', 'imports', 'inherits', 'uses', etc.
  weight?: number;
}

export interface CodeGraph {
  nodes: GraphNode[];
  edges: GraphEdge[];
  nodeCount: number;
  edgeCount: number;
}

export interface GNNWeights {
  nodeEmbeddingWeights: number[][];
  messagePassingWeights: number[][];
  aggregationWeights: number[][];
  outputWeights: number[][];
}

export interface TrainingMetrics {
  loss: number;
  confidence: number;
  nodeCount: number;
  edgeCount: number;
  timestamp: number;
}

/**
 * CodeGraphBuilder: Converts code into a graph structure
 * Analyzes AST patterns to identify nodes and relationships
 */
export class CodeGraphBuilder {
  private nodeIdCounter = 0;

  buildFromCode(code: string): CodeGraph {
    const nodes: GraphNode[] = [];
    const edges: GraphEdge[] = [];

    // Parse code patterns to extract structure
    const functionPattern = /function\s+(\w+)|const\s+(\w+)\s*=|class\s+(\w+)/g;
    const importPattern = /import\s+(?:.*?)\s+from\s+['"]([^'"]+)['"]/g;
    const callPattern = /(\w+)\s*\(/g;

    let match;
    const functionNames = new Set<string>();
    const importedModules = new Set<string>();
    const functionCalls = new Map<string, Set<string>>();

    // Extract functions and classes
    while ((match = functionPattern.exec(code)) !== null) {
      const name = match[1] || match[2] || match[3];
      if (name) {
        functionNames.add(name);
        nodes.push({
          id: `node_${this.nodeIdCounter++}`,
          type: match[0].startsWith("class") ? "class" : "function",
          features: this.encodeNodeFeatures(name, match[0]),
          label: name,
        });
      }
    }

    // Extract imports
    while ((match = importPattern.exec(code)) !== null) {
      const moduleName = match[1];
      if (moduleName) {
        importedModules.add(moduleName);
        nodes.push({
          id: `node_${this.nodeIdCounter++}`,
          type: "import",
          features: this.encodeNodeFeatures(moduleName, "import"),
          label: moduleName,
        });
      }
    }

    // Extract function calls
    while ((match = callPattern.exec(code)) !== null) {
      const callerName = match[1];
      if (functionNames.has(callerName)) {
        if (!functionCalls.has(callerName)) {
          functionCalls.set(callerName, new Set());
        }
      }
    }

    // Build edges: function calls
    const nodeMap = new Map<string, GraphNode>();
    nodes.forEach((node) => {
      if (node.label) nodeMap.set(node.label, node);
    });

    // Add edges for function calls
    const callEntries = Array.from(functionCalls.entries());
    for (const [caller, callees] of callEntries) {
      const callerNode = nodeMap.get(caller);
      if (callerNode) {
        const calleeArray = Array.from(callees);
        for (const callee of calleeArray) {
          const calleeNode = nodeMap.get(callee);
          if (calleeNode) {
            edges.push({
              source: callerNode.id,
              target: calleeNode.id,
              type: "calls",
              weight: 1.0,
            });
          }
        }
      }
    }

    // Add edges for imports
    const moduleArray = Array.from(importedModules);
    for (const moduleName of moduleArray) {
      const importNode = nodeMap.get(moduleName);
      if (importNode) {
        for (const funcNode of nodes) {
          if (funcNode.type === "function" || funcNode.type === "class") {
            edges.push({
              source: importNode.id,
              target: funcNode.id,
              type: "imports_to",
              weight: 0.5,
            });
          }
        }
      }
    }

    return {
      nodes,
      edges,
      nodeCount: nodes.length,
      edgeCount: edges.length,
    };
  }

  private encodeNodeFeatures(name: string, context: string): number[] {
    // Encode node features as a vector
    // Features: name length, context type, complexity indicators
    const features: number[] = [];

    // Feature 1: Name length (normalized)
    features.push(Math.min(name.length / 50, 1.0));

    // Feature 2: Context type encoding
    if (context.includes("class")) features.push(1.0);
    else if (context.includes("function")) features.push(0.7);
    else if (context.includes("const")) features.push(0.5);
    else features.push(0.3);

    // Feature 3: Complexity (presence of certain patterns)
    const complexity =
      (context.match(/async/g)?.length || 0) * 0.3 +
      (context.match(/await/g)?.length || 0) * 0.2 +
      (context.match(/try|catch/g)?.length || 0) * 0.25;
    features.push(Math.min(complexity / 5, 1.0));

    // Feature 4: Presence of type hints
    features.push(context.includes(":") ? 1.0 : 0.0);

    // Pad to fixed size
    while (features.length < 8) {
      features.push(0.0);
    }

    return features.slice(0, 8);
  }
}

/**
 * GraphNeuralNetwork: The core GNN model
 * Performs message passing, node embedding updates, and inference
 */
export class GraphNeuralNetwork {
  private nodeEmbeddingDim = 16;
  private hiddenDim = 32;
  private outputDim = 4; // Analysis categories

  private model: tf.LayersModel | null = null;
  private nodeEmbeddings: tf.Variable | null = null;
  private messagePassingWeights: tf.Variable | null = null;
  private aggregationWeights: tf.Variable | null = null;
  private outputWeights: tf.Variable | null = null;

  private optimizer = tf.train.adam(0.001);
  private trainingHistory: TrainingMetrics[] = [];

  constructor() {
    this.initializeModel();
  }

  private initializeModel(): void {
    // Initialize learnable parameters
    this.nodeEmbeddings = tf.variable(
      tf.randomNormal([100, this.nodeEmbeddingDim], 0, 0.1)
    );
    this.messagePassingWeights = tf.variable(
      tf.randomNormal([this.nodeEmbeddingDim, this.hiddenDim], 0, 0.1)
    );
    this.aggregationWeights = tf.variable(
      tf.randomNormal([this.hiddenDim, this.nodeEmbeddingDim], 0, 0.1)
    );
    this.outputWeights = tf.variable(
      tf.randomNormal([this.nodeEmbeddingDim, this.outputDim], 0, 0.1)
    );
  }

  /**
   * Forward pass: Analyzes a code graph and produces predictions
   */
  forward(graph: CodeGraph): tf.Tensor {
    return tf.tidy(() => {
      // Build adjacency matrix from edges
      const adjacencyMatrix = this.buildAdjacencyMatrix(graph);

      // Encode node features
      const nodeFeatures = tf.tensor2d(
        graph.nodes.length > 0 ? graph.nodes.map((n) => n.features) : [[0, 0, 0, 0, 0, 0, 0, 0]],
        [Math.max(graph.nodes.length, 1), 8]
      );

      // Message passing: aggregate neighbor information
      // Ensure adjacency matrix and node features have compatible dimensions
      const nodeCount = Math.max(graph.nodes.length, 1);
      const messages = tf.matMul(
        adjacencyMatrix.slice([0, 0], [nodeCount, nodeCount]),
        nodeFeatures
      );
      const messageEmbeddings = tf.matMul(messages, this.messagePassingWeights!);
      const messageActivated = tf.relu(messageEmbeddings);

      // Aggregation: combine messages with node embeddings
      const nodeCount2 = Math.max(graph.nodes.length, 1);
      const selectedEmbeddings = this.nodeEmbeddings!.slice(
        [0, 0],
        [nodeCount2, this.nodeEmbeddingDim]
      );
      const aggregated = tf.matMul(messageActivated, this.aggregationWeights!);
      const updatedEmbeddings = tf.add(selectedEmbeddings, aggregated);

      // Output layer: produce predictions
      // Ensure output layer has correct dimensions
      const predictions = tf.matMul(
        updatedEmbeddings.slice([0, 0], [Math.max(graph.nodes.length, 1), this.nodeEmbeddingDim]),
        this.outputWeights!
      );
      const output = tf.softmax(predictions, 1);

      // Ensure we return a 2D tensor
      return output.shape[0] > 0 ? output : tf.zeros([1, this.outputDim]);
    });
  }

  /**
   * Training step: Learn from a code graph and analysis outcome
   */
  async trainStep(
    graph: CodeGraph,
    targetAnalysis: number[]
  ): Promise<number> {
    let lossValue = 0;
    const loss = await this.optimizer.minimize(() => {
      const predictions = this.forward(graph);
      const target = tf.tensor2d([targetAnalysis], [1, this.outputDim]);

      // Mean squared error loss
      const error = tf.losses.meanSquaredError(target, predictions);
      return error as tf.Scalar;
    });

    if (loss) {
      const data = await loss.data();
      lossValue = data[0];
      loss.dispose();
    }

    return lossValue;
  }

  /**
   * Inference: Analyze code and get predictions with confidence
   */
  async analyze(graph: CodeGraph): Promise<{
    predictions: number[];
    confidence: number;
    analysis: string;
  }> {
    const predictions = this.forward(graph);
    const predArray = await predictions.data();
    const predValues = Array.from(predArray);
    predictions.dispose();

    // Confidence is the max prediction value
    const confidence = Math.max(...predValues);

    // Map predictions to analysis categories
    const categories = [
      "complexity",
      "maintainability",
      "modularity",
      "performance",
    ];
    const topIndex = predValues.indexOf(confidence);
    const analysis = categories[topIndex] || "unknown";

    return {
      predictions: predValues,
      confidence,
      analysis,
    };
  }

  /**
   * Get current weights for persistence
   */
  async getWeights(): Promise<GNNWeights> {
    const nodeEmbData = await this.nodeEmbeddings!.data();
    const msgPassData = await this.messagePassingWeights!.data();
    const aggData = await this.aggregationWeights!.data();
    const outData = await this.outputWeights!.data();

    return {
      nodeEmbeddingWeights: Array.from(nodeEmbData) as any,
      messagePassingWeights: Array.from(msgPassData) as any,
      aggregationWeights: Array.from(aggData) as any,
      outputWeights: Array.from(outData) as any,
    };
  }

  /**
   * Load weights from persistence
   */
  loadWeights(weights: GNNWeights): void {
    if (this.nodeEmbeddings) this.nodeEmbeddings.dispose();
    if (this.messagePassingWeights) this.messagePassingWeights.dispose();
    if (this.aggregationWeights) this.aggregationWeights.dispose();
    if (this.outputWeights) this.outputWeights.dispose();

    this.nodeEmbeddings = tf.variable(
      tf.tensor2d(weights.nodeEmbeddingWeights, [100, this.nodeEmbeddingDim])
    );
    this.messagePassingWeights = tf.variable(
      tf.tensor2d(weights.messagePassingWeights, [
        this.nodeEmbeddingDim,
        this.hiddenDim,
      ])
    );
    this.aggregationWeights = tf.variable(
      tf.tensor2d(weights.aggregationWeights, [
        this.hiddenDim,
        this.nodeEmbeddingDim,
      ])
    );
    this.outputWeights = tf.variable(
      tf.tensor2d(weights.outputWeights, [this.nodeEmbeddingDim, this.outputDim])
    );
  }

  /**
   * Get training history for metrics
   */
  getTrainingHistory(): TrainingMetrics[] {
    return this.trainingHistory;
  }

  /**
   * Record training metrics
   */
  recordMetrics(metrics: TrainingMetrics): void {
    this.trainingHistory.push(metrics);
  }

  /**
   * Dispose resources
   */
  dispose(): void {
    if (this.nodeEmbeddings) this.nodeEmbeddings.dispose();
    if (this.messagePassingWeights) this.messagePassingWeights.dispose();
    if (this.aggregationWeights) this.aggregationWeights.dispose();
    if (this.outputWeights) this.outputWeights.dispose();
  }

  private buildAdjacencyMatrix(graph: CodeGraph): tf.Tensor {
    // Create adjacency matrix from edges
    const size = graph.nodes.length || 1;
    const matrix: number[][] = Array(size)
      .fill(null)
      .map(() => Array(size).fill(0));

    // Map node IDs to indices
    const nodeIndexMap = new Map<string, number>();
    graph.nodes.forEach((node, idx) => {
      nodeIndexMap.set(node.id, idx);
    });

    // Fill adjacency matrix
    for (const edge of graph.edges) {
      const sourceIdx = nodeIndexMap.get(edge.source);
      const targetIdx = nodeIndexMap.get(edge.target);

      if (sourceIdx !== undefined && targetIdx !== undefined) {
        matrix[sourceIdx][targetIdx] = edge.weight || 1.0;
        // Symmetric for undirected relationships
        matrix[targetIdx][sourceIdx] = edge.weight || 1.0;
      }
    }

    return tf.tensor2d(matrix);
  }
}

/**
 * GNNAnalyzer: High-level interface for code analysis
 */
export class GNNAnalyzer {
  private graphBuilder = new CodeGraphBuilder();
  private gnn = new GraphNeuralNetwork();

  async analyzeCode(code: string): Promise<{
    graph: CodeGraph;
    predictions: number[];
    confidence: number;
    analysis: string;
  }> {
    // Build graph from code
    const graph = this.graphBuilder.buildFromCode(code);

    // Run inference
    const result = await this.gnn.analyze(graph);

    return {
      graph,
      predictions: result.predictions,
      confidence: result.confidence,
      analysis: result.analysis,
    };
  }

  async trainOnAnalysis(
    code: string,
    analysisOutcome: number[]
  ): Promise<number> {
    const graph = this.graphBuilder.buildFromCode(code);
    const loss = await this.gnn.trainStep(graph, analysisOutcome);
    return loss;
  }

  async getWeights(): Promise<GNNWeights> {
    return this.gnn.getWeights();
  }

  loadWeights(weights: GNNWeights): void {
    this.gnn.loadWeights(weights);
  }

  getTrainingHistory(): TrainingMetrics[] {
    return this.gnn.getTrainingHistory();
  }

  recordMetrics(metrics: TrainingMetrics): void {
    this.gnn.recordMetrics(metrics);
  }

  dispose(): void {
    this.gnn.dispose();
  }
}
