import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * GNN Model State: Stores trained weights and embeddings for the neural network
 * Each session builds on previous learning
 */
export const gnnModelState = mysqlTable("gnn_model_state", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  /** Serialized TensorFlow.js weights as JSON */
  weights: text("weights").notNull(),
  /** Node embeddings from the latest training session */
  nodeEmbeddings: text("nodeEmbeddings").notNull(),
  /** Training loss from last session */
  lastLoss: varchar("lastLoss", { length: 64 }),
  /** Prediction confidence from last inference */
  lastConfidence: varchar("lastConfidence", { length: 64 }),
  /** Total number of training steps completed */
  totalTrainingSteps: int("totalTrainingSteps").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type GNNModelState = typeof gnnModelState.$inferSelect;
export type InsertGNNModelState = typeof gnnModelState.$inferInsert;

/**
 * Training History: Logs each training session for learning curve analysis
 */
export const trainingHistory = mysqlTable("training_history", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  /** Code analyzed in this session (hash for deduplication) */
  codeHash: varchar("codeHash", { length: 64 }).notNull(),
  /** Loss value after training */
  loss: varchar("loss", { length: 64 }).notNull(),
  /** Prediction confidence */
  confidence: varchar("confidence", { length: 64 }).notNull(),
  /** Number of nodes in the code graph */
  nodeCount: int("nodeCount"),
  /** Number of edges in the code graph */
  edgeCount: int("edgeCount"),
  /** GNN analysis output (JSON) */
  analysisOutput: text("analysisOutput"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type TrainingHistory = typeof trainingHistory.$inferSelect;
export type InsertTrainingHistory = typeof trainingHistory.$inferInsert;

/**
 * Self-Improvement Goals: Autonomous goals set by the GNN based on its own metrics
 */
export const selfImprovementGoals = mysqlTable("self_improvement_goals", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  /** Goal title (e.g., "Improve confidence on recursive patterns") */
  title: text("title").notNull(),
  /** Detailed description of the goal */
  description: text("description"),
  /** What metric the GNN is trying to improve */
  targetMetric: varchar("targetMetric", { length: 64 }).notNull(),
  /** Baseline value when goal was created */
  baselineValue: varchar("baselineValue", { length: 64 }).notNull(),
  /** Target value to achieve */
  targetValue: varchar("targetValue", { length: 64 }).notNull(),
  /** Current progress value */
  currentValue: varchar("currentValue", { length: 64 }),
  /** Status of the goal */
  status: mysqlEnum("status", ["active", "completed", "abandoned"]).default("active"),
  /** When the goal was autonomously set */
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  /** When the goal was completed or abandoned */
  completedAt: timestamp("completedAt"),
});

export type SelfImprovementGoal = typeof selfImprovementGoals.$inferSelect;
export type InsertSelfImprovementGoal = typeof selfImprovementGoals.$inferInsert;

/**
 * Self-Build Proposals: Code upgrade proposals identified by the GNN
 */
export const selfBuildProposals = mysqlTable("self_build_proposals", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  /** What weakness the GNN identified */
  weakness: text("weakness").notNull(),
  /** LLM-generated code proposal for fixing it */
  proposedCode: text("proposedCode"),
  /** Human-readable explanation of the proposal */
  explanation: text("explanation"),
  /** Status: pending, approved, rejected, applied */
  status: mysqlEnum("status", ["pending", "approved", "rejected", "applied"]).default("pending"),
  /** User's feedback or rejection reason */
  userFeedback: text("userFeedback"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  appliedAt: timestamp("appliedAt"),
});

export type SelfBuildProposal = typeof selfBuildProposals.$inferSelect;
export type InsertSelfBuildProposal = typeof selfBuildProposals.$inferInsert;

/**
 * GNN Learning Sessions: Metadata about each training session
 */
export const gnnSessions = mysqlTable("gnn_sessions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  /** Session identifier for grouping related operations */
  sessionId: varchar("sessionId", { length: 64 }).notNull().unique(),
  /** Code analyzed in this session */
  codeInput: text("codeInput"),
  /** Graph structure (nodes and edges) */
  graphStructure: text("graphStructure"),
  /** GNN predictions and confidence scores */
  predictions: text("predictions"),
  /** Training metrics from this session */
  metrics: text("metrics"),
  /** Goals set during this session */
  goalsSet: int("goalsSet").default(0),
  /** Self-build proposals generated */
  proposalsGenerated: int("proposalsGenerated").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type GNNSession = typeof gnnSessions.$inferSelect;
export type InsertGNNSession = typeof gnnSessions.$inferInsert;