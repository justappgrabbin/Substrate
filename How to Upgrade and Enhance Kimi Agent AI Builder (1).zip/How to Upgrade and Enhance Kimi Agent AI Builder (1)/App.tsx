import { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Upload, Settings, Code2, Cpu, 
  Sparkles, CheckCircle, Download, 
  ChevronLeft, Zap, Brain,
  FolderOpen, FileCode, Layers, GitMerge,
  Eye, Package
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { Slider } from '@/components/ui/slider';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { toast } from 'sonner';
import JSZip from 'jszip';
import type { 
  AppStage, FileNode, AnalysisResult, MorphPlan, 
  TransformerConfig, UploadedProject, GeneratedApp 
} from '@/types';
import { FileTreeView } from '@/components/FileTreeView';
import { CodeEditor } from '@/components/CodeEditor';
import { AnalysisPanel } from '@/components/AnalysisPanel';
import { PlanViewer } from '@/components/PlanViewer';
import { useMorphAI } from '@/hooks/useMorphAI';
import './App.css';

const defaultTransformerConfig: TransformerConfig = {
  model: 'morph-v2',
  temperature: 0.7,
  maxTokens: 4096,
  topP: 0.9,
  frequencyPenalty: 0.2,
  presencePenalty: 0.1,
  systemPrompt: `You are MorphForge AI, an expert code synthesis engine. Your task is to:
1. Analyze input code (GNNs, neural networks, or any software components)
2. Identify patterns, dependencies, and integration points
3. Create a unified architecture that combines all inputs
4. Fill gaps with appropriate implementations
5. Generate production-ready code with proper structure`
};

function App() {
  const [stage, setStage] = useState<AppStage>('upload');
  const [config, setConfig] = useState<TransformerConfig>(defaultTransformerConfig);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [uploadedProject, setUploadedProject] = useState<UploadedProject | null>(null);
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [plan, setPlan] = useState<MorphPlan | null>(null);
  const [generatedApp, setGeneratedApp] = useState<GeneratedApp | null>(null);
  const [selectedFile, setSelectedFile] = useState<FileNode | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [codeInput, setCodeInput] = useState('');
  const [activeTab, setActiveTab] = useState('input');
  
  const { analyzeCode, generatePlan, synthesizeApp } = useMorphAI(config);

  const handleZipUpload = useCallback(async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      const zip = await JSZip.loadAsync(file);
      const files: FileNode[] = [];
      
      for (const [path, zipEntry] of Object.entries(zip.files)) {
        if (zipEntry.dir) continue;
        
        const content = await zipEntry.async('string');
        const parts = path.split('/');
        const name = parts[parts.length - 1];
        
        files.push({
          id: Math.random().toString(36).substr(2, 9),
          name,
          type: 'file',
          content,
          path,
          language: getLanguageFromExtension(name)
        });
      }

      const project: UploadedProject = {
        id: Math.random().toString(36).substr(2, 9),
        name: file.name.replace('.zip', ''),
        files,
        rawContent: files.map(f => `// ${f.path}\n${f.content}`).join('\n\n'),
        source: 'zip',
        timestamp: Date.now()
      };

      setUploadedProject(project);
      setCodeInput(project.rawContent);
      toast.success(`Loaded ${files.length} files from ${file.name}`);
    } catch (error) {
      toast.error('Failed to parse ZIP file');
    }
  }, []);

  const handleCodePaste = useCallback(() => {
    if (!codeInput.trim()) {
      toast.error('Please paste some code first');
      return;
    }

    const project: UploadedProject = {
      id: Math.random().toString(36).substr(2, 9),
      name: 'Pasted Code',
      files: [{
        id: Math.random().toString(36).substr(2, 9),
        name: 'main.code',
        type: 'file',
        content: codeInput,
        path: 'main.code',
        language: 'typescript'
      }],
      rawContent: codeInput,
      source: 'paste',
      timestamp: Date.now()
    };

    setUploadedProject(project);
    toast.success('Code loaded successfully');
  }, [codeInput]);

  const handleAnalyze = useCallback(async () => {
    if (!uploadedProject) return;
    
    setIsAnalyzing(true);
    toast.info('AI is analyzing your code...');
    
    try {
      const result = await analyzeCode(uploadedProject.rawContent);
      setAnalysis(result);
      setStage('analyze');
      toast.success('Analysis complete!');
    } catch (error) {
      toast.error('Analysis failed');
    } finally {
      setIsAnalyzing(false);
    }
  }, [uploadedProject, analyzeCode]);

  const handleGeneratePlan = useCallback(async () => {
    if (!analysis) return;
    
    setIsGenerating(true);
    toast.info('Generating morph plan...');
    
    try {
      const newPlan = await generatePlan(analysis, uploadedProject!.files);
      setPlan(newPlan);
      setStage('plan');
      toast.success('Plan generated!');
    } catch (error) {
      toast.error('Plan generation failed');
    } finally {
      setIsGenerating(false);
    }
  }, [analysis, uploadedProject, generatePlan]);

  const handleSynthesize = useCallback(async () => {
    if (!plan) return;
    
    setIsGenerating(true);
    toast.info('Synthesizing your super morph...');
    
    try {
      const app = await synthesizeApp(plan);
      setGeneratedApp(app);
      setStage('review');
      toast.success('Super morph created!');
    } catch (error) {
      toast.error('Synthesis failed');
    } finally {
      setIsGenerating(false);
    }
  }, [plan, synthesizeApp]);

  const handleOfficialize = useCallback(() => {
    if (!generatedApp) return;
    
    const officialApp = { ...generatedApp, status: 'official' as const };
    setGeneratedApp(officialApp);
    setStage('officialize');
    toast.success('App officialized! Ready for export.');
  }, [generatedApp]);

  const handleExport = useCallback(async () => {
    if (!generatedApp) return;
    
    const zip = new JSZip();
    
    const addFilesToZip = (files: FileNode[], currentPath: string = '') => {
      files.forEach(file => {
        if (file.type === 'directory' && file.children) {
          addFilesToZip(file.children, `${currentPath}${file.name}/`);
        } else if (file.content) {
          zip.file(`${currentPath}${file.name}`, file.content);
        }
      });
    };
    
    addFilesToZip(generatedApp.files);
    
    const blob = await zip.generateAsync({ type: 'blob' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${generatedApp.name}-official.zip`;
    a.click();
    URL.revokeObjectURL(url);
    
    toast.success('Exported successfully!');
  }, [generatedApp]);

  const getLanguageFromExtension = (filename: string): string => {
    const ext = filename.split('.').pop()?.toLowerCase();
    const langMap: Record<string, string> = {
      ts: 'typescript', tsx: 'typescript',
      js: 'javascript', jsx: 'javascript',
      py: 'python', rb: 'ruby',
      go: 'go', rs: 'rust',
      java: 'java', kt: 'kotlin',
      cpp: 'cpp', c: 'c', h: 'cpp',
      json: 'json', yaml: 'yaml', yml: 'yaml',
      md: 'markdown', css: 'css', scss: 'scss',
      html: 'html', xml: 'xml'
    };
    return langMap[ext || ''] || 'plaintext';
  };

  const stageProgress = {
    upload: 0,
    analyze: 25,
    plan: 50,
    review: 75,
    officialize: 100
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 text-slate-100">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-slate-950/80 backdrop-blur-xl border-b border-slate-800/50">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-600 to-fuchsia-600 flex items-center justify-center">
              <GitMerge className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="font-bold text-lg leading-tight">MorphForge</h1>
              <p className="text-xs text-slate-400">AI Code Synthesis</p>
            </div>
          </div>
          
          <Sheet open={settingsOpen} onOpenChange={setSettingsOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="relative">
                <Settings className="w-5 h-5" />
                <span className="absolute top-1 right-1 w-2 h-2 bg-violet-500 rounded-full animate-pulse" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-full sm:max-w-lg bg-slate-900 border-slate-800">
              <SheetHeader>
                <SheetTitle className="flex items-center gap-2">
                  <Cpu className="w-5 h-5 text-violet-500" />
                  Transformer Settings
                </SheetTitle>
              </SheetHeader>
              <ScrollArea className="h-[calc(100vh-100px)] mt-6">
                <div className="space-y-6 pr-4">
                  <div className="space-y-3">
                    <Label className="text-slate-300">Model</Label>
                    <select 
                      className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm"
                      value={config.model}
                      onChange={(e) => setConfig({...config, model: e.target.value})}
                    >
                      <option value="morph-v2">Morph V2 (Latest)</option>
                      <option value="morph-v1">Morph V1 (Stable)</option>
                      <option value="code-llama">Code Llama</option>
                      <option value="gpt-4">GPT-4 Turbo</option>
                    </select>
                  </div>

                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <Label className="text-slate-300">Temperature</Label>
                      <span className="text-sm text-violet-400">{config.temperature}</span>
                    </div>
                    <Slider 
                      value={[config.temperature * 100]} 
                      onValueChange={([v]) => setConfig({...config, temperature: v / 100})}
                      max={100}
                      step={1}
                    />
                    <p className="text-xs text-slate-500">Higher = more creative, Lower = more deterministic</p>
                  </div>

                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <Label className="text-slate-300">Max Tokens</Label>
                      <span className="text-sm text-violet-400">{config.maxTokens}</span>
                    </div>
                    <Slider 
                      value={[config.maxTokens / 100]} 
                      onValueChange={([v]) => setConfig({...config, maxTokens: v * 100})}
                      max={80}
                      step={1}
                    />
                  </div>

                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <Label className="text-slate-300">Top P</Label>
                      <span className="text-sm text-violet-400">{config.topP}</span>
                    </div>
                    <Slider 
                      value={[config.topP * 100]} 
                      onValueChange={([v]) => setConfig({...config, topP: v / 100})}
                      max={100}
                      step={1}
                    />
                  </div>

                  <Separator className="bg-slate-800" />

                  <div className="space-y-3">
                    <Label className="text-slate-300">System Prompt</Label>
                    <Textarea 
                      value={config.systemPrompt}
                      onChange={(e) => setConfig({...config, systemPrompt: e.target.value})}
                      className="min-h-[200px] bg-slate-800 border-slate-700 text-sm"
                    />
                  </div>
                </div>
              </ScrollArea>
            </SheetContent>
          </Sheet>
        </div>
        
        {/* Progress Bar */}
        <div className="h-1 bg-slate-800">
          <motion.div 
            className="h-full bg-gradient-to-r from-violet-600 to-fuchsia-600"
            initial={{ width: 0 }}
            animate={{ width: `${stageProgress[stage]}%` }}
            transition={{ duration: 0.5 }}
          />
        </div>
      </header>

      {/* Main Content */}
      <main className="pt-20 pb-24 px-4">
        <AnimatePresence mode="wait">
          {/* Upload Stage */}
          {stage === 'upload' && (
            <motion.div
              key="upload"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="max-w-lg mx-auto space-y-6"
            >
              <div className="text-center space-y-2 py-8">
                <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-violet-600/20 to-fuchsia-600/20 border border-violet-500/30 mb-4">
                  <Sparkles className="w-10 h-10 text-violet-400" />
                </div>
                <h2 className="text-2xl font-bold">Create Your Super Morph</h2>
                <p className="text-slate-400">Paste code or upload ZIPs to synthesize a unified application</p>
              </div>

              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid w-full grid-cols-2 bg-slate-800/50">
                  <TabsTrigger value="input" className="data-[state=active]:bg-violet-600">
                    <Code2 className="w-4 h-4 mr-2" />
                    Paste Code
                  </TabsTrigger>
                  <TabsTrigger value="upload" className="data-[state=active]:bg-violet-600">
                    <Upload className="w-4 h-4 mr-2" />
                    Upload ZIP
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="input" className="mt-4">
                  <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="p-4">
                      <Textarea 
                        placeholder="// Paste your code here...&#10;// Example: Multiple GNN implementations, neural network components, etc."
                        value={codeInput}
                        onChange={(e) => setCodeInput(e.target.value)}
                        className="min-h-[300px] bg-slate-950 border-slate-800 font-mono text-sm resize-none"
                      />
                      <Button 
                        onClick={handleCodePaste}
                        className="w-full mt-4 bg-violet-600 hover:bg-violet-700"
                        disabled={!codeInput.trim()}
                      >
                        <Brain className="w-4 h-4 mr-2" />
                        Load Code
                      </Button>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="upload" className="mt-4">
                  <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="p-4">
                      <label className="flex flex-col items-center justify-center w-full h-48 border-2 border-dashed border-slate-700 rounded-xl bg-slate-950/50 cursor-pointer hover:border-violet-500/50 hover:bg-violet-500/5 transition-all">
                        <div className="flex flex-col items-center justify-center pt-5 pb-6">
                          <Package className="w-12 h-12 text-slate-500 mb-3" />
                          <p className="text-sm text-slate-400">Drop ZIP file or click to browse</p>
                          <p className="text-xs text-slate-600 mt-1">Supports .zip files up to 50MB</p>
                        </div>
                        <input 
                          type="file" 
                          accept=".zip" 
                          className="hidden" 
                          onChange={handleZipUpload}
                        />
                      </label>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>

              {uploadedProject && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                >
                  <Card className="bg-violet-900/20 border-violet-500/30">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <CheckCircle className="w-5 h-5 text-violet-400" />
                          <div>
                            <p className="font-medium">{uploadedProject.name}</p>
                            <p className="text-sm text-slate-400">{uploadedProject.files.length} files loaded</p>
                          </div>
                        </div>
                        <Button 
                          onClick={handleAnalyze}
                          disabled={isAnalyzing}
                          className="bg-violet-600 hover:bg-violet-700"
                        >
                          {isAnalyzing ? (
                            <>
                              <div className="w-4 h-4 mr-2 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                              Analyzing...
                            </>
                          ) : (
                            <>
                              <Zap className="w-4 h-4 mr-2" />
                              Analyze
                            </>
                          )}
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </motion.div>
          )}

          {/* Analyze Stage */}
          {stage === 'analyze' && analysis && (
            <motion.div
              key="analyze"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              className="max-w-lg mx-auto space-y-4"
            >
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold flex items-center gap-2">
                  <Brain className="w-6 h-6 text-violet-400" />
                  Analysis Results
                </h2>
                <Badge variant="outline" className="border-violet-500/50 text-violet-400">
                  {analysis.complexity} complexity
                </Badge>
              </div>

              <AnalysisPanel analysis={analysis} />

              <div className="flex gap-3">
                <Button 
                  variant="outline" 
                  onClick={() => setStage('upload')}
                  className="flex-1 border-slate-700"
                >
                  <ChevronLeft className="w-4 h-4 mr-2" />
                  Back
                </Button>
                <Button 
                  onClick={handleGeneratePlan}
                  disabled={isGenerating}
                  className="flex-1 bg-violet-600 hover:bg-violet-700"
                >
                  {isGenerating ? (
                    <>
                      <div className="w-4 h-4 mr-2 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      Planning...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 mr-2" />
                      Generate Plan
                    </>
                  )}
                </Button>
              </div>
            </motion.div>
          )}

          {/* Plan Stage */}
          {stage === 'plan' && plan && (
            <motion.div
              key="plan"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              className="max-w-lg mx-auto space-y-4"
            >
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold flex items-center gap-2">
                  <Layers className="w-6 h-6 text-violet-400" />
                  Morph Plan
                </h2>
                <Badge className="bg-violet-600">
                  {Math.round(plan.confidence * 100)}% confidence
                </Badge>
              </div>

              <PlanViewer plan={plan} />

              <div className="flex gap-3">
                <Button 
                  variant="outline" 
                  onClick={() => setStage('analyze')}
                  className="flex-1 border-slate-700"
                >
                  <ChevronLeft className="w-4 h-4 mr-2" />
                  Back
                </Button>
                <Button 
                  onClick={handleSynthesize}
                  disabled={isGenerating}
                  className="flex-1 bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-700 hover:to-fuchsia-700"
                >
                  {isGenerating ? (
                    <>
                      <div className="w-4 h-4 mr-2 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      Synthesizing...
                    </>
                  ) : (
                    <>
                      <GitMerge className="w-4 h-4 mr-2" />
                      Create Super Morph
                    </>
                  )}
                </Button>
              </div>
            </motion.div>
          )}

          {/* Review Stage */}
          {stage === 'review' && generatedApp && (
            <motion.div
              key="review"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              className="h-[calc(100vh-140px)]"
            >
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold flex items-center gap-2">
                  <Eye className="w-6 h-6 text-violet-400" />
                  Review
                </h2>
                <div className="flex gap-2">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => setStage('plan')}
                    className="border-slate-700"
                  >
                    <ChevronLeft className="w-4 h-4 mr-1" />
                    Back
                  </Button>
                  <Button 
                    size="sm"
                    onClick={handleOfficialize}
                    className="bg-violet-600 hover:bg-violet-700"
                  >
                    <CheckCircle className="w-4 h-4 mr-1" />
                    Officialize
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 h-[calc(100%-60px)]">
                <Card className="lg:col-span-1 bg-slate-900/50 border-slate-800 overflow-hidden">
                  <CardHeader className="p-3 border-b border-slate-800">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <FolderOpen className="w-4 h-4" />
                      File Structure
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-0">
                    <ScrollArea className="h-[calc(100%-50px)]">
                      <FileTreeView 
                        files={generatedApp.files} 
                        onSelect={setSelectedFile}
                        selectedId={selectedFile?.id}
                      />
                    </ScrollArea>
                  </CardContent>
                </Card>

                <Card className="lg:col-span-2 bg-slate-900/50 border-slate-800 overflow-hidden">
                  <CardHeader className="p-3 border-b border-slate-800">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <FileCode className="w-4 h-4" />
                      {selectedFile ? selectedFile.name : 'Select a file'}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-0">
                    {selectedFile ? (
                      <CodeEditor 
                        code={selectedFile.content || ''} 
                        language={selectedFile.language || 'typescript'}
                        readOnly
                      />
                    ) : (
                      <div className="flex items-center justify-center h-64 text-slate-500">
                        <p>Select a file to view its contents</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </motion.div>
          )}

          {/* Officialize Stage */}
          {stage === 'officialize' && generatedApp && (
            <motion.div
              key="officialize"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="max-w-lg mx-auto text-center space-y-6 py-12"
            >
              <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-gradient-to-br from-green-500 to-emerald-600">
                <CheckCircle className="w-12 h-12 text-white" />
              </div>
              
              <div>
                <h2 className="text-3xl font-bold mb-2">Super Morph Complete!</h2>
                <p className="text-slate-400">Your unified application has been officialized</p>
              </div>

              <Card className="bg-slate-900/50 border-slate-800">
                <CardContent className="p-6">
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div>
                      <p className="text-2xl font-bold text-violet-400">
                        {generatedApp.files.length}
                      </p>
                      <p className="text-xs text-slate-500">Files</p>
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-fuchsia-400">
                        {generatedApp.plan.steps.length}
                      </p>
                      <p className="text-xs text-slate-500">Steps</p>
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-emerald-400">
                        {Math.round(generatedApp.plan.confidence * 100)}%
                      </p>
                      <p className="text-xs text-slate-500">Confidence</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div className="space-y-3">
                <Button 
                  onClick={handleExport}
                  className="w-full bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-700 hover:to-fuchsia-700 h-12"
                >
                  <Download className="w-5 h-5 mr-2" />
                  Export as ZIP
                </Button>
                
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setStage('upload');
                    setUploadedProject(null);
                    setAnalysis(null);
                    setPlan(null);
                    setGeneratedApp(null);
                    setSelectedFile(null);
                    setCodeInput('');
                  }}
                  className="w-full border-slate-700"
                >
                  <Sparkles className="w-4 h-4 mr-2" />
                  Create Another Morph
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-slate-950/90 backdrop-blur-xl border-t border-slate-800/50 px-4 py-2">
        <div className="flex justify-around max-w-lg mx-auto">
          {[
            { id: 'upload', icon: Upload, label: 'Upload' },
            { id: 'analyze', icon: Brain, label: 'Analyze' },
            { id: 'plan', icon: Layers, label: 'Plan' },
            { id: 'review', icon: Eye, label: 'Review' },
            { id: 'officialize', icon: CheckCircle, label: 'Done' },
          ].map((item) => {
            const Icon = item.icon;
            const isActive = stage === item.id;
            const isDisabled = 
              (item.id === 'analyze' && !uploadedProject) ||
              (item.id === 'plan' && !analysis) ||
              (item.id === 'review' && !plan) ||
              (item.id === 'officialize' && !generatedApp);
            
            return (
              <button
                key={item.id}
                disabled={isDisabled}
                onClick={() => setStage(item.id as AppStage)}
                className={`flex flex-col items-center gap-1 p-2 rounded-lg transition-all ${
                  isActive 
                    ? 'text-violet-400' 
                    : isDisabled 
                      ? 'text-slate-700' 
                      : 'text-slate-500 hover:text-slate-300'
                }`}
              >
                <Icon className={`w-5 h-5 ${isActive ? 'scale-110' : ''}`} />
                <span className="text-[10px]">{item.label}</span>
                {isActive && (
                  <motion.div 
                    layoutId="activeTab"
                    className="absolute -top-1 w-8 h-1 bg-violet-500 rounded-full"
                  />
                )}
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}

export default App;
