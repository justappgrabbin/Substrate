/**
 * GNN Router: tRPC procedures for neural network analysis and learning
 */

import { z } from "zod";
import { protectedProcedure, publicProcedure, router } from "../_core/trpc";
import { getDb } from "../db";
import { GNNAnalyzer } from "../gnn/core";
import { GoalEngine } from "../gnn/goalEngine";
import { gnnModelState, trainingHistory, gnnSessions, selfImprovementGoals } from "../../drizzle/schema";
import { eq } from "drizzle-orm";
import { nanoid } from "nanoid";

// Initialize GNN and Goal Engine (would be per-user in production)
const gnnAnalyzer = new GNNAnalyzer();
const goalEngine = new GoalEngine();

export const gnnRouter = router({
  /**
   * Analyze code with the GNN
   */
  analyzeCode: protectedProcedure
    .input(
      z.object({
        code: z.string().min(1),
      })
    )
    .mutation(async ({ input, ctx }) => {
      try {
        const result = await gnnAnalyzer.analyzeCode(input.code);

        // Store session data
        const db = await getDb();
        if (db) {
          const sessionId = nanoid();
          await db.insert(gnnSessions).values({
            userId: ctx.user.id,
            sessionId,
            codeInput: input.code,
            graphStructure: JSON.stringify({
              nodes: result.graph.nodes,
              edges: result.graph.edges,
            }),
            predictions: JSON.stringify(result.predictions),
            metrics: JSON.stringify({
              confidence: result.confidence,
              nodeCount: result.graph.nodeCount,
              edgeCount: result.graph.edgeCount,
            }),
          });
        }

        return {
          success: true,
          analysis: {
            summary: `GNN analyzed ${result.graph.nodeCount} nodes and ${result.graph.edgeCount} edges`,
            predictions: result.predictions,
            confidence: result.confidence,
            analysis: result.analysis,
            nodeCount: result.graph.nodeCount,
            edgeCount: result.graph.edgeCount,
          },
        };
      } catch (error) {
        console.error("GNN analysis error:", error);
        return {
          success: false,
          error: "Analysis failed",
        };
      }
    }),

  /**
   * Get autonomous goals set by the GNN
   */
  getGoals: protectedProcedure.query(async ({ ctx }) => {
    try {
      const db = await getDb();
      if (!db) return { goals: [] };

      const goals = await db
        .select()
        .from(selfImprovementGoals)
        .where(eq(selfImprovementGoals.userId, ctx.user.id));

      return {
        goals: goals.map((g) => ({
          id: g.id,
          title: g.title,
          description: g.description,
          targetMetric: g.targetMetric,
          baselineValue: parseFloat(g.baselineValue),
          targetValue: parseFloat(g.targetValue),
          currentValue: g.currentValue ? parseFloat(g.currentValue) : 0,
          status: g.status,
          progress: g.currentValue
            ? Math.min(
                100,
                Math.max(
                  0,
                  ((parseFloat(g.currentValue) - parseFloat(g.baselineValue)) /
                    (parseFloat(g.targetValue) - parseFloat(g.baselineValue))) *
                    100
                )
              )
            : 0,
        })),
      };
    } catch (error) {
      console.error("Error fetching goals:", error);
      return { goals: [] };
    }
  }),

  /**
   * Update goal progress
   */
  updateGoalProgress: protectedProcedure
    .input(
      z.object({
        goalId: z.number(),
        currentValue: z.number(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      try {
        const db = await getDb();
        if (!db) return { success: false };

        await db
          .update(selfImprovementGoals)
          .set({
            currentValue: input.currentValue.toString(),
          })
          .where(eq(selfImprovementGoals.id, input.goalId));

        return { success: true };
      } catch (error) {
        console.error("Error updating goal:", error);
        return { success: false };
      }
    }),

  /**
   * Get training history
   */
  getTrainingHistory: protectedProcedure.query(async ({ ctx }) => {
    try {
      const db = await getDb();
      if (!db) return { history: [] };

      const history = await db
        .select()
        .from(trainingHistory)
        .where(eq(trainingHistory.userId, ctx.user.id));

      return {
        history: history.map((h) => ({
          codeHash: h.codeHash,
          loss: parseFloat(h.loss),
          confidence: parseFloat(h.confidence),
          nodeCount: h.nodeCount || 0,
          edgeCount: h.edgeCount || 0,
          createdAt: h.createdAt,
        })),
      };
    } catch (error) {
      console.error("Error fetching training history:", error);
      return { history: [] };
    }
  }),

  /**
   * Get GNN model state
   */
  getModelState: protectedProcedure.query(async ({ ctx }) => {
    try {
      const db = await getDb();
      if (!db) return { state: null };

      const state = await db
        .select()
        .from(gnnModelState)
        .where(eq(gnnModelState.userId, ctx.user.id))
        .limit(1);

      if (state.length === 0) {
        return { state: null };
      }

      return {
        state: {
          lastLoss: state[0].lastLoss,
          lastConfidence: state[0].lastConfidence,
          totalTrainingSteps: state[0].totalTrainingSteps,
          updatedAt: state[0].updatedAt,
        },
      };
    } catch (error) {
      console.error("Error fetching model state:", error);
      return { state: null };
    }
  }),

  /**
   * Get GNN insights for self-building
   */
  getSelfBuildingInsights: protectedProcedure.query(async ({ ctx }) => {
    try {
      const insights = goalEngine.getSelfBuildingInsights();
      return { insights };
    } catch (error) {
      console.error("Error getting insights:", error);
      return { insights: [] };
    }
  }),
});
