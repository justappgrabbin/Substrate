/**
 * GNN Core Tests: Comprehensive test suite for neural network functionality
 */

import { describe, it, expect, beforeEach, afterEach } from "vitest";
import { CodeGraphBuilder, GraphNeuralNetwork, GNNAnalyzer } from "./core";

describe("CodeGraphBuilder", () => {
  let builder: CodeGraphBuilder;

  beforeEach(() => {
    builder = new CodeGraphBuilder();
  });

  it("should extract functions from code", () => {
    const code = `
      function hello() { return "world"; }
      const greet = () => "hi";
      class MyClass {}
    `;

    const graph = builder.buildFromCode(code);

    expect(graph.nodes.length).toBeGreaterThan(0);
    expect(graph.nodes.some((n) => n.type === "function")).toBe(true);
  });

  it("should extract imports from code", () => {
    const code = `
      import React from 'react';
      import { useState } from 'react';
      import axios from 'axios';
    `;

    const graph = builder.buildFromCode(code);

    expect(graph.nodes.some((n) => n.type === "import")).toBe(true);
  });

  it("should encode node features correctly", () => {
    const code = "function test() {}";
    const graph = builder.buildFromCode(code);

    expect(graph.nodes.length).toBeGreaterThan(0);
    const node = graph.nodes[0];
    expect(node.features).toBeDefined();
    expect(node.features.length).toBe(8);
    expect(node.features.every((f) => f >= 0 && f <= 1)).toBe(true);
  });

  it("should handle empty code gracefully", () => {
    const graph = builder.buildFromCode("");

    expect(graph.nodes).toBeDefined();
    expect(graph.edges).toBeDefined();
    expect(graph.nodeCount).toBe(0);
  });

  it("should create edges for function calls", () => {
    const code = `
      function caller() { callee(); }
      function callee() { return 42; }
    `;

    const graph = builder.buildFromCode(code);

    expect(graph.edges).toBeDefined();
    expect(Array.isArray(graph.edges)).toBe(true);
  });
});

describe("GraphNeuralNetwork", () => {
  let gnn: GraphNeuralNetwork;

  beforeEach(() => {
    gnn = new GraphNeuralNetwork();
  });

  it("should initialize with learnable parameters", () => {
    const history = gnn.getTrainingHistory();
    expect(history).toBeDefined();
    expect(Array.isArray(history)).toBe(true);
  });

  it("should record training metrics", () => {
    const metrics = {
      loss: 0.5,
      confidence: 0.85,
      nodeCount: 10,
      edgeCount: 15,
      timestamp: Date.now(),
    };

    gnn.recordMetrics(metrics);
    const history = gnn.getTrainingHistory();

    expect(history.length).toBe(1);
    expect(history[0].loss).toBe(0.5);
    expect(history[0].confidence).toBe(0.85);
  });

  it("should record multiple metrics in sequence", () => {
    const metrics1 = {
      loss: 0.5,
      confidence: 0.85,
      nodeCount: 10,
      edgeCount: 15,
      timestamp: Date.now(),
    };

    const metrics2 = {
      loss: 0.4,
      confidence: 0.90,
      nodeCount: 12,
      edgeCount: 18,
      timestamp: Date.now() + 1000,
    };

    gnn.recordMetrics(metrics1);
    gnn.recordMetrics(metrics2);
    const history = gnn.getTrainingHistory();

    expect(history.length).toBe(2);
    expect(history[0].loss).toBe(0.5);
    expect(history[1].loss).toBe(0.4);
  });

  it("should dispose resources without error", () => {
    expect(() => {
      gnn.dispose();
    }).not.toThrow();
  });
});

describe("GNNAnalyzer", () => {
  let analyzer: GNNAnalyzer;

  beforeEach(() => {
    analyzer = new GNNAnalyzer();
  });

  it("should create analyzer instance", () => {
    expect(analyzer).toBeDefined();
  });

  it("should get training history", () => {
    const history = analyzer.getTrainingHistory();

    expect(Array.isArray(history)).toBe(true);
    expect(history.length).toBe(0);
  });

  it("should record metrics", () => {
    const metrics = {
      loss: 0.5,
      confidence: 0.85,
      nodeCount: 10,
      edgeCount: 15,
      timestamp: Date.now(),
    };

    analyzer.recordMetrics(metrics);
    const history = analyzer.getTrainingHistory();

    expect(history.length).toBe(1);
    expect(history[0].confidence).toBe(0.85);
  });

  it("should dispose without error", () => {
    expect(() => {
      analyzer.dispose();
    }).not.toThrow();
  });
});

describe("GNN Integration", () => {
  let analyzer: GNNAnalyzer;

  beforeEach(() => {
    analyzer = new GNNAnalyzer();
  });

  it("should initialize analyzer without error", () => {
    expect(analyzer).toBeDefined();
    expect(analyzer.getTrainingHistory).toBeDefined();
  });

  it("should handle graph building for various code patterns", () => {
    const builder = new CodeGraphBuilder();

    const patterns = [
      "const x = 1;",
      "function f() {}",
      "class C {}",
      "import React from 'react';",
      "async function test() { await something(); }",
    ];

    for (const code of patterns) {
      const graph = builder.buildFromCode(code);
      expect(graph).toBeDefined();
      expect(graph.nodes).toBeDefined();
      expect(graph.edges).toBeDefined();
    }
  });

  afterEach(() => {
    analyzer.dispose();
  });
});
