/**
 * Proposal Router: Manage LLM-generated code proposals
 */

import { protectedProcedure, router } from "../_core/trpc";
import { getDb } from "../db";
import { selfBuildProposals } from "../../drizzle/schema";
import { eq, desc } from "drizzle-orm";
import { invokeLLM } from "../_core/llm";
import {
  executeProposal,
  validateProposal,
  getProposalHistory,
  rollbackProposal,
  getExecutionStats,
} from "../gnn/proposalExecutor";

export const proposalRouter = router({
  /**
   * Generate proposals based on GNN analysis
   */
  generate: protectedProcedure
    .input((val: unknown) => {
      const input = val as {
        analysis: string;
        currentCode: string;
        goals: string[];
      };
      return input;
    })
    .mutation(async ({ ctx, input }) => {
      try {
        const db = await getDb();
        if (!db) {
          return {
            success: false,
            proposals: [],
            error: "Database not available",
          };
        }

        // Call LLM to generate proposals
        const response = await invokeLLM({
          messages: [
            {
              role: "system",
              content: `You are a code improvement expert. Based on the GNN analysis and current code, generate 2-3 specific, actionable code improvement proposals. Each proposal should include:
1. A clear title
2. Description of the improvement
3. The reasoning behind it
4. The exact code changes (before and after)

Format your response as a JSON array of proposals.`,
            },
            {
              role: "user",
              content: `GNN Analysis: ${input.analysis}

Current Code:
${input.currentCode}

Goals to achieve:
${input.goals.join("\n")}

Generate improvement proposals as JSON array.`,
            },
          ],
          response_format: {
            type: "json_schema",
            json_schema: {
              name: "proposals",
              strict: true,
              schema: {
                type: "object",
                properties: {
                  proposals: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        title: { type: "string" },
                        description: { type: "string" },
                        reasoning: { type: "string" },
                        beforeCode: { type: "string" },
                        afterCode: { type: "string" },
                      },
                      required: [
                        "title",
                        "description",
                        "reasoning",
                        "beforeCode",
                        "afterCode",
                      ],
                      additionalProperties: false,
                    },
                  },
                },
                required: ["proposals"],
                additionalProperties: false,
              },
            },
          },
        });

        // Parse LLM response
        let proposalsData: any[] = [];
        try {
          const content = response.choices[0]?.message?.content;
          if (content && typeof content === "string") {
            const parsed = JSON.parse(content);
            proposalsData = parsed.proposals || [];
          }
        } catch (e) {
          console.error("Failed to parse LLM response:", e);
          return {
            success: false,
            proposals: [],
            error: "Failed to parse LLM response",
          };
        }

        // Save proposals to database
        const savedProposals = [];
        for (const proposal of proposalsData) {
          const result = await db.insert(selfBuildProposals).values({
            userId: ctx.user.id,
            weakness: proposal.title,
            proposedCode: proposal.afterCode,
            explanation: `${proposal.description}\n\nReasoning: ${proposal.reasoning}`,
            status: "pending",
          });

          const proposalId = (result as any)[0]?.insertId || Date.now();
          savedProposals.push({
            id: String(proposalId),
            title: proposal.title,
            description: proposal.description,
            reasoning: proposal.reasoning,
            beforeCode: proposal.beforeCode,
            afterCode: proposal.afterCode,
            impact: "medium" as const,
            category: "code-improvement",
            status: "pending",
            createdAt: new Date(),
          });
        }

        return {
          success: true,
          proposals: savedProposals,
          error: null,
        };
      } catch (error) {
        console.error("Error generating proposals:", error);
        return {
          success: false,
          proposals: [],
          error: error instanceof Error ? error.message : "Unknown error",
        };
      }
    }),

  /**
   * Get all proposals for user
   */
  getAll: protectedProcedure.query(async ({ ctx }) => {
    try {
      const db = await getDb();
      if (!db) return { proposals: [], error: "Database not available" };

      const proposals = await db
        .select()
        .from(selfBuildProposals)
        .where(eq(selfBuildProposals.userId, ctx.user.id))
        .orderBy(desc(selfBuildProposals.createdAt));

      return {
        proposals: proposals.map((p: any) => ({
          id: String(p.id),
          title: p.weakness,
          description: p.explanation || "",
          reasoning: p.explanation || "",
          beforeCode: "",
          afterCode: p.proposedCode || "",
          impact: "medium" as const,
          category: "code-improvement",
          status: p.status,
          createdAt: p.createdAt,
        })),
        error: null,
      };
    } catch (error) {
      console.error("Error fetching proposals:", error);
      return {
        proposals: [],
        error: error instanceof Error ? error.message : "Unknown error",
      };
    }
  }),

  /**
   * Get pending proposals
   */
  getPending: protectedProcedure.query(async ({ ctx }) => {
    try {
      const db = await getDb();
      if (!db) return { proposals: [], error: "Database not available" };

      const proposals = await db
        .select()
        .from(selfBuildProposals)
        .where(eq(selfBuildProposals.userId, ctx.user.id))
        .orderBy(desc(selfBuildProposals.createdAt));

      return {
        proposals: proposals
          .filter((p: any) => p.status === "pending")
          .map((p: any) => ({
            id: String(p.id),
            title: p.weakness,
            description: p.explanation || "",
            reasoning: p.explanation || "",
            beforeCode: "",
            afterCode: p.proposedCode || "",
            impact: "medium" as const,
            category: "code-improvement",
            status: p.status,
            createdAt: p.createdAt,
          })),
        error: null,
      };
    } catch (error) {
      console.error("Error fetching pending proposals:", error);
      return {
        proposals: [],
        error: error instanceof Error ? error.message : "Unknown error",
      };
    }
  }),

  /**
   * Approve a proposal
   */
  approve: protectedProcedure
    .input((val: unknown) => {
      const input = val as { proposalId: string };
      return input;
    })
    .mutation(async ({ ctx, input }) => {
      try {
        const db = await getDb();
        if (!db) {
          return { success: false, error: "Database not available" };
        }

        await db
          .update(selfBuildProposals)
          .set({ status: "approved" })
          .where(eq(selfBuildProposals.id, parseInt(input.proposalId)));

        return { success: true, error: null };
      } catch (error) {
        console.error("Error approving proposal:", error);
        return {
          success: false,
          error: error instanceof Error ? error.message : "Unknown error",
        };
      }
    }),

  /**
   * Reject a proposal
   */
  reject: protectedProcedure
    .input((val: unknown) => {
      const input = val as { proposalId: string };
      return input;
    })
    .mutation(async ({ ctx, input }) => {
      try {
        const db = await getDb();
        if (!db) {
          return { success: false, error: "Database not available" };
        }

        await db
          .update(selfBuildProposals)
          .set({ status: "rejected" })
          .where(eq(selfBuildProposals.id, parseInt(input.proposalId)));

        return { success: true, error: null };
      } catch (error) {
        console.error("Error rejecting proposal:", error);
        return {
          success: false,
          error: error instanceof Error ? error.message : "Unknown error",
        };
      }
    }),

  /**
   * Execute/Apply a proposal with validation
   */
  execute: protectedProcedure
    .input((val: unknown) => {
      const input = val as { proposalId: string; proposedCode: string };
      return input;
    })
    .mutation(async ({ ctx, input }) => {
      try {
        const result = await executeProposal(
          input.proposalId,
          ctx.user.id,
          input.proposedCode
        );

        if (!result.success) {
          return {
            success: false,
            error: result.errors?.join(", ") || "Execution failed",
          };
        }

        return { success: true, error: null };
      } catch (error) {
        console.error("Error executing proposal:", error);
        return {
          success: false,
          error: error instanceof Error ? error.message : "Unknown error",
        };
      }
    }),

  /**
   * Validate a proposal before execution
   */
  validate: protectedProcedure
    .input((val: unknown) => {
      const input = val as { code: string };
      return input;
    })
    .query(async ({ input }) => {
      const validation = await validateProposal(input.code);
      return validation;
    }),

  /**
   * Get execution history for a proposal
   */
  getHistory: protectedProcedure
    .input((val: unknown) => {
      const input = val as { proposalId: string };
      return input;
    })
    .query(async ({ ctx, input }) => {
      const history = await getProposalHistory(input.proposalId, ctx.user.id);
      return { history, error: null };
    }),

  /**
   * Rollback a proposal execution
   */
  rollback: protectedProcedure
    .input((val: unknown) => {
      const input = val as { proposalId: string };
      return input;
    })
    .mutation(async ({ ctx, input }) => {
      const result = await rollbackProposal(input.proposalId, ctx.user.id);
      return result;
    }),

  /**
   * Get execution statistics
   */
  getStats: protectedProcedure.query(async ({ ctx }) => {
    const stats = await getExecutionStats(ctx.user.id);
    return { stats, error: null };
  }),
});
