/**
 * Tests for proposal executor and validation
 */

import { describe, it, expect } from "vitest";
import {
  validateProposal,
  getExecutionStats,
} from "./proposalExecutor";

describe("Proposal Executor", () => {
  describe("validateProposal", () => {
    it("should validate correct JavaScript code", async () => {
      const code = `
        function add(a, b) {
          return a + b;
        }
        const result = add(2, 3);
      `;
      const result = await validateProposal(code);
      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    it("should reject code with syntax errors", async () => {
      const code = `
        function broken(a, b {
          return a + b;
        }
      `;
      const result = await validateProposal(code);
      expect(result.valid).toBe(false);
      expect(result.errors.length).toBeGreaterThan(0);
    });

    it("should reject code with eval()", async () => {
      const code = `
        const userCode = "alert('xss')";
        eval(userCode);
      `;
      const result = await validateProposal(code);
      expect(result.valid).toBe(false);
      expect(result.errors.some((e) => e.includes("eval"))).toBe(true);
    });

    it("should reject code with Function constructor", async () => {
      const code = `
        const fn = new Function('return 42');
      `;
      const result = await validateProposal(code);
      expect(result.valid).toBe(false);
      expect(result.errors.some((e) => e.includes("Function"))).toBe(true);
    });

    it("should reject code with process.exit", async () => {
      const code = `
        if (error) {
          process.exit(1);
        }
      `;
      const result = await validateProposal(code);
      expect(result.valid).toBe(false);
      expect(result.errors.some((e) => e.includes("process.exit"))).toBe(true);
    });

    it("should reject code with require()", async () => {
      const code = `
        const fs = require('fs');
      `;
      const result = await validateProposal(code);
      expect(result.valid).toBe(false);
      expect(result.errors.some((e) => e.includes("require"))).toBe(true);
    });

    it("should validate arrow functions", async () => {
      const code = `
        const multiply = (a, b) => a * b;
        const result = multiply(3, 4);
      `;
      const result = await validateProposal(code);
      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    it("should validate async functions", async () => {
      const code = `
        async function fetchData() {
          const response = await fetch('/api/data');
          return response.json();
        }
      `;
      const result = await validateProposal(code);
      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    it("should validate class definitions", async () => {
      const code = `
        class Calculator {
          add(a, b) {
            return a + b;
          }
        }
        const calc = new Calculator();
      `;
      const result = await validateProposal(code);
      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });
  });

  describe("getExecutionStats", () => {
    it("should return default stats when database is unavailable", async () => {
      const stats = await getExecutionStats(999);
      expect(stats.totalExecuted).toBe(0);
      expect(stats.successfulExecutions).toBe(0);
      expect(stats.failedExecutions).toBe(0);
      expect(stats.averageValidationTime).toBe(0);
    });

    it("should have correct stat properties", async () => {
      const stats = await getExecutionStats(1);
      expect(stats).toHaveProperty("totalExecuted");
      expect(stats).toHaveProperty("successfulExecutions");
      expect(stats).toHaveProperty("failedExecutions");
      expect(stats).toHaveProperty("averageValidationTime");
    });
  });
});
