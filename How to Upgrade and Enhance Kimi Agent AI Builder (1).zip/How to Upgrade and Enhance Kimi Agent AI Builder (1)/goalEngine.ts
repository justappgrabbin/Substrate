/**
 * Goal Engine: Autonomous goal setting powered by GNN metrics
 * The neural network evaluates its own performance and sets self-improvement goals
 */

import { TrainingMetrics } from "./core";

export interface Goal {
  id: string;
  title: string;
  description: string;
  targetMetric: "confidence" | "loss" | "complexity_handling" | "speed";
  baselineValue: number;
  targetValue: number;
  currentValue: number;
  status: "active" | "completed" | "abandoned";
  createdAt: Date;
  completedAt?: Date;
  progress: number; // 0-100
}

export interface GoalEvaluationResult {
  shouldSetNewGoal: boolean;
  newGoals: Goal[];
  completedGoals: Goal[];
  insights: string[];
}

/**
 * GoalEngine: Analyzes GNN metrics and autonomously sets goals
 */
export class GoalEngine {
  private goals: Map<string, Goal> = new Map();
  private metricsHistory: TrainingMetrics[] = [];
  private goalIdCounter = 0;

  /**
   * Evaluate metrics and determine if new goals should be set
   */
  evaluateMetrics(
    newMetrics: TrainingMetrics,
    recentHistory: TrainingMetrics[]
  ): GoalEvaluationResult {
    this.metricsHistory.push(newMetrics);
    const newGoals: Goal[] = [];
    const completedGoals: Goal[] = [];
    const insights: string[] = [];

    // Check if existing goals are completed
    const goalEntries = Array.from(this.goals.entries());
    for (const [goalId, goal] of goalEntries) {
      if (goal.status === "active") {
        goal.currentValue = this.getCurrentMetricValue(goal.targetMetric);
        goal.progress = this.calculateProgress(goal);

        if (this.isGoalCompleted(goal)) {
          goal.status = "completed";
          goal.completedAt = new Date();
          completedGoals.push(goal);
          insights.push(
            `✅ Goal completed: ${goal.title} (${goal.currentValue.toFixed(3)})`
          );
        }
      }
    }

    // Analyze trends to set new goals
    if (recentHistory.length >= 3) {
      const trend = this.analyzeTrend(recentHistory);

      // Goal 1: Improve confidence if trending down
      if (trend.confidenceTrend < -0.05 && !this.hasGoal("confidence")) {
        const goal = this.createGoal(
          "Improve Prediction Confidence",
          "The GNN's confidence has been declining. Improve by training on more diverse code patterns.",
          "confidence",
          newMetrics.confidence,
          newMetrics.confidence * 1.15
        );
        newGoals.push(goal);
        insights.push(
          `📈 New goal: Improve confidence from ${newMetrics.confidence.toFixed(3)}`
        );
      }

      // Goal 2: Reduce loss if it's increasing
      if (trend.lossTrend > 0.1 && !this.hasGoal("loss")) {
        const goal = this.createGoal(
          "Reduce Training Loss",
          "Training loss is increasing. Optimize the model architecture.",
          "loss",
          newMetrics.loss,
          newMetrics.loss * 0.7
        );
        newGoals.push(goal);
        insights.push(
          `📉 New goal: Reduce loss from ${newMetrics.loss.toFixed(3)}`
        );
      }

      // Goal 3: Handle more complex graphs
      if (
        newMetrics.nodeCount > 50 &&
        !this.hasGoal("complexity_handling")
      ) {
        const goal = this.createGoal(
          "Handle Complex Code Graphs",
          "Successfully analyze code with 100+ nodes and 150+ edges.",
          "complexity_handling",
          newMetrics.nodeCount,
          100
        );
        newGoals.push(goal);
        insights.push(
          `🧠 New goal: Handle graphs with 100+ nodes (current: ${newMetrics.nodeCount})`
        );
      }

      // Goal 4: Improve inference speed
      if (this.metricsHistory.length >= 5) {
        const avgSpeed = this.calculateAverageInferenceTime();
        if (avgSpeed > 100 && !this.hasGoal("speed")) {
          const goal = this.createGoal(
            "Improve Inference Speed",
            "Optimize the forward pass to run in under 50ms.",
            "speed",
            avgSpeed,
            50
          );
          newGoals.push(goal);
          insights.push(
            `⚡ New goal: Improve speed from ${avgSpeed.toFixed(0)}ms`
          );
        }
      }
    }

    // Add new goals to tracking
    for (const goal of newGoals) {
      this.goals.set(goal.id, goal);
    }

    return {
      shouldSetNewGoal: newGoals.length > 0,
      newGoals,
      completedGoals,
      insights,
    };
  }

  /**
   * Get all active goals
   */
  getActiveGoals(): Goal[] {
    return Array.from(this.goals.values()).filter((g) => g.status === "active");
  }

  /**
   * Get all goals
   */
  getAllGoals(): Goal[] {
    return Array.from(this.goals.values());
  }

  /**
   * Update goal progress
   */
  updateGoalProgress(goalId: string, currentValue: number): void {
    const goal = this.goals.get(goalId);
    if (goal) {
      goal.currentValue = currentValue;
      goal.progress = this.calculateProgress(goal);

      if (this.isGoalCompleted(goal)) {
        goal.status = "completed";
        goal.completedAt = new Date();
      }
    }
  }

  /**
   * Mark goal as abandoned
   */
  abandonGoal(goalId: string): void {
    const goal = this.goals.get(goalId);
    if (goal) {
      goal.status = "abandoned";
    }
  }

  /**
   * Get insights for self-building
   */
  getSelfBuildingInsights(): string[] {
    const insights: string[] = [];

    // Analyze goal completion rate
    const allGoals = Array.from(this.goals.values());
    const completedCount = allGoals.filter((g) => g.status === "completed")
      .length;
    const completionRate = allGoals.length > 0 ? completedCount / allGoals.length : 0;

    if (completionRate > 0.7) {
      insights.push(
        "🎯 High goal completion rate. Consider increasing goal difficulty."
      );
    } else if (completionRate < 0.3 && allGoals.length > 0) {
      insights.push(
        "📊 Low goal completion rate. Goals may be too ambitious. Consider architectural improvements."
      );
    }

    // Analyze confidence trends
    if (this.metricsHistory.length >= 5) {
      const recentConfidence = this.metricsHistory.slice(-5).map((m) => m.confidence);
      const confidenceVariance =
        recentConfidence.reduce((sum, c) => sum + c, 0) / recentConfidence.length;

      if (confidenceVariance < 0.5) {
        insights.push(
          "⚠️ Low average confidence. The model may need better training data or architecture changes."
        );
      }
    }

    // Suggest architectural improvements
    if (this.metricsHistory.length >= 10) {
      const avgLoss = this.metricsHistory
        .slice(-10)
        .reduce((sum, m) => sum + m.loss, 0) / 10;

      if (avgLoss > 0.5) {
        insights.push(
          "🔧 High training loss. Consider adding more hidden layers or using a different activation function."
        );
      }
    }

    return insights;
  }

  /**
   * Private helper methods
   */

  private createGoal(
    title: string,
    description: string,
    targetMetric: "confidence" | "loss" | "complexity_handling" | "speed",
    baselineValue: number,
    targetValue: number
  ): Goal {
    return {
      id: `goal_${this.goalIdCounter++}`,
      title,
      description,
      targetMetric,
      baselineValue,
      targetValue,
      currentValue: baselineValue,
      status: "active",
      createdAt: new Date(),
      progress: 0,
    };
  }

  private hasGoal(metric: string): boolean {
    const goalValues = Array.from(this.goals.values());
    for (const goal of goalValues) {
      if (goal.status === "active" && goal.targetMetric === metric) {
        return true;
      }
    }
    return false;
  }

  private getCurrentMetricValue(metric: string): number {
    if (this.metricsHistory.length === 0) return 0;
    const latest = this.metricsHistory[this.metricsHistory.length - 1];

    switch (metric) {
      case "confidence":
        return latest.confidence;
      case "loss":
        return latest.loss;
      case "complexity_handling":
        return latest.nodeCount + latest.edgeCount;
      case "speed":
        return 100; // Placeholder - would need timing data
      default:
        return 0;
    }
  }

  private calculateProgress(goal: Goal): number {
    if (goal.targetMetric === "loss") {
      // For loss, lower is better
      const range = goal.baselineValue - goal.targetValue;
      const progress = goal.baselineValue - goal.currentValue;
      return Math.min(100, Math.max(0, (progress / range) * 100));
    } else {
      // For other metrics, higher is better
      const range = goal.targetValue - goal.baselineValue;
      const progress = goal.currentValue - goal.baselineValue;
      return Math.min(100, Math.max(0, (progress / range) * 100));
    }
  }

  private isGoalCompleted(goal: Goal): boolean {
    if (goal.targetMetric === "loss") {
      return goal.currentValue <= goal.targetValue;
    } else {
      return goal.currentValue >= goal.targetValue;
    }
  }

  private analyzeTrend(history: TrainingMetrics[]): {
    confidenceTrend: number;
    lossTrend: number;
  } {
    if (history.length < 2) {
      return { confidenceTrend: 0, lossTrend: 0 };
    }

    const recent = history.slice(-3);
    const older = history.slice(-6, -3);

    const recentConfidence =
      recent.reduce((sum, m) => sum + m.confidence, 0) / recent.length;
    const olderConfidence =
      older.length > 0
        ? older.reduce((sum, m) => sum + m.confidence, 0) / older.length
        : recentConfidence;

    const recentLoss = recent.reduce((sum, m) => sum + m.loss, 0) / recent.length;
    const olderLoss =
      older.length > 0
        ? older.reduce((sum, m) => sum + m.loss, 0) / older.length
        : recentLoss;

    return {
      confidenceTrend: recentConfidence - olderConfidence,
      lossTrend: recentLoss - olderLoss,
    };
  }

  private calculateAverageInferenceTime(): number {
    if (this.metricsHistory.length === 0) return 0;
    // Placeholder - would need actual timing data
    return 75;
  }
}
