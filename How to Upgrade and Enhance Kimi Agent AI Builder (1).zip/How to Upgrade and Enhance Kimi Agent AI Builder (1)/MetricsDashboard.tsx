/**
 * MetricsDashboard: Real-time visualization of GNN training metrics
 * Displays loss trends, confidence curves, and training statistics
 */

import { useMemo } from "react";
import { motion } from "framer-motion";
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ComposedChart,
} from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { TrendingUp, TrendingDown, Activity, Zap, Brain } from "lucide-react";
import { MetricsState } from "@/hooks/useMetricsPolling";

interface MetricsDashboardProps {
  metrics: MetricsState;
  isLive?: boolean;
}

export function MetricsDashboard({ metrics, isLive = true }: MetricsDashboardProps) {
  // Format data for charts
  const chartData = useMemo(() => {
    return metrics.history
      .slice()
      .reverse()
      .map((m, idx) => ({
        time: idx,
        loss: parseFloat(m.loss.toFixed(4)),
        confidence: parseFloat((m.confidence * 100).toFixed(1)),
        sessions: m.sessionCount,
      }));
  }, [metrics.history]);

  // Calculate statistics
  const stats = useMemo(() => {
    if (metrics.history.length === 0) {
      return {
        minLoss: 0,
        maxLoss: 0,
        minConfidence: 0,
        maxConfidence: 0,
        improvementRate: 0,
      };
    }

    const losses = metrics.history.map((m) => m.loss);
    const confidences = metrics.history.map((m) => m.confidence);

    const minLoss = Math.min(...losses);
    const maxLoss = Math.max(...losses);
    const minConfidence = Math.min(...confidences);
    const maxConfidence = Math.max(...confidences);

    // Calculate improvement rate (% decrease in loss)
    const firstLoss = metrics.history[metrics.history.length - 1].loss;
    const lastLoss = metrics.history[0].loss;
    const improvementRate = firstLoss > 0 ? ((firstLoss - lastLoss) / firstLoss) * 100 : 0;

    return {
      minLoss,
      maxLoss,
      minConfidence,
      maxConfidence,
      improvementRate,
    };
  }, [metrics.history]);

  const trendIcon =
    metrics.trend === "improving" ? (
      <TrendingUp className="w-5 h-5 text-emerald-500" />
    ) : metrics.trend === "degrading" ? (
      <TrendingDown className="w-5 h-5 text-red-500" />
    ) : (
      <Activity className="w-5 h-5 text-slate-400" />
    );

  const trendColor =
    metrics.trend === "improving"
      ? "bg-emerald-500/20 text-emerald-400"
      : metrics.trend === "degrading"
        ? "bg-red-500/20 text-red-400"
        : "bg-slate-500/20 text-slate-400";

  return (
    <div className="space-y-6">
      {/* Header Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Current Loss */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0 }}
        >
          <Card className="bg-slate-900/50 border-slate-800">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-400">Current Loss</p>
                  <p className="text-2xl font-bold text-violet-400">
                    {metrics.current?.loss.toFixed(4) || "—"}
                  </p>
                </div>
                <Zap className="w-8 h-8 text-violet-500/50" />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Average Confidence */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="bg-slate-900/50 border-slate-800">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-400">Avg Confidence</p>
                  <p className="text-2xl font-bold text-fuchsia-400">
                    {(metrics.averageConfidence * 100).toFixed(0)}%
                  </p>
                </div>
                <Brain className="w-8 h-8 text-fuchsia-500/50" />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Training Sessions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="bg-slate-900/50 border-slate-800">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-400">Sessions</p>
                  <p className="text-2xl font-bold text-cyan-400">
                    {metrics.current?.sessionCount || 0}
                  </p>
                </div>
                <Activity className="w-8 h-8 text-cyan-500/50" />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Trend */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card className="bg-slate-900/50 border-slate-800">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-400">Trend</p>
                  <Badge className={`mt-2 capitalize ${trendColor}`}>
                    {metrics.trend}
                  </Badge>
                </div>
                {trendIcon}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Loss Trend Chart */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
      >
        <Card className="bg-slate-900/50 border-slate-800">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-violet-400" />
              Loss Trend
            </CardTitle>
          </CardHeader>
          <CardContent>
            {chartData.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={chartData}>
                  <defs>
                    <linearGradient id="colorLoss" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#a855f7" stopOpacity={0.8} />
                      <stop offset="95%" stopColor="#a855f7" stopOpacity={0.1} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis dataKey="time" stroke="#94a3b8" />
                  <YAxis stroke="#94a3b8" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#1e293b",
                      border: "1px solid #475569",
                      borderRadius: "8px",
                    }}
                    labelStyle={{ color: "#e2e8f0" }}
                  />
                  <Area
                    type="monotone"
                    dataKey="loss"
                    stroke="#a855f7"
                    fillOpacity={1}
                    fill="url(#colorLoss)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-80 flex items-center justify-center text-slate-400">
                No data yet. Start analyzing code to see loss trends.
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* Confidence & Loss Comparison */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
      >
        <Card className="bg-slate-900/50 border-slate-800">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Brain className="w-5 h-5 text-fuchsia-400" />
              Confidence vs Loss
            </CardTitle>
          </CardHeader>
          <CardContent>
            {chartData.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <ComposedChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis dataKey="time" stroke="#94a3b8" />
                  <YAxis yAxisId="left" stroke="#94a3b8" />
                  <YAxis yAxisId="right" orientation="right" stroke="#94a3b8" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#1e293b",
                      border: "1px solid #475569",
                      borderRadius: "8px",
                    }}
                    labelStyle={{ color: "#e2e8f0" }}
                  />
                  <Legend />
                  <Line
                    yAxisId="left"
                    type="monotone"
                    dataKey="loss"
                    stroke="#a855f7"
                    dot={false}
                    name="Loss"
                  />
                  <Line
                    yAxisId="right"
                    type="monotone"
                    dataKey="confidence"
                    stroke="#ec4899"
                    dot={false}
                    name="Confidence (%)"
                  />
                </ComposedChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-80 flex items-center justify-center text-slate-400">
                No data yet. Start analyzing code to see metrics.
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* Statistics */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
      >
        <Card className="bg-slate-900/50 border-slate-800">
          <CardHeader>
            <CardTitle>Statistics</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex justify-between mb-2">
                <span className="text-sm text-slate-400">Loss Range</span>
                <span className="text-sm font-mono text-slate-200">
                  {stats.minLoss.toFixed(4)} → {stats.maxLoss.toFixed(4)}
                </span>
              </div>
              <Progress
                value={(stats.minLoss / stats.maxLoss) * 100}
                className="h-2"
              />
            </div>

            <div>
              <div className="flex justify-between mb-2">
                <span className="text-sm text-slate-400">Confidence Range</span>
                <span className="text-sm font-mono text-slate-200">
                  {(stats.minConfidence * 100).toFixed(0)}% → {(stats.maxConfidence * 100).toFixed(0)}%
                </span>
              </div>
              <Progress
                value={stats.maxConfidence * 100}
                className="h-2"
              />
            </div>

            <div>
              <div className="flex justify-between mb-2">
                <span className="text-sm text-slate-400">Improvement Rate</span>
                <span className={`text-sm font-mono ${stats.improvementRate > 0 ? "text-emerald-400" : "text-red-400"}`}>
                  {stats.improvementRate > 0 ? "+" : ""}
                  {stats.improvementRate.toFixed(1)}%
                </span>
              </div>
              <Progress
                value={Math.min(Math.abs(stats.improvementRate), 100)}
                className="h-2"
              />
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Live Status */}
      {isLive && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="flex items-center justify-center gap-2 text-sm text-slate-400"
        >
          <motion.div
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="w-2 h-2 rounded-full bg-emerald-500"
          />
          Live metrics updating every 2 seconds
        </motion.div>
      )}
    </div>
  );
}
