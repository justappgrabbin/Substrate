/**
 * EnhancedProposalPanel: Proposal management with filtering, sorting, and history
 */

import { useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { EnhancedDiffViewer } from "@/components/EnhancedDiffViewer";
import {
  Check,
  X,
  Zap,
  AlertCircle,
  ChevronDown,
  ChevronUp,
  Loader2,
  Filter,
  ArrowUpDown,
} from "lucide-react";
import { toast } from "sonner";
import { useLLMSettings } from "@/contexts/LLMSettingsContext";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export interface Proposal {
  id: string;
  title: string;
  description: string;
  impact: "low" | "medium" | "high";
  category: string;
  beforeCode: string;
  afterCode: string;
  reasoning: string;
  createdAt: Date;
  status: "pending" | "approved" | "rejected" | "executed";
}

interface EnhancedProposalPanelProps {
  proposals: Proposal[];
  onApprove: (proposalId: string) => Promise<void>;
  onReject: (proposalId: string) => void;
  onExecute: (proposalId: string) => Promise<void>;
  isLoading?: boolean;
}

type SortBy = "date" | "impact" | "status";
type FilterStatus = "all" | "pending" | "approved" | "rejected" | "executed";
type FilterImpact = "all" | "low" | "medium" | "high";

function ImpactBadge({ impact }: { impact: "low" | "medium" | "high" }) {
  const colors = {
    low: "bg-blue-500/20 text-blue-400 border-blue-500/30",
    medium: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
    high: "bg-red-500/20 text-red-400 border-red-500/30",
  };
  return (
    <Badge variant="outline" className={colors[impact]}>
      {impact.toUpperCase()} Impact
    </Badge>
  );
}

function StatusBadge({
  status,
}: {
  status: "pending" | "approved" | "rejected" | "executed";
}) {
  const colors = {
    pending: "bg-slate-500/20 text-slate-400 border-slate-500/30",
    approved: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30",
    rejected: "bg-red-500/20 text-red-400 border-red-500/30",
    executed: "bg-violet-500/20 text-violet-400 border-violet-500/30",
  };
  return (
    <Badge variant="outline" className={colors[status]}>
      {status.toUpperCase()}
    </Badge>
  );
}

function ProposalCard({
  proposal,
  onApprove,
  onReject,
  onExecute,
  isLoading,
}: {
  proposal: Proposal;
  onApprove: (id: string) => Promise<void>;
  onReject: (id: string) => void;
  onExecute: (id: string) => Promise<void>;
  isLoading?: boolean;
}) {
  const [expanded, setExpanded] = useState(false);
  const [executing, setExecuting] = useState(false);

  const handleExecute = async () => {
    setExecuting(true);
    try {
      await onExecute(proposal.id);
      toast.success("Proposal executed successfully");
    } catch (error) {
      toast.error("Failed to execute proposal");
    } finally {
      setExecuting(false);
    }
  };

  const canExecute = proposal.status === "approved" && !executing;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
    >
      <Card className="bg-slate-900/50 border-slate-800 overflow-hidden">
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1">
              <CardTitle className="text-lg">{proposal.title}</CardTitle>
              <p className="text-sm text-slate-400 mt-2">{proposal.description}</p>
            </div>
            <button
              onClick={() => setExpanded(!expanded)}
              className="text-slate-400 hover:text-slate-200"
            >
              {expanded ? (
                <ChevronUp className="w-5 h-5" />
              ) : (
                <ChevronDown className="w-5 h-5" />
              )}
            </button>
          </div>

          <div className="flex items-center gap-2 mt-3 flex-wrap">
            <ImpactBadge impact={proposal.impact} />
            <Badge variant="outline" className="bg-slate-800 text-slate-300 border-slate-700">
              {proposal.category}
            </Badge>
            <StatusBadge status={proposal.status} />
            <span className="text-xs text-slate-500 ml-auto">
              {new Date(proposal.createdAt).toLocaleDateString()}
            </span>
          </div>
        </CardHeader>

        <AnimatePresence>
          {expanded && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
            >
              <Separator className="bg-slate-800" />
              <CardContent className="pt-4 space-y-4">
                {/* Reasoning */}
                <div>
                  <h4 className="text-sm font-semibold text-slate-200 mb-2">Reasoning</h4>
                  <p className="text-sm text-slate-400 bg-slate-950/50 p-3 rounded border border-slate-800">
                    {proposal.reasoning}
                  </p>
                </div>

                {/* Diff Viewer */}
                <div>
                  <h4 className="text-sm font-semibold text-slate-200 mb-2">Code Changes</h4>
                  <EnhancedDiffViewer
                    before={proposal.beforeCode}
                    after={proposal.afterCode}
                    title="Proposed Changes"
                    compact={true}
                  />
                </div>

                {/* Info Box */}
                <div className="p-3 bg-blue-500/10 border border-blue-500/30 rounded-lg flex gap-3">
                  <AlertCircle className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
                  <div className="text-xs text-blue-300">
                    <p className="font-semibold mb-1">Review Before Approval</p>
                    <p>
                      Carefully review the proposed changes. Once approved, the changes can be
                      executed to update the system.
                    </p>
                  </div>
                </div>

                {/* Action Buttons */}
                {proposal.status === "pending" && (
                  <div className="flex gap-2 pt-2">
                    <Button
                      variant="outline"
                      onClick={() => onReject(proposal.id)}
                      disabled={isLoading}
                      className="flex-1 border-red-500/30 text-red-400 hover:bg-red-500/10"
                    >
                      <X className="w-4 h-4 mr-2" />
                      Reject
                    </Button>
                    <Button
                      onClick={() => onApprove(proposal.id)}
                      disabled={isLoading}
                      className="flex-1 bg-emerald-600 hover:bg-emerald-700"
                    >
                      {isLoading ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Approving...
                        </>
                      ) : (
                        <>
                          <Check className="w-4 h-4 mr-2" />
                          Approve
                        </>
                      )}
                    </Button>
                  </div>
                )}

                {proposal.status === "approved" && (
                  <Button
                    onClick={handleExecute}
                    disabled={!canExecute}
                    className="w-full bg-violet-600 hover:bg-violet-700"
                  >
                    {executing ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Executing...
                      </>
                    ) : (
                      <>
                        <Zap className="w-4 h-4 mr-2" />
                        Execute Proposal
                      </>
                    )}
                  </Button>
                )}

                {proposal.status === "rejected" && (
                  <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-lg text-center">
                    <p className="text-sm text-red-400 font-medium">Proposal Rejected</p>
                  </div>
                )}

                {proposal.status === "executed" && (
                  <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-lg text-center">
                    <p className="text-sm text-emerald-400 font-medium">
                      ✓ Proposal Executed Successfully
                    </p>
                  </div>
                )}
              </CardContent>
            </motion.div>
          )}
        </AnimatePresence>
      </Card>
    </motion.div>
  );
}

export function EnhancedProposalPanel({
  proposals,
  onApprove,
  onReject,
  onExecute,
  isLoading,
}: EnhancedProposalPanelProps) {
  const { settings } = useLLMSettings();
  const [sortBy, setSortBy] = useState<SortBy>("date");
  const [filterStatus, setFilterStatus] = useState<FilterStatus>("all");
  const [filterImpact, setFilterImpact] = useState<FilterImpact>("all");

  const filtered = useMemo(() => {
    let result = proposals;

    // Filter by status
    if (filterStatus !== "all") {
      result = result.filter((p) => p.status === filterStatus);
    }

    // Filter by impact
    if (filterImpact !== "all") {
      result = result.filter((p) => p.impact === filterImpact);
    }

    // Sort
    switch (sortBy) {
      case "date":
        result = [...result].sort(
          (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        );
        break;
      case "impact":
        const impactOrder = { high: 3, medium: 2, low: 1 };
        result = [...result].sort(
          (a, b) => impactOrder[b.impact] - impactOrder[a.impact]
        );
        break;
      case "status":
        const statusOrder = { pending: 1, approved: 2, executed: 3, rejected: 4 };
        result = [...result].sort(
          (a, b) => statusOrder[a.status] - statusOrder[b.status]
        );
        break;
    }

    return result;
  }, [proposals, sortBy, filterStatus, filterImpact]);

  if (!settings.enabled) {
    return (
      <Card className="bg-slate-900/50 border-slate-800">
        <CardContent className="p-8 text-center">
          <AlertCircle className="w-12 h-12 text-slate-500 mx-auto mb-3" />
          <p className="text-slate-400">
            LLM proposal generation is disabled. Enable it in settings to generate proposals.
          </p>
        </CardContent>
      </Card>
    );
  }

  if (proposals.length === 0) {
    return (
      <Card className="bg-slate-900/50 border-slate-800">
        <CardContent className="p-8 text-center">
          <AlertCircle className="w-12 h-12 text-slate-500 mx-auto mb-3" />
          <p className="text-slate-400">No proposals yet. Analyze code to generate proposals.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <h3 className="text-lg font-semibold text-slate-200">
          Self-Improvement Proposals ({filtered.length})
        </h3>
        <div className="flex gap-2 flex-wrap">
          <Badge variant="outline" className="bg-slate-800 text-slate-300 border-slate-700">
            {proposals.filter((p) => p.status === "pending").length} Pending
          </Badge>
          <Badge
            variant="outline"
            className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30"
          >
            {proposals.filter((p) => p.status === "approved").length} Approved
          </Badge>
          <Badge
            variant="outline"
            className="bg-violet-500/20 text-violet-400 border-violet-500/30"
          >
            {proposals.filter((p) => p.status === "executed").length} Executed
          </Badge>
        </div>
      </div>

      {/* Filters and Sorting */}
      <div className="flex gap-3 flex-wrap bg-slate-900/50 p-3 rounded-lg border border-slate-800">
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-slate-400" />
          <span className="text-sm text-slate-400">Filter:</span>
        </div>

        <Select value={filterStatus} onValueChange={(value) => setFilterStatus(value as FilterStatus)}>
          <SelectTrigger className="w-32 h-8 text-xs">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="approved">Approved</SelectItem>
            <SelectItem value="executed">Executed</SelectItem>
            <SelectItem value="rejected">Rejected</SelectItem>
          </SelectContent>
        </Select>

        <Select value={filterImpact} onValueChange={(value) => setFilterImpact(value as FilterImpact)}>
          <SelectTrigger className="w-32 h-8 text-xs">
            <SelectValue placeholder="Impact" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Impact</SelectItem>
            <SelectItem value="low">Low</SelectItem>
            <SelectItem value="medium">Medium</SelectItem>
            <SelectItem value="high">High</SelectItem>
          </SelectContent>
        </Select>

        <div className="ml-auto flex items-center gap-2">
          <ArrowUpDown className="w-4 h-4 text-slate-400" />
          <Select value={sortBy} onValueChange={(value) => setSortBy(value as SortBy)}>
            <SelectTrigger className="w-32 h-8 text-xs">
              <SelectValue placeholder="Sort" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="date">Newest First</SelectItem>
              <SelectItem value="impact">Highest Impact</SelectItem>
              <SelectItem value="status">By Status</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Proposals List */}
      <AnimatePresence mode="popLayout">
        {filtered.map((proposal) => (
          <ProposalCard
            key={proposal.id}
            proposal={proposal}
            onApprove={onApprove}
            onReject={onReject}
            onExecute={onExecute}
            isLoading={isLoading}
          />
        ))}
      </AnimatePresence>
    </div>
  );
}
