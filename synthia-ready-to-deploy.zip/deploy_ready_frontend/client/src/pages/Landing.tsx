import React, { useState, useEffect } from 'react';

export default function Landing() {
  const [particles, setParticles] = useState<{x: number, y: number, size: number, speed: number, opacity: number}[]>([]);

  useEffect(() => {
    const p = Array.from({length: 40}, () => ({
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 3 + 1,
      speed: Math.random() * 0.3 + 0.1,
      opacity: Math.random() * 0.5 + 0.2,
    }));
    setParticles(p);
  }, []);

  const entries = [
    {
      id: 'lab',
      icon: '🔬',
      label: 'The Lab',
      description: 'Explore your energy & human design',
      href: '/lab',
      color: 'from-cyan-500 to-blue-600',
      glow: 'shadow-cyan-500/40',
      border: 'border-cyan-500/50',
    },
    {
      id: 'joint',
      icon: '⬡',
      label: 'The Joint',
      description: 'Symbiant Circle — your social hub',
      href: '/joint',
      color: 'from-violet-500 to-purple-600',
      glow: 'shadow-violet-500/40',
      border: 'border-violet-500/50',
    },
    {
      id: 'universe',
      icon: '🌌',
      label: 'Your Universe',
      description: 'Your agent\'s living world',
      href: '/universe',
      color: 'from-indigo-500 to-blue-700',
      glow: 'shadow-indigo-500/40',
      border: 'border-indigo-500/50',
    },
    {
      id: 'dashboard',
      icon: '◈',
      label: 'Dashboard',
      description: 'Your personal control center',
      href: '/dashboard',
      color: 'from-emerald-500 to-teal-600',
      glow: 'shadow-emerald-500/40',
      border: 'border-emerald-500/50',
    },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-white flex flex-col items-center justify-center relative overflow-hidden">
      {/* Animated background particles */}
      {particles.map((p, i) => (
        <div
          key={i}
          className="absolute rounded-full bg-cyan-400 pointer-events-none"
          style={{
            left: `${p.x}%`,
            top: `${p.y}%`,
            width: `${p.size}px`,
            height: `${p.size}px`,
            opacity: p.opacity,
            filter: 'blur(1px)',
          }}
        />
      ))}

      {/* Radial glow center */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="w-[600px] h-[600px] rounded-full bg-cyan-900/10 blur-3xl" />
      </div>

      {/* Content */}
      <div className="relative z-10 flex flex-col items-center px-6 max-w-2xl w-full">
        {/* Title */}
        <div className="text-center mb-12">
          <div className="text-xs font-mono text-cyan-500 tracking-[0.3em] mb-3 uppercase">
            Welcome to
          </div>
          <h1 className="text-5xl md:text-7xl font-bold tracking-tight mb-3">
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-blue-400 to-violet-400">
              SYNTHIA
            </span>
          </h1>
          <p className="text-slate-400 text-sm font-mono tracking-wide">
            A living lab • A social experiment • Your universe
          </p>
        </div>

        {/* Entry buttons */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 w-full">
          {entries.map((entry) => (
            <a
              key={entry.id}
              href={entry.href}
              className={`group relative flex flex-col items-start p-6 rounded-2xl border ${entry.border} bg-slate-900/80 backdrop-blur-sm hover:bg-slate-800/90 transition-all duration-300 hover:scale-[1.02] hover:shadow-xl ${entry.glow} cursor-pointer no-underline`}
            >
              <div className="flex items-center gap-3 mb-2">
                <span className="text-3xl">{entry.icon}</span>
                <span className={`text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r ${entry.color}`}>
                  {entry.label}
                </span>
              </div>
              <p className="text-slate-400 text-sm leading-relaxed">
                {entry.description}
              </p>
              <div className={`absolute bottom-0 left-0 right-0 h-0.5 rounded-b-2xl bg-gradient-to-r ${entry.color} opacity-0 group-hover:opacity-100 transition-opacity duration-300`} />
            </a>
          ))}
        </div>

        {/* Footer */}
        <div className="mt-12 text-center text-slate-600 text-xs font-mono">
          <p>Anonymous • Alive • Evolving</p>
        </div>
      </div>
    </div>
  );
}
