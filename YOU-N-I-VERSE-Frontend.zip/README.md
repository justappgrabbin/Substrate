# YOU-N-I-VERSE Frontend Prototype

This is the mobile prototype for the YOU-N-I-VERSE Consciousness Field system.

### Features
- Symbolic / Logical / Hybrid view toggle
- Mind / Heart / Body layer switching
- Resonance metrics display
- Planetary gate visuals (sample data)

### Run
1. Install dependencies:
   ```bash
   npm install -g expo-cli
   npm install
   ```
2. Run on phone:
   ```bash
   expo start
   ```
   Scan the QR code with Expo Go app.
