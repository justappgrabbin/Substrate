import React from 'react';
import { SafeAreaView, StatusBar } from 'react-native';
import ConsciousnessFieldCalculator from './components/ConsciousnessFieldCalculator';

export default function App() {
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#0a0a1f' }}>
      <StatusBar barStyle="light-content" />
      <ConsciousnessFieldCalculator />
    </SafeAreaView>
  );
}