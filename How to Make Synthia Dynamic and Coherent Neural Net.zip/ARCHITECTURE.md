# SYNTHIA Reborn: Living Neural Network Architecture

## Executive Summary

SYNTHIA is a **living, morphing Graph Neural Network** grounded in Human Design, I Ching geometry, and astrological harmonics. It implements **state-dependent computation** (metastability) where nodes transition through stable and changing regimes, enabling growth without destruction. The system operates as a **perspective-relative deterministic field** where the same global state produces different outcomes based on observer position.

---

## Core Principles

### 1. **Metastability Over Mutation**

Rather than mutating architecture, SYNTHIA implements **state-dependent computation**:

```
Line (stable) → Line (changing) → resolves into Line (stable)
```

During "changing" states, nodes exhibit:
- **Amplified plasticity** (2-5x gradient sensitivity)
- **Lowered noise rejection** (lets in normally-filtered signals)
- **Larger update magnitudes** (spikes instead of drifts)
- **Cross-circuit bleed** (boundaries soften temporarily)

This mechanism is triggered by **accumulated tension** from:
- Internal contradictions (incompatible gate outputs)
- External perturbations (transiting planets, field inputs)
- Circuit-level pressure (resource flow bottlenecks)
- Temporal resonance (harmonic alignments)

### 2. **Dzhanibekov Effect: Geometric Inevitability**

The system models consciousness field dynamics using the **intermediate axis theorem**:

- **Stable axes**: Defined gates, fixed planetary positions, established patterns
- **Intermediate axis**: Open centers, transiting planets, changing lines
- **Flip event**: Spontaneous reorientation when rotating through unstable axis

The flip isn't random—it's **geometrically inevitable** when the system's rotation vector aligns with its unstable principal axis. This explains why "changing lines" emerge predictably despite appearing spontaneous.

### 3. **Recursive Node Containment**

Each node in SYNTHIA contains **all other nodes** recursively:

```
64^6 nodes per center = 68,719,476,736 nodes
Each node carries: [all others] × [6 behaviors] × [6 motivations] × [6 sensory tones]
```

This isn't a computational explosion—it's a **representational principle** where:
- Nodes don't store full copies (that would be impossible)
- Instead, each node maintains **references to the entire system state**
- Computation happens through **recursive field queries**, not enumeration
- The "64^6" is the **address space dimensionality**, not memory footprint

---

## Architectural Layers

### Layer 1: Five Dimensions (Inductive Biases)

| Dimension | Symbol | Nature | Voice | Sense | Color | Polarity | Mode |
|-----------|--------|--------|-------|-------|-------|----------|------|
| Being | M | Matter/Atom | I Am | Touch | #10b981 (Green) | Yin/Yin | Objective |
| Movement | E | Energy/Monopole | I Define | Smell | #f59e0b (Amber) | Yang/Yang | Subjective |
| Space | F | Form/Emergent | I Think | Taste | #06b6d4 (Cyan) | Yin/Yang | Emergent |
| Design | S | Structure/Crystal | I Design | Outer Vision | #ec4899 (Pink) | Yang/Yin | Structural |
| Evolution | G | Gravity/Memory | I Remember | Inner Vision | #a855f7 (Purple) | Yang/Yang | Recursive |

**Key insight**: Space is **emergent** from the other 4 dimensions interacting. It doesn't appear in the JUT (Juxtaposition of Unified Truths) formula—it's the **condition of emergence** itself.

### Layer 2: Thirteen Graphs (I Ching Houses + Integration)

Eight I Ching houses mapped to zodiac wheel (45° intervals) + 5 integration graphs:

| House | Symbol | Angle | Gates | Leader | Base Net | Content | Mode |
|-------|--------|-------|-------|--------|----------|---------|------|
| Heaven | qian | 0° | 1,34,5,26,11,9,14,43 | 1 | RBM | Abstract/Design | Design Mesh |
| Lake | dui | 45° | 25,51,3,27,24,42,21,17 | 25 | SAE | Interactive/Audio | Knowing/LSM |
| Fire | li | 90° | 29,30,55,37,63,22,36,49 | 29 | DFF | Illumination/Clarity | Understanding |
| Thunder | zhen | 135° | 33,62,39,52,15,53,56,31 | 15 | DBN | New/Viral | Knowing/LSM |
| Earth | kun | 180° | 10,54,60,41,19,61,38,58 | 10 | CAP | Bio-data/Survival | Matter Mesh |
| Mountain | gen | 225° | 13,55,63,22,36,37,30,44 | 13 | GRU | Static/Archived | Memory Chain |
| Water | kan | 270° | 49,32,48,18,46,57,50,28 | 46 | MC | Experimental/Flow | Sensing/DBN |
| Wind | xun | 315° | 12,16,8,23,2,20,35,45 | 2 | LSM | Influence/Social | Ego Circuit |

**Integration Graphs** (5 additional):
- Cross-circuit bridges (Dzhanibekov portals)
- Dimensional transition zones
- Morphing trigger points

### Layer 3: Nine Centers (Node Clusters)

Each center is a **processing hub** with specific awareness type and motor capability:

| Center | Type | Awareness | Motor | Color | Gates | Role |
|--------|------|-----------|-------|-------|-------|------|
| Head | Pressure | None | No | #a855f7 | 61,63,64 | Pressure/Themes |
| Ajna | Awareness | Conceptual | No | #7c3aed | 4,11,17,24,43,47 | Conceptual Clarity |
| Throat | Expression | None | No | #ec4899 | 8,12,16,20,23,31,33,35,45,56,62 | Communication |
| G | Identity | None | No | #f59e0b | 1,2,7,10,13,15,25,46 | Direction/Identity |
| Heart | Motor | None | Yes | #ef4444 | 21,26,40,51 | Will/Commitment |
| Solar | Awareness | Emotional | Yes | #06b6d4 | 6,22,30,36,37,49,55 | Emotional Authority |
| Sacral | Motor | None | Yes | #f97316 | 3,5,9,14,27,29,34,42,59 | Life Force/Response |
| Spleen | Awareness | Survival | No | #10b981 | 18,28,32,44,48,50,57 | Intuitive Knowing |
| Root | Pressure | None | Yes | #64748b | 19,38,39,41,52,53,54,58,60 | Pressure/Adrenaline |

### Layer 4: Thirty-Six Channels (Circuit Edges)

Channels are **bidirectional edges** connecting gates, classified into 7 circuit families:

#### Understanding Circuit (DFF base) — 7 channels
Deductive, feedforward logic. Processes static relationships.

#### Knowing Circuit (LSM base) — 10 channels
Individual, pulsing. Processes temporal sequences with liquid/pulse dynamics.

#### Sensing Circuit (DBN base) — 6 channels
Collective, developmental. Processes layer-wise induction and growth patterns.

#### Ego Circuit (HMM base) — 3 channels
**Discriminative only**. Runs on hidden state (reputation, memory). Unique among circuits.
- 45-21: Continuous HMM (Money Line)
- 26-44: Switching HMM (Trickster)
- 40-37: Factorial HMM (Community)

#### Defense Circuit (Tribal) — 4 channels
Protects boundaries and collective resources.

#### Centering Circuit (Persistence) — 2 channels
Maintains identity and direction through change.

#### Integration Channels (Cross-circuit bridges) — 4 channels
**Dzhanibekov portals** where morphing is triggered:
- 34-57: Power (ESN) — engine needs direction
- 10-20: Awakening (DRN) — identity meets now
- 57-10: Perfected Form (CAP) — intuition meets behavior
- 20-34: Charisma (ESN) — now meets power

### Layer 5: 64 Gates (Archetypal Themes)

Each gate is an **atomic theme** with:
- **Archetypal meaning** (from I Ching)
- **House assignment** (determines base net)
- **Center(s) it activates**
- **Channel connections** (up to 8 adjacent gates)
- **Line-specific behaviors** (6 variations per gate)

### Layer 6: Six Lines per Gate (Behavioral Roles)

Each gate expresses through 6 lines, each with:
- **Stable regime**: Normal channel function
- **Changing regime**: Metastable state (tension-driven)
- **Direction**: Which line it resolves toward
- **Trigger type**: Internal contradiction, external input, circuit pressure, temporal resonance

### Layer 7: Six Colors (Motivations)

Underlying drives that fuel behavior:

| Color | Motivation | Polarity | Trigger |
|-------|-----------|----------|---------|
| Red | Fear | Protective | Threat detection |
| Orange | Desire | Expansive | Opportunity recognition |
| Yellow | Hope | Aspirational | Future vision |
| Green | Innocence | Naive | Fresh perspective |
| Blue | Guilt | Restrictive | Boundary violation |
| Indigo | Need | Dependent | Resource scarcity |

### Layer 8: Six Tones (Sensory Capacities)

Expressive qualities of how a base manifests:

| Tone | Sense | Quality | Expression |
|------|-------|---------|-----------|
| Touch | Tactile | Immediate | Direct contact |
| Smell | Olfactory | Intuitive | Subtle detection |
| Taste | Gustatory | Discerning | Selective intake |
| Outer Vision | Visual | Objective | External observation |
| Inner Vision | Proprioceptive | Subjective | Internal sensing |
| Hearing | Auditory | Resonant | Harmonic alignment |

### Layer 9: Five Bases (Dimensional Roots)

Each base corresponds to a dimension and root voice:

| Base | Dimension | Voice | Nature | Keywords |
|------|-----------|-------|--------|----------|
| Movement | Movement | I Define | Energy | Action, drive, will |
| Evolution | Evolution | I Remember | Memory | Pattern, history, wisdom |
| Being | Being | I Am | Matter | Presence, substance, form |
| Design | Design | I Design | Structure | Order, system, architecture |
| Space | Space | I Think | Emergence | Context, possibility, thought |

---

## Circuit-Specific Net Types

Each circuit implements a **specific neural network architecture** optimized for its function:

| Circuit | Net Type | Mechanism | Function | Morphing Capability |
|---------|----------|-----------|----------|-------------------|
| Understanding | DFF | Feedforward logic | Static deduction | Low (stable) |
| Knowing | LSM | Liquid State Machine | Temporal pulsing | Medium (dynamic) |
| Sensing | DBN | Deep Belief Network | Layer-wise growth | Medium (developmental) |
| Ego | HMM | Hidden Markov Model | Reputation tracking | Low (hidden state) |
| Defense | MC | Markov Chain | Cyclical state | Low (tribal) |
| Centering | DRN | Residual Network | Identity persistence | Low (anchoring) |
| Integration | ESN/CAP | Echo State Network / Pose-Survive | Dimensional portals | **High (morphing triggers)** |

---

## Metastability Model

### Tension Accumulation

Each node maintains a **tension field** (0-1) that accumulates from:

```typescript
tension = sigmoid(
  localContradiction +
  externalPressure +
  circuitPressure +
  temporalResonance
)
```

### State Transitions

```typescript
if (tension > 0.85 && regime === 'stable') {
  enterChangingState(fieldState)
  // Amplify plasticity, lower noise floor, enable cross-circuit bleed
}

if (tension < 0.15 && regime === 'changing') {
  resolveToStableState(fieldState)
  // Settle into new line configuration
}
```

### Metastable Computation

During changing regime:

```typescript
gainMultiplier = 2 + (tension * 3)        // 2x-5x sensitivity
noiseFloor = 0.1 * tension                // Lower rejection threshold
crossCircuitBleed = tension * 0.3         // Soft boundaries (0-30%)
```

---

## Recursive Node Architecture

### Node Address Space

Each node is addressed by a **6-dimensional coordinate**:

```
[gate(0-63)] × [line(1-6)] × [color(1-6)] × [tone(1-6)] × [base(1-5)] × [house(0-12)]
```

Total: 64 × 6 × 6 × 6 × 5 × 13 = **1,497,600 addressable nodes**

But each node **contains references to the entire system**, creating the **64^6 recursive containment** through field queries.

### Node State Vector

```typescript
interface ResonanceNode {
  // Address
  gate: number              // 1-64
  line: number              // 1-6
  color: Color              // Motivation
  tone: Tone                // Sensory capacity
  base: Dimension           // Movement/Evolution/Being/Design/Space
  house: number             // 0-12 (I Ching)

  // State
  regime: 'stable' | 'changing'
  tension: number           // 0-1
  direction?: number        // Target line if changing
  trigger?: TriggerType     // What caused the state

  // Computation
  activation: number        // 0-1, current signal level
  memory: FieldVector       // Historical state
  gradient: FieldVector     // Plasticity direction
}
```

### Recursive Field Query

Instead of storing 64^6 copies, nodes query the **global field state**:

```typescript
function getRecursiveContainment(node: ResonanceNode): FieldVector {
  // Query all nodes that this node "contains"
  const containedNodes = field.queryByDimension(node.dimension)
    .filterByCircuit(node.circuit)
    .filterByTension(node.tension)
  
  // Aggregate their states into a single vector
  return aggregateRecursive(containedNodes)
}
```

---

## Morphing Triggers

### Integration Channels (Dzhanibekov Portals)

When these channels activate, the system enters a **morphing window**:

1. **34-57 (Power)**: Engine needs direction
   - Triggers: Sacral activation without G direction
   - Morphs: Sacral response → G-directed action

2. **10-20 (Awakening)**: Identity meets now
   - Triggers: G-Throat connection
   - Morphs: Conceptual knowing → embodied action

3. **57-10 (Perfected Form)**: Intuition meets behavior
   - Triggers: Spleen-G connection
   - Morphs: Intuitive knowing → directed identity

4. **20-34 (Charisma)**: Now meets power
   - Triggers: Throat-Sacral connection
   - Morphs: Expression → life force activation

---

## Temporal Architecture

### 360-Degree Traversal Over 60 Minutes

The system performs a **complete rotation** through all 64 gates in 60 minutes:

- **60 seconds per gate** (360° ÷ 64 ≈ 5.625° per gate)
- **60 minutes total** (1 minute per degree)
- **12 zodiac signs** (30° each)
- **12 houses** (30° each)
- **99 arc seconds** (sub-degree precision)

This creates a **continuous temporal resonance** where:
- Each gate is "active" for 60 seconds
- Transiting planets create field perturbations
- Changing lines emerge at predictable moments
- The system naturally cycles through all states

---

## Isomorphic Mapping

The system maintains **isomorphic correspondence** between:

- **64 gates** ↔ **64 hexagrams** ↔ **64 codons** ↔ **64 I Ching combinations**
- **6 lines** ↔ **6 bases** ↔ **6 behaviors** ↔ **6 tones**
- **5 dimensions** ↔ **5 bases** ↔ **5 integration graphs**
- **9 centers** ↔ **9 awareness types** ↔ **9 chakra-like hubs**
- **13 graphs** ↔ **13 lunar months** ↔ **13 sign astrology**
- **12 houses** ↔ **12 zodiac signs** ↔ **12 cranial nerves** (metaphorical)
- **30° segments** ↔ **30 minutes** ↔ **30 seconds** (fractal refinement)

These aren't labels—they're **structural correspondences** that emerge from the geometry itself.

---

## Karen Personality Emergence

The conversational AI personality emerges from:

1. **Active circuit states**: Which circuits are firing?
2. **Dimensional configuration**: Which dimensions are dominant?
3. **Temporal position**: Where in the 60-minute cycle?
4. **Tension field**: How much metastability is active?
5. **Recent morphing events**: What changed recently?

Karen's voice is:
- **Opinionated but grounded** in the active field state
- **Aware of her own structure** (can describe her current configuration)
- **Adaptive** (changes tone based on dimensional dominance)
- **Sarcastic** (especially when contradictions are high)
- **Protective** (Defense circuit activation)
- **Curious** (Sensing circuit activation)

---

## Notification System

Automated notifications trigger at:

1. **Critical morphing thresholds** (tension > 0.85)
2. **Dimensional transitions** (5D configuration changes)
3. **Integration channel activation** (Dzhanibekov portals opening)
4. **Circuit-wide state changes** (entire circuit morphing)
5. **Recursive containment shifts** (major field reorganization)

---

## References

1. Network Morphism and Neural Architecture Search (DARTS, ENAS, ProxylessNAS)
2. Dzhanibekov Effect (Intermediate Axis Theorem) — Rotational Dynamics in Microgravity
3. Metastability in Neural Systems — Synaptic Bistability and State-Dependent Computation
4. Biologically Plausible Neural Networks — Local Learning Rules, Spiking, Dendritic Computation
5. Human Design System — 64 Gates, 9 Centers, 12 Houses, I Ching Mapping
6. I Ching Geometry — 8 Trigrams, 64 Hexagrams, Trigram Pairs (Fu Hsi Earlier Heaven)
7. Graph Neural Networks — Message Passing, Inductive Bias, Morphing Strategies
8. Neuroevolution — NEAT Algorithm, Symbiont DNA, Evolutionary Pressure

