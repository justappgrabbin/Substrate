import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { X, Loader2 } from "lucide-react";
import { componentRegistry, ComponentRequest } from "@/lib/componentRegistry";

interface DynamicComponentRendererProps {
  request: ComponentRequest | null;
  onClose: () => void;
  onResult?: (result: any) => void;
}

export default function DynamicComponentRenderer({
  request,
  onClose,
  onResult,
}: DynamicComponentRendererProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setError(null);
  }, [request]);

  if (!request) return null;

  const registeredComponent = componentRegistry.get(request.componentId);

  if (!registeredComponent) {
    return (
      <Dialog open={!!request} onOpenChange={onClose}>
        <DialogContent className="border-neon-magenta bg-card">
          <DialogHeader>
            <DialogTitle className="text-neon-magenta">Component Not Found</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-gray-400">
              The requested component "{request.componentId}" is not available.
            </p>
            <Button onClick={onClose} className="w-full bg-neon-magenta hover:bg-neon-magenta/80">
              Close
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  const Component = registeredComponent.component;
  const props = {
    ...registeredComponent.defaultProps,
    ...request.context,
    ...request.props,
    onClose,
    onResult,
  };

  return (
    <Dialog open={!!request} onOpenChange={onClose}>
      <DialogContent className="border-neon-cyan bg-card max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader className="flex items-center justify-between">
          <div>
            <DialogTitle className="text-neon-cyan">{request.title}</DialogTitle>
            {request.description && (
              <p className="text-xs text-gray-400 mt-1">{request.description}</p>
            )}
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="text-neon-magenta hover:bg-neon-magenta/10"
          >
            <X className="w-4 h-4" />
          </Button>
        </DialogHeader>

        {isLoading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="w-6 h-6 animate-spin text-neon-cyan" />
          </div>
        ) : error ? (
          <div className="space-y-4 py-4">
            <p className="text-sm text-red-500">{error}</p>
            <Button onClick={onClose} className="w-full bg-neon-magenta hover:bg-neon-magenta/80">
              Close
            </Button>
          </div>
        ) : (
          <div className="py-4">
            <Component {...props} />
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
