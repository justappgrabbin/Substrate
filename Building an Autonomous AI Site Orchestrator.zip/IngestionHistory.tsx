import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { FileText, Loader2, Zap } from "lucide-react";

export function IngestionHistory() {
  const { data: materials, isLoading } = trpc.material.list.useQuery();

  const getFileIcon = (fileType: string) => {
    if (fileType.includes("code") || fileType.includes("javascript") || fileType.includes("typescript")) {
      return "📝";
    }
    if (fileType.includes("markdown")) return "📄";
    if (fileType.includes("json")) return "{ }";
    if (fileType.includes("yaml")) return "⚙️";
    if (fileType.includes("sql")) return "🗄️";
    return "📋";
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="border-b border-neon-cyan pb-3">
        <h3 className="text-neon-cyan font-mono font-bold text-lg">INGESTION HISTORY</h3>
        <p className="text-xs text-muted-foreground mt-1">
          All materials processed and mapped to modules
        </p>
      </div>

      {/* Materials List */}
      {isLoading ? (
        <div className="flex items-center justify-center h-32">
          <Loader2 className="w-6 h-6 animate-spin text-neon-cyan" />
        </div>
      ) : materials && materials.length > 0 ? (
        <div className="space-y-2 max-h-96 overflow-y-auto">
          {materials.map((material) => (
            <Card key={material.id} className="p-3 border-neon-cyan bg-card/50 hover:bg-card/70 transition-all">
              <div className="flex items-start gap-3">
                {/* File icon */}
                <div className="text-xl flex-shrink-0">{getFileIcon(material.fileType)}</div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="font-mono font-bold text-foreground text-sm truncate">
                      {material.fileName}
                    </h4>
                    <span className="text-xs text-muted-foreground flex-shrink-0">
                      {(material.content?.length || 0) > 1000
                        ? `${Math.round((material.content?.length || 0) / 1024)}KB`
                        : `${material.content?.length || 0}B`}
                    </span>
                  </div>

                  {/* Mapped modules */}
                  <div className="flex flex-wrap gap-1 mb-2">
                    {material.mappedModules && material.mappedModules.length > 0 ? (
                      material.mappedModules.map((mod) => (
                        <Badge key={mod} variant="secondary" className="text-xs">
                          {mod}
                        </Badge>
                      ))
                    ) : (
                      <span className="text-xs text-muted-foreground italic">No modules mapped</span>
                    )}
                  </div>

                  {/* Metadata */}
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <span>{material.fileType}</span>
                    <span>•</span>
                    <span>{new Date(material.createdAt).toLocaleDateString()}</span>
                  </div>
                </div>

                {/* Status indicator */}
                <div className="flex-shrink-0">
                  <div className="w-2 h-2 rounded-full bg-neon-green animate-pulse"></div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="p-6 border-neon-cyan bg-card/50 text-center">
          <Zap className="w-8 h-8 mx-auto mb-2 text-neon-cyan/50" />
          <p className="text-sm text-muted-foreground">No materials ingested yet</p>
          <p className="text-xs text-muted-foreground mt-1">
            Upload files in the Materials tab to see them here
          </p>
        </Card>
      )}

      {/* Summary stats */}
      {materials && materials.length > 0 && (
        <Card className="p-3 border-neon-magenta/50 bg-card/30">
          <div className="grid grid-cols-3 gap-2 text-center">
            <div>
              <p className="text-neon-cyan font-mono font-bold text-lg">{materials.length}</p>
              <p className="text-xs text-muted-foreground">Total Materials</p>
            </div>
            <div>
              <p className="text-neon-magenta font-mono font-bold text-lg">
                {new Set(materials.flatMap((m) => m.mappedModules || [])).size}
              </p>
              <p className="text-xs text-muted-foreground">Modules Mapped</p>
            </div>
            <div>
              <p className="text-neon-green font-mono font-bold text-lg">
                {Math.round(
                  materials.reduce((sum, m) => sum + (m.content?.length || 0), 0) / 1024
                )}
              </p>
              <p className="text-xs text-muted-foreground">Total KB</p>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}
