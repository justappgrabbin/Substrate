/**
 * Context Detector - Analyzes conversation content to determine orchestrator mood/state
 * Returns visual state indicators for reactive UI changes
 */

export type OrchestratorState = 'calm' | 'chaos' | 'listening' | 'thinking';

interface ContextAnalysis {
  state: OrchestratorState;
  intensity: number; // 0-1, how intense the state is
  keywords: string[];
}

const chaosKeywords = [
  'error', 'broken', 'fail', 'crash', 'bug', 'disaster', 'mess', 'chaos',
  'wtf', 'f***', 'shit', 'damn', 'hell', 'problem', 'issue', 'bug',
  'trainwreck', 'wreck', 'disaster', 'catastrophe', 'apocalypse',
  'confused', 'confusing', 'unclear', 'broken', 'doesn\'t work',
  'help', 'stuck', 'lost', 'what', 'why', 'how', 'urgent', 'emergency'
];

const calmKeywords = [
  'good', 'great', 'perfect', 'working', 'smooth', 'nice', 'clean',
  'ready', 'set', 'go', 'proceed', 'continue', 'next', 'thanks',
  'thank you', 'appreciate', 'awesome', 'excellent', 'brilliant'
];

const listeningKeywords = [
  'listen', 'hear', 'tell', 'explain', 'describe', 'show', 'look',
  'check', 'review', 'examine', 'analyze', 'understand', 'know',
  'what', 'how', 'why', 'tell me', 'show me'
];

export function analyzeContext(text: string): ContextAnalysis {
  const lowerText = text.toLowerCase();
  const words = lowerText.split(/\s+/);
  
  let chaosScore = 0;
  let calmScore = 0;
  let listeningScore = 0;
  const detectedKeywords: string[] = [];

  // Count keyword matches
  words.forEach((word) => {
    // Remove punctuation for matching
    const cleanWord = word.replace(/[.,!?;:]/g, '');
    
    if (chaosKeywords.some(k => cleanWord.includes(k))) {
      chaosScore++;
      detectedKeywords.push(cleanWord);
    }
    if (calmKeywords.some(k => cleanWord.includes(k))) {
      calmScore++;
      detectedKeywords.push(cleanWord);
    }
    if (listeningKeywords.some(k => cleanWord.includes(k))) {
      listeningScore++;
      detectedKeywords.push(cleanWord);
    }
  });

  // Determine dominant state
  let state: OrchestratorState = 'calm';
  let intensity = 0;

  if (chaosScore > calmScore && chaosScore > listeningScore) {
    state = 'chaos';
    intensity = Math.min(chaosScore / words.length, 1);
  } else if (listeningScore > calmScore && listeningScore > chaosScore) {
    state = 'listening';
    intensity = Math.min(listeningScore / words.length, 1);
  } else if (calmScore > 0) {
    state = 'calm';
    intensity = Math.min(calmScore / words.length, 1);
  }

  // If text is very short, assume listening state
  if (words.length < 3) {
    state = 'listening';
    intensity = 0.5;
  }

  return {
    state,
    intensity: Math.max(intensity, 0.3), // Minimum intensity
    keywords: Array.from(new Set(detectedKeywords)).slice(0, 5), // Unique keywords, max 5
  };
}

/**
 * Get CSS class names for reactive visual state
 */
export function getStateClasses(state: OrchestratorState, intensity: number): string {
  const baseClasses = 'transition-all duration-500';

  switch (state) {
    case 'chaos':
      return `${baseClasses} animate-glitch-intense`;
    case 'listening':
      return `${baseClasses} animate-pulse-glow`;
    case 'thinking':
      return `${baseClasses} animate-thinking`;
    case 'calm':
    default:
      return baseClasses;
  }
}

/**
 * Get visual effect intensity (for CSS variables or animation speed)
 */
export function getVisualIntensity(state: OrchestratorState, intensity: number): {
  glitchAmount: number;
  aberrationAmount: number;
  scanlineOpacity: number;
  pulseSpeed: number;
} {
  switch (state) {
    case 'chaos':
      return {
        glitchAmount: 8 * intensity,
        aberrationAmount: 4 * intensity,
        scanlineOpacity: 0.4 + 0.3 * intensity,
        pulseSpeed: 0.3,
      };
    case 'listening':
      return {
        glitchAmount: 1,
        aberrationAmount: 1,
        scanlineOpacity: 0.2 + 0.1 * intensity,
        pulseSpeed: 0.8,
      };
    case 'thinking':
      return {
        glitchAmount: 2,
        aberrationAmount: 1.5,
        scanlineOpacity: 0.25,
        pulseSpeed: 0.5,
      };
    case 'calm':
    default:
      return {
        glitchAmount: 0,
        aberrationAmount: 0.5,
        scanlineOpacity: 0.15,
        pulseSpeed: 1,
      };
  }
}
