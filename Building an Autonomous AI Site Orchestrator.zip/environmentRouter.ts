/**
 * Environmental Router - tRPC endpoints for orchestrator observation system
 */

import { protectedProcedure, router } from "./_core/trpc";
import { observer } from "./environmentalObserver";
import { strategicReasoner } from "./strategicReasoner";
import { z } from "zod";

export const environmentRouter = router({
  /**
   * Record an agent action in the environment
   */
  recordAction: protectedProcedure
    .input(
      z.object({
        agentId: z.number(),
        agentName: z.string(),
        action: z.string(),
        moduleContext: z.enum(["GNN", "Resonance", "Embodied Reality"] as const),
        parameters: z.record(z.string(), z.unknown()).optional(),
        result: z.record(z.string(), z.unknown()).optional(),
      })
    )
    .mutation(({ input }) => {
      observer.recordAction({
        agentId: input.agentId,
        agentName: input.agentName,
        action: input.action,
        timestamp: new Date(),
        moduleContext: input.moduleContext,
        parameters: input.parameters,
        result: input.result,
      });

      return { success: true };
    }),

  /**
   * Get current environmental state
   */
  getEnvironmentalState: protectedProcedure.query(() => {
    return observer.getEnvironmentalState();
  }),

  /**
   * Analyze causality in recent actions
   */
  analyzeCausality: protectedProcedure.query(async ({ ctx }) => {
    const causalChains = await observer.analyzeCausality(ctx.user.id);
    return { causalChains };
  }),

  /**
   * Detect patterns in agent behavior
   */
  detectPatterns: protectedProcedure.query(async ({ ctx }) => {
    const patterns = await observer.detectPatterns(ctx.user.id);
    return { patterns };
  }),

  /**
   * Generate strategic insights
   */
  generateInsights: protectedProcedure.query(async ({ ctx }) => {
    const insights = await strategicReasoner.generateInsights(ctx.user.id);
    return { insights };
  }),

  /**
   * Check if orchestrator should communicate proactively
   */
  checkProactiveCommunication: protectedProcedure.query(async ({ ctx }) => {
    const insight = await strategicReasoner.shouldCommunicate(ctx.user.id);

    if (!insight) {
      return { shouldCommunicate: false, insight: null, message: null };
    }

    const message = await strategicReasoner.generateProactiveMessage(insight);

    return {
      shouldCommunicate: true,
      insight,
      message,
    };
  }),

  /**
   * Get agent history
   */
  getAgentHistory: protectedProcedure
    .input(
      z.object({
        agentId: z.number(),
        limit: z.number().optional().default(10),
      })
    )
    .query(({ input }) => {
      const history = observer.getAgentHistory(input.agentId, input.limit);
      return { history };
    }),

  /**
   * Get module actions
   */
  getModuleActions: protectedProcedure
    .input(
      z.object({
        module: z.enum(["GNN", "Resonance", "Embodied Reality"] as const),
        limit: z.number().optional().default(10),
      })
    )
    .query(({ input }) => {
      const actions = observer.getModuleActions(input.module, input.limit);
      return { actions };
    }),

  /**
   * Get last generated insights
   */
  getLastInsights: protectedProcedure.query(() => {
    const insights = strategicReasoner.getLastInsights();
    return { insights };
  }),
});
