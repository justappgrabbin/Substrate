import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Lightbulb, TrendingUp, AlertCircle, CheckCircle } from "lucide-react";

const BEST_PRACTICES = [
  {
    category: "Architecture",
    icon: TrendingUp,
    tips: [
      {
        title: "Modular Design",
        description: "Keep GNN, Resonance, and Embodied Reality as separate, independently deployable modules",
        severity: "high",
      },
      {
        title: "Clear Interfaces",
        description: "Define explicit APIs between modules to enable autonomous assembly",
        severity: "high",
      },
      {
        title: "Feedback Loops",
        description: "Ensure Embodied Reality feeds data back to GNN for continuous learning",
        severity: "medium",
      },
    ],
  },
  {
    category: "Code Organization",
    icon: CheckCircle,
    tips: [
      {
        title: "Single Responsibility",
        description: "Each agent should have one clear purpose within its module",
        severity: "high",
      },
      {
        title: "Version Control",
        description: "Track changes to scaffolding to enable rollback and experimentation",
        severity: "medium",
      },
      {
        title: "Documentation",
        description: "Document module dependencies and data flows for the orchestrator",
        severity: "medium",
      },
    ],
  },
  {
    category: "Agent Training",
    icon: Lightbulb,
    tips: [
      {
        title: "Incremental Training",
        description: "Train agents on small, focused tasks before complex orchestration",
        severity: "high",
      },
      {
        title: "Validation",
        description: "Always validate agent outputs before autonomous deployment",
        severity: "high",
      },
      {
        title: "Monitoring",
        description: "Track agent performance metrics and adjust instructions based on results",
        severity: "medium",
      },
    ],
  },
];

const getSeverityColor = (severity: string) => {
  switch (severity) {
    case "high":
      return "bg-destructive/10 border-destructive text-destructive";
    case "medium":
      return "bg-neon-magenta/10 border-neon-magenta text-neon-magenta";
    default:
      return "bg-neon-cyan/10 border-neon-cyan text-neon-cyan";
  }
};

const getSeverityIcon = (severity: string) => {
  return severity === "high" ? (
    <AlertCircle className="w-4 h-4" />
  ) : (
    <Lightbulb className="w-4 h-4" />
  );
};

export function BestPracticeAdvisor() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="border-b border-neon-cyan pb-3">
        <h3 className="text-neon-cyan font-mono font-bold text-lg">BEST PRACTICE ADVISOR</h3>
        <p className="text-xs text-muted-foreground mt-1">
          Strategic recommendations for optimal orchestrator performance
        </p>
      </div>

      {/* Practice Categories */}
      {BEST_PRACTICES.map((category) => {
        const Icon = category.icon;
        return (
          <div key={category.category} className="space-y-3">
            {/* Category Header */}
            <div className="flex items-center gap-2 mb-3">
              <Icon className="w-5 h-5 text-neon-cyan" />
              <h4 className="font-mono font-bold text-neon-cyan">{category.category}</h4>
            </div>

            {/* Tips Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {category.tips.map((tip, idx) => (
                <Card key={idx} className={`p-3 border-2 ${getSeverityColor(tip.severity)} bg-card`}>
                  <div className="flex items-start gap-2 mb-2">
                    {getSeverityIcon(tip.severity)}
                    <h5 className="font-mono font-bold text-sm">{tip.title}</h5>
                  </div>
                  <p className="text-xs text-muted-foreground">{tip.description}</p>
                  <div className="mt-2 pt-2 border-t border-current/20">
                    <Badge
                      variant="outline"
                      className={`text-xs ${
                        tip.severity === "high"
                          ? "border-destructive text-destructive"
                          : "border-neon-magenta text-neon-magenta"
                      }`}
                    >
                      {tip.severity === "high" ? "Critical" : "Recommended"}
                    </Badge>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        );
      })}

      {/* Quick Checklist */}
      <Card className="p-4 border-neon-magenta bg-card/50">
        <h4 className="font-mono font-bold text-neon-magenta mb-3">ORCHESTRATOR READINESS</h4>
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-sm">
            <CheckCircle className="w-4 h-4 text-neon-green" />
            <span className="text-muted-foreground">All three modules initialized</span>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <CheckCircle className="w-4 h-4 text-neon-green" />
            <span className="text-muted-foreground">Material ingestion pipeline active</span>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <CheckCircle className="w-4 h-4 text-neon-green" />
            <span className="text-muted-foreground">Agent training framework ready</span>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <CheckCircle className="w-4 h-4 text-neon-green" />
            <span className="text-muted-foreground">Autonomous assembly engine configured</span>
          </div>
        </div>
      </Card>

      {/* Next Steps */}
      <Card className="p-4 border-neon-cyan bg-card/30">
        <h4 className="font-mono font-bold text-neon-cyan mb-2">NEXT STEPS</h4>
        <ol className="space-y-1 text-xs text-muted-foreground list-decimal list-inside">
          <li>Ingest your scaffolding materials via the MATERIALS tab</li>
          <li>Configure specialized agents in the AGENTS tab</li>
          <li>Discuss architecture with the orchestrator in the chat</li>
          <li>Monitor module topology in the TOPOLOGY tab</li>
          <li>Review ingestion history for insights</li>
        </ol>
      </Card>
    </div>
  );
}
