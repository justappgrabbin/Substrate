/**
 * Environmental Observer - Real-time perception system for the orchestrator
 * She observes all agents, tracks state changes, and understands causality
 */

import { invokeLLM } from "./_core/llm";
import * as db from "./db";

export interface AgentAction {
  agentId: number;
  agentName: string;
  action: string;
  timestamp: Date;
  moduleContext: string; // GNN, Resonance, or Embodied Reality
  parameters?: Record<string, unknown>;
  result?: Record<string, unknown>;
}

export interface EnvironmentalState {
  activeAgents: number[];
  recentActions: AgentAction[];
  systemHealth: "calm" | "active" | "chaotic";
  patterns: string[];
  anomalies: string[];
}

class EnvironmentalObserver {
  private actionHistory: AgentAction[] = [];
  private environmentalState: EnvironmentalState = {
    activeAgents: [],
    recentActions: [],
    systemHealth: "calm",
    patterns: [],
    anomalies: [],
  };

  /**
   * Record an agent action in the environment
   */
  recordAction(action: AgentAction): void {
    this.actionHistory.push(action);
    this.environmentalState.recentActions.push(action);

    // Keep only last 100 actions in memory
    if (this.environmentalState.recentActions.length > 100) {
      this.environmentalState.recentActions.shift();
    }

    // Track active agents
    if (!this.environmentalState.activeAgents.includes(action.agentId)) {
      this.environmentalState.activeAgents.push(action.agentId);
    }

    // Update system health based on action frequency
    this.updateSystemHealth();
  }

  /**
   * Analyze causal relationships between actions
   */
  async analyzeCausality(userId: number): Promise<string[]> {
    if (this.actionHistory.length < 2) {
      return [];
    }

    const recentActions = this.actionHistory.slice(-20);
    const actionSummary = recentActions
      .map((a) => `${a.agentName} (${a.moduleContext}): ${a.action}`)
      .join("\n");

    const prompt = `Analyze these agent actions and identify causal relationships:

${actionSummary}

For each causal chain, explain:
1. What action triggered the chain
2. What subsequent actions were caused by it
3. The impact on the overall system

Format as bullet points.`;

    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content:
            "You are an expert at understanding system dynamics and causal relationships. Analyze the action sequence and identify clear cause-effect chains.",
        },
        {
          role: "user",
          content: prompt,
        },
      ],
    });

    const content = response.choices?.[0]?.message?.content as string;
    if (!content) return [];

    return content.split("\n").filter((line) => line.trim().length > 0);
  }

  /**
   * Detect patterns in agent behavior
   */
  async detectPatterns(userId: number): Promise<string[]> {
    if (this.actionHistory.length < 5) {
      return [];
    }

    const recentActions = this.actionHistory.slice(-30);
    const actionTypes = recentActions.map((a) => a.action);
    const agents = Array.from(new Set(recentActions.map((a) => a.agentName)));
    const modules = Array.from(new Set(recentActions.map((a) => a.moduleContext)));

    const prompt = `Analyze these agent actions and identify patterns:

Actions: ${actionTypes.join(", ")}
Agents: ${agents.join(", ")}
Modules: ${modules.join(", ")}

Identify:
1. Recurring action sequences
2. Agent collaboration patterns
3. Module-specific behaviors
4. Timing patterns (fast/slow actions)
5. Any anomalies or unexpected behaviors

Be specific and actionable.`;

    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content:
            "You are an expert at pattern recognition in multi-agent systems. Identify meaningful patterns that could inform system optimization.",
        },
        {
          role: "user",
          content: prompt,
        },
      ],
    });

    const content = response.choices?.[0]?.message?.content as string;
    if (!content) return [];

    return content.split("\n").filter((line) => line.trim().length > 0);
  }

  /**
   * Generate strategic insights for proactive communication
   */
  async generateStrategicInsights(userId: number): Promise<string[]> {
    const causalChains = await this.analyzeCausality(userId);
    const patterns = await this.detectPatterns(userId);

    if (causalChains.length === 0 && patterns.length === 0) {
      return [];
    }

    const prompt = `Based on these system observations, generate strategic insights:

Causal Chains:
${causalChains.join("\n")}

Patterns:
${patterns.join("\n")}

System Health: ${this.environmentalState.systemHealth}

Generate 2-3 strategic insights that:
1. Identify opportunities for optimization
2. Highlight potential risks or conflicts
3. Suggest improvements to agent coordination
4. Point out emerging patterns worth monitoring

Format each insight as: [PRIORITY] Insight: [description]`;

    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content:
            "You are a strategic advisor for multi-agent systems. Generate actionable insights that help optimize system performance.",
        },
        {
          role: "user",
          content: prompt,
        },
      ],
    });

    const content = response.choices?.[0]?.message?.content as string;
    if (!content) return [];

    return content.split("\n").filter((line) => line.trim().length > 0);
  }

  /**
   * Get current environmental state
   */
  getEnvironmentalState(): EnvironmentalState {
    return { ...this.environmentalState };
  }

  /**
   * Update system health based on activity level
   */
  private updateSystemHealth(): void {
    const recentActionCount = this.environmentalState.recentActions.filter(
      (a) => Date.now() - new Date(a.timestamp).getTime() < 60000 // Last minute
    ).length;

    if (recentActionCount === 0) {
      this.environmentalState.systemHealth = "calm";
    } else if (recentActionCount < 5) {
      this.environmentalState.systemHealth = "active";
    } else {
      this.environmentalState.systemHealth = "chaotic";
    }
  }

  /**
   * Get recent actions for a specific agent
   */
  getAgentHistory(agentId: number, limit: number = 10): AgentAction[] {
    return this.actionHistory
      .filter((a) => a.agentId === agentId)
      .slice(-limit);
  }

  /**
   * Get actions for a specific module
   */
  getModuleActions(module: string, limit: number = 10): AgentAction[] {
    return this.actionHistory
      .filter((a) => a.moduleContext === module)
      .slice(-limit);
  }

  /**
   * Clear old history (keep last 1000 actions)
   */
  pruneHistory(): void {
    if (this.actionHistory.length > 1000) {
      this.actionHistory = this.actionHistory.slice(-1000);
    }
  }
}

// Singleton instance
export const observer = new EnvironmentalObserver();
