import { ComponentType } from "react";

export type ComponentRequest = {
  componentId: string;
  title: string;
  description?: string;
  context?: Record<string, any>;
  props?: Record<string, any>;
};

export type RegisteredComponent = {
  id: string;
  name: string;
  description: string;
  component: ComponentType<any>;
  requiredContext?: string[];
  defaultProps?: Record<string, any>;
};

class ComponentRegistry {
  private components: Map<string, RegisteredComponent> = new Map();

  register(component: RegisteredComponent) {
    this.components.set(component.id, component);
  }

  get(id: string): RegisteredComponent | undefined {
    return this.components.get(id);
  }

  getAll(): RegisteredComponent[] {
    return Array.from(this.components.values());
  }

  exists(id: string): boolean {
    return this.components.has(id);
  }

  getByName(name: string): RegisteredComponent | undefined {
    return Array.from(this.components.values()).find(
      (c) => c.name.toLowerCase() === name.toLowerCase()
    );
  }

  // Find best matching component based on description
  findBestMatch(description: string): RegisteredComponent | undefined {
    const desc = description.toLowerCase();
    
    // Direct matches
    if (desc.includes("upload") || desc.includes("material")) {
      return this.get("material-upload");
    }
    if (desc.includes("agent") || desc.includes("configure")) {
      return this.get("agent-config");
    }
    if (desc.includes("module") || desc.includes("topology")) {
      return this.get("module-map");
    }
    if (desc.includes("feedback") || desc.includes("rate")) {
      return this.get("message-feedback");
    }
    if (desc.includes("research") || desc.includes("context")) {
      return this.get("research-context");
    }
    if (desc.includes("learning") || desc.includes("analytics")) {
      return this.get("learning-analytics");
    }
    if (desc.includes("suggestion") || desc.includes("improvement")) {
      return this.get("autonomous-suggestions");
    }
    if (desc.includes("observer") || desc.includes("insight")) {
      return this.get("environmental-observer");
    }

    return undefined;
  }
}

export const componentRegistry = new ComponentRegistry();
