import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";

export default function LearningAnalytics() {
  const { data: analytics, isLoading } = trpc.learning.analyzeFeedback.useQuery();
  const [chartData, setChartData] = useState<any[]>([]);

  useEffect(() => {
    if (analytics?.analysis) {
      const { goodCount, mehCount, badCount } = analytics.analysis;
      setChartData([
        { name: "Good", value: goodCount, fill: "#10b981" },
        { name: "Meh", value: mehCount, fill: "#f59e0b" },
        { name: "Bad", value: badCount, fill: "#ef4444" },
      ]);
    }
  }, [analytics]);

  if (isLoading) {
    return <div className="text-cyan-400 text-sm">Loading analytics...</div>;
  }

  if (!analytics) {
    return <div className="text-cyan-600 text-sm">No data yet</div>;
  }

  const { analysis, topPatterns, recommendations } = analytics;

  return (
    <div className="space-y-6">
      {/* Key Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <Card className="p-3 border-cyan-700 bg-black/50">
          <div className="text-xs text-cyan-500 font-mono">TOTAL FEEDBACK</div>
          <div className="text-2xl font-bold text-cyan-300">{analysis.totalFeedback}</div>
        </Card>

        <Card className="p-3 border-cyan-700 bg-black/50">
          <div className="text-xs text-cyan-500 font-mono">SUCCESS RATE</div>
          <div className="text-2xl font-bold text-green-400">{analysis.successRate.toFixed(0)}%</div>
        </Card>

        <Card className="p-3 border-cyan-700 bg-black/50">
          <div className="text-xs text-cyan-500 font-mono">EFFECTIVENESS</div>
          <div className="text-2xl font-bold text-cyan-300">{analysis.effectivenessScore}</div>
        </Card>

        <Card className="p-3 border-cyan-700 bg-black/50">
          <div className="text-xs text-cyan-500 font-mono">PATTERNS FOUND</div>
          <div className="text-2xl font-bold text-magenta-400">{topPatterns.length}</div>
        </Card>
      </div>

      {/* Feedback Distribution */}
      {chartData.length > 0 && (
        <Card className="p-4 border-cyan-700 bg-black/50">
          <div className="text-cyan-400 text-sm font-bold mb-4">FEEDBACK DISTRIBUTION</div>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie data={chartData} cx="50%" cy="50%" labelLine={false} label={{ fill: "#06b6d4", fontSize: 12 }} outerRadius={60} fill="#8884d8" dataKey="value">
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.fill} />
                ))}
              </Pie>
              <Tooltip contentStyle={{ backgroundColor: "#000", border: "1px solid #06b6d4" }} />
            </PieChart>
          </ResponsiveContainer>
        </Card>
      )}

      {/* Top Patterns */}
      {topPatterns.length > 0 && (
        <Card className="p-4 border-cyan-700 bg-black/50">
          <div className="text-cyan-400 text-sm font-bold mb-4">TOP EFFECTIVE PATTERNS</div>
          <div className="space-y-2">
            {topPatterns.map((pattern, idx) => (
              <div key={pattern.id} className="flex items-center justify-between p-2 bg-black/70 rounded border border-cyan-900">
                <div>
                  <div className="text-xs font-mono text-cyan-300">{pattern.patternType}</div>
                  <div className="text-xs text-cyan-600">{pattern.description}</div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-bold text-green-400">{pattern.effectivenessScore}%</div>
                  <div className="text-xs text-cyan-600">{pattern.occurrences}x</div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}

      {/* Recommendations */}
      {recommendations.length > 0 && (
        <Card className="p-4 border-cyan-700 bg-black/50">
          <div className="text-cyan-400 text-sm font-bold mb-4">💡 IMPROVEMENT RECOMMENDATIONS</div>
          <div className="space-y-2">
            {recommendations.map((rec, idx) => (
              <div key={idx} className="p-2 bg-black/70 rounded border border-yellow-900 text-xs text-yellow-300">
                • {rec}
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}
