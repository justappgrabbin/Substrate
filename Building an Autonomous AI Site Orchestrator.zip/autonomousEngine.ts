/**
 * Autonomous Engine - Generates suggestions and self-modifications based on learning
 */

import { invokeLLM } from "./_core/llm";
import * as learning from "./learning";
import * as db from "./db";

/**
 * Generate autonomous suggestions based on feedback patterns
 */
export async function generateAutonomousSuggestions(userId: number, conversationId: number) {
  try {
    // Get feedback analysis
    const patterns = await learning.getTopPatterns(userId, 10);
    const analysis = await learning.analyzeFeedbackPatterns(userId);
    const recommendations = await learning.generateImprovementRecommendations(userId);

    // Get conversation context
    const conversation = await db.getConversationById(conversationId);
    if (!conversation) return [];

    // Build prompt for LLM to generate suggestions
    const suggestionPrompt = `You are analyzing the SYNTHAI Orchestrator's performance and generating improvement suggestions.

Current Performance Analysis:
- Success Rate: ${analysis.successRate.toFixed(1)}%
- Total Feedback: ${analysis.totalFeedback}
- Good Responses: ${analysis.goodCount}
- Meh Responses: ${analysis.mehCount}
- Bad Responses: ${analysis.badCount}

Top Effective Patterns:
${patterns.slice(0, 3).map((p) => `- ${p.patternType}: ${p.effectivenessScore}% effective (${p.occurrences} times)`).join("\n")}

Current Recommendations:
${recommendations.join("\n")}

Active Modules: ${conversation.activeModules.join(", ")}

Generate 2-3 specific, actionable suggestions for improving the orchestrator. For each suggestion, provide:
1. Title (short)
2. Description (what to improve)
3. Proposed Change (how to implement)
4. Rationale (why this would help)
5. Confidence Score (0-100)

Format as JSON array with objects containing: title, description, proposedChange, rationale, confidenceScore`;

    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content:
            "You are an expert AI system analyzer. Generate specific, actionable improvement suggestions in JSON format.",
        },
        {
          role: "user",
          content: suggestionPrompt,
        },
      ],
      response_format: {
        type: "json_schema",
        json_schema: {
          name: "suggestions",
          strict: true,
          schema: {
            type: "array",
            items: {
              type: "object",
              properties: {
                title: { type: "string" },
                description: { type: "string" },
                proposedChange: { type: "string" },
                rationale: { type: "string" },
                confidenceScore: { type: "number" },
              },
              required: ["title", "description", "proposedChange", "rationale", "confidenceScore"],
              additionalProperties: false,
            },
          },
        },
      },
    });

    const content = response.choices?.[0]?.message?.content;
    if (!content) return [];

    const suggestions = JSON.parse(content as string);

    // Store suggestions in database
    const stored = [];
    for (const suggestion of suggestions) {
      await learning.createAutonomousSuggestion(
        userId,
        "performance-improvement",
        suggestion.title,
        suggestion.description,
        suggestion.proposedChange,
        suggestion.rationale,
        suggestion.confidenceScore,
        conversationId
      );
      stored.push(suggestion);
    }

    return stored;
  } catch (error) {
    console.error("[Autonomous Engine] Error generating suggestions:", error);
    return [];
  }
}

/**
 * Generate self-modification recommendations
 */
export async function generateSelfModifications(userId: number) {
  try {
    const patterns = await learning.getTopPatterns(userId, 5);
    const lowEffectivePatterns = patterns.filter((p) => p.effectivenessScore < 40);

    if (lowEffectivePatterns.length === 0) {
      return [];
    }

    const modifications = [];

    for (const pattern of lowEffectivePatterns) {
      const prompt = `The following response pattern has low effectiveness (${pattern.effectivenessScore}%):
Pattern Type: ${pattern.patternType}
Description: ${pattern.description}
Context: ${JSON.stringify(pattern.context)}

Suggest a specific modification to improve this pattern. Provide:
1. What to change (old approach)
2. New approach
3. Why this would be better

Keep it concise and actionable.`;

      const response = await invokeLLM({
        messages: [
          {
            role: "system",
            content: "You are an expert at improving AI response patterns. Be specific and actionable.",
          },
          {
            role: "user",
            content: prompt,
          },
        ],
      });

      const suggestion = response.choices?.[0]?.message?.content as string;
      if (suggestion) {
        modifications.push({
          patternType: pattern.patternType,
          suggestion,
        });
      }
    }

    return modifications;
  } catch (error) {
    console.error("[Autonomous Engine] Error generating modifications:", error);
    return [];
  }
}

/**
 * Evaluate if a suggestion should be auto-applied
 */
export async function shouldAutoApply(suggestion: {
  title: string;
  confidenceScore: number;
  proposedChange: string;
}): Promise<boolean> {
  // Auto-apply only high-confidence suggestions that are low-risk
  const isLowRisk = !suggestion.proposedChange.includes("delete") && !suggestion.proposedChange.includes("remove");
  const isHighConfidence = suggestion.confidenceScore > 85;

  return isLowRisk && isHighConfidence;
}

/**
 * Apply a suggestion to the system
 */
export async function applySuggestion(
  userId: number,
  suggestionId: number,
  suggestion: {
    title: string;
    proposedChange: string;
  }
) {
  try {
    // Mark suggestion as applied
    await learning.approveSuggestion(suggestionId);

    // Record the modification
    await learning.recordSelfModification(
      userId,
      "suggestion-applied",
      "previous-state",
      suggestion.proposedChange,
      `Applied suggestion: ${suggestion.title}`
    );

    return { success: true };
  } catch (error) {
    console.error("[Autonomous Engine] Error applying suggestion:", error);
    throw error;
  }
}
