CREATE TABLE `agents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`role` varchar(255) NOT NULL,
	`instructions` text,
	`trainingData` json NOT NULL DEFAULT (JSON_OBJECT()),
	`status` enum('idle','active','training') NOT NULL DEFAULT 'idle',
	`assignedModules` json NOT NULL DEFAULT (JSON_ARRAY()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `agents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `assemblyTasks` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`conversationId` int,
	`moduleId` int,
	`taskType` varchar(255) NOT NULL,
	`description` text,
	`suggestion` text,
	`applied` boolean NOT NULL DEFAULT false,
	`result` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `assemblyTasks_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `conversations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`title` varchar(255),
	`activeModules` json NOT NULL DEFAULT (JSON_ARRAY()),
	`context` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `conversations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `diagrams` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`conversationId` int,
	`moduleId` int,
	`description` text NOT NULL,
	`diagramType` varchar(255) NOT NULL,
	`imageUrl` varchar(512),
	`generationStatus` enum('pending','generating','complete','failed') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `diagrams_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `ingestedMaterials` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`conversationId` int,
	`fileName` varchar(255) NOT NULL,
	`fileType` varchar(64) NOT NULL,
	`content` text,
	`summary` text,
	`mappedModules` json NOT NULL DEFAULT (JSON_ARRAY()),
	`tags` json NOT NULL DEFAULT (JSON_ARRAY()),
	`s3Url` varchar(512),
	`processingStatus` enum('pending','processing','complete','failed') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `ingestedMaterials_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `messages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`conversationId` int NOT NULL,
	`role` enum('user','assistant') NOT NULL,
	`content` text NOT NULL,
	`metadata` json NOT NULL DEFAULT (JSON_OBJECT()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `messages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `modules` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` text,
	`status` enum('idle','active','processing','error') NOT NULL DEFAULT 'idle',
	`architecture` json NOT NULL DEFAULT (JSON_OBJECT()),
	`dependencies` json NOT NULL DEFAULT (JSON_ARRAY()),
	`metadata` json NOT NULL DEFAULT (JSON_OBJECT()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `modules_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `researchReferences` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`conversationId` int,
	`moduleId` int,
	`title` varchar(512) NOT NULL,
	`source` varchar(512) NOT NULL,
	`summary` text,
	`relevance` varchar(255),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `researchReferences_id` PRIMARY KEY(`id`)
);
