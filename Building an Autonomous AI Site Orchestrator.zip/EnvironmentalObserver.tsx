import React, { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertCircle, Zap, TrendingUp, Eye } from "lucide-react";
import { Streamdown } from "streamdown";

interface StrategicInsight {
  priority: "critical" | "high" | "medium" | "low";
  category: "opportunity" | "risk" | "conflict" | "pattern" | "optimization";
  title: string;
  description: string;
  recommendation: string;
  confidence: number;
  shouldCommunicate: boolean;
  timing: "immediate" | "soon" | "monitor";
}

export default function EnvironmentalObserver() {
  const [insights, setInsights] = useState<StrategicInsight[]>([]);
  const [envState, setEnvState] = useState<any>(null);
  const [proactiveMessage, setProactiveMessage] = useState<string | null>(null);

  const generateInsights = trpc.environment.generateInsights.useQuery();
  const getEnvState = trpc.environment.getEnvironmentalState.useQuery();
  const checkProactive = trpc.environment.checkProactiveCommunication.useQuery();

  useEffect(() => {
    if (generateInsights.data?.insights) {
      setInsights(generateInsights.data.insights);
    }
  }, [generateInsights.data]);

  useEffect(() => {
    if (getEnvState.data) {
      setEnvState(getEnvState.data);
    }
  }, [getEnvState.data]);

  useEffect(() => {
    if (checkProactive.data?.shouldCommunicate && checkProactive.data?.message) {
      setProactiveMessage(checkProactive.data.message);
    }
  }, [checkProactive.data]);

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "critical":
        return "destructive";
      case "high":
        return "secondary";
      case "medium":
        return "outline";
      default:
        return "default";
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "opportunity":
        return <TrendingUp className="w-4 h-4" />;
      case "risk":
        return <AlertCircle className="w-4 h-4" />;
      case "conflict":
        return <Zap className="w-4 h-4" />;
      case "pattern":
        return <Eye className="w-4 h-4" />;
      default:
        return <TrendingUp className="w-4 h-4" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Proactive Message */}
      {proactiveMessage && (
        <Card className="border-neon-cyan bg-black/50 backdrop-blur">
          <CardHeader>
            <CardTitle className="text-neon-cyan flex items-center gap-2">
              <Eye className="w-5 h-5" />
              Observation
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Streamdown>{proactiveMessage}</Streamdown>
          </CardContent>
        </Card>
      )}

      {/* Environmental State */}
      {envState && (
        <Card className="border-neon-magenta/30">
          <CardHeader>
            <CardTitle className="text-neon-magenta">System Status</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-xs text-gray-400 uppercase tracking-wider">System Health</p>
                <Badge
                  variant={
                    envState.systemHealth === "calm"
                      ? "outline"
                      : envState.systemHealth === "active"
                        ? "secondary"
                        : "destructive"
                  }
                  className="mt-2"
                >
                  {envState.systemHealth}
                </Badge>
              </div>
              <div>
                <p className="text-xs text-gray-400 uppercase tracking-wider">Active Agents</p>
                <p className="text-2xl font-bold text-neon-cyan mt-2">{envState.activeAgents.length}</p>
              </div>
              <div>
                <p className="text-xs text-gray-400 uppercase tracking-wider">Recent Actions</p>
                <p className="text-2xl font-bold text-neon-magenta mt-2">{envState.recentActions.length}</p>
              </div>
              <div>
                <p className="text-xs text-gray-400 uppercase tracking-wider">Anomalies</p>
                <p className="text-2xl font-bold text-red-500 mt-2">{envState.anomalies.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Strategic Insights */}
      <div className="space-y-4">
        <h3 className="text-lg font-bold text-neon-cyan uppercase tracking-wider">Strategic Insights</h3>
        {insights.length === 0 ? (
          <p className="text-gray-400 text-sm">Analyzing system patterns...</p>
        ) : (
          insights.map((insight, idx) => (
            <Card
              key={idx}
              className={`border-l-4 ${
                insight.priority === "critical"
                  ? "border-l-red-500"
                  : insight.priority === "high"
                    ? "border-l-neon-magenta"
                    : "border-l-neon-cyan"
              }`}
            >
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-start gap-3 flex-1">
                    {getCategoryIcon(insight.category)}
                    <div className="flex-1">
                      <CardTitle className="text-sm font-bold text-white">{insight.title}</CardTitle>
                      <CardDescription className="text-xs mt-1">{insight.category}</CardDescription>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Badge variant={getPriorityColor(insight.priority)} className="text-xs">
                      {insight.priority}
                    </Badge>
                    <Badge variant="outline" className="text-xs">
                      {insight.confidence}%
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <p className="text-xs text-gray-400 uppercase tracking-wider mb-1">Description</p>
                  <p className="text-sm text-gray-300">{insight.description}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-400 uppercase tracking-wider mb-1">Recommendation</p>
                  <p className="text-sm text-neon-cyan font-mono">{insight.recommendation}</p>
                </div>
                <div className="flex items-center justify-between pt-2 border-t border-gray-700">
                  <span className="text-xs text-gray-500">Timing: {insight.timing}</span>
                  {insight.shouldCommunicate && (
                    <Badge variant="secondary" className="text-xs">
                      Will Communicate
                    </Badge>
                  )}
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
