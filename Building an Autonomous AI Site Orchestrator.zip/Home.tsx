import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { OrchestratorChat } from "@/components/OrchestratorChat";
import { ModuleMap } from "@/components/ModuleMap";
import { MaterialUpload } from "@/components/MaterialUpload";
import { AgentConfig } from "@/components/AgentConfig";
import { IngestionHistory } from "@/components/IngestionHistory";
import { BestPracticeAdvisor } from "@/components/BestPracticeAdvisor";
import LearningAnalytics from "@/components/LearningAnalytics";
import AutonomousSuggestions from "@/components/AutonomousSuggestions";
import EnvironmentalObserver from "@/components/EnvironmentalObserver";
import DynamicComponentRenderer from "@/components/DynamicComponentRenderer";
import { useDynamicComponent } from "@/contexts/DynamicComponentContext";
import { trpc } from "@/lib/trpc";
import { getLoginUrl } from "@/const";
import { Loader2, Plus, Zap, Brain, Lightbulb, Eye } from "lucide-react";
import { useState, useEffect } from "react";

export default function Home() {
  const { user, loading, isAuthenticated, logout } = useAuth();
  const { currentRequest, closeComponent } = useDynamicComponent();
  const [conversationId, setConversationId] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState("chat");

  // Fetch or create conversation
  const { data: conversations, isLoading: conversationsLoading } = trpc.conversation.list.useQuery(
    undefined,
    { enabled: isAuthenticated }
  );

  const createConversationMutation = trpc.conversation.create.useMutation({
    onSuccess: (data) => {
      setConversationId(data.conversationId);
    },
  });

  useEffect(() => {
    if (conversations && conversations.length > 0 && !conversationId) {
      setConversationId(conversations[0].id);
    }
  }, [conversations, conversationId]);

  const handleCreateConversation = async () => {
    await createConversationMutation.mutateAsync({
      title: `Session ${new Date().toLocaleTimeString()}`,
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-neon-cyan" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background grid-bg flex flex-col items-center justify-center p-4">
        {/* Retro header */}
        <div className="text-center mb-8 space-y-4">
          <div className="text-6xl font-mono font-bold text-neon-cyan animate-pulse">
            SYNTHAI
          </div>
          <div className="text-2xl font-mono text-neon-magenta">
            ORCHESTRATOR
          </div>
          <p className="text-sm text-muted-foreground max-w-md">
            Autonomous AI partner for managing modular science lab architectures.
            GNN • Resonance • Embodied Reality
          </p>
        </div>

        {/* Login button */}
        <Button
          onClick={() => (window.location.href = getLoginUrl())}
          className="bg-neon-cyan hover:bg-neon-magenta text-background font-mono font-bold px-8 py-6 text-lg"
        >
          <Zap className="w-5 h-5 mr-2" />
          INITIALIZE SYSTEM
        </Button>

        {/* Error codes */}
        <div className="mt-12 space-y-2 text-xs font-mono">
          <div className="error-code">ERR_AUTH_REQUIRED</div>
          <div className="error-code">ERR_SESSION_INACTIVE</div>
          <div className="error-code">ERR_ORCHESTRATOR_OFFLINE</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="border-b border-neon-cyan bg-card px-4 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Zap className="w-6 h-6 text-neon-cyan animate-pulse" />
            <div>
              <h1 className="text-neon-cyan font-mono font-bold text-xl">SYNTHAI ORCHESTRATOR</h1>
              <p className="text-xs text-muted-foreground">Science Lab Command Center</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-sm text-muted-foreground">
              <span className="text-neon-cyan">{user?.name}</span>
            </div>
            <Button
              onClick={() => logout()}
              variant="outline"
              className="border-neon-magenta text-neon-magenta hover:bg-neon-magenta/10"
            >
              DISCONNECT
            </Button>
          </div>
        </div>
      </header>

      {/* Main content */}
      <div className="flex-1 max-w-7xl mx-auto w-full p-4">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full">
          {/* Tab list */}
          <TabsList className="bg-card border-b border-neon-cyan mb-4 flex-wrap">
            <TabsTrigger
              value="chat"
              className="data-[state=active]:bg-neon-cyan/20 data-[state=active]:text-neon-cyan"
            >
              <Zap className="w-4 h-4 mr-2" />
              ORCHESTRATOR
            </TabsTrigger>
            <TabsTrigger
              value="modules"
              className="data-[state=active]:bg-neon-cyan/20 data-[state=active]:text-neon-cyan"
            >
              <Zap className="w-4 h-4 mr-2" />
              TOPOLOGY
            </TabsTrigger>
            <TabsTrigger
              value="materials"
              className="data-[state=active]:bg-neon-cyan/20 data-[state=active]:text-neon-cyan"
            >
              <Zap className="w-4 h-4 mr-2" />
              MATERIALS
            </TabsTrigger>
            <TabsTrigger
              value="agents"
              className="data-[state=active]:bg-neon-cyan/20 data-[state=active]:text-neon-cyan"
            >
              <Zap className="w-4 h-4 mr-2" />
              AGENTS
            </TabsTrigger>
            <TabsTrigger
              value="history"
              className="data-[state=active]:bg-neon-cyan/20 data-[state=active]:text-neon-cyan"
            >
              <Zap className="w-4 h-4 mr-2" />
              HISTORY
            </TabsTrigger>
            <TabsTrigger
              value="advisor"
              className="data-[state=active]:bg-neon-cyan/20 data-[state=active]:text-neon-cyan"
            >
              <Zap className="w-4 h-4 mr-2" />
              ADVISOR
            </TabsTrigger>
            <TabsTrigger
              value="learning"
              className="data-[state=active]:bg-neon-cyan/20 data-[state=active]:text-neon-cyan"
            >
              <Brain className="w-4 h-4 mr-2" />
              LEARNING
            </TabsTrigger>
            <TabsTrigger
              value="suggestions"
              className="data-[state=active]:bg-neon-cyan/20 data-[state=active]:text-neon-cyan"
            >
              <Lightbulb className="w-4 h-4 mr-2" />
              SUGGESTIONS
            </TabsTrigger>
            <TabsTrigger
              value="observer"
              className="data-[state=active]:bg-neon-cyan/20 data-[state=active]:text-neon-cyan"
            >
              <Eye className="w-4 h-4 mr-2" />
              OBSERVER
            </TabsTrigger>
          </TabsList>

          {/* Chat tab */}
          <TabsContent value="chat" className="h-[calc(100vh-200px)]">
            {conversationsLoading ? (
              <div className="flex items-center justify-center h-full">
                <Loader2 className="w-6 h-6 animate-spin text-neon-cyan" />
              </div>
            ) : conversationId ? (
              <div className="flex gap-4 h-full">
                {/* Chat */}
                <div className="flex-1">
                  <OrchestratorChat conversationId={conversationId} />
                </div>

                {/* Sidebar */}
                <div className="w-64 space-y-4">
                  <Card className="p-3 border-neon-magenta bg-card">
                    <h3 className="text-neon-magenta font-mono font-bold text-sm mb-2">
                      SESSIONS
                    </h3>
                    <div className="space-y-2 max-h-48 overflow-y-auto">
                      {conversations?.map((conv) => (
                        <button
                          key={conv.id}
                          onClick={() => setConversationId(conv.id)}
                          className={`w-full text-left text-xs p-2 rounded border transition-all ${
                            conversationId === conv.id
                              ? "border-neon-cyan bg-neon-cyan/10 text-neon-cyan"
                              : "border-neon-magenta/30 text-muted-foreground hover:border-neon-magenta"
                          }`}
                        >
                          {conv.title || `Session ${conv.id}`}
                        </button>
                      ))}
                    </div>
                    <Button
                      onClick={handleCreateConversation}
                      className="w-full mt-2 bg-neon-magenta hover:bg-neon-cyan text-background font-mono text-xs"
                    >
                      <Plus className="w-3 h-3 mr-1" />
                      NEW SESSION
                    </Button>
                  </Card>

                  {/* Quick stats */}
                  <Card className="p-3 border-neon-cyan bg-card/50">
                    <h3 className="text-neon-cyan font-mono font-bold text-sm mb-2">STATUS</h3>
                    <div className="space-y-1 text-xs text-muted-foreground">
                      <div>Active: <span className="text-neon-green">●</span></div>
                      <div>Modules: 3</div>
                      <div>Agents: 0</div>
                      <div>Materials: 0</div>
                    </div>
                  </Card>
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-center h-full">
                <Button
                  onClick={handleCreateConversation}
                  className="bg-neon-cyan hover:bg-neon-magenta text-background font-mono font-bold"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  START NEW SESSION
                </Button>
              </div>
            )}
          </TabsContent>

          {/* Modules tab */}
          <TabsContent value="modules" className="h-[calc(100vh-200px)] overflow-y-auto">
            <ModuleMap />
          </TabsContent>

          {/* Materials tab */}
          <TabsContent value="materials" className="h-[calc(100vh-200px)] overflow-y-auto">
            <MaterialUpload conversationId={conversationId || undefined} />
          </TabsContent>

          {/* Agents tab */}
          <TabsContent value="agents" className="h-[calc(100vh-200px)] overflow-y-auto">
            <AgentConfig />
          </TabsContent>

          {/* History tab */}
          <TabsContent value="history" className="h-[calc(100vh-200px)] overflow-y-auto">
            <IngestionHistory />
          </TabsContent>

          {/* Advisor tab */}
          <TabsContent value="advisor" className="h-[calc(100vh-200px)] overflow-y-auto">
            <BestPracticeAdvisor />
          </TabsContent>

          {/* Learning tab */}
          <TabsContent value="learning" className="h-[calc(100vh-200px)] overflow-y-auto">
            <Card className="p-4 border-neon-cyan bg-card">
              <h2 className="text-neon-cyan font-mono font-bold text-lg mb-4">📊 LEARNING ANALYTICS</h2>
              <LearningAnalytics />
            </Card>
          </TabsContent>

          {/* Suggestions tab */}
          <TabsContent value="suggestions" className="h-[calc(100vh-200px)] overflow-y-auto">
            <Card className="p-4 border-neon-cyan bg-card">
              <h2 className="text-neon-cyan font-mono font-bold text-lg mb-4">AUTONOMOUS SUGGESTIONS</h2>
              <AutonomousSuggestions />
            </Card>
          </TabsContent>

          {/* Observer tab */}
          <TabsContent value="observer" className="h-[calc(100vh-200px)] overflow-y-auto">
            <Card className="p-4 border-neon-magenta bg-card">
              <h2 className="text-neon-magenta font-mono font-bold text-lg mb-4">ENVIRONMENTAL OBSERVER</h2>
              <EnvironmentalObserver />
            </Card>
          </TabsContent>
        </Tabs>
        
        {/* Dynamic Component Renderer for UI Morphing */}
        <DynamicComponentRenderer
          request={currentRequest}
          onClose={closeComponent}
        />
      </div>
    </div>
  );
}
