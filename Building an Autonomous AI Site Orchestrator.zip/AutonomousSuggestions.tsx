import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Lightbulb, CheckCircle, XCircle } from "lucide-react";
import { toast } from "sonner";

export default function AutonomousSuggestions() {
  const [suggestions, setSuggestions] = useState<any[]>([]);

  const { data: pendingSuggestions, isLoading } = trpc.learning.getPendingSuggestions.useQuery();

  const approveMutation = trpc.learning.approveSuggestion.useMutation({
    onSuccess: () => {
      toast.success("Suggestion approved! The system will apply this improvement.");
      setSuggestions((prev) => prev.filter((s) => s.id !== approveMutation.variables?.suggestionId));
    },
    onError: () => {
      toast.error("Failed to approve suggestion");
    },
  });

  useEffect(() => {
    if (pendingSuggestions) {
      setSuggestions(pendingSuggestions);
    }
  }, [pendingSuggestions]);

  if (isLoading) {
    return <div className="text-cyan-400 text-sm">Loading suggestions...</div>;
  }

  if (suggestions.length === 0) {
    return (
      <div className="text-center py-8 text-cyan-600">
        <Lightbulb className="w-8 h-8 mx-auto mb-2 opacity-50" />
        <p className="text-sm">No suggestions yet. Keep providing feedback to help me learn!</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="text-cyan-400 text-sm font-bold mb-4">
        🤖 AUTONOMOUS SUGGESTIONS ({suggestions.length})
      </div>

      {suggestions.map((suggestion) => (
        <Card key={suggestion.id} className="p-4 border-cyan-700 bg-black/50 hover:border-cyan-500 transition">
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <Lightbulb className="w-4 h-4 text-yellow-400" />
                <h3 className="font-bold text-cyan-300">{suggestion.title}</h3>
                <span className="text-xs px-2 py-1 bg-cyan-900/50 rounded text-cyan-400">
                  {suggestion.confidenceScore}% confident
                </span>
              </div>

              <p className="text-sm text-cyan-100 mb-2">{suggestion.description}</p>

              <div className="bg-black/70 p-3 rounded border border-cyan-900 mb-3">
                <div className="text-xs text-cyan-500 font-mono mb-1">PROPOSED CHANGE:</div>
                <p className="text-xs text-cyan-200 font-mono">{suggestion.proposedChange}</p>
              </div>

              <div className="text-xs text-cyan-600 italic">{suggestion.rationale}</div>
            </div>

            <Button
              size="sm"
              onClick={() => approveMutation.mutate({ suggestionId: suggestion.id })}
              disabled={approveMutation.isPending}
              className="bg-green-600 hover:bg-green-700 text-black font-bold whitespace-nowrap"
            >
              <CheckCircle className="w-4 h-4 mr-1" />
              Approve
            </Button>
          </div>
        </Card>
      ))}
    </div>
  );
}
