import React, { createContext, useContext, useState, useCallback } from "react";
import { ComponentRequest } from "@/lib/componentRegistry";

interface DynamicComponentContextType {
  currentRequest: ComponentRequest | null;
  requestComponent: (request: ComponentRequest) => void;
  closeComponent: () => void;
  setComponentResult: (result: any) => void;
  lastResult: any;
}

const DynamicComponentContext = createContext<DynamicComponentContextType | undefined>(undefined);

export function DynamicComponentProvider({ children }: { children: React.ReactNode }) {
  const [currentRequest, setCurrentRequest] = useState<ComponentRequest | null>(null);
  const [lastResult, setLastResult] = useState<any>(null);

  const requestComponent = useCallback((request: ComponentRequest) => {
    setCurrentRequest(request);
  }, []);

  const closeComponent = useCallback(() => {
    setCurrentRequest(null);
  }, []);

  const setComponentResult = useCallback((result: any) => {
    setLastResult(result);
    closeComponent();
  }, [closeComponent]);

  return (
    <DynamicComponentContext.Provider
      value={{
        currentRequest,
        requestComponent,
        closeComponent,
        setComponentResult,
        lastResult,
      }}
    >
      {children}
    </DynamicComponentContext.Provider>
  );
}

export function useDynamicComponent() {
  const context = useContext(DynamicComponentContext);
  if (!context) {
    throw new Error("useDynamicComponent must be used within DynamicComponentProvider");
  }
  return context;
}
