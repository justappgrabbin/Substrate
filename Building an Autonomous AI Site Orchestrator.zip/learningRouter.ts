/**
 * Learning Router - tRPC endpoints for feedback, patterns, and self-improvement
 */

import { z } from "zod";
import { protectedProcedure, router } from "./_core/trpc";
import * as learning from "./learning";

export const learningRouter = router({
  /**
   * Record feedback on an orchestrator response
   */
  recordFeedback: protectedProcedure
    .input(
      z.object({
        messageId: z.number(),
        conversationId: z.number(),
        rating: z.enum(["good", "meh", "bad"]),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      if (!ctx.user) throw new Error("Not authenticated");

      await learning.recordFeedback(
        ctx.user.id,
        input.messageId,
        input.conversationId,
        input.rating,
        input.notes
      );

      // Analyze patterns after feedback
      const patterns = await learning.analyzeFeedbackPatterns(ctx.user.id);

      return {
        success: true,
        patterns,
      };
    }),

  /**
   * Get feedback for a conversation
   */
  getConversationFeedback: protectedProcedure
    .input(z.object({ conversationId: z.number() }))
    .query(async ({ input, ctx }) => {
      if (!ctx.user) throw new Error("Not authenticated");

      return await learning.getFeedbackByConversation(ctx.user.id, input.conversationId);
    }),

  /**
   * Analyze feedback patterns
   */
  analyzeFeedback: protectedProcedure.query(async ({ ctx }) => {
    if (!ctx.user) throw new Error("Not authenticated");

    const analysis = await learning.analyzeFeedbackPatterns(ctx.user.id);
    const topPatterns = await learning.getTopPatterns(ctx.user.id, 5);
    const recommendations = await learning.generateImprovementRecommendations(ctx.user.id);

    return {
      analysis,
      topPatterns,
      recommendations,
    };
  }),

  /**
   * Get pending autonomous suggestions
   */
  getPendingSuggestions: protectedProcedure.query(async ({ ctx }) => {
    if (!ctx.user) throw new Error("Not authenticated");

    return await learning.getPendingSuggestions(ctx.user.id);
  }),

  /**
   * Approve an autonomous suggestion
   */
  approveSuggestion: protectedProcedure
    .input(z.object({ suggestionId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      if (!ctx.user) throw new Error("Not authenticated");

      await learning.approveSuggestion(input.suggestionId);

      return { success: true };
    }),

  /**
   * Get top learning patterns
   */
  getTopPatterns: protectedProcedure
    .input(z.object({ limit: z.number().default(5) }))
    .query(async ({ input, ctx }) => {
      if (!ctx.user) throw new Error("Not authenticated");

      return await learning.getTopPatterns(ctx.user.id, input.limit);
    }),

  /**
   * Get improvement recommendations
   */
  getRecommendations: protectedProcedure.query(async ({ ctx }) => {
    if (!ctx.user) throw new Error("Not authenticated");

    return await learning.generateImprovementRecommendations(ctx.user.id);
  }),
});
