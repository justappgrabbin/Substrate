/**
 * Learning Module - Handles feedback, pattern analysis, and self-improvement
 */

import { eq, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import * as schema from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    _db = drizzle(process.env.DATABASE_URL);
  }
  return _db;
}

/**
 * Record feedback on an orchestrator response
 */
export async function recordFeedback(
  userId: number,
  messageId: number,
  conversationId: number,
  rating: "good" | "meh" | "bad",
  notes?: string,
  context?: Record<string, unknown>
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(schema.feedback).values({
    userId,
    messageId,
    conversationId,
    rating,
    notes,
    context: context || {},
  });
}

/**
 * Get feedback for a conversation
 */
export async function getFeedbackByConversation(userId: number, conversationId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db
    .select()
    .from(schema.feedback)
    .where(and(eq(schema.feedback.userId, userId), eq(schema.feedback.conversationId, conversationId)));
}

/**
 * Analyze patterns from feedback
 */
export async function analyzeFeedbackPatterns(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const allFeedback = await db.select().from(schema.feedback).where(eq(schema.feedback.userId, userId));

  // Count ratings
  const goodCount = allFeedback.filter((f) => f.rating === "good").length;
  const mehCount = allFeedback.filter((f) => f.rating === "meh").length;
  const badCount = allFeedback.filter((f) => f.rating === "bad").length;

  // Calculate effectiveness score (0-100)
  const total = allFeedback.length;
  const effectivenessScore = total > 0 ? Math.round((goodCount / total) * 100) : 0;

  return {
    totalFeedback: total,
    goodCount,
    mehCount,
    badCount,
    effectivenessScore,
    successRate: total > 0 ? ((goodCount + mehCount * 0.5) / total) * 100 : 0,
  };
}

/**
 * Create or update a learning pattern
 */
export async function recordLearningPattern(
  userId: number,
  patternType: string,
  description: string,
  effectivenessScore: number,
  context?: Record<string, unknown>
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Check if pattern exists
  const existing = await db
    .select()
    .from(schema.learningPatterns)
    .where(
      and(eq(schema.learningPatterns.userId, userId), eq(schema.learningPatterns.patternType, patternType))
    )
    .limit(1);

  if (existing.length > 0) {
    // Update existing pattern
    return await db
      .update(schema.learningPatterns)
      .set({
        effectivenessScore,
        occurrences: existing[0].occurrences + 1,
        context: context || {},
      })
      .where(eq(schema.learningPatterns.id, existing[0].id));
  } else {
    // Create new pattern
    return await db.insert(schema.learningPatterns).values({
      userId,
      patternType,
      description,
      effectivenessScore,
      occurrences: 1,
      context: context || {},
    });
  }
}

/**
 * Get top learning patterns for a user
 */
export async function getTopPatterns(userId: number, limit: number = 5) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db
    .select()
    .from(schema.learningPatterns)
    .where(eq(schema.learningPatterns.userId, userId))
    .orderBy((t) => t.effectivenessScore)
    .limit(limit);
}

/**
 * Record a self-modification
 */
export async function recordSelfModification(
  userId: number,
  modificationType: string,
  oldValue: string,
  newValue: string,
  rationale: string,
  agentId?: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(schema.selfModifications).values({
    userId,
    agentId,
    modificationType,
    oldValue,
    newValue,
    rationale,
    approved: false,
  });
}

/**
 * Approve and apply a self-modification
 */
export async function approveSelfModification(modificationId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db
    .update(schema.selfModifications)
    .set({
      approved: true,
      appliedAt: new Date(),
    })
    .where(eq(schema.selfModifications.id, modificationId));
}

/**
 * Create an autonomous suggestion
 */
export async function createAutonomousSuggestion(
  userId: number,
  suggestionType: string,
  title: string,
  description: string,
  proposedChange: string,
  rationale: string,
  confidenceScore: number,
  conversationId?: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(schema.autonomousSuggestions).values({
    userId,
    conversationId,
    suggestionType,
    title,
    description,
    proposedChange,
    rationale,
    confidenceScore,
  });
}

/**
 * Get pending suggestions for a user
 */
export async function getPendingSuggestions(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db
    .select()
    .from(schema.autonomousSuggestions)
    .where(
      and(
        eq(schema.autonomousSuggestions.userId, userId),
        eq(schema.autonomousSuggestions.status, "pending")
      )
    );
}

/**
 * Approve an autonomous suggestion
 */
export async function approveSuggestion(suggestionId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db
    .update(schema.autonomousSuggestions)
    .set({
      status: "approved",
      approvedAt: new Date(),
    })
    .where(eq(schema.autonomousSuggestions.id, suggestionId));
}

/**
 * Record inter-agent communication
 */
export async function recordAgentCommunication(
  userId: number,
  fromAgentId: number,
  toAgentId: number,
  messageType: string,
  message: string,
  metadata?: Record<string, unknown>
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(schema.agentCommunications).values({
    userId,
    fromAgentId,
    toAgentId,
    messageType,
    message,
    metadata: metadata || {},
  });
}

/**
 * Get communications for an agent
 */
export async function getAgentCommunications(userId: number, agentId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db
    .select()
    .from(schema.agentCommunications)
    .where(
      and(
        eq(schema.agentCommunications.userId, userId),
        eq(schema.agentCommunications.toAgentId, agentId)
      )
    );
}

/**
 * Generate improvement recommendations based on feedback patterns
 */
export async function generateImprovementRecommendations(userId: number): Promise<string[]> {
  const patterns = await getTopPatterns(userId, 10);
  const analysis = await analyzeFeedbackPatterns(userId);

  const recommendations: string[] = [];

  // If success rate is low, suggest improvements
  if (analysis.successRate < 50) {
    recommendations.push("Success rate is below 50%. Consider adjusting response style or module focus.");
  }

  // If there are high-effectiveness patterns, suggest leveraging them more
  const highEffectiveness = patterns.filter((p) => p.effectivenessScore > 75);
  if (highEffectiveness.length > 0) {
    recommendations.push(
      `Found ${highEffectiveness.length} highly effective patterns. Consider applying these more consistently.`
    );
  }

  // If there are low-effectiveness patterns, suggest reducing them
  const lowEffectiveness = patterns.filter((p) => p.effectivenessScore < 30);
  if (lowEffectiveness.length > 0) {
    recommendations.push(
      `Found ${lowEffectiveness.length} low-effectiveness patterns. Consider reducing or removing these.`
    );
  }

  return recommendations;
}
