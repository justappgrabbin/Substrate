import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { Plus, Zap, Loader2, Trash2 } from "lucide-react";
import { toast } from "sonner";

const AGENT_ROLES = [
  "code-assembler",
  "architect",
  "researcher",
  "optimizer",
  "validator",
  "trainer",
];

export function AgentConfig() {
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    role: "code-assembler",
    instructions: "",
  });

  const { data: agents, isLoading: agentsLoading, refetch } = trpc.agent.list.useQuery();

  const createAgentMutation = trpc.agent.create.useMutation({
    onSuccess: () => {
      toast.success("Agent created successfully");
      setFormData({ name: "", role: "code-assembler", instructions: "" });
      setShowForm(false);
      refetch();
    },
    onError: (error) => {
      toast.error(`Failed to create agent: ${error.message}`);
    },
  });

  const handleCreateAgent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) {
      toast.error("Agent name is required");
      return;
    }

    await createAgentMutation.mutateAsync({
      name: formData.name,
      role: formData.role,
      instructions: formData.instructions,
    });
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="border-b border-neon-cyan pb-3">
        <h3 className="text-neon-cyan font-mono font-bold text-lg">AGENT TRAINING PIPELINE</h3>
        <p className="text-xs text-muted-foreground mt-1">
          Configure specialized sub-agents to handle specific tasks autonomously
        </p>
      </div>

      {/* Create Agent Form */}
      {showForm ? (
        <Card className="p-4 border-neon-magenta bg-card">
          <h4 className="font-mono font-bold text-neon-magenta mb-3">NEW AGENT</h4>
          <form onSubmit={handleCreateAgent} className="space-y-3">
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">Agent Name</label>
              <Input
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="e.g., CodeAssembler, ArchitectAdvisor"
                className="bg-input border-neon-cyan text-foreground"
              />
            </div>

            <div>
              <label className="text-xs text-muted-foreground mb-1 block">Role</label>
              <select
                value={formData.role}
                onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                className="w-full bg-input border border-neon-cyan text-foreground rounded px-3 py-2 text-sm"
              >
                {AGENT_ROLES.map((role) => (
                  <option key={role} value={role}>
                    {role}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-xs text-muted-foreground mb-1 block">Instructions</label>
              <Textarea
                value={formData.instructions}
                onChange={(e) => setFormData({ ...formData, instructions: e.target.value })}
                placeholder="Describe what this agent should do..."
                className="bg-input border-neon-cyan text-foreground text-sm"
                rows={4}
              />
            </div>

            <div className="flex gap-2">
              <Button
                type="submit"
                disabled={createAgentMutation.isPending}
                className="flex-1 bg-neon-magenta hover:bg-neon-cyan text-background font-mono text-sm"
              >
                {createAgentMutation.isPending ? (
                  <>
                    <Loader2 className="w-3 h-3 mr-1 animate-spin" />
                    Creating...
                  </>
                ) : (
                  <>
                    <Plus className="w-3 h-3 mr-1" />
                    Create Agent
                  </>
                )}
              </Button>
              <Button
                type="button"
                onClick={() => setShowForm(false)}
                variant="outline"
                className="border-neon-cyan text-neon-cyan hover:bg-neon-cyan/10 text-sm"
              >
                Cancel
              </Button>
            </div>
          </form>
        </Card>
      ) : (
        <Button
          onClick={() => setShowForm(true)}
          className="w-full bg-neon-magenta hover:bg-neon-cyan text-background font-mono font-bold"
        >
          <Plus className="w-4 h-4 mr-2" />
          CREATE NEW AGENT
        </Button>
      )}

      {/* Agents List */}
      {agentsLoading ? (
        <div className="flex items-center justify-center h-32">
          <Loader2 className="w-6 h-6 animate-spin text-neon-cyan" />
        </div>
      ) : agents && agents.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {agents.map((agent) => (
            <Card key={agent.id} className="p-3 border-neon-cyan bg-card/50">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <h4 className="font-mono font-bold text-neon-cyan text-sm">{agent.name}</h4>
                  <Badge variant="outline" className="text-xs mt-1">
                    {agent.role}
                  </Badge>
                </div>
                <button className="text-destructive hover:text-destructive/80">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

              {agent.instructions && (
                <p className="text-xs text-muted-foreground line-clamp-2">{agent.instructions}</p>
              )}

              <div className="mt-2 pt-2 border-t border-neon-cyan/20">
                <p className="text-xs text-muted-foreground">
                  Created: {new Date(agent.createdAt).toLocaleDateString()}
                </p>
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="p-6 border-neon-cyan bg-card/50 text-center">
          <Zap className="w-8 h-8 mx-auto mb-2 text-neon-cyan/50" />
          <p className="text-sm text-muted-foreground">No agents configured yet</p>
          <p className="text-xs text-muted-foreground mt-1">
            Create your first agent to start the training pipeline
          </p>
        </Card>
      )}

      {/* Info */}
      <Card className="p-3 border-neon-magenta/50 bg-card/30">
        <h4 className="font-mono text-xs font-bold text-neon-magenta mb-2">AGENT CAPABILITIES</h4>
        <div className="space-y-1 text-xs text-muted-foreground">
          <p>• <span className="text-neon-cyan">code-assembler</span>: Organize and structure code</p>
          <p>• <span className="text-neon-cyan">architect</span>: Design system architecture</p>
          <p>• <span className="text-neon-cyan">researcher</span>: Investigate and analyze</p>
          <p>• <span className="text-neon-cyan">optimizer</span>: Improve performance</p>
          <p>• <span className="text-neon-cyan">validator</span>: Test and verify</p>
          <p>• <span className="text-neon-cyan">trainer</span>: Train other agents</p>
        </div>
      </Card>
    </div>
  );
}
