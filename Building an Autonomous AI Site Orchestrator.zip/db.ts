import { eq, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, conversations, messages, ingestedMaterials, modules, agents, assemblyTasks, diagrams, researchReferences } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Conversation queries
export async function createConversation(userId: number, title?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(conversations).values({
    userId,
    title,
  });
  return result;
}

export async function getConversationsByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(conversations).where(eq(conversations.userId, userId)).orderBy(desc(conversations.updatedAt));
}

export async function getConversationById(id: number) {
  const db = await getDb();
  if (!db) return null;
  
  const result = await db.select().from(conversations).where(eq(conversations.id, id)).limit(1);
  return result.length > 0 ? result[0] : null;
}

// Message queries
export async function addMessage(conversationId: number, role: "user" | "assistant", content: string, metadata?: Record<string, unknown>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.insert(messages).values({
    conversationId,
    role,
    content,
    metadata: metadata || {},
  });
}

export async function getMessagesByConversationId(conversationId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(messages).where(eq(messages.conversationId, conversationId)).orderBy(messages.createdAt);
}

// Ingested materials queries
export async function addIngestedMaterial(userId: number, fileName: string, fileType: string, content: string, mappedModules: string[] = []) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.insert(ingestedMaterials).values({
    userId,
    fileName,
    fileType,
    content,
    mappedModules,
  });
}

export async function getIngestedMaterialsByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(ingestedMaterials).where(eq(ingestedMaterials.userId, userId)).orderBy(desc(ingestedMaterials.createdAt));
}

// Module queries
export async function createModule(userId: number, name: string, description?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.insert(modules).values({
    userId,
    name,
    description,
  });
}

export async function getModulesByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(modules).where(eq(modules.userId, userId));
}

export async function getModuleById(id: number) {
  const db = await getDb();
  if (!db) return null;
  
  const result = await db.select().from(modules).where(eq(modules.id, id)).limit(1);
  return result.length > 0 ? result[0] : null;
}

// Agent queries
export async function createAgent(userId: number, name: string, role: string, instructions?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.insert(agents).values({
    userId,
    name,
    role,
    instructions,
  });
}

export async function getAgentsByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(agents).where(eq(agents.userId, userId));
}

// Assembly task queries
export async function createAssemblyTask(userId: number, taskType: string, description?: string, suggestion?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.insert(assemblyTasks).values({
    userId,
    taskType,
    description,
    suggestion,
  });
}

export async function getAssemblyTasksByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(assemblyTasks).where(eq(assemblyTasks.userId, userId)).orderBy(desc(assemblyTasks.createdAt));
}

// Diagram queries
export async function createDiagram(userId: number, description: string, diagramType: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.insert(diagrams).values({
    userId,
    description,
    diagramType,
  });
}

export async function getDiagramsByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(diagrams).where(eq(diagrams.userId, userId)).orderBy(desc(diagrams.createdAt));
}

// Research reference queries
export async function addResearchReference(userId: number, title: string, source: string, summary?: string, relevance?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.insert(researchReferences).values({
    userId,
    title,
    source,
    summary,
    relevance,
  });
}

export async function getResearchReferencesByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(researchReferences).where(eq(researchReferences.userId, userId)).orderBy(desc(researchReferences.createdAt));
}
