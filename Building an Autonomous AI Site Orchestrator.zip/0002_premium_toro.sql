CREATE TABLE `agentCommunications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`fromAgentId` int NOT NULL,
	`toAgentId` int NOT NULL,
	`messageType` varchar(255) NOT NULL,
	`message` text NOT NULL,
	`metadata` json NOT NULL DEFAULT ('{}'),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `agentCommunications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `autonomousSuggestions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`conversationId` int,
	`suggestionType` varchar(255) NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text NOT NULL,
	`proposedChange` text,
	`rationale` text,
	`confidenceScore` int NOT NULL DEFAULT 0,
	`status` enum('pending','approved','rejected','applied') NOT NULL DEFAULT 'pending',
	`approvedAt` timestamp,
	`appliedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `autonomousSuggestions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `feedback` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`messageId` int NOT NULL,
	`conversationId` int NOT NULL,
	`rating` enum('good','meh','bad') NOT NULL,
	`notes` text,
	`context` json NOT NULL DEFAULT ('{}'),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `feedback_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `learningPatterns` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`patternType` varchar(255) NOT NULL,
	`description` text,
	`effectivenessScore` int NOT NULL DEFAULT 0,
	`occurrences` int NOT NULL DEFAULT 0,
	`context` json NOT NULL DEFAULT ('{}'),
	`lastUpdated` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `learningPatterns_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `selfModifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`agentId` int,
	`modificationType` varchar(255) NOT NULL,
	`oldValue` text,
	`newValue` text,
	`rationale` text,
	`impactScore` int NOT NULL DEFAULT 0,
	`approved` boolean NOT NULL DEFAULT false,
	`appliedAt` timestamp,
	`rolledBackAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `selfModifications_id` PRIMARY KEY(`id`)
);
