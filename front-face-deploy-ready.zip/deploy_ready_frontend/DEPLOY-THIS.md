# Deploy settings

## Render Web Service
- Build Command: `pnpm install --frozen-lockfile && pnpm run build`
- Start Command: `pnpm start`

## Netlify
- Build Command: `pnpm install --frozen-lockfile && pnpm run build`
- Publish Directory: `dist/public`

Use Netlify only if you want the static front face. Use Render if you want the bundled Node server wrapper too.
