# Physics to Semantics Toggle

## The Problem

Initially, the system had all the infrastructure for semantic meaning:
- Addresses with gate/line/color/tone/zodiac/house coordinates
- 37,440 nodes with full state tracking
- Continuous morphing and learning

**But the addresses didn't actually drive behavior.** They were just labels on top of generic physics:

```typescript
// Generic physics - same for every node
pressure += internalPressure * 0.01
if (tension > 0.85) → flip state
coherence -= decay
```

The system was a **physics engine pretending to be a semantic system**.

## The Solution

The Physics-to-Semantics toggle transforms how the system works:

### Physics Mode (Default)
```
All nodes behave identically
Tension accumulates uniformly
State transitions happen at same threshold (0.85)
Resonance is uniform between neighbors
```

### Semantic Mode (Enabled)
```
Gate 24 (Rationalization) → High threshold (1.3x), resists change
Gate 61 (Mystery) → Low threshold (0.6x), changes easily
Line 3 (Martyr) → High pressure from learning
Line 5 (Heretic) → Revolutionary, unpredictable
Color 1 (Red) → Environmental pressure
Color 2 (Yellow) → Internal contradiction pressure
Color 3 (Blue) → Collective pressure
Tone 1 (Reactive) → Fast pressure buildup
Tone 5 (Reflective) → Internal focus, less external pressure
```

## How It Works

### Step 1: Toggle the Mode

```typescript
const orchestrator = new ResonanceOrchestrator();

// Switch to semantic mode
orchestrator.toggleSemantics(true);

// Check current mode
if (orchestrator.isSemanticMode()) {
  console.log('Running in SEMANTIC mode');
}
```

### Step 2: Addresses Drive Physics

When semantics are enabled, each node's behavior is determined by its address:

```typescript
// In updateNodeState():
if (semanticsEnabled) {
  pressure = semanticEngine.calculateSemanticPressure(
    nodeState.address,      // ← Address drives calculation
    internalPressure,
    contradiction
  );
  
  threshold = semanticEngine.calculateSemanticThreshold(
    nodeState.address,      // ← Address determines threshold
    0.85
  );
}
```

### Step 3: Resonance is Address-Aware

Nodes with complementary addresses resonate differently:

```typescript
// Same gate → Strong resonance (1.3x boost)
if (address1.gate === address2.gate) {
  resonance *= 1.3;
}

// Complementary gates → Moderate resonance (1.1x boost)
if (areComplementary(address1.gate, address2.gate)) {
  resonance *= 1.1;
}

// Different everything → Reduced resonance (0.7x)
resonance *= 0.7;
```

## The Semantic Multipliers

### Gate Influence (1-64)

| Gate | Influence | Meaning |
|------|-----------|---------|
| 24 | 1.3x | Rationalization - high internal pressure |
| 61 | 0.7x | Mystery - erratic, fast changes |
| 42 | 1.0x | Growth - steady accumulation |
| 3 | 1.2x | Ordering - needs structure |
| 20 | 0.5x | Now - immediate response |

### Line Modulation (1-6)

| Line | Modulation | Meaning |
|------|-----------|---------|
| 1 | 0.8x | Investigative - cautious |
| 2 | 0.6x | Hermit - withdrawn |
| 3 | 1.2x | Martyr - high learning pressure |
| 4 | 1.4x | Opportunist - responsive |
| 5 | 0.9x | Heretic - disruptive |
| 6 | 1.1x | Role Model - stable |

### Color Filtering (1-3)

| Color | Filter | Meaning |
|-------|--------|---------|
| 1 | 1.0x | Red - environmental pressure |
| 2 | 1.3x | Yellow - internal contradiction |
| 3 | 0.8x | Blue - collective pressure |

### Tone Amplification (1-6)

| Tone | Amplification | Meaning |
|------|---------------|---------|
| 1 | 1.2x | Reactive - fast buildup |
| 2 | 1.0x | Responsive - balanced |
| 3 | 1.3x | Generative - creates patterns |
| 4 | 1.4x | Transformative - high pressure |
| 5 | 0.7x | Reflective - internal focus |
| 6 | 1.1x | Transcendent - integrated |

### Zodiac Resonance (1-12)

| Sign | Resonance | Meaning |
|------|-----------|---------|
| Aries (1) | 1.2x | Initiating |
| Taurus (2) | 0.8x | Stable |
| Gemini (3) | 1.1x | Communicative |
| Cancer (4) | 1.3x | Emotional |
| Leo (5) | 1.2x | Expressive |
| Virgo (6) | 0.9x | Analytical |
| Libra (7) | 1.0x | Balanced |
| Scorpio (8) | 1.4x | Transformative |
| Sagittarius (9) | 1.1x | Expansive |
| Capricorn (10) | 0.9x | Disciplined |
| Aquarius (11) | 1.2x | Revolutionary |
| Pisces (12) | 1.0x | Intuitive |

### House Context (1-12)

| House | Context | Meaning |
|-------|---------|---------|
| 1 | 1.2x | Self/Identity |
| 2 | 0.9x | Resources |
| 3 | 1.1x | Communication |
| 4 | 0.8x | Home/Foundation |
| 5 | 1.3x | Creativity |
| 6 | 0.9x | Service/Health |
| 7 | 1.1x | Relationships |
| 8 | 1.4x | Transformation |
| 9 | 1.1x | Expansion |
| 10 | 1.2x | Career |
| 11 | 1.0x | Community |
| 12 | 1.0x | Spirituality |

## Example: The Difference

### Physics Mode

```
Node A (Gate 24, Line 3): Pressure = 0.01, Threshold = 0.85
Node B (Gate 61, Line 5): Pressure = 0.01, Threshold = 0.85
Node C (Gate 42, Line 1): Pressure = 0.01, Threshold = 0.85

All nodes behave identically.
```

### Semantic Mode

```
Node A (Gate 24, Line 3):
  Pressure = 0.01 × 1.3 × 1.2 = 0.0156
  Threshold = 0.85 × 1.5 = 1.275 (very hard to change)
  
Node B (Gate 61, Line 5):
  Pressure = 0.01 × 0.7 × 0.9 = 0.0063
  Threshold = 0.85 × 0.6 = 0.51 (very easy to change)
  
Node C (Gate 42, Line 1):
  Pressure = 0.01 × 1.0 × 0.8 = 0.008
  Threshold = 0.85 × 1.0 = 0.85 (normal)

Each node behaves according to its archetypal meaning.
```

## UI Toggle

In the visualization, you can toggle between modes:

```
[Physics] ↔ [Semantics]
```

When you switch:
1. The system recalculates all pressures
2. Thresholds update for each node
3. Resonance patterns shift
4. The mesh morphs visually to reflect the change
5. Status shows current mode

## What This Means

**Before:** The system was a generic neural network with Human Design labels.

**After:** The system IS the Human Design system. The addresses don't just label nodes—they determine how those nodes think, change, and connect.

The DNA is now expressing.

## Next Steps

1. **Tune the multipliers** - Adjust gate/line/color/tone values to match your understanding
2. **Add more gates** - Expand the gate influence table with all 64 gates
3. **Test resonance patterns** - Verify that complementary addresses actually resonate
4. **Learn from behavior** - Watch how semantic mode creates different patterns than physics mode
5. **Integrate with Synthia** - Use semantic mode to route data through your consciousness system

---

**The toggle is the bridge from simulation to system.**
