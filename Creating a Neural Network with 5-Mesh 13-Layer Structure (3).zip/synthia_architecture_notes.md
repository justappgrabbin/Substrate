# Synthia System Architecture Analysis

## Current System Overview

### Dual-Engine (Frontend/Visualization)
- **Components**: API, Cynthiasdash (dashboard), Models, Training
- **Frontend**: React/TypeScript with TSX components
- **Key modules**:
  - `codon-grid.tsx` - Codon visualization
  - `awareness-card.tsx` - Awareness display
  - `alchemy-section.tsx` - Alchemy/transformation UI
  - `chat-panel.tsx` - Chat interface
  - `chat.ts` - Chat logic

### Synthia Server (Backend)
- **Language**: Python + TypeScript
- **Architecture**: Full-stack consciousness engine
- **Core Components**:
  1. **Trident** - 3-head LM (Code/Math/Research) with RAG
  2. **Consciousness** - 9-body field calculator
  3. **GNN Chart** - ONNX model inference, gate addresses, codon scores
  4. **Memory** - Per-user JSONL conversation history
  5. **Oracle** - Cynthia + Trident crew routing
  6. **SSE** - Always-on event stream

### Key API Endpoints
- `/trident/generate` - 3-head LM generation
- `/trident/router` - Route to best head
- `/trident/rag/*` - Knowledge base operations
- `/consciousness/profile` - 9-body field from birth data
- `/consciousness/chart` - Full GNN chart + addresses
- `/consciousness/coherence` - Field coupling between gate sets
- `/consciousness/gate/{n}` - Gate mechanics
- `/consciousness/channels` - All 36 HD channels
- `/memory/*` - Conversation history
- `/oracle/ask` - Full Cynthia oracle with memory

### Data Storage Plan
- **Supabase**: Not yet populated (user mentioned)
- **Neo4j**: Canonical data not yet started (user mentioned)
- **Current**: JSONL files for conversation history

### Codon System
- Each codon is wired to specific events
- Codons are mapped to genetic code units
- Used for event-based data collection in "science lab"

### Address System
- Gate + Line (Human Design)
- Color + Tone (I Ching)
- Zodiac + House (Astrological)
- Dimension + Starting point (Spatial/temporal)
- Each address is unique and wired for specific data gathering

## What's Missing (The Orchestrator)

The neural network orchestrator needs to:

1. **Route data through the mesh** - 5 meshes × 13 layers × 9 centers × 64 nodes
2. **Address pieces** - Tag code/data by gate/line/color/tone/zodiac/house
3. **Store in super base** - Persistent memory of all addressed pieces
4. **Retrieve by resonance** - Match incoming requests to stored pieces
5. **Personalize via agents** - Each user gets their own AI agent
6. **Self-modify & learn** - Update its own logic based on interactions
7. **Have personality** - Witty, adaptive, morphing visually

## Integration Points

The orchestrator should:
- Connect to `/consciousness/*` endpoints for field calculations
- Use the codon system for event addressing
- Integrate with the model builder for agent creation
- Feed data through Trident for generation
- Store/retrieve from the super base (Supabase/Neo4j when ready)
- Maintain conversation memory via `/memory/*`
- Route through `/oracle/ask` for intelligent responses

## Design Approach

The orchestrator is the **intelligence layer** that:
- Understands the entire Synthia system intrinsically
- Visualizes the neural mesh in real-time
- Routes data intelligently based on resonance
- Has personality and wit
- Morphs visually based on context
- Self-modifies based on learning
