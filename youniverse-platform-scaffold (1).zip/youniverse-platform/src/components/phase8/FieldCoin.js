// FieldCoin.js - Phase 8: FieldCoin + Marketplace
export default function FieldCoin() {
  return (
    <div className="p-4 border border-white/10 rounded-lg">
      <h3 className="font-semibold">FieldCoin.js — Phase 8: FieldCoin + Marketplace</h3>
      <p>Placeholder component. Replace with real logic.</p>
    </div>
  );
}
