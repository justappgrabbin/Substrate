// GateDecoder.js - Phase 1: Chart Engine
export default function GateDecoder() {
  return (
    <div className="p-4 border border-white/10 rounded-lg">
      <h3 className="font-semibold">GateDecoder.js — Phase 1: Chart Engine</h3>
      <p>Placeholder component. Replace with real logic.</p>
    </div>
  );
}
