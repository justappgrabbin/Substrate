// LegacyStorage.js - Phase 7: Soul & Spirit Layers
export default function LegacyStorage() {
  return (
    <div className="p-4 border border-white/10 rounded-lg">
      <h3 className="font-semibold">LegacyStorage.js — Phase 7: Soul & Spirit Layers</h3>
      <p>Placeholder component. Replace with real logic.</p>
    </div>
  );
}
