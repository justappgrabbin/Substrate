// SynthiaRouter.jsx - Phase 0: UI Foundation
export default function SynthiaRouter() {
  return (
    <div className="p-4 border border-white/10 rounded-lg">
      <h3 className="font-semibold">SynthiaRouter.jsx — Phase 0: UI Foundation</h3>
      <p>Placeholder component. Replace with real logic.</p>
    </div>
  );
}
