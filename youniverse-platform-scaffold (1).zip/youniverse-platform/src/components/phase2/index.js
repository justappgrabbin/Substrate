export { default as GateResonanceTest } from './GateResonanceTest.jsx';
export { default as CoherenceTest } from './CoherenceTest.jsx';
export { default as HeartVectorTest } from './HeartVectorTest.jsx';
export { default as FreeWillTest } from './FreeWillTest.jsx';
