export default function Page() {
  return (
    <main className="p-8">
      <h1 className="text-3xl font-bold">YOU-N-I-VERSE</h1>
      <p className="text-slate-300">Phase 0 online. See /download to copy structure.</p>
    </main>
  );
}