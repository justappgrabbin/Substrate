export default function DownloadPage() {
  return (
    <main className="p-8">
      <h1 className="text-2xl font-bold">Development & Download Center</h1>
      <p className="text-slate-300">Use the scaffold zip I gave you to bootstrap locally.</p>
    </main>
  );
}