
-- Schema for YOU-N-I-VERSE
create table if not exists users (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  handle text unique not null,
  display_name text,
  email text
);

create table if not exists charts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references users(id) on delete cascade,
  created_at timestamptz default now(),
  metadata jsonb
);

create table if not exists planets (
  id uuid primary key default gen_random_uuid(),
  chart_id uuid references charts(id) on delete cascade,
  field text check (field in ('Body','Mind','Heart')),
  planet text,
  degree double precision check (degree>=0 and degree<360),
  gate int,
  line int,
  color int,
  tone int,
  base int,
  zodiac_sign text,
  element text
);

create table if not exists glyphs (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  user_id uuid references users(id) on delete cascade,
  label text,
  svg text
);

create table if not exists interference_flags (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references users(id) on delete cascade,
  created_at timestamptz default now(),
  kind text,
  severity int check (severity between 1 and 5),
  notes text
);

create table if not exists quests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references users(id) on delete cascade,
  created_at timestamptz default now(),
  title text,
  status text check (status in ('planned','active','complete')) default 'planned',
  contract_uri text
);
