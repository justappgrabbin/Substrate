# YOU-N-I-VERSE Platform

This repo is the 9‑phase consciousness platform scaffold with UI Foundation, Chart Engine, Tests, Recalibration, Interference, Glyphs, Purpose Pathways, Soul/Spirit, FieldCoin, and Deployment.

## Quickstart
```bash
npm install
npm run dev
```
Then open http://localhost:3000

## Structure
- `src/app` – Next.js app router, global styles, routes
- `src/components/phase*` – phase components
- `src/lib` – scientific, database, utils
- `docs` – research papers, field notes, deployment guide

See `docs/deployment-guide.md` to deploy on Vercel.
