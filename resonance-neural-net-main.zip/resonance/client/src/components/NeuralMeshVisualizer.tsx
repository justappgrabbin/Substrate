/**
 * NEURAL MESH VISUALIZER
 *
 * Does not draw shapes. Reads live orchestrator state every animation frame
 * and lets form emerge from what the mesh actually IS.
 *
 * Layout rules (derived from state, not hardcoded):
 *   Node position   = mesh × layer × arcDegree (time-driven rotation)
 *   Node size       = coherence
 *   Node brightness = tension
 *   Node color      = baseState
 *   Edge bend       = tension differential between endpoints
 *   Ring radius     = average coherence of that mesh layer (breathes)
 *   Center pulse    = globalCoherence
 *
 * Everything geometric is a consequence of data.
 * The only hardcoded values are the color palette.
 */

import React, { useEffect, useRef, useCallback, useState } from 'react';
import { ResonanceOrchestrator, NodeState } from '@/lib/orchestrator';

interface Props {
  orchestrator: ResonanceOrchestrator;
  width?: number;
  height?: number;
  interactive?: boolean;
}

const STATE_COLORS: Record<string, string> = {
  STABLE:    '#a78bfa',
  CHANGING:  '#fbbf24',
  RESOLVING: '#34d399',
  RESONANT:  '#22d3ee',
  DORMANT:   '#334155',
};

const MESH_COLORS = [
  '#ef4444',  // Physical
  '#06b6d4',  // Emotional
  '#a855f7',  // Mental
  '#f59e0b',  // Soul
  '#10b981',  // Field
];

const NeuralMeshVisualizer: React.FC<Props> = ({
  orchestrator,
  width = 800,
  height = 600,
  interactive = true,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const frameRef  = useRef<number | undefined>(undefined);
  const [selected, setSelected] = useState<NodeState | null>(null);
  const [liveStats, setLiveStats] = useState({ coherence: 0.5, morph: 0.5, ticks: 0 });

  // Node position derived entirely from live state — no preset geometry
  const nodePos = useCallback((node: NodeState, cx: number, cy: number) => {
    const { mesh, layer, center, arcDegree, dimension } = node.address;

    // Ring radius breathes with coherence — incoherent mesh shrinks
    const baseR = 40 + mesh * 38;
    const r = baseR * (0.75 + node.coherence * 0.5) + node.tension * 18;

    // Angle: layer spreads nodes around ring, arcDegree rotates over time
    const angle =
      (layer / 13) * Math.PI * 2 +
      (center / 9) * (Math.PI / 4) +
      (arcDegree * Math.PI) / 180;

    // dimension adds subtle wobble
    const wobble = Math.sin(dimension * Math.PI * 2 + Date.now() / 3000) * 4;

    return {
      x: cx + Math.cos(angle) * r + wobble,
      y: cy + Math.sin(angle) * r + wobble,
    };
  }, []);

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const cx = width / 2;
    const cy = height / 2;

    // Background
    ctx.fillStyle = '#020812';
    ctx.fillRect(0, 0, width, height);

    // Dot grid
    ctx.fillStyle = '#0e1f35';
    for (let gx = 0; gx < width; gx += 28)
      for (let gy = 0; gy < height; gy += 28) {
        ctx.beginPath();
        ctx.arc(gx, gy, 0.5, 0, Math.PI * 2);
        ctx.fill();
      }

    const nodes       = orchestrator.getAllMeshNodes();
    const globalCoh   = orchestrator.getGlobalCoherence();
    const morphState  = orchestrator.getMorphState();
    const attractors  = orchestrator.getAttractors();
    const connWeights = orchestrator.getConnectionWeights();

    // Coherence rings — radius is live, not fixed
    for (let m = 0; m < 5; m++) {
      const meshNodes = nodes.filter(n => n.address.mesh === m);
      const avgCoh = meshNodes.length
        ? meshNodes.reduce((s, n) => s + n.coherence, 0) / meshNodes.length
        : 0.5;
      const r = (40 + m * 38) * (0.75 + avgCoh * 0.5);
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.strokeStyle = MESH_COLORS[m];
      ctx.globalAlpha = 0.04 + avgCoh * 0.10;
      ctx.lineWidth = 0.5 + avgCoh * 1.2;
      ctx.stroke();
      ctx.globalAlpha = 1;
    }

    // Attractor glows — stable patterns that emerged
    attractors.forEach((count, key) => {
      const parts = key.split('_');
      if (parts.length < 3) return;
      const mesh = parseInt(parts[0]);
      const fakeNode = {
        address: { mesh, layer: parseInt(parts[1]), center: parseInt(parts[2]),
          arcDegree: 0, dimension: 0 },
        tension: 0, coherence: 0.5
      } as unknown as NodeState;
      const { x, y } = nodePos(fakeNode, cx, cy);
      const strength = Math.min(1, count / 50);
      ctx.beginPath();
      ctx.arc(x, y, 6 + strength * 8, 0, Math.PI * 2);
      ctx.fillStyle = MESH_COLORS[mesh] || '#ffffff';
      ctx.globalAlpha = 0.06 + strength * 0.12;
      ctx.fill();
      ctx.globalAlpha = 1;
    });

    // Learned edges — tension bends the curve
    Array.from(connWeights.entries()).slice(0, 200).forEach(([key, weight]) => {
      if (weight < 1.05) return;
      const parts = key.split('_');
      if (parts.length < 10) return;
      const n1 = nodes.find(n =>
        n.address.mesh === parseInt(parts[0]) &&
        n.address.layer === parseInt(parts[1]) &&
        n.address.center === parseInt(parts[2])
      );
      const n2 = nodes.find(n =>
        n.address.mesh === parseInt(parts[5]) &&
        n.address.layer === parseInt(parts[6]) &&
        n.address.center === parseInt(parts[7])
      );
      if (!n1 || !n2) return;

      const p1 = nodePos(n1, cx, cy);
      const p2 = nodePos(n2, cx, cy);
      const tensionDiff = Math.abs(n1.tension - n2.tension);
      const midX = (p1.x + p2.x) / 2, midY = (p1.y + p2.y) / 2;
      const perpX = -(p2.y - p1.y), perpY = p2.x - p1.x;
      const perpLen = Math.sqrt(perpX * perpX + perpY * perpY) || 1;
      const bend = tensionDiff * 20;

      ctx.beginPath();
      ctx.moveTo(p1.x, p1.y);
      ctx.quadraticCurveTo(
        midX + (perpX / perpLen) * bend,
        midY + (perpY / perpLen) * bend,
        p2.x, p2.y
      );
      ctx.strokeStyle = MESH_COLORS[n1.address.mesh] || '#ffffff';
      ctx.globalAlpha = Math.min(0.35, (weight - 1) * 0.15);
      ctx.lineWidth = 0.4 + (weight - 1) * 0.3;
      ctx.stroke();
      ctx.globalAlpha = 1;
    });

    // Nodes — render hot ones always, cold ones sampled
    const hot  = nodes.filter(n => n.baseState === 'CHANGING' || n.baseState === 'RESONANT');
    const cold = nodes.filter(n => n.baseState !== 'CHANGING' && n.baseState !== 'RESONANT');
    const renderSet = [...hot, ...cold.filter((_, i) => i % 8 === 0)];

    renderSet.forEach(node => {
      const { x, y } = nodePos(node, cx, cy);
      const stateColor = STATE_COLORS[node.baseState] || '#ffffff';
      const r = 1.2 + node.coherence * 3.5;

      if (node.baseState === 'CHANGING') {
        ctx.beginPath();
        ctx.arc(x, y, r + 4, 0, Math.PI * 2);
        ctx.fillStyle = '#fbbf24';
        ctx.globalAlpha = 0.12 + node.tension * 0.18;
        ctx.fill();
        ctx.globalAlpha = 1;
      } else if (node.baseState === 'RESONANT') {
        const pulse = 0.5 + Math.sin(Date.now() / 400 + node.address.node) * 0.5;
        ctx.beginPath();
        ctx.arc(x, y, r + 5, 0, Math.PI * 2);
        ctx.fillStyle = '#22d3ee';
        ctx.globalAlpha = 0.08 + pulse * 0.14;
        ctx.fill();
        ctx.globalAlpha = 1;
      }

      if (node.coherence > 0.4) {
        ctx.beginPath();
        ctx.arc(x, y, r + 1.5, 0, Math.PI * 2);
        ctx.strokeStyle = MESH_COLORS[node.address.mesh] || '#ffffff';
        ctx.globalAlpha = 0.10 + node.coherence * 0.15;
        ctx.lineWidth = 0.5;
        ctx.stroke();
        ctx.globalAlpha = 1;
      }

      ctx.beginPath();
      ctx.arc(x, y, r, 0, Math.PI * 2);
      ctx.fillStyle = stateColor;
      ctx.globalAlpha = 0.12 + node.coherence * 0.75;
      ctx.fill();
      ctx.globalAlpha = 1;
    });

    // Center core — pulses with globalCoherence
    const coreGlow = 8 + globalCoh * 18;
    const grad = ctx.createRadialGradient(cx, cy, 0, cx, cy, coreGlow);
    grad.addColorStop(0, `rgba(34,211,238,${globalCoh * 0.3})`);
    grad.addColorStop(1, 'rgba(34,211,238,0)');
    ctx.beginPath();
    ctx.arc(cx, cy, coreGlow, 0, Math.PI * 2);
    ctx.fillStyle = grad;
    ctx.fill();

    ctx.beginPath();
    ctx.arc(cx, cy, 4 + globalCoh * 8, 0, Math.PI * 2);
    ctx.fillStyle = '#22d3ee';
    ctx.globalAlpha = 0.6 + globalCoh * 0.4;
    ctx.fill();
    ctx.globalAlpha = 1;

    // Morph ring
    ctx.beginPath();
    ctx.arc(cx, cy, 240 + morphState * 40, 0, Math.PI * 2);
    ctx.strokeStyle = '#a78bfa';
    ctx.globalAlpha = morphState * 0.18;
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ctx.globalAlpha = 1;

    // HUD
    ctx.font = '10px monospace';
    ctx.fillStyle = 'rgba(34,211,238,0.45)';
    ctx.textAlign = 'left';
    ctx.fillText(
      `coh ${(globalCoh * 100).toFixed(0)}%  morph ${(morphState * 100).toFixed(0)}%  rendered ${renderSet.length}/${nodes.length}`,
      10, height - 10
    );

    setLiveStats({ coherence: globalCoh, morph: morphState, ticks: orchestrator.getTickCount() });
  }, [orchestrator, width, height, nodePos]);

  useEffect(() => {
    const loop = () => { draw(); frameRef.current = requestAnimationFrame(loop); };
    frameRef.current = requestAnimationFrame(loop);
    return () => { if (frameRef.current !== undefined) cancelAnimationFrame(frameRef.current); };
  }, [draw]);

  const handleClick = useCallback((e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!interactive || !canvasRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    const mx = (e.clientX - rect.left) * (width / rect.width);
    const my = (e.clientY - rect.top) * (height / rect.height);
    const cx = width / 2, cy = height / 2;
    let best: NodeState | null = null, bestD = 16;
    orchestrator.getAllMeshNodes().forEach(node => {
      const { x, y } = nodePos(node, cx, cy);
      const d = Math.sqrt((x - mx) ** 2 + (y - my) ** 2);
      if (d < bestD) { bestD = d; best = node; }
    });
    setSelected(best);
  }, [interactive, orchestrator, nodePos, width, height]);

  return (
    <div className="flex flex-col gap-3 w-full">
      <canvas
        ref={canvasRef}
        width={width}
        height={height}
        onClick={handleClick}
        style={{ width: '100%', height: 'auto', display: 'block' }}
        className="rounded-lg cursor-crosshair border border-slate-700"
      />

      <div className="grid grid-cols-3 gap-2 font-mono text-xs text-cyan-100">
        {[
          ['Coherence', (liveStats.coherence * 100).toFixed(1) + '%'],
          ['Morph',     (liveStats.morph * 100).toFixed(1) + '%'],
          ['Ticks',     liveStats.ticks.toLocaleString()],
        ].map(([label, val]) => (
          <div key={label} className="bg-slate-900 border border-slate-700 rounded p-2">
            <div className="text-cyan-500 mb-1">{label}</div>
            <div className="text-lg">{val}</div>
          </div>
        ))}
      </div>

      {selected && (
        <div className="bg-slate-900 border border-slate-700 rounded-lg p-3 font-mono text-xs text-cyan-100">
          <div className="text-cyan-400 font-bold mb-2 tracking-wider">NODE</div>
          <div className="grid grid-cols-3 gap-x-4 gap-y-1">
            {([
              ['Mesh',      selected.address.mesh],
              ['Layer',     selected.address.layer],
              ['Center',    selected.address.center],
              ['Node',      selected.address.node],
              ['Line',      selected.address.line],
              ['Zodiac',    selected.address.zodiac],
              ['House',     selected.address.house],
              ['Arc°',      selected.address.arcDegree.toFixed(1)],
              ['Tension',   (selected.tension * 100).toFixed(0) + '%'],
              ['Coherence', (selected.coherence * 100).toFixed(0) + '%'],
            ] as [string, string | number][]).map(([k, v]) => (
              <div key={k} className="flex justify-between gap-1">
                <span className="text-slate-400">{k}</span>
                <span className="text-cyan-300">{v}</span>
              </div>
            ))}
            <div className="col-span-3 flex justify-between mt-1">
              <span className="text-slate-400">State</span>
              <span style={{ color: STATE_COLORS[selected.baseState] || '#fff' }}>
                {selected.baseState}
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default NeuralMeshVisualizer;
