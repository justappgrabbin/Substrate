/**
 * SUPABASE CLIENT
 * Project: leisphnjslcuepflefri
 * Tables used:
 *   gate_neural_ops       — 64 gates × neural op metadata (read-only seed data)
 *   consciousness_users   — per-user HD profile + adaptation state
 *   resonance_matches     — logged resonance events between users/nodes
 *   platform_config       — runtime config flags
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';

const SUPABASE_URL = 'https://leisphnjslcuepflefri.supabase.co';
// Anon key — safe for client. Row-level security handles the rest.
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

if (!SUPABASE_ANON_KEY) {
  console.warn('[Supabase] VITE_SUPABASE_ANON_KEY not set — running in offline mode');
}

export const supabase: SupabaseClient = createClient(
  SUPABASE_URL,
  SUPABASE_ANON_KEY || 'offline',
  {
    auth: { persistSession: false },
  }
);

// ── TABLE TYPE DEFINITIONS ─────────────────────────────────────────────────

export interface GateNeuralOp {
  gate: number;                    // 1-64
  center: string;                  // Head|Ajna|Throat|G|Heart|Solar|Sacral|Spleen|Root
  net_type: string;                // dff|rbm|lsm|esn|hmm|etc
  op_code: string;                 // e.g. "G1_L1_D