# YOU-N-I-VERSE Engine (Slice)
This bundle contains:
- `you_n_i_verse_engine.py` — parser + sentence generators
- `you-n-i-verse-schema.json` — JSON schema for coordinates
- `GRAMMAR.txt` — human-readable grammar
- `examples.json` — parsed examples

## Quick Use (Python)
```python
from you_n_i_verse_engine import parse_coordinate, metaphysical_sentence, scientific_sentence
obj = parse_coordinate("G, 25.4.6.3.4 12° 15′ 09″ Identity” Virgo 5")
print(metaphysical_sentence(obj))
print(scientific_sentence(obj))
```

## Coordinate Pattern
CENTER, GATE.LINE.COLOR.TONE.BASE DEG MIN′ SEC″ AXIS” SIGN HOUSE
Example:
G, 25.4.6.3.4 12° 15′ 09″ Identity” Virgo 5
