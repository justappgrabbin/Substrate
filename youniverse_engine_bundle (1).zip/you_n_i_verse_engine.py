
"""
YOU-N-I-VERSE Sentence Engine (compact slice)
- Parses dimensional coordinates
- Emits metaphysical + scientific sentences
"""
import re, json

CENTER_COLORS = {'Head': 'yellow', 'Ajna': 'green', 'Throat': 'brown', 'Heart': 'red', 'Spleen': 'brown', 'Sacral': 'red', 'Solar Plexus': 'brown', 'Root': 'brown', 'G': 'yellow'}
DIMENSION_KEYNOTES = {'Movement': 'I Define', 'Evolution': 'I Remember', 'Being': 'I Am', 'Design': 'I Design', 'Space': 'I Think'}
SCIENTIFIC_OVERLAY = {'Movement': {'mechanism': 'field energy / activity', 'analogy': 'spin alignment → activation threshold'}, 'Evolution': {'mechanism': 'gravity / entropy-memory', 'analogy': 'state retention → pattern learning'}, 'Being': {'mechanism': 'biochemistry / sensation', 'analogy': 'ligand binding → signal transduction'}, 'Design': {'mechanism': 'geometry / structure', 'analogy': 'crystal symmetry → constraint → function'}, 'Space': {'mechanism': 'photons / interference', 'analogy': 'perception → rhythm → timing'}}
GATE_TO_CODON = {1: {'amino': 'Methionine/Start', 'note': 'creative ignition / initiator'}, 2: {'amino': 'Tryptophan', 'note': 'deep receptive guidance'}, 3: {'amino': 'Lysine', 'note': 'ordering chaos / polymerase vibe'}, 4: {'amino': 'Threonine', 'note': 'logic crystallization'}, 5: {'amino': 'Glutamine', 'note': 'rhythmic attunement'}, 6: {'amino': 'Arginine', 'note': 'boundary / membrane gating'}, 25: {'amino': 'Histidine', 'note': 'innocence / immune regulation'}}
LINE_NAMES = {1: {1: 'Objectivity', 2: 'Energy to Attract Society', 3: 'Aloneness as Medium', 4: 'Sustain Creative Work', 5: 'Love is Light', 6: 'Creation beyond Will'}, 2: {1: 'Fixation', 2: 'Intelligent Application', 3: 'Secretiveness', 4: 'Patience', 5: 'Genius', 6: 'Intuition'}, 3: {1: 'Surrender', 2: 'Victimization', 3: 'Charisma', 4: 'Survival', 5: 'Immaturity', 6: 'Synthesis'}, 4: {1: 'Excess', 2: 'Seduction', 3: 'The Liar', 4: 'Irresponsibility', 5: 'Acceptance', 6: 'Pleasure'}, 5: {1: 'Yielding', 2: 'Joy', 3: 'The Hunter', 4: 'Compulsiveness', 5: 'Inner Peace', 6: 'Perseverance'}, 6: {1: 'The Peacemaker', 2: 'Arbitration', 3: 'Triumph', 4: 'Allegiance', 5: 'The Guerilla', 6: 'Retreat'}, 25: {1: 'Selflessness', 2: 'Control', 3: 'Sensitivity', 4: 'Survival', 5: 'Recapitulation', 6: 'Innocence'}}

def normalize_sign(s: str) -> str:
    s = s.strip().capitalize()
    full = {"Ari":"Aries","Tau":"Taurus","Gem":"Gemini","Can":"Cancer","Leo":"Leo",
            "Vir":"Virgo","Lib":"Libra","Sco":"Scorpio","Sag":"Sagittarius",
            "Cap":"Capricorn","Aqu":"Aquarius","Pis":"Pisces"}
    if s in full.values(): return s
    key = s[:3]
    return full.get(key, s)

def parse_coordinate(s: str):
    if "," not in s:
        raise ValueError("Expected comma after center, e.g., 'G, ...'")
    center, rest = s.split(",", 1)
    center = center.strip()
    m = re.match(r"\s*(\d+)\.(\d)\.(\d)\.(\d)\.(\d)\s+([0-2]?\d)\D*\s*([0-5]?\d)\D*\s*([0-5]?\d)\D*\s+([^\s\"]+)\s*[”\"]\s*([A-Za-z]+)\s+(\d{1,2})", rest.strip())
    if not m:
        raise ValueError("Could not parse the coordinate; check the sequence and punctuation.")
    gate, line, color, tone, base, deg, minute, second, axis, zodiac, house = m.groups()
    gate = int(gate); line=int(line); color=int(color); tone=int(tone); base=int(base)
    deg=int(deg); minute=int(minute); second=int(second); house=int(house)
    zodiac = normalize_sign(zodiac)
    axis = axis.capitalize()
    center_map_dim = {
        "Head":"Space", "Ajna":"Design", "Throat":"Space",
        "Heart":"Design", "Spleen":"Being", "Sacral":"Being",
        "Solar Plexus":"Being", "Root":"Evolution", "G":"Movement"
    }
    dimension = center_map_dim.get(center, "Space")
    obj = {
        "dimension": dimension,
        "center": center,
        "center_color": CENTER_COLORS.get(center),
        "gate": gate,
        "line": line,
        "color": color,
        "tone": tone,
        "base": base,
        "position": {"degree":deg,"minute":minute,"second":second},
        "axis": axis,
        "zodiac": zodiac,
        "house": house,
        "crystal": "Personality" if dimension in ["Space","Evolution"] else ("Design" if dimension in ["Being","Design"] else "Monopole")
    }
    return obj

def metaphysical_sentence(obj):
    keynote = DIMENSION_KEYNOTES.get(obj["dimension"], "I Am")
    gate = obj["gate"]; line = obj["line"]
    line_label = LINE_NAMES.get(gate, {}).get(line, f"Line {line}")
    sign = obj["zodiac"]; house = obj["house"]
    return (f"{keynote} {line_label.lower()} through Gate {gate}.{line} "
            f"with Color {obj['color']} • Tone {obj['tone']} • Base {obj['base']}, "
            f"at {obj['position']['degree']}°{obj['position']['minute']}′{obj['position']['second']}″ "
            f"in {sign} House {house} on the {obj['axis']} Axis.")

def scientific_sentence(obj):
    mech = SCIENTIFIC_OVERLAY.get(obj["dimension"],{}).get("mechanism","field dynamics")
    ana = SCIENTIFIC_OVERLAY.get(obj["dimension"],{}).get("analogy","pattern → outcome")
    codon = GATE_TO_CODON.get(obj["gate"], {"amino":"(unmapped)","note":"add mapping"})
    return (f"Dimension → {obj['dimension']} ({mech}; {ana}). "
            f"Gate {obj['gate']} encodes {codon['amino']} ({codon['note']}). "
            f"Line {obj['line']} = behavioral micro-strategy; Color {obj['color']} = motivation pressure; "
            f"Tone {obj['tone']} = sensory vector; Base {obj['base']} = crystalline geometry. "
            f"Position {obj['zodiac']} {obj['position']['degree']}°{obj['position']['minute']}′{obj['position']['second']}″, "
            f"House {obj['house']}, Axis {obj['axis']}. Center {obj['center']} ({obj['center_color']}).")

def compress_symbolic(obj):
    return (f"F:{obj['dimension']}|C:{obj['center']}→{obj['gate']}.{obj['line']}.{obj['color']}."
            f"{obj['tone']}.{obj['base']}@{obj['zodiac']} {obj['position']['degree']}°{obj['position']['minute']}′{obj['position']['second']}″"
            f"#{obj['axis']}·H{obj['house']}")
