// ═══════════════════════════════════════════
//  PAPER PRIME — CONSTANTS
// ═══════════════════════════════════════════

import type { FieldMode, GateData, SubstrateMode } from '@/types'

// ── FIELD CONFIG ──────────────────────────
export const FIELD_CONFIG: Record<FieldMode, {
  label:    string
  color:    string
  accent:   string
  chart:    string
  center:   string
  bg:       string
}> = {
  mind: {
    label:  'Mind',
    color:  '#3de8ff',
    accent: 'rgba(61,232,255,0.15)',
    chart:  'Sidereal',
    center: 'Ajna / Head',
    bg:     'rgba(61,232,255,0.04)',
  },
  heart: {
    label:  'Heart',
    color:  '#ff3d5a',
    accent: 'rgba(255,61,90,0.15)',
    chart:  'Draconic',
    center: 'Heart / Solar Plexus',
    bg:     'rgba(255,61,90,0.04)',
  },
  body: {
    label:  'Body',
    color:  '#39ff7a',
    accent: 'rgba(57,255,122,0.15)',
    chart:  'Tropical',
    center: 'Spleen / Sacral / Root',
    bg:     'rgba(57,255,122,0.04)',
  },
}

// ── MODE CONFIG ───────────────────────────
export const MODE_CONFIG: Record<SubstrateMode, {
  label:  string
  color:  string
  desc:   string
}> = {
  stable: { label: 'STABLE',  color: '#3de8ff', desc: 'High coherence. Field holding.' },
  evolve: { label: 'EVOLVE',  color: '#39ff7a', desc: 'Partial alignment. Growing.' },
  drift:  { label: 'DRIFT',   color: '#ffd84d', desc: 'Pressure building. Course correct.' },
  mutate: { label: 'MUTATE',  color: '#ff3d5a', desc: 'Significant divergence. Restructure.' },
}

// ── GATES (subset — key gates for SYNTIA) ─
export const GATE_DATA: GateData[] = [
  { gate: 1,  name: 'Self-Expression',   keyword: 'Creativity',     center: 'G',            field: 'heart' },
  { gate: 8,  name: 'Contribution',      keyword: 'Holding Together',center: 'Throat',       field: 'heart' },
  { gate: 10, name: 'Self-Love',         keyword: 'Behavior',       center: 'G',            field: 'body'  },
  { gate: 17, name: 'Opinions',          keyword: 'Following',      center: 'Ajna',         field: 'mind'  },
  { gate: 18, name: 'Correction',        keyword: 'Judgment',       center: 'Spleen',       field: 'body'  },
  { gate: 25, name: 'Innocence',         keyword: 'Universal Love', center: 'G',            field: 'heart' },
  { gate: 29, name: 'Saying Yes',        keyword: 'Perseverance',   center: 'Sacral',       field: 'body'  },
  { gate: 32, name: 'Continuity',        keyword: 'Endurance',      center: 'Spleen',       field: 'body'  },
  { gate: 41, name: 'Fantasy',           keyword: 'Contraction',    center: 'Root',         field: 'heart' },
  { gate: 46, name: 'Determination',     keyword: 'Pushing Upward', center: 'G',            field: 'body'  },
  { gate: 51, name: 'Shock',             keyword: 'Initiative',     center: 'Heart',        field: 'heart' },
  { gate: 57, name: 'Intuition',         keyword: 'Gentle',         center: 'Spleen',       field: 'body'  },
  { gate: 59, name: 'Sexuality',         keyword: 'Dispersion',     center: 'Sacral',       field: 'body'  },
  { gate: 64, name: 'Confusion',         keyword: 'Before Completion', center: 'Head',      field: 'mind'  },
]

export function getGateData(gate: number): GateData {
  return GATE_DATA.find(g => g.gate === gate) ?? {
    gate,
    name:    'Unnamed',
    keyword: 'Mystery',
    center:  'Unknown',
    field:   'body',
  }
}

// ── VERDICTS BY MODE ──────────────────────
export const VERDICTS: Record<SubstrateMode, string[]> = {
  stable: [
    'The seed is landing well. Coherence is high. This substrate is in alignment — continue growing in this direction.',
    'Structure holding. Output reflects intent cleanly. The field recognises itself.',
    'High resonance between seed and reality. The substrate knows what it is becoming.',
  ],
  evolve: [
    'Partial alignment. The seed is being heard but not yet fully received. One more cycle should clarify the signal.',
    'The substrate is learning the seed\'s frequency. Push further into core intent next generation.',
    'Coherence growing. The pattern is emerging but not yet crystallised.',
  ],
  drift: [
    'Pressure is building. The substrate has been running long without reassessment. A course correction is advised.',
    'The field is drifting from origin. Re-anchor to the seed intent before the next generation compounds the divergence.',
    'Something is pulling the output away from the seed. Name it, then decide: follow or return.',
  ],
  mutate: [
    'Significant drift detected. The output has diverged substantially. Mutation is indicated — accept the new branch or prune and re-seed.',
    'The substrate has evolved beyond the original pattern. This is not failure. Decide: accept the new direction, or return to origin.',
    'The field has broken its own symmetry. A new attractor has formed. Conscious choice required.',
  ],
}

export function pickVerdict(mode: SubstrateMode): string {
  const set = VERDICTS[mode]
  return set[Math.floor(Math.random() * set.length)]
}

// ── LOADER PHASES ─────────────────────────
export const LOADER_PHASES = [
  { label: 'Anchoring Seed',         sub: 'Encoding seed into consciousness address...' },
  { label: 'Evolving Reality',       sub: 'Generating output through field engine...'  },
  { label: 'Scoring Coherence',      sub: 'Self-assessment running...'                  },
]

// ── COORDINATE GENERATION ─────────────────
export function buildAddress(
  gen: number,
  field: FieldMode,
  seed: string
) {
  const hash = seed.split('').reduce((a, c) => a + c.charCodeAt(0), 0)
  const gate  = (hash % 64) + 1
  const line  = (hash % 6) + 1
  const color = ((hash >> 2) % 6) + 1
  const tone  = ((hash >> 4) % 6) + 1
  const base  = ((hash >> 6) % 5) + 1
  const degree = parseFloat(((gate - 1) * 5.625 + (line - 1) * 0.9375).toFixed(3))
  const gd = getGateData(gate)

  return {
    gate, line, color, tone, base, degree, field,
    label: `${gate}.${line}.${color}.${tone}.${base} · ${gd.name}`,
  }
}
