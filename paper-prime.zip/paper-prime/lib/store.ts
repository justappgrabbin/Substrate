'use client'

// ═══════════════════════════════════════════
//  PAPER PRIME — CONSCIOUSNESS STORE (Zustand)
// ═══════════════════════════════════════════

import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type {
  SubstrateState, Generation, SubstrateVitals,
  SubstrateMode, FieldMode, GenerateRequest
} from '@/types'
import { buildAddress, pickVerdict, LOADER_PHASES } from '@/lib/constants'

// ── SELF-SCORING ENGINE ───────────────────
function selfScore(
  seed: string,
  output: string,
  genome: Generation[]
): SubstrateVitals {
  // Coherence: how well does output reflect seed keywords
  const seedWords = seed.toLowerCase().split(/\s+/).filter(w => w.length > 3)
  const outputText = output.toLowerCase()
  const hits = seedWords.filter(w => outputText.includes(w)).length
  const coherence = seedWords.length ? Math.min(hits / seedWords.length, 1) : 0.5

  // Drift: divergence from previous generation
  let drift = 0.1
  if (genome.length > 1) {
    const prev = genome[genome.length - 1]
    const prevText = prev.output.toLowerCase()
    const outWords = outputText.split(/\s+/)
    const shared = outWords.filter(w => prevText.includes(w)).length
    drift = outWords.length > 0 ? Math.min(Math.max(1 - shared / outWords.length, 0), 1) : 0.5
  }

  // Pressure: accumulates per generation, resets on reassess
  const pressure = Math.min(genome.length * 0.11, 1)

  // Resonance: cross-field (simple heuristic for now)
  const resonance = (coherence * 0.6 + (1 - drift) * 0.4)

  return { coherence, drift, pressure, resonance }
}

function decideMode(v: SubstrateVitals): SubstrateMode {
  if (v.coherence > 0.75 && v.drift < 0.3) return 'stable'
  if (v.drift > 0.65)                        return 'mutate'
  if (v.pressure > 0.65)                     return 'drift'
  return 'evolve'
}

// ── STORE ─────────────────────────────────
export const useSubstrate = create<SubstrateState>()(
  persist(
    (set, get) => ({
      // ── Initial state ──
      generation:    0,
      mode:          'stable',
      activeField:   'body',
      authorMode:    'director',
      genome:        [],
      activeGen:     null,
      currentOutput: null,
      vitals:        { coherence: 0, drift: 0, pressure: 0, resonance: 0 },
      isEvolving:    false,
      loaderPhase:   null,
      assessOpen:    false,
      seed:          '',

      // ── Setters ──
      setSeed:       (s) => set({ seed: s }),
      setField:      (f) => set({ activeField: f }),
      setAuthorMode: (m) => set({ authorMode: m }),

      // ── EVOLVE ───────────────────────────
      evolve: async () => {
        const { seed, activeField, authorMode, generation, genome, vitals, mode } = get()
        if (!seed.trim()) return

        set({ isEvolving: true, loaderPhase: { ...LOADER_PHASES[0], phase: 1, progress: 0 } })

        // Phase 1 progress
        await tick(300)
        set({ loaderPhase: { ...LOADER_PHASES[0], phase: 1, progress: 60 } })
        await tick(200)
        set({ loaderPhase: { ...LOADER_PHASES[1], phase: 2, progress: 0 } })

        try {
          const req: GenerateRequest = {
            seed, field: activeField, authorMode,
            gen: generation + 1,
            history: genome.slice(-3).map(g => ({ gen: g.gen, preview: g.preview, mode: g.mode })),
            vitals, mode,
          }

          set({ loaderPhase: { ...LOADER_PHASES[1], phase: 2, progress: 30 } })

          const res = await fetch('/api/generate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(req),
          })

          set({ loaderPhase: { ...LOADER_PHASES[1], phase: 2, progress: 80 } })

          if (!res.ok) throw new Error(`API ${res.status}`)
          const data = await res.json()
          if (data.error) throw new Error(data.error)

          set({ loaderPhase: { ...LOADER_PHASES[2], phase: 3, progress: 40 } })
          await tick(300)

          const gen = generation + 1
          const newVitals = selfScore(seed, data.html, genome)
          const newMode   = decideMode(newVitals)
          const address   = buildAddress(gen, activeField, seed)
          const verdict   = data.verdict || pickVerdict(newMode)

          const entry: Generation = {
            id:        `gen-${gen}-${Date.now()}`,
            gen,
            seed,
            output:    data.html,
            vitals:    newVitals,
            mode:      newMode,
            address,
            field:     activeField,
            timestamp: Date.now(),
            preview:   seed.substring(0, 72) + (seed.length > 72 ? '…' : ''),
            tags:      data.tags || [],
            verdict,
          }

          set({ loaderPhase: { ...LOADER_PHASES[2], phase: 3, progress: 100 } })
          await tick(200)

          set(s => ({
            generation:    gen,
            genome:        [...s.genome, entry],
            activeGen:     entry,
            currentOutput: data.html,
            vitals:        newVitals,
            mode:          newMode,
            isEvolving:    false,
            loaderPhase:   null,
          }))

          // Auto-assess on drift/mutate
          if (newMode === 'mutate' || newMode === 'drift') {
            await tick(600)
            set({ assessOpen: true })
          }

        } catch (err) {
          console.error('[PAPER] evolve error:', err)
          set({ isEvolving: false, loaderPhase: null })
        }
      },

      // ── FORCE MUTATE ──────────────────────
      forceMutate: async () => {
        const { seed, setSeed, evolve } = get()
        setSeed(seed + '\n\n[MUTATION: Break the previous pattern. Structural divergence required.]')
        await evolve()
        setSeed(seed)
      },

      // ── RESTORE GEN ───────────────────────
      restoreGen: (id) => {
        const entry = get().genome.find(g => g.id === id)
        if (!entry) return
        set({
          activeGen:     entry,
          currentOutput: entry.output,
          vitals:        entry.vitals,
          mode:          entry.mode,
          generation:    entry.gen,
        })
      },

      // ── ASSESS ───────────────────────────
      triggerAssess: () => set({ assessOpen: true }),
      closeAssess:   () => set({ assessOpen: false }),
      acceptEvolution: () => set({ assessOpen: false }),
      forceReassess: () => set({
        assessOpen: false,
        vitals: { ...get().vitals, pressure: 0 },
        mode: 'evolve',
      }),

      // ── RESET ────────────────────────────
      reset: () => set({
        generation: 0, mode: 'stable', genome: [], activeGen: null,
        currentOutput: null, vitals: { coherence: 0, drift: 0, pressure: 0, resonance: 0 },
        isEvolving: false, loaderPhase: null, assessOpen: false,
      }),
    }),
    {
      name:    'paper-prime-substrate',
      partialize: (s) => ({
        seed:       s.seed,
        activeField: s.activeField,
        authorMode:  s.authorMode,
        genome:      s.genome.slice(-10),  // persist last 10 gens
        generation:  s.generation,
      }),
    }
  )
)

function tick(ms: number) { return new Promise(r => setTimeout(r, ms)) }
