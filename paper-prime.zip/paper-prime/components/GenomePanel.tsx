'use client'

// ═══════════════════════════════════════════
//  GenomePanel — generation history
// ═══════════════════════════════════════════

import { useSubstrate } from '@/lib/store'
import { FIELD_CONFIG, MODE_CONFIG } from '@/lib/constants'
import { GateIndicator } from '@/components/shared/GateIndicator'
import type { Generation } from '@/types'

export function GenomePanel() {
  const { genome, activeGen, restoreGen } = useSubstrate()

  return (
    <div style={{
      display:       'flex',
      flexDirection: 'column',
      background:    'var(--soil)',
      borderLeft:    '1px solid var(--rule)',
      width:         'var(--sidebar-w)',
      overflow:      'hidden',
      flexShrink:    0,
    }}>
      {/* Header */}
      <div style={{
        padding:      '8px 14px',
        borderBottom: '1px solid var(--rule)',
        display:      'flex',
        alignItems:   'center',
        gap:          8,
        flexShrink:   0,
      }}>
        <GateIndicator field="mind" size={6} />
        <span className="mono-label">Genome</span>
        {genome.length > 0 && (
          <span style={{
            marginLeft:    'auto',
            fontFamily:    'var(--font-mono)',
            fontSize:      '0.58rem',
            color:         'var(--dimmer)',
          }}>
            {genome.length} gen{genome.length !== 1 ? 's' : ''}
          </span>
        )}
      </div>

      {/* List */}
      <div style={{
        flex:       1,
        overflowY:  'auto',
        padding:    10,
        display:    'flex',
        flexDirection: 'column',
        gap:        6,
      }}>
        {genome.length === 0 ? (
          <div style={{
            fontFamily:    'var(--font-mono)',
            fontSize:      '0.6rem',
            letterSpacing: '0.1em',
            color:         'var(--dimmer)',
            padding:       '8px 4px',
          }}>
            No generations yet.
          </div>
        ) : (
          [...genome].reverse().map(g => (
            <GenCard
              key={g.id}
              gen={g}
              active={activeGen?.id === g.id}
              onClick={() => restoreGen(g.id)}
            />
          ))
        )}
      </div>
    </div>
  )
}

function GenCard({ gen, active, onClick }: { gen: Generation; active: boolean; onClick: () => void }) {
  const field    = FIELD_CONFIG[gen.field]
  const modeConf = MODE_CONFIG[gen.mode]

  const score = gen.vitals.coherence
  const scoreColor = score > 0.7 ? 'var(--body)' : score > 0.4 ? 'var(--warn)' : 'var(--heart)'

  return (
    <div
      onClick={onClick}
      style={{
        background:   active ? `${field.color}08` : 'var(--mycelium)',
        border:       `1px solid ${active ? field.color + '66' : 'var(--rule)'}`,
        borderRadius: 4,
        padding:      '9px 11px',
        cursor:       'pointer',
        transition:   'all 0.15s',
        animation:    'slide-in-right 0.25s ease both',
      }}
    >
      {/* Header row */}
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 5 }}>
        <span style={{
          fontFamily:    'var(--font-mono)',
          fontSize:      '0.65rem',
          fontWeight:    500,
          color:         field.color,
          letterSpacing: '0.06em',
        }}>
          GEN_{String(gen.gen).padStart(2,'0')}
        </span>
        <span style={{
          fontFamily:    'var(--font-mono)',
          fontSize:      '0.56rem',
          color:         scoreColor,
          background:    `${scoreColor}18`,
          padding:       '1px 6px',
          borderRadius:  3,
        }}>
          {Math.round(gen.vitals.coherence * 100)}%
        </span>
      </div>

      {/* Preview */}
      <div style={{
        fontFamily:    'var(--font-mono)',
        fontSize:      '0.6rem',
        color:         'var(--dim)',
        whiteSpace:    'nowrap',
        overflow:      'hidden',
        textOverflow:  'ellipsis',
        marginBottom:  5,
      }}>
        {gen.preview}
      </div>

      {/* Tags */}
      <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
        <Tag color={modeConf.color}>{gen.mode}</Tag>
        <Tag>drift:{Math.round(gen.vitals.drift * 100)}%</Tag>
        <Tag color={field.color}>{gen.field}</Tag>
      </div>
    </div>
  )
}

function Tag({ children, color }: { children: React.ReactNode; color?: string }) {
  return (
    <span style={{
      fontFamily:    'var(--font-mono)',
      fontSize:      '0.52rem',
      letterSpacing: '0.06em',
      padding:       '1px 5px',
      borderRadius:  10,
      border:        '1px solid var(--rule)',
      color:         color ?? 'var(--dimmer)',
    }}>
      {children}
    </span>
  )
}
