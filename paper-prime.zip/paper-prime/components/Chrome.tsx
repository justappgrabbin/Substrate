'use client'

// ═══════════════════════════════════════════
//  TopBar
// ═══════════════════════════════════════════

import { useSubstrate } from '@/lib/store'
import { FIELD_CONFIG, MODE_CONFIG } from '@/lib/constants'

export function TopBar() {
  const { generation, mode, vitals, activeField } = useSubstrate()
  const field    = FIELD_CONFIG[activeField]
  const modeConf = MODE_CONFIG[mode]

  return (
    <div style={{
      height:       'var(--topbar-h)',
      background:   'var(--soil)',
      borderBottom: '1px solid var(--rule)',
      display:      'flex',
      alignItems:   'center',
      padding:      '0 20px',
      gap:          20,
      flexShrink:   0,
      gridColumn:   '1 / -1',
    }}>
      {/* Logo */}
      <div style={{
        fontFamily:    'var(--font-serif)',
        fontStyle:     'italic',
        fontSize:      '1.05rem',
        color:         '#f5f0e8',
        letterSpacing: '0.02em',
        flexShrink:    0,
      }}>
        PAPER<span style={{ color: field.color, fontStyle: 'normal' }}>.</span>
      </div>

      {/* Status pill */}
      <StatusPill />

      {/* Mode tag */}
      <div style={{
        fontFamily:    'var(--font-mono)',
        fontSize:      '0.56rem',
        letterSpacing: '0.14em',
        padding:       '2px 8px',
        borderRadius:  10,
        border:        `1px solid ${modeConf.color}55`,
        color:         modeConf.color,
        background:    `${modeConf.color}0e`,
        textTransform: 'uppercase',
      }}>
        {modeConf.label}
      </div>

      {/* Right */}
      <div style={{
        marginLeft:    'auto',
        fontFamily:    'var(--font-mono)',
        fontSize:      '0.58rem',
        color:         'var(--dimmer)',
        letterSpacing: '0.08em',
        display:       'flex',
        gap:           16,
        alignItems:    'center',
      }}>
        <span>GEN <span style={{ color: field.color }}>{String(generation).padStart(2,'0')}</span></span>
        <span>COH <span style={{ color: 'var(--body)' }}>{Math.round(vitals.coherence * 100)}%</span></span>
        <span style={{ color: 'var(--dimmer)' }}>{field.label} · {field.chart}</span>
      </div>
    </div>
  )
}

function StatusPill() {
  const { isEvolving, mode } = useSubstrate()
  const labels: Record<string, string> = {
    stable: 'Coherent', evolve: 'Evolving', drift: 'Drifting', mutate: 'Mutating',
  }
  const label = isEvolving ? 'Evolving...' : labels[mode] ?? 'Dormant'
  const color = isEvolving ? 'var(--warn)' : 'var(--body)'

  return (
    <div style={{
      fontFamily:    'var(--font-mono)',
      fontSize:      '0.6rem',
      letterSpacing: '0.14em',
      textTransform: 'uppercase',
      padding:       '3px 10px',
      borderRadius:  20,
      border:        `1px solid ${color}`,
      color,
      animation:     'breathe 3s ease-in-out infinite',
      flexShrink:    0,
    }}>
      {label}
    </div>
  )
}

// ═══════════════════════════════════════════
//  BottomBar
// ═══════════════════════════════════════════

export function BottomBar() {
  const {
    evolve, forceMutate, triggerAssess, reset,
    isEvolving, generation, currentOutput,
  } = useSubstrate()

  function downloadCurrent() {
    if (!currentOutput) return
    const blob = new Blob([currentOutput], { type: 'text/html' })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = `paper-gen-${String(generation).padStart(2,'0')}.html`
    a.click()
  }

  return (
    <div style={{
      height:      'var(--bottom-h)',
      background:  'var(--soil)',
      borderTop:   '1px solid var(--rule)',
      display:     'flex',
      alignItems:  'center',
      padding:     '0 16px',
      gap:         8,
      flexShrink:  0,
      gridColumn:  '1 / -1',
    }}>
      <Btn primary onClick={evolve} disabled={isEvolving}>🌱 Evolve</Btn>
      <Btn onClick={() => triggerAssess()} disabled={generation === 0 || isEvolving}>⚖ Assess</Btn>
      <Btn onClick={forceMutate} disabled={generation === 0 || isEvolving}>⚡ Mutate</Btn>
      <Btn onClick={downloadCurrent} disabled={!currentOutput || isEvolving}>📦 Export</Btn>
      <Btn danger onClick={reset} style={{ marginLeft: 'auto' }}>↺ Reset</Btn>
    </div>
  )
}

function Btn({
  children, onClick, disabled, primary, danger, style,
}: {
  children:  React.ReactNode
  onClick:   () => void
  disabled?: boolean
  primary?:  boolean
  danger?:   boolean
  style?:    React.CSSProperties
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      style={{
        fontFamily:    'var(--font-mono)',
        fontSize:      '0.6rem',
        letterSpacing: '0.1em',
        textTransform: 'uppercase',
        padding:       '7px 16px',
        borderRadius:  3,
        border:        primary ? '1px solid var(--body)'
                    :  danger  ? '1px solid var(--heart)'
                    :             '1px solid var(--rule)',
        background:    primary ? 'rgba(57,255,122,0.1)'
                    :  danger  ? 'rgba(255,61,90,0.08)'
                    :             'var(--mycelium)',
        color:         primary ? 'var(--body)'
                    :  danger  ? 'var(--heart)'
                    :             '#e0e0f0',
        cursor:        disabled ? 'not-allowed' : 'pointer',
        opacity:       disabled ? 0.35 : 1,
        transition:    'all 0.15s',
        flexShrink:    0,
        ...style,
      }}
    >
      {children}
    </button>
  )
}
