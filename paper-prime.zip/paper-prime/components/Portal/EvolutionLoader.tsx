'use client'

// ═══════════════════════════════════════════
//  Portal/EvolutionLoader — phase progress
// ═══════════════════════════════════════════

import { useSubstrate } from '@/lib/store'
import { FIELD_CONFIG } from '@/lib/constants'

export function EvolutionLoader() {
  const { isEvolving, loaderPhase, activeField } = useSubstrate()
  const field = FIELD_CONFIG[activeField]

  if (!isEvolving || !loaderPhase) return null

  return (
    <div style={{
      position:       'absolute',
      inset:          0,
      zIndex:         50,
      background:     'rgba(7,7,10,0.85)',
      backdropFilter: 'blur(6px)',
      display:        'flex',
      alignItems:     'center',
      justifyContent: 'center',
      flexDirection:  'column',
      gap:            24,
      animation:      'fade-in 0.2s ease both',
    }}>

      {/* Orbital ring */}
      <div style={{
        width:        64,
        height:       64,
        borderRadius: '50%',
        border:       `1px solid var(--rule)`,
        borderTop:    `1px solid ${field.color}`,
        animation:    'spin 1s linear infinite',
        boxShadow:    `0 0 20px ${field.color}22`,
      }} />

      {/* Phase label */}
      <div style={{ textAlign: 'center' }}>
        <div style={{
          fontFamily:    'var(--font-mono)',
          fontSize:      '0.7rem',
          letterSpacing: '0.15em',
          textTransform: 'uppercase',
          color:         field.color,
          marginBottom:  6,
        }}>
          {loaderPhase.label}
        </div>
        <div style={{
          fontFamily:    'var(--font-mono)',
          fontSize:      '0.58rem',
          letterSpacing: '0.1em',
          color:         'var(--dim)',
        }}>
          {loaderPhase.sub}
        </div>
      </div>

      {/* Phase dots */}
      <div style={{ display: 'flex', gap: 8 }}>
        {[1, 2, 3].map(p => (
          <div key={p} style={{
            width:        6,
            height:       6,
            borderRadius: '50%',
            background:   loaderPhase.phase >= p ? field.color : 'var(--rule)',
            transition:   'background 0.3s',
            boxShadow:    loaderPhase.phase >= p ? `0 0 8px ${field.color}` : 'none',
          }} />
        ))}
      </div>

      {/* Progress bar */}
      <div style={{
        width:        200,
        height:       2,
        background:   'var(--rule)',
        borderRadius: 2,
        overflow:     'hidden',
      }}>
        <div style={{
          width:        `${loaderPhase.progress}%`,
          height:       '100%',
          background:   field.color,
          borderRadius: 2,
          transition:   'width 0.4s ease',
          boxShadow:    `0 0 6px ${field.color}`,
        }} />
      </div>

      <div style={{
        fontFamily:    'var(--font-mono)',
        fontSize:      '0.55rem',
        letterSpacing: '0.1em',
        color:         'var(--dimmer)',
      }}>
        PHASE {loaderPhase.phase} / 3
      </div>
    </div>
  )
}
