'use client'

// ═══════════════════════════════════════════
//  Portal/HUD — consciousness overlay
// ═══════════════════════════════════════════

import { useSubstrate } from '@/lib/store'
import { FIELD_CONFIG, MODE_CONFIG } from '@/lib/constants'
import { CoordinateTag } from '@/components/shared/CoordinateTag'

export function HUD() {
  const { generation, mode, vitals, activeField, activeGen } = useSubstrate()
  const field = FIELD_CONFIG[activeField]
  const modeConf = MODE_CONFIG[mode]

  if (generation === 0) return null

  return (
    <div
      className="hud-glass"
      style={{
        position:  'absolute',
        top:       12,
        right:     12,
        zIndex:    20,
        padding:   '10px 14px',
        minWidth:  200,
        animation: 'fade-in 0.4s ease both',
      }}
    >
      {/* Gen + mode */}
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
        <span style={{
          fontFamily:    'var(--font-mono)',
          fontSize:      '0.68rem',
          fontWeight:    500,
          color:         field.color,
          letterSpacing: '0.06em',
        }}>
          GEN_{String(generation).padStart(2,'0')}
        </span>
        <span style={{
          fontFamily:    'var(--font-mono)',
          fontSize:      '0.56rem',
          letterSpacing: '0.14em',
          color:         modeConf.color,
          textTransform: 'uppercase',
          padding:       '1px 6px',
          border:        `1px solid ${modeConf.color}`,
          borderRadius:  10,
          opacity:       0.9,
        }}>
          {modeConf.label}
        </span>
      </div>

      {/* Vitals bars */}
      <VitalBar label="COH" value={vitals.coherence} color="var(--body)"  />
      <VitalBar label="DRF" value={vitals.drift}     color="var(--warn)"  />
      <VitalBar label="PRS" value={vitals.pressure}  color="var(--heart)" />
      <VitalBar label="RES" value={vitals.resonance} color={field.color}  />

      {/* Coordinate */}
      {activeGen && (
        <div style={{ marginTop: 10, paddingTop: 8, borderTop: '1px solid var(--rule)' }}>
          <CoordinateTag address={activeGen.address} />
        </div>
      )}
    </div>
  )
}

function VitalBar({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 }}>
      <span style={{
        fontFamily:    'var(--font-mono)',
        fontSize:      '0.55rem',
        letterSpacing: '0.1em',
        color:         'var(--dimmer)',
        width:         24,
        flexShrink:    0,
      }}>
        {label}
      </span>
      <div style={{
        flex:       1,
        height:     2,
        background: 'var(--rule)',
        borderRadius: 2,
        overflow:   'hidden',
      }}>
        <div style={{
          width:      `${value * 100}%`,
          height:     '100%',
          background: color,
          borderRadius: 2,
          transition: 'width 1s ease',
        }} />
      </div>
      <span style={{
        fontFamily:    'var(--font-mono)',
        fontSize:      '0.55rem',
        color:         'var(--dimmer)',
        width:         28,
        textAlign:     'right',
        flexShrink:    0,
      }}>
        {Math.round(value * 100)}%
      </span>
    </div>
  )
}
