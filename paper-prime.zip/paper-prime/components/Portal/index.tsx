'use client'

// ═══════════════════════════════════════════
//  Portal — reality output container
// ═══════════════════════════════════════════

import { GateIndicator } from '@/components/shared/GateIndicator'
import { HUD } from './HUD'
import { OutputFrame } from './OutputFrame'
import { EvolutionLoader } from './EvolutionLoader'
import { useSubstrate } from '@/lib/store'
import { FIELD_CONFIG } from '@/lib/constants'

export function Portal() {
  const { activeField, activeGen, generation } = useSubstrate()
  const field = FIELD_CONFIG[activeField]

  return (
    <div style={{
      display:       'flex',
      flexDirection: 'column',
      background:    'var(--void)',
      overflow:      'hidden',
    }}>
      {/* Panel header */}
      <div style={{
        padding:      '8px 14px',
        borderBottom: '1px solid var(--rule)',
        background:   'var(--soil)',
        display:      'flex',
        alignItems:   'center',
        gap:          8,
        flexShrink:   0,
      }}>
        <GateIndicator field={activeField} size={6} />
        <span className="mono-label">Reality — Live Output</span>
        {generation > 0 && (
          <span style={{
            marginLeft:    'auto',
            fontFamily:    'var(--font-mono)',
            fontSize:      '0.56rem',
            letterSpacing: '0.08em',
            color:         field.color,
            opacity:       0.7,
          }}>
            {activeGen?.address.label ?? '—'}
          </span>
        )}
      </div>

      {/* Frame */}
      <div style={{ flex: 1, position: 'relative', overflow: 'hidden' }}>
        <OutputFrame />
        <HUD />
        <EvolutionLoader />
      </div>
    </div>
  )
}
