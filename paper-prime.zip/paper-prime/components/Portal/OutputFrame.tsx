'use client'

// ═══════════════════════════════════════════
//  Portal/OutputFrame — reality iframe
// ═══════════════════════════════════════════

import { useEffect, useRef, useState } from 'react'
import { useSubstrate } from '@/lib/store'
import { FIELD_CONFIG } from '@/lib/constants'

export function OutputFrame() {
  const { currentOutput, activeField, generation } = useSubstrate()
  const ref = useRef<HTMLIFrameElement>(null)
  const [visible, setVisible] = useState(false)
  const field = FIELD_CONFIG[activeField]

  useEffect(() => {
    if (!currentOutput || !ref.current) return
    setVisible(false)
    const t = setTimeout(() => {
      if (ref.current) {
        ref.current.srcdoc = currentOutput
        setVisible(true)
      }
    }, 100)
    return () => clearTimeout(t)
  }, [currentOutput, generation])

  if (!currentOutput) {
    return (
      <div style={{
        position:       'absolute',
        inset:          0,
        display:        'flex',
        alignItems:     'center',
        justifyContent: 'center',
        flexDirection:  'column',
        gap:            14,
        color:          'var(--dim)',
      }}>
        <IdleOrb color={field.color} />
        <span style={{
          fontFamily:    'var(--font-mono)',
          fontSize:      '0.62rem',
          letterSpacing: '0.14em',
          textTransform: 'uppercase',
        }}>
          Reality Awaiting Seed
        </span>
      </div>
    )
  }

  return (
    <iframe
      ref={ref}
      title="Reality Output"
      sandbox="allow-scripts allow-same-origin"
      style={{
        width:      '100%',
        height:     '100%',
        border:     'none',
        background: 'white',
        opacity:    visible ? 1 : 0,
        transition: 'opacity 0.5s ease',
      }}
    />
  )
}

function IdleOrb({ color }: { color: string }) {
  return (
    <div style={{
      width:        48,
      height:       48,
      borderRadius: '50%',
      border:       `1px solid ${color}33`,
      animation:    'orbit 4s linear infinite',
      position:     'relative',
      flexShrink:   0,
    }}>
      <div style={{
        position:     'absolute',
        top:          -3,
        left:         '50%',
        transform:    'translateX(-50%)',
        width:        6,
        height:       6,
        borderRadius: '50%',
        background:   color,
        boxShadow:    `0 0 8px ${color}`,
      }} />
    </div>
  )
}
