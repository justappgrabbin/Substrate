'use client'

// ═══════════════════════════════════════════
//  BioCanvas — living mycelium background
// ═══════════════════════════════════════════

import { useEffect, useRef } from 'react'
import { useSubstrate } from '@/lib/store'
import { FIELD_CONFIG, MODE_CONFIG } from '@/lib/constants'

interface Node {
  x: number; y: number
  vx: number; vy: number
  r: number; pulse: number
}

export function BioCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const nodesRef  = useRef<Node[]>([])
  const rafRef    = useRef<number>(0)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')!
    let W = 0, H = 0

    function resize() {
      W = canvas.width  = window.innerWidth
      H = canvas.height = window.innerHeight
      initNodes()
    }

    function initNodes() {
      const count = Math.floor((W * H) / 16000)
      nodesRef.current = Array.from({ length: count }, () => ({
        x:     Math.random() * W,
        y:     Math.random() * H,
        vx:    (Math.random() - 0.5) * 0.3,
        vy:    (Math.random() - 0.5) * 0.3,
        r:     Math.random() * 1.5 + 0.4,
        pulse: Math.random() * Math.PI * 2,
      }))
    }

    function draw() {
      const state = useSubstrate.getState()
      const fieldColor = FIELD_CONFIG[state.activeField].color
      // Extract rgb components from hex
      const r = parseInt(fieldColor.slice(1,3),16)
      const g = parseInt(fieldColor.slice(3,5),16)
      const b = parseInt(fieldColor.slice(5,7),16)
      const rgb = `${r},${g},${b}`

      ctx.clearRect(0, 0, W, H)

      const nodes = nodesRef.current
      const coherence = state.vitals.coherence

      nodes.forEach(n => {
        n.x += n.vx; n.y += n.vy
        n.pulse += 0.018
        if (n.x < 0 || n.x > W) n.vx *= -1
        if (n.y < 0 || n.y > H) n.vy *= -1

        const a = 0.12 + 0.08 * Math.sin(n.pulse)
        ctx.beginPath()
        ctx.arc(n.x, n.y, n.r, 0, Math.PI * 2)
        ctx.fillStyle = `rgba(${rgb},${a})`
        ctx.fill()
      })

      // Connections
      const maxDist = 70 + coherence * 50
      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const dx = nodes[i].x - nodes[j].x
          const dy = nodes[i].y - nodes[j].y
          const dist = Math.sqrt(dx*dx + dy*dy)
          if (dist < maxDist) {
            ctx.beginPath()
            ctx.moveTo(nodes[i].x, nodes[i].y)
            ctx.lineTo(nodes[j].x, nodes[j].y)
            ctx.strokeStyle = `rgba(${rgb},${0.05 * (1 - dist / maxDist)})`
            ctx.lineWidth = 0.5
            ctx.stroke()
          }
        }
      }

      rafRef.current = requestAnimationFrame(draw)
    }

    resize()
    rafRef.current = requestAnimationFrame(draw)
    window.addEventListener('resize', resize)

    return () => {
      cancelAnimationFrame(rafRef.current)
      window.removeEventListener('resize', resize)
    }
  }, [])

  return (
    <canvas
      ref={canvasRef}
      style={{
        position: 'fixed',
        inset:    0,
        zIndex:   0,
        opacity:  0.45,
        pointerEvents: 'none',
      }}
    />
  )
}
