'use client'

// ═══════════════════════════════════════════
//  AssessOverlay — self-assessment modal
// ═══════════════════════════════════════════

import { useSubstrate } from '@/lib/store'
import { FIELD_CONFIG, MODE_CONFIG } from '@/lib/constants'
import { CoordinateTag } from '@/components/shared/CoordinateTag'

export function AssessOverlay() {
  const {
    assessOpen, activeGen, vitals, mode, activeField,
    closeAssess, acceptEvolution, forceReassess,
  } = useSubstrate()

  if (!assessOpen || !activeGen) return null

  const field    = FIELD_CONFIG[activeField]
  const modeConf = MODE_CONFIG[mode]

  return (
    <div style={{
      position:       'fixed',
      inset:          0,
      background:     'rgba(7,7,10,0.9)',
      zIndex:         100,
      display:        'flex',
      alignItems:     'center',
      justifyContent: 'center',
      backdropFilter: 'blur(4px)',
      animation:      'fade-in 0.2s ease both',
    }}>
      <div style={{
        background:    'var(--soil)',
        border:        `1px solid ${field.color}44`,
        borderRadius:  6,
        padding:       32,
        maxWidth:      480,
        width:         '90%',
        boxShadow:     `0 0 40px ${field.color}14`,
        animation:     'fade-in 0.3s ease both',
      }}>

        {/* Header */}
        <div style={{ marginBottom: 20 }}>
          <div style={{
            fontFamily:    'var(--font-serif)',
            fontStyle:     'italic',
            fontSize:      '1.2rem',
            color:         '#f0f0f8',
            marginBottom:  4,
          }}>
            Self-Assessment
          </div>
          <div style={{
            fontFamily:    'var(--font-mono)',
            fontSize:      '0.6rem',
            letterSpacing: '0.15em',
            textTransform: 'uppercase',
            color:         'var(--dim)',
          }}>
            GEN_{String(activeGen.gen).padStart(2,'0')} · {modeConf.label} ANALYSIS
          </div>
        </div>

        {/* Vitals matrix */}
        <div style={{
          display:             'grid',
          gridTemplateColumns: '1fr 1fr',
          gap:                 8,
          marginBottom:        16,
        }}>
          <MetricCell label="Coherence" value={vitals.coherence} color="var(--body)"  />
          <MetricCell label="Drift"     value={vitals.drift}     color="var(--warn)"  />
          <MetricCell label="Pressure"  value={vitals.pressure}  color="var(--heart)" />
          <div style={{
            background:   'var(--mycelium)',
            borderRadius: 4,
            padding:      12,
            border:       '1px solid var(--rule)',
          }}>
            <div className="mono-label" style={{ marginBottom: 4 }}>Mode</div>
            <div style={{
              fontFamily: 'var(--font-mono)',
              fontSize:   '1rem',
              fontWeight: 500,
              color:      modeConf.color,
            }}>
              {modeConf.label}
            </div>
          </div>
        </div>

        {/* Verdict */}
        <div style={{
          background:   `${field.color}08`,
          border:       `1px solid ${field.color}22`,
          borderRadius: 4,
          padding:      14,
          marginBottom: 16,
          fontFamily:   'var(--font-hand)',
          fontSize:     '1.05rem',
          lineHeight:   1.6,
          color:        'rgba(224,224,240,0.85)',
        }}>
          {activeGen.verdict}
        </div>

        {/* Coordinate */}
        <div style={{
          marginBottom: 20,
          padding:      '10px 14px',
          background:   'var(--mycelium)',
          borderRadius: 4,
          border:       '1px solid var(--rule)',
        }}>
          <CoordinateTag address={activeGen.address} />
        </div>

        {/* Actions */}
        <div style={{ display: 'flex', gap: 8 }}>
          <Btn onClick={acceptEvolution} primary color={field.color}>Accept Evolution</Btn>
          <Btn onClick={forceReassess}   danger>Force Reassess</Btn>
          <Btn onClick={closeAssess}>Dismiss</Btn>
        </div>
      </div>
    </div>
  )
}

function MetricCell({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div style={{
      background:   'var(--mycelium)',
      borderRadius: 4,
      padding:      12,
      border:       '1px solid var(--rule)',
    }}>
      <div className="mono-label" style={{ marginBottom: 4 }}>{label}</div>
      <div style={{ fontFamily: 'var(--font-mono)', fontSize: '1.15rem', color, fontWeight: 500 }}>
        {Math.round(value * 100)}%
      </div>
    </div>
  )
}

function Btn({
  children, onClick, primary, danger, color,
}: {
  children: React.ReactNode
  onClick: () => void
  primary?: boolean
  danger?:  boolean
  color?:   string
}) {
  const bg     = primary ? `${color}18` : danger ? 'rgba(255,61,90,0.08)' : 'transparent'
  const border = primary ? `${color}66` : danger ? 'var(--heart)'         : 'var(--rule)'
  const col    = primary ? color        : danger ? 'var(--heart)'         : 'var(--dim)'

  return (
    <button
      onClick={onClick}
      style={{
        fontFamily:    'var(--font-mono)',
        fontSize:      '0.6rem',
        letterSpacing: '0.1em',
        textTransform: 'uppercase',
        padding:       '7px 14px',
        borderRadius:  3,
        border:        `1px solid ${border}`,
        background:    bg,
        color:         col as string,
        cursor:        'pointer',
        transition:    'all 0.15s',
        flex:          primary ? 1 : 'none',
      }}
    >
      {children}
    </button>
  )
}
