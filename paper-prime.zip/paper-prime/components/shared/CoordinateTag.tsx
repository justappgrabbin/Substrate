'use client'

// ═══════════════════════════════════════════
//  CoordinateTag — consciousness address
// ═══════════════════════════════════════════

import type { ConsciousnessAddress } from '@/types'
import { FIELD_CONFIG } from '@/lib/constants'

interface Props {
  address: ConsciousnessAddress
  compact?: boolean
}

export function CoordinateTag({ address, compact }: Props) {
  const field = FIELD_CONFIG[address.field]
  const coord = `${address.gate}.${address.line}.${address.color}.${address.tone}.${address.base}`

  if (compact) {
    return (
      <span style={{
        fontFamily:    'var(--font-mono)',
        fontSize:      '0.6rem',
        letterSpacing: '0.08em',
        color:         field.color,
        opacity:       0.8,
      }}>
        {coord}
      </span>
    )
  }

  return (
    <div style={{
      fontFamily:    'var(--font-mono)',
      fontSize:      '0.58rem',
      letterSpacing: '0.1em',
    }}>
      <div style={{
        color:         field.color,
        fontWeight:    500,
        fontSize:      '0.75rem',
        marginBottom:  2,
      }}>
        {coord}
      </div>
      <div style={{ color: 'var(--dim)' }}>
        {address.label}
      </div>
      <div style={{ color: 'var(--dimmer)', marginTop: 2 }}>
        {address.degree}° · {field.chart} · {field.center}
      </div>
    </div>
  )
}
