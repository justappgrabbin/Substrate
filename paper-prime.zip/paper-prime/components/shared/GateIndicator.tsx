'use client'

// ═══════════════════════════════════════════
//  GateIndicator — pulsing status node
// ═══════════════════════════════════════════

import { FIELD_CONFIG } from '@/lib/constants'
import type { FieldMode, SubstrateMode } from '@/types'

interface Props {
  field:  FieldMode
  mode?:  SubstrateMode
  size?:  number
  pulse?: boolean
  label?: string
}

export function GateIndicator({ field, mode, size = 8, pulse = true, label }: Props) {
  const color = FIELD_CONFIG[field].color

  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
      <span
        style={{
          display:       'inline-block',
          width:         size,
          height:        size,
          borderRadius:  '50%',
          background:    color,
          boxShadow:     `0 0 ${size * 1.5}px ${color}`,
          flexShrink:    0,
          animation:     pulse ? 'breathe 2.5s ease-in-out infinite' : 'none',
        }}
      />
      {label && (
        <span style={{
          fontFamily:    'var(--font-mono)',
          fontSize:      '0.6rem',
          letterSpacing: '0.12em',
          textTransform: 'uppercase',
          color:         'var(--dim)',
        }}>
          {label}
        </span>
      )}
    </span>
  )
}
