'use client'

// ═══════════════════════════════════════════
//  Notebook — seed input panel
// ═══════════════════════════════════════════

import { Editor } from './Editor'
import { ModeDock } from './ModeDock'
import { GateIndicator } from '@/components/shared/GateIndicator'
import { useSubstrate } from '@/lib/store'

export function Notebook() {
  const activeField = useSubstrate(s => s.activeField)

  return (
    <div style={{
      display:        'flex',
      flexDirection:  'column',
      background:     'var(--soil)',
      overflow:       'hidden',
      borderRight:    '1px solid var(--rule)',
    }}>
      {/* Panel header */}
      <div style={{
        padding:       '8px 14px',
        borderBottom:  '1px solid var(--rule)',
        display:       'flex',
        alignItems:    'center',
        gap:           8,
        flexShrink:    0,
      }}>
        <GateIndicator field={activeField} size={6} />
        <span className="mono-label">Soil — Seed Input</span>
      </div>

      {/* Editor surface */}
      <Editor />

      {/* Mode dock */}
      <ModeDock />
    </div>
  )
}
