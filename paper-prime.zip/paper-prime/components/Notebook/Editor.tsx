'use client'

// ═══════════════════════════════════════════
//  Notebook/Editor — handwriting input surface
// ═══════════════════════════════════════════

import { useRef, useEffect } from 'react'
import { useSubstrate } from '@/lib/store'

export function Editor() {
  const { seed, setSeed, isEvolving } = useSubstrate()
  const ref = useRef<HTMLTextAreaElement>(null)

  // Autofocus
  useEffect(() => { ref.current?.focus() }, [])

  // Keyboard shortcut: Cmd/Ctrl + Enter
  function handleKeyDown(e: React.KeyboardEvent) {
    if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
      e.preventDefault()
      useSubstrate.getState().evolve()
    }
  }

  return (
    <div
      className="ruled-paper paper-texture"
      style={{
        flex:     1,
        position: 'relative',
        overflow: 'hidden',
      }}
    >
      <textarea
        ref={ref}
        value={seed}
        onChange={e => setSeed(e.target.value)}
        onKeyDown={handleKeyDown}
        disabled={isEvolving}
        placeholder={`Write the seed of your world here...

What does it need to become?
What does it need to feel?
What does it need to know?

Cmd+Enter to evolve.`}
        style={{
          position:   'relative',
          zIndex:     1,
          width:      '100%',
          height:     '100%',
          background: 'transparent',
          border:     'none',
          outline:    'none',
          resize:     'none',
          fontFamily: 'var(--font-hand)',
          fontSize:   '1.4rem',
          lineHeight: '32px',
          color:      '#1a1a28',
          padding:    '12px 20px 12px 68px',
          caretColor: '#c0392b',
          opacity:    isEvolving ? 0.5 : 1,
          transition: 'opacity 0.3s',
        }}
      />
    </div>
  )
}
