'use client'

// ═══════════════════════════════════════════
//  Notebook/ModeDock — author mode + field
// ═══════════════════════════════════════════

import { useSubstrate } from '@/lib/store'
import { FIELD_CONFIG } from '@/lib/constants'
import type { FieldMode, AuthorMode } from '@/types'

export function ModeDock() {
  const { authorMode, setAuthorMode, activeField, setField, isEvolving } = useSubstrate()

  const fields: FieldMode[] = ['mind', 'heart', 'body']
  const modes: { id: AuthorMode; label: string; desc: string }[] = [
    { id: 'director', label: 'Director', desc: 'Blueprint intent' },
    { id: 'artist',   label: 'Artist',   desc: 'Intuitive flow'   },
  ]

  return (
    <div style={{
      padding:       '8px 12px',
      borderTop:     '1px solid var(--rule)',
      background:    'var(--soil)',
      display:       'flex',
      alignItems:    'center',
      gap:           12,
      flexShrink:    0,
    }}>

      {/* Author mode */}
      <div style={{ display: 'flex', gap: 4 }}>
        {modes.map(m => (
          <button
            key={m.id}
            onClick={() => setAuthorMode(m.id)}
            disabled={isEvolving}
            title={m.desc}
            style={{
              fontFamily:    'var(--font-mono)',
              fontSize:      '0.58rem',
              letterSpacing: '0.1em',
              textTransform: 'uppercase',
              padding:       '4px 10px',
              borderRadius:  3,
              border:        `1px solid ${authorMode === m.id ? 'var(--dim)' : 'var(--rule)'}`,
              background:    authorMode === m.id ? 'rgba(255,255,255,0.06)' : 'transparent',
              color:         authorMode === m.id ? '#e0e0f0' : 'var(--dim)',
              cursor:        'pointer',
              transition:    'all 0.15s',
            }}
          >
            {m.label}
          </button>
        ))}
      </div>

      {/* Divider */}
      <div style={{ width: 1, height: 20, background: 'var(--rule)' }} />

      {/* Field selector */}
      <div style={{ display: 'flex', gap: 4 }}>
        {fields.map(f => {
          const cfg = FIELD_CONFIG[f]
          const active = activeField === f
          return (
            <button
              key={f}
              onClick={() => setField(f)}
              disabled={isEvolving}
              title={`${cfg.label} Field · ${cfg.chart}`}
              style={{
                fontFamily:    'var(--font-mono)',
                fontSize:      '0.58rem',
                letterSpacing: '0.1em',
                textTransform: 'uppercase',
                padding:       '4px 10px',
                borderRadius:  3,
                border:        `1px solid ${active ? cfg.color : 'var(--rule)'}`,
                background:    active ? `rgba(${hexToRgb(cfg.color)},0.1)` : 'transparent',
                color:         active ? cfg.color : 'var(--dim)',
                cursor:        'pointer',
                transition:    'all 0.15s',
              }}
            >
              {cfg.label}
            </button>
          )
        })}
      </div>

      {/* Seed length */}
      <SeedLen />
    </div>
  )
}

function SeedLen() {
  const seed = useSubstrate(s => s.seed)
  const len = seed.trim().split(/\s+/).filter(Boolean).length
  return (
    <span style={{
      marginLeft:    'auto',
      fontFamily:    'var(--font-mono)',
      fontSize:      '0.55rem',
      letterSpacing: '0.1em',
      color:         'var(--dimmer)',
    }}>
      {len} words
    </span>
  )
}

function hexToRgb(hex: string): string {
  const r = parseInt(hex.slice(1,3),16)
  const g = parseInt(hex.slice(3,5),16)
  const b = parseInt(hex.slice(5,7),16)
  return `${r},${g},${b}`
}
