# PAPER PRIME

Self-aware consciousness generation substrate.  
Next.js 14 · TypeScript · Zustand · Anthropic SDK

## Stack

| Layer       | Tech                          |
|-------------|-------------------------------|
| Framework   | Next.js 14 (App Router)       |
| Language    | TypeScript                    |
| State       | Zustand + persist middleware  |
| AI          | Anthropic SDK (claude-sonnet) |
| Styling     | CSS-in-JS (inline) + globals  |
| Background  | Canvas API (BioCanvas)        |

## Quick Start

```bash
# 1. Install
npm install

# 2. Set your key
cp .env.example .env.local
# edit .env.local → ANTHROPIC_API_KEY=sk-ant-...

# 3. Run
npm run dev
# → http://localhost:3000
```

## Architecture

```
app/
  page.tsx              ← 3-column grid layout
  layout.tsx            ← root + metadata
  globals.css           ← CSS vars, animations, paper texture
  api/generate/route.ts ← Anthropic API route

components/
  Notebook/             ← seed input (Editor + ModeDock)
  Portal/               ← reality output (OutputFrame + HUD + Loader)
  GenomePanel.tsx       ← generation history sidebar
  AssessOverlay.tsx     ← self-assessment modal
  Chrome.tsx            ← TopBar + BottomBar
  BioCanvas.tsx         ← living mycelium background

lib/
  store.ts              ← Zustand substrate state + self-scoring engine
  constants.ts          ← fields, modes, gates, verdicts
types/
  index.ts              ← all TypeScript interfaces
```

## Self-Scoring Engine

After every generation, `selfScore()` computes:
- **Coherence** — seed keyword alignment with output
- **Drift** — divergence from previous generation
- **Pressure** — accumulation since last reassessment
- **Resonance** — composite field coherence

`decideMode()` maps vitals → `stable | evolve | drift | mutate`

Auto-triggers Self-Assessment overlay on `mutate` or `drift`.

## Fields

| Field | Chart     | Centers              | Color   |
|-------|-----------|----------------------|---------|
| Mind  | Sidereal  | Ajna / Head          | `#3de8ff` |
| Heart | Draconic  | Heart / Solar Plexus | `#ff3d5a` |
| Body  | Tropical  | Spleen / Sacral / Root | `#39ff7a` |

## Keyboard

`Cmd/Ctrl + Enter` — Evolve
