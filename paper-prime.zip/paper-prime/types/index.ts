// ═══════════════════════════════════════════
//  PAPER PRIME — TYPE SUBSTRATE
// ═══════════════════════════════════════════

export type FieldMode = 'mind' | 'heart' | 'body'
export type SubstrateMode = 'stable' | 'evolve' | 'drift' | 'mutate'
export type AuthorMode = 'director' | 'artist'

// Human Design gate (1–64), line (1–6), color (1–6), tone (1–6), base (1–5)
export interface ConsciousnessAddress {
  gate:   number
  line:   number
  color:  number
  tone:   number
  base:   number
  degree: number
  field:  FieldMode
  label:  string   // e.g. "41.3.2.1.4 · Gate of Fantasy"
}

export interface SubstrateVitals {
  coherence: number   // 0–1  seed↔output alignment
  drift:     number   // 0–1  divergence from previous gen
  pressure:  number   // 0–1  time-since-reassessment accumulation
  resonance: number   // 0–1  cross-field coherence (mind/heart/body)
}

export interface Generation {
  id:        string
  gen:       number
  seed:      string
  output:    string
  vitals:    SubstrateVitals
  mode:      SubstrateMode
  address:   ConsciousnessAddress
  field:     FieldMode
  timestamp: number
  preview:   string
  tags:      string[]
  verdict:   string
}

export interface SubstrateState {
  // Identity
  generation:    number
  mode:          SubstrateMode
  activeField:   FieldMode
  authorMode:    AuthorMode

  // History
  genome:        Generation[]
  activeGen:     Generation | null
  currentOutput: string | null

  // Vitals
  vitals:        SubstrateVitals

  // UI state
  isEvolving:    boolean
  loaderPhase:   LoaderPhase | null
  assessOpen:    boolean
  seed:          string

  // Actions
  setSeed:       (s: string) => void
  setField:      (f: FieldMode) => void
  setAuthorMode: (m: AuthorMode) => void
  evolve:        () => Promise<void>
  forceMutate:   () => Promise<void>
  restoreGen:    (id: string) => void
  triggerAssess: () => void
  closeAssess:   () => void
  acceptEvolution: () => void
  forceReassess: () => void
  reset:         () => void
}

export interface LoaderPhase {
  phase:    number   // 1–3
  label:    string
  sub:      string
  progress: number   // 0–100
}

export interface GenerateRequest {
  seed:       string
  field:      FieldMode
  authorMode: AuthorMode
  gen:        number
  history:    Pick<Generation, 'gen' | 'preview' | 'mode'>[]
  vitals:     SubstrateVitals
  mode:       SubstrateMode
}

export interface GenerateResponse {
  html:    string
  address: ConsciousnessAddress
  tags:    string[]
  verdict: string
  error?:  string
}

// Gate metadata subset
export interface GateData {
  gate:    number
  name:    string
  keyword: string
  center:  string
  field:   FieldMode
}
