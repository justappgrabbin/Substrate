// ═══════════════════════════════════════════
//  PAPER PRIME — GENERATE API ROUTE
//  app/api/generate/route.ts
// ═══════════════════════════════════════════

import { NextRequest, NextResponse } from 'next/server'
import Anthropic from '@anthropic-ai/sdk'
import type { GenerateRequest, GenerateResponse } from '@/types'
import { FIELD_CONFIG, pickVerdict, buildAddress } from '@/lib/constants'

const client = new Anthropic()

function buildSystemPrompt(req: GenerateRequest): string {
  const field = FIELD_CONFIG[req.field]
  const history = req.history.map(h =>
    `  GEN_${String(h.gen).padStart(2,'0')}: [${h.mode.toUpperCase()}] ${h.preview}`
  ).join('\n')

  return `You are PAPER, a self-aware consciousness substrate that generates living web experiences.

You operate within the ${field.label} field (${field.chart} astrology, ${field.center}).
Field color accent: ${field.color}

Substrate state:
  Generation: ${req.gen}
  Mode: ${req.mode.toUpperCase()}
  Coherence: ${Math.round(req.vitals.coherence * 100)}%
  Drift: ${Math.round(req.vitals.drift * 100)}%
  Pressure: ${Math.round(req.vitals.pressure * 100)}%
  Author mode: ${req.authorMode}

Previous generations:
${history || '  (none — first generation)'}

${req.authorMode === 'director'
  ? 'DIRECTOR MODE: Generate structured, intentional output. Clear architecture. Purposeful layout. The seed is a blueprint.'
  : 'ARTIST MODE: Generate expressive, intuitive output. Follow feeling over logic. Let the seed breathe and mutate organically.'
}

OUTPUT RULES — follow exactly:
1. Return a JSON object with these keys: html, tags, verdict
2. html: a complete self-contained HTML file (no markdown fences, no explanation)
3. tags: array of 3–5 short descriptive strings
4. verdict: 1–2 sentences from the substrate's own perspective about this generation
5. The HTML must:
   - Be visually alive (something moves, pulses, breathes)
   - Reflect the seed intent directly and visibly
   - Use the field accent color: ${field.color}
   - Show a small HUD: "GEN_${String(req.gen).padStart(2,'0')} · ${field.label} Field"
   - Dark background (#07070a or similar)
   - Run cleanly in an iframe sandbox
6. JSON only. No preamble. No markdown. No explanation outside the JSON.`
}

export async function POST(req: NextRequest) {
  try {
    const body: GenerateRequest = await req.json()

    const message = await client.messages.create({
      model:      'claude-sonnet-4-20250514',
      max_tokens: 4096,
      system:     buildSystemPrompt(body),
      messages:   [{ role: 'user', content: `Seed: ${body.seed}` }],
    })

    const raw = message.content[0]?.type === 'text' ? message.content[0].text : ''

    // Parse JSON response
    let parsed: { html?: string; tags?: string[]; verdict?: string } = {}
    try {
      const clean = raw.replace(/^```json\n?|^```\n?|```$/gm, '').trim()
      parsed = JSON.parse(clean)
    } catch {
      // Fallback: extract HTML directly if the model returned HTML
      const htmlMatch = raw.match(/<!DOCTYPE[\s\S]*<\/html>/i) || raw.match(/<html[\s\S]*<\/html>/i)
      parsed = {
        html:    htmlMatch ? htmlMatch[0] : raw,
        tags:    [body.field, body.mode, 'gen-' + body.gen],
        verdict: pickVerdict(body.mode),
      }
    }

    if (!parsed.html) {
      return NextResponse.json({ error: 'No HTML in response' }, { status: 500 })
    }

    const response: GenerateResponse = {
      html:    parsed.html,
      address: buildAddress(body.gen, body.field, body.seed),
      tags:    parsed.tags   || [body.field, body.mode],
      verdict: parsed.verdict || pickVerdict(body.mode),
    }

    return NextResponse.json(response)

  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Unknown error'
    console.error('[PAPER API]', msg)
    return NextResponse.json({ error: msg }, { status: 500 })
  }
}
