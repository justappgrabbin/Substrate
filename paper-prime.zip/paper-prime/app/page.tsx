'use client'

// ═══════════════════════════════════════════
//  PAPER PRIME — Main Page
// ═══════════════════════════════════════════

import { Notebook } from '@/components/Notebook'
import { Portal } from '@/components/Portal'
import { GenomePanel } from '@/components/GenomePanel'
import { AssessOverlay } from '@/components/AssessOverlay'
import { TopBar, BottomBar } from '@/components/Chrome'
import { BioCanvas } from '@/components/BioCanvas'

export default function Home() {
  return (
    <>
      <BioCanvas />

      <div style={{
        position:            'relative',
        zIndex:              10,
        width:               '100vw',
        height:              '100vh',
        display:             'grid',
        gridTemplateColumns: '1fr 1fr var(--sidebar-w)',
        gridTemplateRows:    'var(--topbar-h) 1fr var(--bottom-h)',
        gap:                 '1px',
        background:          'var(--rule)',
      }}>

        {/* Top bar — spans full width */}
        <div style={{ gridColumn: '1 / -1' }}>
          <TopBar />
        </div>

        {/* Left — Seed input (Notebook) */}
        <Notebook />

        {/* Center — Reality output (Portal) */}
        <Portal />

        {/* Right — Generation history (Genome) */}
        <GenomePanel />

        {/* Bottom bar — spans full width */}
        <div style={{ gridColumn: '1 / -1' }}>
          <BottomBar />
        </div>

      </div>

      {/* Overlay — Self-assessment modal */}
      <AssessOverlay />
    </>
  )
}
