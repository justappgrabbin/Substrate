from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional

app = FastAPI(title="YOU-N-I-VERSE API", version="0.1.0")

# Enable CORS for local dev (Vite -> FastAPI)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class StitchRequest(BaseModel):
    title: Optional[str] = None
    content: str

class ChatRequest(BaseModel):
    prompt: str

@app.get("/api/health")
def health():
    return {"ok": True}

@app.post("/api/stitch")
def stitch(body: StitchRequest):
    # "Stitch" is a simple summarizer/formatter for now; replace with your logic
    text = body.content.strip()
    # Toy summary: take first 3 lines/300 chars + counts
    snippet = (text[:300] + ("…" if len(text) > 300 else "")) if text else ""
    lines = len(text.splitlines()) if text else 0
    words = len(text.split()) if text else 0
    return {
        "title": body.title or "Untitled",
        "summary": f"{snippet}",
        "meta": {"lines": lines, "words": words}
    }

# ---- Optional: TinyLlama chat endpoint ----
# To enable, ensure transformers/torch installed and first run will download weights.
# Model: TinyLlama/TinyLlama-1.1B-Chat-v1.0
LLAMA_ENABLED = False
pipe = None

def _init_llama():
    global pipe, LLAMA_ENABLED
    if pipe is not None:
        return
    try:
        from transformers import pipeline
        # You can switch to a faster quantized variant if desired
        pipe = pipeline(
            "text-generation",
            model="TinyLlama/TinyLlama-1.1B-Chat-v1.0",
            torch_dtype="auto",
            device_map="auto"
        )
        LLAMA_ENABLED = True
    except Exception as e:
        print("TinyLlama init failed:", e)
        LLAMA_ENABLED = False

@app.post("/api/chat")
def chat(body: ChatRequest):
    if not LLAMA_ENABLED:
        _init_llama()
    if not LLAMA_ENABLED:
        return {"reply": "TinyLlama not initialized. Install requirements and restart the server."}
    prompt = body.prompt.strip()
    if not prompt:
        return {"reply": ""}
    out = pipe(prompt, max_new_tokens=120, do_sample=True, temperature=0.7)
    # transformers returns list[dict] with 'generated_text'
    txt = out[0].get("generated_text", "")
    # Return only the completion beyond the prompt if present
    if txt.startswith(prompt):
        txt = txt[len(prompt):].strip()
    return {"reply": txt}
