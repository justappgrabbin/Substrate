# YOU‑N‑I‑VERSE Fullstack Starter

A minimal **React + TypeScript (Vite)** frontend and a **FastAPI** backend, with an optional **TinyLlama** chat endpoint.
Use this to stitch ideas together, preview quickly, and ship to GitHub.

## Structure
```
you-n-i-verse-fullstack-starter/
  frontend/   # React + TS (Vite)
  backend/    # FastAPI API (stitch + optional TinyLlama)
  .github/workflows/pages.yml  # GitHub Pages deploy for frontend
```

## Quickstart

### 1) Frontend
```bash
cd frontend
npm i
npm run dev
```
Open http://localhost:5173

### 2) Backend (API)
```bash
cd backend
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```
Open http://localhost:8000/api/health

During development, the Vite dev server proxies `/api/*` to `http://localhost:8000`.

### Optional: Enable TinyLlama
Install the extra requirements (already listed in `requirements.txt`) and make sure you have enough disk space and a working PyTorch install. The first run will download the model:
```bash
pip install -r requirements.txt
# Start the API
uvicorn main:app --reload --port 8000
```
Then hit the `/api/chat` endpoint from the frontend.
If you see "TinyLlama not initialized", check your environment and server logs. Edit `main.py` to tweak model settings (quantization, device).

## Deploy Frontend to GitHub Pages
1. Create a GitHub repo (e.g., `you-n-i-verse`).
2. Commit this project and push.
3. In GitHub → Settings → Pages, set "Deploy from a branch" and use `/ (root)` or enable "GitHub Actions".
4. The included workflow builds and publishes the `frontend` folder.

## Deploy Backend
- Simple: Deploy FastAPI to **Railway**, **Render**, **Fly.io**, **Azure App Service**, or **Heroku**.
- Or containerize with Docker and host anywhere.

## Save & Zip
Zip this folder and upload to GitHub. (Or just push directly.)

---

Generated: 2025-09-21T22:18:52.851667Z
