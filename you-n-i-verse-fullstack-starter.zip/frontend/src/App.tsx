import React, { useState } from 'react'

export default function App(){
  const [msg, setMsg] = useState('')
  const [stitched, setStitched] = useState<string | null>(null)
  const [chat, setChat] = useState<string>('')
  const [reply, setReply] = useState<string | null>(null)

  async function callStitch(){
    const res = await fetch('/api/stitch', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        title: 'YOU‑N‑I‑VERSE',
        content: msg
      })
    })
    const data = await res.json()
    setStitched(data.summary ?? JSON.stringify(data))
  }

  async function callTinyLlama(){
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ prompt: chat })
    })
    const data = await res.json()
    setReply(data.reply ?? JSON.stringify(data))
  }

  return (
    <div style={{minHeight:'100vh',display:'grid',placeItems:'center',background:'#0b0b10',color:'#e8e8ef'}}>
      <div style={{width:960,maxWidth:'95vw',display:'grid',gap:16}}>
        <header style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
          <h1 style={{margin:0}}>YOU‑N‑I‑VERSE</h1>
          <span style={{opacity:.7}}>React + TS + FastAPI starter</span>
        </header>

        <section style={{display:'grid',gap:8, padding:16, background:'#13131a', borderRadius:14, border:'1px solid #2a2a3a'}}>
          <h2 style={{margin:'0 0 4px 0'}}>Stitch</h2>
          <p style={{margin:'0 0 8px 0',opacity:.8}}>Send text to FastAPI to get a stitched summary.</p>
          <textarea placeholder="Put any content here…" value={msg} onChange={e=>setMsg(e.target.value)} style={{width:'100%', minHeight:120, borderRadius:12, padding:10, background:'#0f0f14', color:'#e8e8ef', border:'1px solid #2a2a3a'}}/>
          <button onClick={callStitch} style={{padding:'10px 14px',borderRadius:12, border:'1px solid #2a2a3a', background:'#1c1c26', color:'#e8e8ef', cursor:'pointer'}}>Call /api/stitch</button>
          {stitched && <pre style={{whiteSpace:'pre-wrap', background:'#0f0f14', padding:10, borderRadius:12, border:'1px solid #2a2a3a'}}>{stitched}</pre>}
        </section>

        <section style={{display:'grid',gap:8, padding:16, background:'#13131a', borderRadius:14, border:'1px solid #2a2a3a'}}>
          <h2 style={{margin:'0 0 4px 0'}}>TinyLlama (optional)</h2>
          <p style={{margin:'0 0 8px 0',opacity:.8}}>If you enable the /api/chat endpoint in FastAPI, you can chat here.</p>
          <textarea placeholder="Say hi to TinyLlama…" value={chat} onChange={e=>setChat(e.target.value)} style={{width:'100%', minHeight:80, borderRadius:12, padding:10, background:'#0f0f14', color:'#e8e8ef', border:'1px solid #2a2a3a'}}/>
          <button onClick={callTinyLlama} style={{padding:'10px 14px',borderRadius:12, border:'1px solid #2a2a3a', background:'#1c1c26', color:'#e8e8ef', cursor:'pointer'}}>Call /api/chat</button>
          {reply && <pre style={{whiteSpace:'pre-wrap', background:'#0f0f14', padding:10, borderRadius:12, border:'1px solid #2a2a3a'}}>{reply}</pre>}
        </section>
      </div>
    </div>
  )
}
