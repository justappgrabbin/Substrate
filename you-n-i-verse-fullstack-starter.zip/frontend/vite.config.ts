import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api': 'http://localhost:8000' // proxy to FastAPI during dev
    }
  },
  build: {
    outDir: 'dist',
  },
  base: process.env.GITHUB_ACTIONS ? '/you-n-i-verse/' : '/',
})
