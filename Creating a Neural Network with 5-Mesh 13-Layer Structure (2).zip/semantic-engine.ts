/**
 * SEMANTIC ENGINE
 * 
 * Transforms generic physics into address-driven behavior.
 * 
 * Instead of: pressure += tension * 0.01
 * Now: pressure += gate-specific bias * line-specific resonance * color-filter * tone-amplification
 * 
 * The address DRIVES the physics, not just labels it.
 */

export interface SemanticBehavior {
  gateInfluence: number;
  lineModulation: number;
  colorFiltering: number;
  toneAmplification: number;
  zodiacResonance: number;
  houseContext: number;
}

export class SemanticEngine {
  private semanticsEnabled: boolean = false;

  /**
   * Toggle between physics and semantics mode
   */
  toggleSemantics(enabled: boolean): void {
    this.semanticsEnabled = enabled;
  }

  /**
   * Check if semantics are enabled
   */
  isSemanticMode(): boolean {
    return this.semanticsEnabled;
  }

  /**
   * Calculate semantic behavior for a node address
   */
  calculateSemanticBehavior(address: any): SemanticBehavior {
    return {
      gateInfluence: this.getGateInfluence(address.gate),
      lineModulation: this.getLineModulation(address.line),
      colorFiltering: this.getColorFiltering(address.color),
      toneAmplification: this.getToneAmplification(address.tone),
      zodiacResonance: this.getZodiacResonance(address.zodiac),
      houseContext: this.getHouseContext(address.house),
    };
  }

  /**
   * GATE INFLUENCE (1-64)
   * Different gates have different resonance patterns and pressure thresholds
   */
  private getGateInfluence(gate: number): number {
    // Gate 24 (Rationalization): High internal pressure, slow transitions
    if (gate === 24) return 1.3;
    
    // Gate 61 (Mystery/Intrigue): Erratic pressure, fast state changes
    if (gate === 61) return 0.7;
    
    // Gate 42 (Growth): Steady pressure accumulation
    if (gate === 42) return 1.0;
    
    // Gate 3 (Ordering): Chaotic pressure, needs structure
    if (gate === 3) return 1.2;
    
    // Gate 20 (Now): Immediate response, no pressure buildup
    if (gate === 20) return 0.5;
    
    // Default: neutral
    return 1.0;
  }

  /**
   * LINE MODULATION (1-6)
   * Lines determine HOW the gate expresses
   * Line 1: Investigative (probing, testing)
   * Line 2: Hermit (withdrawn, internal)
   * Line 3: Martyr (trial/error, learning)
   * Line 4: Opportunist (social, connected)
   * Line 5: Heretic (revolutionary, disruptive)
   * Line 6: Role Model (integrated, whole)
   */
  private getLineModulation(line: number): number {
    const lineModulations: { [key: number]: number } = {
      1: 0.8,  // Investigative: slower, more cautious
      2: 0.6,  // Hermit: withdrawn, minimal external pressure
      3: 1.2,  // Martyr: high pressure from learning
      4: 1.4,  // Opportunist: responsive to network
      5: 0.9,  // Heretic: disruptive, unpredictable
      6: 1.1,  // Role Model: stable, integrated
    };
    return lineModulations[line] || 1.0;
  }

  /**
   * COLOR FILTERING (1-3)
   * Colors represent different types of pressure
   * 1 (Red): Pressure from external environment
   * 2 (Yellow): Pressure from internal contradiction
   * 3 (Blue): Pressure from collective need
   */
  private getColorFiltering(color: number): number {
    const colorFilters: { [key: number]: number } = {
      1: 1.0,  // Red: normal environmental pressure
      2: 1.3,  // Yellow: amplified internal pressure
      3: 0.8,  // Blue: collective pressure (smoother)
    };
    return colorFilters[color] || 1.0;
  }

  /**
   * TONE AMPLIFICATION (1-6)
   * Tones represent the quality of the pressure
   * 1: Reactive (fast response)
   * 2: Responsive (balanced)
   * 3: Generative (creates new patterns)
   * 4: Transformative (changes structure)
   * 5: Reflective (introspective)
   * 6: Transcendent (integrative)
   */
  private getToneAmplification(tone: number): number {
    const toneAmplifications: { [key: number]: number } = {
      1: 1.2,  // Reactive: fast pressure buildup
      2: 1.0,  // Responsive: balanced
      3: 1.3,  // Generative: creates patterns
      4: 1.4,  // Transformative: high pressure for change
      5: 0.7,  // Reflective: internal focus, less external pressure
      6: 1.1,  // Transcendent: integrated pressure
    };
    return toneAmplifications[tone] || 1.0;
  }

  /**
   * ZODIAC RESONANCE (1-12)
   * Zodiac signs influence how nodes interact with time and cycles
   */
  private getZodiacResonance(zodiac: number): number {
    // Aries (1): Initiating, high pressure
    if (zodiac === 1) return 1.2;
    
    // Taurus (2): Stable, low pressure
    if (zodiac === 2) return 0.8;
    
    // Gemini (3): Communicative, variable
    if (zodiac === 3) return 1.1;
    
    // Cancer (4): Emotional, reactive
    if (zodiac === 4) return 1.3;
    
    // Leo (5): Expressive, confident
    if (zodiac === 5) return 1.2;
    
    // Virgo (6): Analytical, precise
    if (zodiac === 6) return 0.9;
    
    // Libra (7): Balanced, harmonious
    if (zodiac === 7) return 1.0;
    
    // Scorpio (8): Intense, transformative
    if (zodiac === 8) return 1.4;
    
    // Sagittarius (9): Expansive, optimistic
    if (zodiac === 9) return 1.1;
    
    // Capricorn (10): Structured, disciplined
    if (zodiac === 10) return 0.9;
    
    // Aquarius (11): Revolutionary, unpredictable
    if (zodiac === 11) return 1.2;
    
    // Pisces (12): Intuitive, flowing
    if (zodiac === 12) return 1.0;
    
    return 1.0;
  }

  /**
   * HOUSE CONTEXT (1-12)
   * Houses determine the life area and contextual pressure
   */
  private getHouseContext(house: number): number {
    // House 1: Self/Identity (strong pressure)
    if (house === 1) return 1.2;
    
    // House 2: Resources (stability)
    if (house === 2) return 0.9;
    
    // House 3: Communication (variable)
    if (house === 3) return 1.1;
    
    // House 4: Home/Foundation (grounding)
    if (house === 4) return 0.8;
    
    // House 5: Creativity/Expression (high pressure)
    if (house === 5) return 1.3;
    
    // House 6: Service/Health (detail-oriented)
    if (house === 6) return 0.9;
    
    // House 7: Relationships (interactive)
    if (house === 7) return 1.1;
    
    // House 8: Transformation (intense)
    if (house === 8) return 1.4;
    
    // House 9: Expansion (optimistic)
    if (house === 9) return 1.1;
    
    // House 10: Career/Public (ambitious)
    if (house === 10) return 1.2;
    
    // House 11: Community (collective)
    if (house === 11) return 1.0;
    
    // House 12: Spirituality (transcendent)
    if (house === 12) return 1.0;
    
    return 1.0;
  }

  /**
   * Calculate semantic pressure for a node
   * Instead of generic tension, pressure is driven by address meaning
   */
  calculateSemanticPressure(
    address: any,
    basePressure: number,
    internalContradiction: number
  ): number {
    if (!this.semanticsEnabled) {
      return basePressure;
    }

    const semantic = this.calculateSemanticBehavior(address);

    // Combine all semantic influences
    const semanticMultiplier =
      semantic.gateInfluence *
      semantic.lineModulation *
      semantic.colorFiltering *
      semantic.toneAmplification *
      semantic.zodiacResonance *
      semantic.houseContext;

    // Semantic pressure = base pressure modulated by address meaning
    return basePressure * semanticMultiplier + internalContradiction * 0.05;
  }

  /**
   * Calculate semantic state transition threshold
   * Different addresses have different thresholds for state changes
   */
  calculateSemanticThreshold(address: any, baseThreshold: number): number {
    if (!this.semanticsEnabled) {
      return baseThreshold;
    }

    const semantic = this.calculateSemanticBehavior(address);

    // Gate 24 (Rationalization) has HIGH threshold (resists change)
    if (address.gate === 24) {
      return baseThreshold * 1.5;
    }

    // Gate 61 (Mystery) has LOW threshold (changes easily)
    if (address.gate === 61) {
      return baseThreshold * 0.6;
    }

    // Line 3 (Martyr) has LOW threshold (learns through trial/error)
    if (address.line === 3) {
      return baseThreshold * 0.8;
    }

    // Line 5 (Heretic) has VERY LOW threshold (revolutionary)
    if (address.line === 5) {
      return baseThreshold * 0.7;
    }

    // Default: apply semantic multiplier
    const semantic_multiplier =
      semantic.gateInfluence * semantic.lineModulation;
    return baseThreshold * semantic_multiplier;
  }

  /**
   * Calculate semantic resonance with neighbors
   * Different addresses resonate differently with each other
   */
  calculateSemanticResonance(
    address1: any,
    address2: any,
    baseResonance: number
  ): number {
    if (!this.semanticsEnabled) {
      return baseResonance;
    }

    // Same gate: strong resonance
    if (address1.gate === address2.gate) {
      return baseResonance * 1.3;
    }

    // Complementary gates: moderate resonance
    if (this.areComplementaryGates(address1.gate, address2.gate)) {
      return baseResonance * 1.1;
    }

    // Same line: moderate resonance
    if (address1.line === address2.line) {
      return baseResonance * 1.15;
    }

    // Same color: slight resonance boost
    if (address1.color === address2.color) {
      return baseResonance * 1.05;
    }

    // Different everything: reduced resonance
    return baseResonance * 0.7;
  }

  /**
   * Check if two gates are complementary
   * (This is a simplified version - real Human Design has specific complementary pairs)
   */
  private areComplementaryGates(gate1: number, gate2: number): boolean {
    // Gate 24 (Rationalization) complements Gate 61 (Mystery)
    if ((gate1 === 24 && gate2 === 61) || (gate1 === 61 && gate2 === 24)) {
      return true;
    }

    // Gate 3 (Ordering) complements Gate 42 (Growth)
    if ((gate1 === 3 && gate2 === 42) || (gate1 === 42 && gate2 === 3)) {
      return true;
    }

    return false;
  }

  /**
   * Get semantic description of a node
   */
  getSemanticDescription(address: any): string {
    const gateName = this.getGateName(address.gate);
    const lineName = this.getLineName(address.line);
    const colorName = this.getColorName(address.color);
    const toneName = this.getToneName(address.tone);

    return `${gateName} / ${lineName} / ${colorName} / ${toneName}`;
  }

  private getGateName(gate: number): string {
    const gateNames: { [key: number]: string } = {
      24: "Rationalization",
      61: "Mystery",
      42: "Growth",
      3: "Ordering",
      20: "Now",
    };
    return gateNames[gate] || `Gate ${gate}`;
  }

  private getLineName(line: number): string {
    const lineNames: { [key: number]: string } = {
      1: "Investigative",
      2: "Hermit",
      3: "Martyr",
      4: "Opportunist",
      5: "Heretic",
      6: "Role Model",
    };
    return lineNames[line] || `Line ${line}`;
  }

  private getColorName(color: number): string {
    const colorNames: { [key: number]: string } = {
      1: "Red",
      2: "Yellow",
      3: "Blue",
    };
    return colorNames[color] || `Color ${color}`;
  }

  private getToneName(tone: number): string {
    const toneNames: { [key: number]: string } = {
      1: "Reactive",
      2: "Responsive",
      3: "Generative",
      4: "Transformative",
      5: "Reflective",
      6: "Transcendent",
    };
    return toneNames[tone] || `Tone ${tone}`;
  }
}

export default SemanticEngine;
