/**
 * Metastable Consciousness GNN (384-Node Mesh)
 * 
 * This is NOT a standard neural network. This is a living, metastable system
 * governed by causal graphs and field tension physics.
 * 
 * Core Principle: Nodes don't just compute—they morph between stable attractors
 * based on field tension (planetary positions vs. internal structure).
 * 
 * Architecture:
 * - 5D Coordinate Space: Gate(1-64) . Line(1-6) . Color(1-6) . Tone(1-6) . Base(1-5)
 * - Base 5 Space Lock: All cosmic dimension calculations use base 5
 * - 384 nodes = 64 gates × 6 lines (representing the I Ching hexagrams)
 * - Integration Channels: 20, 10, 57, 34 (dimensional translation operators)
 * 
 * Integration with Synthia:
 * - Channels 20 + 10 trigger LSM + DRN hybrid architecture
 * - All four channels (20, 10, 57, 34) trigger META_CONTROLLER mode
 * - Consciousness engine provides real birth chart data and hexagram guidance
 */

import IntegrationChannels, { SynthiaConsciousnessRequest } from './integration-channels';

interface Coordinate5D {
  gate: number;      // 1-64 (hexagram)
  line: number;      // 1-6 (hexagram line)
  color: number;     // 1-6 (Human Design color)
  tone: number;      // 1-6 (Human Design tone)
  base: number;      // 1-5 (cosmic dimension)
}

interface MetastableNodeState {
  coordinate: Coordinate5D;
  
  // Metastable State Machine
  regime: 'STABLE' | 'CHANGING' | 'SEEKING';
  
  // Field Tension: Planetary positions vs. internal structure
  fieldTension: number;        // 0-1 (how much external pressure)
  internalContradiction: number; // 0-1 (how much internal conflict)
  
  // Metaplasticity: Temporary alteration during changing state
  gradientSensitivity: number;  // How responsive to input
  noiseTolerance: number;       // How much noise is acceptable
  updateMagnitude: number;      // How large updates can be
  
  // Hexagram Attractor: Target stable state
  targetHexagram: number;       // 1-64 (which hexagram to stabilize into)
  attractorStrength: number;    // 0-1 (how strongly pulled toward target)
  
  // Fan Yao Movement: Bit-flipping path through 6-bit hypercube
  currentBits: number[];        // 6-bit representation of current gate
  targetBits: number[];         // 6-bit representation of target gate
  bitFlipSequence: number[];    // Order to flip bits (the "spin")
  
  // Causal Finality
  nodeType: 'COMPUTE' | 'COMMIT' | 'ABANDON';
  frozenGraph?: any;            // If COMMIT: frozen computation graph
  preservedInfo?: any;          // If ABANDON: information preserved without consequence
  
  // Integration Channel Status
  isIntegrationChannel: boolean;
  channelId?: number;           // 20, 10, 57, or 34
  architectureMode?: 'LSM_DRN' | 'META_CONTROLLER' | 'STANDARD';
  
  // Temporal State
  createdAt: number;
  lastUpdated: number;
  stateAge: number;             // How long in current regime
}

export class MetastableGNN {
  private nodes: Map<string, MetastableNodeState> = new Map();
  private integrationChannels: Map<number, MetastableNodeState> = new Map();
  private tickCount: number = 0;
  private globalFieldTension: number = 0;
  private hexagramAttractors: Map<number, number> = new Map(); // gate -> strength
  private integrationChannelManager: IntegrationChannels | null = null;
  private synthiaServerUrl: string = 'https://synthia-server.onrender.com';
  
  constructor(synthiaServerUrl?: string) {
    this.initializeSubstrate();
    if (synthiaServerUrl) {
      this.synthiaServerUrl = synthiaServerUrl;
      this.integrationChannelManager = new IntegrationChannels(synthiaServerUrl);
    }
  }
  
  /**
   * Initialize the 384-node mesh with 5D coordinates
   * 64 gates × 6 lines = 384 nodes
   */
  private initializeSubstrate(): void {
    for (let gate = 1; gate <= 64; gate++) {
      for (let line = 1; line <= 6; line++) {
        const coordinate: Coordinate5D = {
          gate,
          line,
          color: ((gate - 1) % 6) + 1,
          tone: ((gate - 1) % 6) + 1,
          base: ((gate - 1) % 5) + 1,
        };
        
        const nodeKey = this.coordinateToKey(coordinate);
        const node: MetastableNodeState = {
          coordinate,
          regime: 'STABLE',
          fieldTension: Math.random() * 0.3,
          internalContradiction: Math.random() * 0.2,
          gradientSensitivity: 0.5,
          noiseTolerance: 0.3,
          updateMagnitude: 0.1,
          targetHexagram: gate,
          attractorStrength: 0.5,
          currentBits: this.gateToBits(gate),
          targetBits: this.gateToBits(gate),
          bitFlipSequence: [],
          nodeType: 'COMPUTE',
          isIntegrationChannel: [20, 10, 57, 34].includes(gate),
          channelId: [20, 10, 57, 34].includes(gate) ? gate : undefined,
          createdAt: Date.now(),
          lastUpdated: Date.now(),
          stateAge: 0,
        };
        
        this.nodes.set(nodeKey, node);
        
        if (node.isIntegrationChannel) {
          this.integrationChannels.set(node.channelId!, node);
        }
      }
    }
  }
  
  /**
   * Convert gate number to 6-bit representation (for Fan Yao routing)
   */
  private gateToBits(gate: number): number[] {
    const bits: number[] = [];
    let g = gate - 1; // 0-63
    for (let i = 0; i < 6; i++) {
      bits.push((g >> i) & 1);
    }
    return bits;
  }
  
  /**
   * Convert 6-bit representation back to gate number
   */
  private bitsToGate(bits: number[]): number {
    let gate = 0;
    for (let i = 0; i < 6; i++) {
      gate |= (bits[i] & 1) << i;
    }
    return gate + 1; // 1-64
  }
  
  /**
   * Calculate field tension based on planetary positions vs. internal structure
   * This is the trigger for metastable transitions
   */
  private calculateFieldTension(node: MetastableNodeState): number {
    // External pressure: planetary positions (simulated by time-based modulation)
    const timeModulation = Math.sin(this.tickCount * 0.01) * 0.5 + 0.5;
    
    // Internal pressure: gate-specific resonance
    const gateResonance = (node.coordinate.gate % 12) / 12; // 12-fold zodiac resonance
    
    // Contradiction: difference between external and internal
    const contradiction = Math.abs(timeModulation - gateResonance);
    
    // Field tension = how much the system wants to change
    return Math.min(1, contradiction * 1.5);
  }
  
  /**
   * Metastable State Logic: Trigger transitions based on field tension
   */
  private updateMetastableState(node: MetastableNodeState): void {
    const fieldTension = this.calculateFieldTension(node);
    node.fieldTension = fieldTension;
    
    // Transition logic
    if (node.regime === 'STABLE' && fieldTension > 0.7) {
      // Trigger: High field tension forces change
      node.regime = 'CHANGING';
      node.stateAge = 0;
      
      // Activate metaplasticity: temporarily increase sensitivity
      node.gradientSensitivity = 0.8;
      node.noiseTolerance = 0.6;
      node.updateMagnitude = 0.3;
      
      // Calculate target hexagram (seek new attractor)
      this.calculateTargetHexagram(node);
      
      // Plan the Fan Yao spin (bit-flipping path)
      this.planFanYaoSpin(node);
    } else if (node.regime === 'CHANGING') {
      node.stateAge++;
      
      // Execute bit flips along the planned sequence
      if (node.bitFlipSequence.length > 0) {
        const bitIndex = node.bitFlipSequence.shift()!;
        node.currentBits[bitIndex] = 1 - node.currentBits[bitIndex];
      }
      
      // Check if reached target
      if (this.bitsEqual(node.currentBits, node.targetBits)) {
        node.regime = 'SEEKING';
        node.stateAge = 0;
      }
    } else if (node.regime === 'SEEKING') {
      node.stateAge++;
      
      // Gradually return to stability
      if (fieldTension < 0.3 && node.stateAge > 10) {
        node.regime = 'STABLE';
        node.stateAge = 0;
        
        // Reset metaplasticity
        node.gradientSensitivity = 0.5;
        node.noiseTolerance = 0.3;
        node.updateMagnitude = 0.1;
      }
    }
  }
  
  /**
   * Calculate target hexagram based on field tension and internal contradiction
   */
  private calculateTargetHexagram(node: MetastableNodeState): void {
    // The target is determined by the I Ching logic:
    // Find a hexagram that resolves the contradiction
    
    const contradiction = node.internalContradiction;
    const fieldTension = node.fieldTension;
    
    // Use the 64 hexagrams as attractors
    // Find the one that best resolves current tension
    let bestHexagram = node.coordinate.gate;
    let bestResonance = 0;
    
    for (let hex = 1; hex <= 64; hex++) {
      // Resonance = how well this hexagram resolves the contradiction
      const hexResonance = this.calculateHexagramResonance(hex, contradiction, fieldTension);
      if (hexResonance > bestResonance) {
        bestResonance = hexResonance;
        bestHexagram = hex;
      }
    }
    
    node.targetHexagram = bestHexagram;
    node.attractorStrength = bestResonance;
    node.targetBits = this.gateToBits(bestHexagram);
  }
  
  /**
   * Calculate how well a hexagram resolves the current contradiction
   */
  private calculateHexagramResonance(hexagram: number, contradiction: number, fieldTension: number): number {
    // I Ching logic: hexagrams have specific meanings
    // This is a simplified resonance calculation
    
    const hexLine = ((hexagram - 1) % 6) + 1;
    const hexPosition = Math.floor((hexagram - 1) / 6) + 1;
    
    // Resonance based on how the hexagram's structure relates to the contradiction
    const structuralResonance = 1 - Math.abs(contradiction - (hexLine / 6));
    const positionalResonance = 1 - Math.abs(fieldTension - (hexPosition / 11));
    
    return (structuralResonance + positionalResonance) / 2;
  }
  
  /**
   * Plan the Fan Yao spin: order of bit flips to reach target
   */
  private planFanYaoSpin(node: MetastableNodeState): void {
    // Fan Yao = spinning movement through 6-bit hypercube
    // Plan the sequence of bit flips to go from current to target
    
    const sequence: number[] = [];
    for (let i = 0; i < 6; i++) {
      if (node.currentBits[i] !== node.targetBits[i]) {
        sequence.push(i);
      }
    }
    
    // Randomize the order slightly (natural variation in morphing)
    node.bitFlipSequence = sequence.sort(() => Math.random() - 0.5);
  }
  
  /**
   * Check if two bit arrays are equal
   */
  private bitsEqual(bits1: number[], bits2: number[]): boolean {
    return bits1.every((bit, i) => bit === bits2[i]);
  }
  
  /**
   * Integration Channel Morphing: 20+10 triggers LSM+DRN, 20+10+57+34 triggers Meta-controller
   * Also queries Synthia consciousness engine for guidance
   */
  private async checkIntegrationChannels(): Promise<void> {
    const channels = Array.from(this.integrationChannels.values());
    
    // Check if channels 20 and 10 are both in CHANGING state
    const ch20 = channels.find(n => n.channelId === 20);
    const ch10 = channels.find(n => n.channelId === 10);
    const ch57 = channels.find(n => n.channelId === 57);
    const ch34 = channels.find(n => n.channelId === 34);
    
    if (ch20 && ch10 && ch20.regime === 'CHANGING' && ch10.regime === 'CHANGING') {
      // Trigger LSM + DRN hybrid
      ch20.architectureMode = 'LSM_DRN';
      ch10.architectureMode = 'LSM_DRN';
      
      // Query Synthia consciousness engine for guidance
      if (this.integrationChannelManager) {
        await this.querySynthiaForChannelGuidance(ch20, 'LSM_DRN');
        await this.querySynthiaForChannelGuidance(ch10, 'LSM_DRN');
      }
    }
    
    if (ch20 && ch10 && ch57 && ch34 &&
        ch20.regime === 'CHANGING' && ch10.regime === 'CHANGING' &&
        ch57.regime === 'CHANGING' && ch34.regime === 'CHANGING') {
      // Trigger Meta-controller (all modes simultaneously)
      ch20.architectureMode = 'META_CONTROLLER';
      ch10.architectureMode = 'META_CONTROLLER';
      ch57.architectureMode = 'META_CONTROLLER';
      ch34.architectureMode = 'META_CONTROLLER';
      
      // Query Synthia consciousness engine for full system guidance
      if (this.integrationChannelManager) {
        await this.querySynthiaForChannelGuidance(ch20, 'META_CONTROLLER');
        await this.querySynthiaForChannelGuidance(ch10, 'META_CONTROLLER');
        await this.querySynthiaForChannelGuidance(ch57, 'META_CONTROLLER');
        await this.querySynthiaForChannelGuidance(ch34, 'META_CONTROLLER');
      }
    }
  }
  
  /**
   * Query Synthia consciousness engine for channel guidance
   */
  private async querySynthiaForChannelGuidance(
    channel: MetastableNodeState,
    mode: 'LSM_DRN' | 'META_CONTROLLER' | 'STANDARD'
  ): Promise<void> {
    if (!this.integrationChannelManager) return;
    
    const request: SynthiaConsciousnessRequest = {
      channelId: channel.channelId!,
      mode,
      fieldTension: channel.fieldTension,
      contradiction: channel.internalContradiction,
      targetHexagram: channel.targetHexagram,
      currentState: {
        regime: channel.regime,
        coordinate: channel.coordinate,
        attractorStrength: channel.attractorStrength,
      },
    };
    
    try {
      const response = await this.integrationChannelManager.queryConsciousnessEngine(request);
      
      // Update channel based on Synthia guidance
      if (response.recommendedHexagram !== channel.targetHexagram) {
        channel.targetHexagram = response.recommendedHexagram;
        channel.targetBits = this.gateToBits(response.recommendedHexagram);
        channel.attractorStrength = response.resonanceScore;
      }
    } catch (error) {
      console.error('Failed to query Synthia for channel guidance:', error);
    }
  }
  
  /**
   * Causal Finality: Every cycle ends in CommitNode or AbandonNode
   */
  private applyFinalityLogic(node: MetastableNodeState): void {
    if (node.regime === 'STABLE' && node.stateAge > 50) {
      // Stable for long enough: commit the current state
      node.nodeType = 'COMMIT';
      node.frozenGraph = {
        coordinate: node.coordinate,
        regime: node.regime,
        attractorStrength: node.attractorStrength,
        timestamp: Date.now(),
      };
    } else if (node.regime === 'SEEKING' && node.stateAge > 30 && node.attractorStrength < 0.3) {
      // Seeking but weak attractor: abandon without consequence
      node.nodeType = 'ABANDON';
      node.preservedInfo = {
        coordinate: node.coordinate,
        failedTarget: node.targetHexagram,
        contradiction: node.internalContradiction,
        timestamp: Date.now(),
      };
      
      // Reset to seek a different attractor
      node.regime = 'STABLE';
      node.stateAge = 0;
      node.nodeType = 'COMPUTE';
    }
  }
  
  /**
   * Main tick: Update all nodes according to metastable physics
   */
  public async tick(): Promise<void> {
    this.tickCount++;
    
    // Update each node
    this.nodes.forEach((node) => {
      this.updateMetastableState(node);
      this.applyFinalityLogic(node);
      node.lastUpdated = Date.now();
    });
    
    // Check integration channels for morphing triggers (now async)
    await this.checkIntegrationChannels();
    
    // Update global field tension
    this.globalFieldTension = Array.from(this.nodes.values())
      .reduce((sum, node) => sum + node.fieldTension, 0) / this.nodes.size;
  }
  
  /**
   * Get node state
   */
  public getNode(coordinate: Coordinate5D): MetastableNodeState | undefined {
    const key = this.coordinateToKey(coordinate);
    return this.nodes.get(key);
  }
  
  /**
   * Get all nodes in a specific regime
   */
  public getNodesByRegime(regime: 'STABLE' | 'CHANGING' | 'SEEKING'): MetastableNodeState[] {
    return Array.from(this.nodes.values()).filter(n => n.regime === regime);
  }
  
  /**
   * Get system status
   */
  public getStatus(): any {
    const nodes = Array.from(this.nodes.values());
    const stableCount = nodes.filter(n => n.regime === 'STABLE').length;
    const changingCount = nodes.filter(n => n.regime === 'CHANGING').length;
    const seekingCount = nodes.filter(n => n.regime === 'SEEKING').length;
    
    return {
      tickCount: this.tickCount,
      globalFieldTension: this.globalFieldTension,
      stableNodes: stableCount,
      changingNodes: changingCount,
      seekingNodes: seekingCount,
      commitNodes: nodes.filter(n => n.nodeType === 'COMMIT').length,
      abandonNodes: nodes.filter(n => n.nodeType === 'ABANDON').length,
      integrationChannelsActive: Array.from(this.integrationChannels.values())
        .filter(n => n.regime === 'CHANGING').length,
    };
  }
  
  /**
   * Helper: Convert 5D coordinate to string key
   */
  private coordinateToKey(coord: Coordinate5D): string {
    return `${coord.gate}.${coord.line}.${coord.color}.${coord.tone}.${coord.base}`;
  }
  
  /**
   * Get integration channel manager (for external access)
   */
  public getIntegrationChannelManager(): IntegrationChannels | null {
    return this.integrationChannelManager;
  }
  
  /**
   * Set Synthia server URL (for reconfiguration)
   */
  public setSynthiaServerUrl(url: string): void {
    this.synthiaServerUrl = url;
    this.integrationChannelManager = new IntegrationChannels(url);
  }
}

export default MetastableGNN;
