  /**
   * TIER 2: Initialize Synthia client
   */
  private initializeSynthiaClient(): void {
    // Create client for Synthia server
    this.synthiaClient = {
      baseUrl: this.config.synthiaServerUrl,
      reason: async (input: string) => {
        return await this.callSynthia('/consciousness/reason', { input });
      },
      analyze: async (code: string) => {
        return await this.callSynthia('/consciousness/analyze', { code });
      },
      decide: async (options: any[]) => {
        return await this.callSynthia('/consciousness/decide', { options });
      },
    };
  }

  /**
   * TIER 2: Call Synthia for intelligent reasoning
   */
  async analyzeDeep(input: string, context?: any): Promise<AnalysisResult> {
    // Check cache
    const cached = this.cache.get(`deep:${input}`);
    if (cached) return cached;

    try {
      if (!this.synthiaClient) {
        return this.analyzeFast(input);
      }

      const reasoning = await this.synthiaClient.reason(input);
      
      const result: AnalysisResult = {
        tier: 2,
        reasoning: reasoning.explanation || input,
        confidence: reasoning.confidence || 0.8,
        decision: reasoning.decision || this.makeQuickDecision(input),
        metadata: {
          source: 'synthia_server',
          context,
          fullResponse: reasoning,
        },
      };

      this.cache.set(`deep:${input}`, result);
      return result;
    } catch (error) {
      console.error('Synthia analysis failed, falling back to fast:', error);
      return this.analyzeFast(input);
    }
  }

  /**
   * TIER 3: Initialize Gnn client
   */
  private initializeGnnClient(): void {
    this.gnnClient = {
      baseUrl: this.config.gnnServerUrl,
      findRelationships: async (entity: string) => {
        return await this.callGnn('/relationships/find', { entity });
      },
      mapNetwork: async (entities: string[]) => {
        return await this.callGnn('/relationships/map', { entities });
      },
      findResonance: async (address: any) => {
        return await this.callGnn('/resonance/find', { address });
      },
    };
  }

  /**
   * TIER 3: Analyze relationships and resonance
   */
  async analyzeResonance(address: any, entities: string[]): Promise<AnalysisResult> {
    const cacheKey = `resonance:${JSON.stringify(address)}`;
    const cached = this.cache.get(cacheKey);
    if (cached) return cached;

    try {
      if (!this.gnnClient) {
        return this.analyzeFast(JSON.stringify(address));
      }

      const relationships = await this.gnnClient.findResonance(address);
      const network = await this.gnnClient.mapNetwork(entities);

      const result: AnalysisResult = {
        tier: 3,
        reasoning: `Resonance analysis for address: ${JSON.stringify(address)}`,
        confidence: relationships.resonanceStrength || 0.85,
        decision: this.findBestMatch(relationships, entities),
        metadata: {
          source: 'gnn_relationships',
          relationships,
          network,
          resonanceStrength: relationships.resonanceStrength,
        },
      };

      this.cache.set(cacheKey, result);
      return result;
    } catch (error) {
      console.error('Gnn analysis failed:', error);
      return this.analyzeFast(JSON.stringify(address));
    }
  }

  /**
   * Full intelligence pipeline: Fast → Deep → Resonance
   */
  async intelligentAnalysis(input: string, context?: any): Promise<AnalysisResult> {
    // Start with fast analysis
    const fast = await this.analyzeFast(input);

    // If confidence is high enough, return fast result
    if (fast.confidence > 0.85) {
      return fast;
    }

    // Otherwise, go deeper with Synthia
    const deep = await this.analyzeDeep(input, context);

    // If context includes address, add resonance analysis
    if (context?.address) {
      const resonance = await this.analyzeResonance(context.address, context.entities || []);
      return {
        ...resonance,
        reasoning: `${deep.reasoning} → ${resonance.reasoning}`,
        confidence: Math.max(deep.confidence, resonance.confidence),
      };
    }

    return deep;
  }

  /**
   * Make quick decision (Tier 1)
   */
  private makeQuickDecision(input: string): string {
    const lower = input.toLowerCase();

    if (lower.includes('upload')) return 'MORPH_UPLOADER';
    if (lower.includes('video')) return 'MORPH_PLAYER';
    if (lower.includes('game')) return 'MORPH_GAME';
    if (lower.includes('learn')) return 'MORPH_LEARNING';
    if (lower.includes('orchestrate')) return 'EXECUTE_ORCHESTRATION';
    if (lower.includes('analyze')) return 'DEEP_ANALYSIS';
    if (lower.includes('decide')) return 'REQUEST_REASONING';