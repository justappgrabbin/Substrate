/**
 * I CHING HEXAGRAM DATABASE
 * 
 * All 64 hexagrams with their specific field tension multipliers,
 * resonance profiles, and behavioral characteristics.
 * 
 * Each hexagram has:
 * - Name and traditional meaning
 * - Field tension multiplier (how strongly it responds to external pressure)
 * - Resonance profile (how it resolves different types of contradictions)
 * - Attractor strength (how stable it is as a target state)
 * - Zodiac correspondence (astrological resonance)
 * - Human Design gates it relates to
 */

export interface HexagramProfile {
  number: number;           // 1-64
  name: string;             // Traditional I Ching name
  meaning: string;          // Core meaning
  fieldTensionMultiplier: number;  // How responsive to field tension (0.5-2.0)
  resonanceProfile: {
    contradiction: number;  // How well it resolves internal contradiction (0-1)
    transformation: number; // How well it enables transformation (0-1)
    stability: number;      // How stable as an attractor (0-1)
    expansion: number;      // How much it expands possibility space (0-1)
  };
  attractorStrength: number; // Base strength (0-1)
  zodiacSign: string;       // Astrological correspondence
  humanDesignGates: number[]; // Related HD gates
  relatedHexagrams: number[]; // Hexagrams it naturally transitions to
  description: string;      // Detailed description
}

export class HexagramDatabase {
  private hexagrams: Map<number, HexagramProfile> = new Map();

  constructor() {
    this.initializeHexagrams();
  }

  /**
   * Initialize all 64 hexagrams with their profiles
   */
  private initializeHexagrams(): void {
    // Hexagram 1: The Creative (Heaven)
    this.addHexagram({
      number: 1,
      name: 'The Creative',
      meaning: 'Pure creative force, initiation, pure yang',
      fieldTensionMultiplier: 1.8,
      resonanceProfile: {
        contradiction: 0.9,
        transformation: 0.95,
        stability: 0.6,
        expansion: 1.0,
      },
      attractorStrength: 0.95,
      zodiacSign: 'Aries',
      humanDesignGates: [1, 8, 34],
      relatedHexagrams: [2, 11, 29],
      description:
        'The supreme creative force. Pure potential and initiation. When activated, it drives rapid transformation and expansion. High field tension multiplier means it responds strongly to external pressure.',
    });

    // Hexagram 2: The Receptive (Earth)
    this.addHexagram({
      number: 2,
      name: 'The Receptive',
      meaning: 'Pure receptive force, yielding, pure yin',
      fieldTensionMultiplier: 0.8,
      resonanceProfile: {
        contradiction: 0.7,
        transformation: 0.6,
        stability: 0.95,
        expansion: 0.4,
      },
      attractorStrength: 0.9,
      zodiacSign: 'Taurus',
      humanDesignGates: [2, 7, 10],
      relatedHexagrams: [1, 12, 24],
      description:
        'Pure receptive force. Grounding and stabilizing. Low field tension multiplier means it resists change and provides stability. Excellent for consolidating gains.',
    });

    // Hexagram 3: Difficulty at the Beginning
    this.addHexagram({
      number: 3,
      name: 'Difficulty at the Beginning',
      meaning: 'Chaos, birth, new beginnings with obstacles',
      fieldTensionMultiplier: 1.5,
      resonanceProfile: {
        contradiction: 0.8,
        transformation: 0.85,
        stability: 0.4,
        expansion: 0.8,
      },
      attractorStrength: 0.7,
      zodiacSign: 'Gemini',
      humanDesignGates: [3, 42, 60],
      relatedHexagrams: [4, 8, 29],
      description:
        'The chaos of creation. High field tension but unstable. Represents the turbulent beginning of any process. Resolves contradictions through breaking through obstacles.',
    });

    // Hexagram 4: Youthful Folly
    this.addHexagram({
      number: 4,
      name: 'Youthful Folly',
      meaning: 'Inexperience, learning, seeking guidance',
      fieldTensionMultiplier: 1.2,
      resonanceProfile: {
        contradiction: 0.6,
        transformation: 0.7,
        stability: 0.5,
        expansion: 0.7,
      },
      attractorStrength: 0.65,
      zodiacSign: 'Cancer',
      humanDesignGates: [4, 63, 64],
      relatedHexagrams: [3, 5, 8],
      description:
        'Learning and growth through experience. Moderate field tension. Represents the phase where the system is still finding its way. Resolves contradictions through education and experience.',
    });

    // Hexagram 5: Waiting (Nourishment)
    this.addHexagram({
      number: 5,
      name: 'Waiting',
      meaning: 'Patience, timing, nourishment',
      fieldTensionMultiplier: 0.9,
      resonanceProfile: {
        contradiction: 0.7,
        transformation: 0.65,
        stability: 0.8,
        expansion: 0.5,
      },
      attractorStrength: 0.8,
      zodiacSign: 'Leo',
      humanDesignGates: [5, 15, 52],
      relatedHexagrams: [4, 6, 7],
      description:
        'Patience and proper timing. Low-moderate field tension. The system waits for the right moment. Resolves contradictions through timing and nourishment.',
    });

    // Hexagram 6: Conflict
    this.addHexagram({
      number: 6,
      name: 'Conflict',
      meaning: 'Opposition, struggle, resolution through dialogue',
      fieldTensionMultiplier: 1.4,
      resonanceProfile: {
        contradiction: 0.85,
        transformation: 0.75,
        stability: 0.3,
        expansion: 0.6,
      },
      attractorStrength: 0.6,
      zodiacSign: 'Virgo',
      humanDesignGates: [6, 37, 40],
      relatedHexagrams: [5, 7, 13],
      description:
        'Direct conflict and opposition. High field tension. Represents the clash of forces. Resolves contradictions through dialogue and negotiation.',
    });

    // Hexagram 7: The Army
    this.addHexagram({
      number: 7,
      name: 'The Army',
      meaning: 'Organization, discipline, collective action',
      fieldTensionMultiplier: 1.3,
      resonanceProfile: {
        contradiction: 0.75,
        transformation: 0.7,
        stability: 0.7,
        expansion: 0.6,
      },
      attractorStrength: 0.75,
      zodiacSign: 'Libra',
      humanDesignGates: [7, 13, 33],
      relatedHexagrams: [6, 8, 15],
      description:
        'Organized collective force. Moderate-high field tension. Represents coordinated action and discipline. Resolves contradictions through organization and strategy.',
    });

    // Hexagram 8: Holding Together (Union)
    this.addHexagram({
      number: 8,
      name: 'Holding Together',
      meaning: 'Union, cooperation, mutual support',
      fieldTensionMultiplier: 1.0,
      resonanceProfile: {
        contradiction: 0.8,
        transformation: 0.7,
        stability: 0.85,
        expansion: 0.65,
      },
      attractorStrength: 0.85,
      zodiacSign: 'Scorpio',
      humanDesignGates: [8, 14, 19],
      relatedHexagrams: [7, 9, 16],
      description:
        'Cooperative union and mutual support. Balanced field tension. Represents the bonding of forces. Resolves contradictions through cooperation and alignment.',
    });

    // Hexagram 9: The Taming Power of the Small
    this.addHexagram({
      number: 9,
      name: 'The Taming Power of the Small',
      meaning: 'Restraint, gentle control, small steps',
      fieldTensionMultiplier: 0.85,
      resonanceProfile: {
        contradiction: 0.65,
        transformation: 0.6,
        stability: 0.8,
        expansion: 0.4,
      },
      attractorStrength: 0.75,
      zodiacSign: 'Sagittarius',
      humanDesignGates: [9, 52, 62],
      relatedHexagrams: [8, 10, 14],
      description:
        'Gentle restraint and small adjustments. Low field tension. Represents the power of subtle control. Resolves contradictions through gentle influence.',
    });

    // Hexagram 10: Treading (Conduct)
    this.addHexagram({
      number: 10,
      name: 'Treading',
      meaning: 'Conduct, right action, proper behavior',
      fieldTensionMultiplier: 1.1,
      resonanceProfile: {
        contradiction: 0.75,
        transformation: 0.7,
        stability: 0.75,
        expansion: 0.6,
      },
      attractorStrength: 0.8,
      zodiacSign: 'Capricorn',
      humanDesignGates: [10, 57, 34],
      relatedHexagrams: [9, 11, 20],
      description:
        'Right action and proper conduct. Moderate field tension. Integration channel gate. Represents correct behavior and alignment with natural order.',
    });

    // Hexagram 11: Peace
    this.addHexagram({
      number: 11,
      name: 'Peace',
      meaning: 'Harmony, peace, proper order',
      fieldTensionMultiplier: 0.9,
      resonanceProfile: {
        contradiction: 0.7,
        transformation: 0.65,
        stability: 0.9,
        expansion: 0.55,
      },
      attractorStrength: 0.88,
      zodiacSign: 'Aquarius',
      humanDesignGates: [11, 56, 31],
      relatedHexagrams: [10, 12, 24],
      description:
        'Harmony and peace. Low-moderate field tension. Represents the state of proper order and balance. Resolves contradictions through harmony.',
    });

    // Hexagram 12: Standstill (Stagnation)
    this.addHexagram({
      number: 12,
      name: 'Standstill',
      meaning: 'Stagnation, blockage, necessary pause',
      fieldTensionMultiplier: 1.2,
      resonanceProfile: {
        contradiction: 0.6,
        transformation: 0.5,
        stability: 0.6,
        expansion: 0.3,
      },
      attractorStrength: 0.5,
      zodiacSign: 'Pisces',
      humanDesignGates: [12, 22, 36],
      relatedHexagrams: [11, 13, 23],
      description:
        'Stagnation and blockage. Moderate field tension. Represents the necessary pause before transformation. Resolves contradictions through acceptance of limitation.',
    });

    // Hexagram 13: Fellowship with Men
    this.addHexagram({
      number: 13,
      name: 'Fellowship with Men',
      meaning: 'Community, fellowship, shared purpose',
      fieldTensionMultiplier: 1.15,
      resonanceProfile: {
        contradiction: 0.8,
        transformation: 0.75,
        stability: 0.75,
        expansion: 0.8,
      },
      attractorStrength: 0.82,
      zodiacSign: 'Aries',
      humanDesignGates: [13, 49, 30],
      relatedHexagrams: [12, 14, 29],
      description:
        'Community and shared fellowship. Moderate-high field tension. Represents collective purpose and connection. Resolves contradictions through community alignment.',
    });

    // Hexagram 14: Possession in Great Measure
    this.addHexagram({
      number: 14,
      name: 'Possession in Great Measure',
      meaning: 'Abundance, wealth, great possession',
      fieldTensionMultiplier: 1.3,
      resonanceProfile: {
        contradiction: 0.85,
        transformation: 0.8,
        stability: 0.7,
        expansion: 0.9,
      },
      attractorStrength: 0.85,
      zodiacSign: 'Taurus',
      humanDesignGates: [14, 50, 32],
      relatedHexagrams: [13, 15, 34],
      description:
        'Abundance and great possession. High field tension. Represents the state of plenty. Resolves contradictions through abundance and generosity.',
    });

    // Hexagram 15: Modesty (Humility)
    this.addHexagram({
      number: 15,
      name: 'Modesty',
      meaning: 'Humility, moderation, proper measure',
      fieldTensionMultiplier: 0.85,
      resonanceProfile: {
        contradiction: 0.7,
        transformation: 0.65,
        stability: 0.85,
        expansion: 0.5,
      },
      attractorStrength: 0.8,
      zodiacSign: 'Gemini',
      humanDesignGates: [15, 10, 5],
      relatedHexagrams: [14, 16, 22],
      description:
        'Humility and moderation. Low field tension. Represents the virtue of proper measure. Resolves contradictions through humility and restraint.',
    });

    // Hexagram 16: Enthusiasm
    this.addHexagram({
      number: 16,
      name: 'Enthusiasm',
      meaning: 'Enthusiasm, inspiration, joy',
      fieldTensionMultiplier: 1.4,
      resonanceProfile: {
        contradiction: 0.8,
        transformation: 0.85,
        stability: 0.6,
        expansion: 0.9,
      },
      attractorStrength: 0.8,
      zodiacSign: 'Cancer',
      humanDesignGates: [16, 48, 35],
      relatedHexagrams: [15, 17, 55],
      description:
        'Enthusiasm and inspiration. High field tension. Represents the state of joy and inspiration. Resolves contradictions through enthusiasm and alignment.',
    });

    // Hexagram 17: Following
    this.addHexagram({
      number: 17,
      name: 'Following',
      meaning: 'Following, obedience, natural sequence',
      fieldTensionMultiplier: 1.0,
      resonanceProfile: {
        contradiction: 0.75,
        transformation: 0.7,
        stability: 0.75,
        expansion: 0.65,
      },
      attractorStrength: 0.78,
      zodiacSign: 'Leo',
      humanDesignGates: [17, 18, 2],
      relatedHexagrams: [16, 18, 21],
      description:
        'Following the natural sequence. Balanced field tension. Represents alignment with natural order. Resolves contradictions through following the way.',
    });

    // Hexagram 18: Work on What Has Been Spoiled (Decay)
    this.addHexagram({
      number: 18,
      name: 'Work on What Has Been Spoiled',
      meaning: 'Decay, restoration, fixing what is broken',
      fieldTensionMultiplier: 1.25,
      resonanceProfile: {
        contradiction: 0.8,
        transformation: 0.75,
        stability: 0.65,
        expansion: 0.6,
      },
      attractorStrength: 0.7,
      zodiacSign: 'Virgo',
      humanDesignGates: [18, 17, 54],
      relatedHexagrams: [17, 19, 23],
      description:
        'Restoration and fixing decay. Moderate-high field tension. Represents the work of restoration. Resolves contradictions through healing and repair.',
    });

    // Hexagram 19: Approach (Nearing)
    this.addHexagram({
      number: 19,
      name: 'Approach',
      meaning: 'Approach, nearing, coming close',
      fieldTensionMultiplier: 1.15,
      resonanceProfile: {
        contradiction: 0.75,
        transformation: 0.7,
        stability: 0.7,
        expansion: 0.75,
      },
      attractorStrength: 0.78,
      zodiacSign: 'Libra',
      humanDesignGates: [19, 33, 49],
      relatedHexagrams: [18, 20, 24],
      description:
        'Approach and nearing. Moderate field tension. Represents the drawing near of something. Resolves contradictions through proximity and approach.',
    });

    // Hexagram 20: Contemplation (Viewing)
    this.addHexagram({
      number: 20,
      name: 'Contemplation',
      meaning: 'Contemplation, viewing, observation',
      fieldTensionMultiplier: 0.9,
      resonanceProfile: {
        contradiction: 0.7,
        transformation: 0.65,
        stability: 0.8,
        expansion: 0.55,
      },
      attractorStrength: 0.8,
      zodiacSign: 'Scorpio',
      humanDesignGates: [20, 34, 57],
      relatedHexagrams: [19, 21, 29],
      description:
        'Contemplation and observation. Integration channel gate. Low-moderate field tension. Represents the observer state. Resolves contradictions through deep observation.',
    });

    // Hexagram 21: Biting Through
    this.addHexagram({
      number: 21,
      name: 'Biting Through',
      meaning: 'Penetration, clarity, cutting through',
      fieldTensionMultiplier: 1.35,
      resonanceProfile: {
        contradiction: 0.85,
        transformation: 0.8,
        stability: 0.5,
        expansion: 0.7,
      },
      attractorStrength: 0.75,
      zodiacSign: 'Sagittarius',
      humanDesignGates: [21, 48, 16],
      relatedHexagrams: [20, 22, 29],
      description:
        'Penetration and clarity. High field tension. Represents cutting through obstacles. Resolves contradictions through clear perception.',
    });

    // Hexagram 22: Grace (Elegance)
    this.addHexagram({
      number: 22,
      name: 'Grace',
      meaning: 'Grace, elegance, beauty',
      fieldTensionMultiplier: 1.0,
      resonanceProfile: {
        contradiction: 0.7,
        transformation: 0.7,
        stability: 0.75,
        expansion: 0.7,
      },
      attractorStrength: 0.8,
      zodiacSign: 'Capricorn',
      humanDesignGates: [22, 12, 36],
      relatedHexagrams: [21, 23, 27],
      description:
        'Grace and elegance. Balanced field tension. Represents aesthetic harmony. Resolves contradictions through beauty and grace.',
    });

    // Hexagram 23: Splitting Apart (Decay)
    this.addHexagram({
      number: 23,
      name: 'Splitting Apart',
      meaning: 'Decay, dissolution, necessary ending',
      fieldTensionMultiplier: 1.2,
      resonanceProfile: {
        contradiction: 0.65,
        transformation: 0.6,
        stability: 0.4,
        expansion: 0.3,
      },
      attractorStrength: 0.5,
      zodiacSign: 'Aquarius',
      humanDesignGates: [23, 8, 20],
      relatedHexagrams: [22, 24, 27],
      description:
        'Decay and dissolution. Moderate field tension. Represents necessary endings. Resolves contradictions through acceptance of dissolution.',
    });

    // Hexagram 24: Return (The Turning Point)
    this.addHexagram({
      number: 24,
      name: 'Return',
      meaning: 'Return, renewal, the turning point',
      fieldTensionMultiplier: 1.3,
      resonanceProfile: {
        contradiction: 0.8,
        transformation: 0.85,
        stability: 0.65,
        expansion: 0.8,
      },
      attractorStrength: 0.85,
      zodiacSign: 'Pisces',
      humanDesignGates: [24, 2, 27],
      relatedHexagrams: [23, 25, 29],
      description:
        'Return and renewal. High field tension. Represents the turning point and new beginning. Resolves contradictions through renewal.',
    });

    // Hexagram 25: Innocence (The Unexpected)
    this.addHexagram({
      number: 25,
      name: 'Innocence',
      meaning: 'Innocence, spontaneity, the unexpected',
      fieldTensionMultiplier: 1.15,
      resonanceProfile: {
        contradiction: 0.75,
        transformation: 0.75,
        stability: 0.6,
        expansion: 0.8,
      },
      attractorStrength: 0.75,
      zodiacSign: 'Aries',
      humanDesignGates: [25, 51, 3],
      relatedHexagrams: [24, 26, 27],
      description:
        'Innocence and spontaneity. Moderate-high field tension. Represents natural action without calculation. Resolves contradictions through spontaneity.',
    });

    // Hexagram 26: The Taming Power of the Great
    this.addHexagram({
      number: 26,
      name: 'The Taming Power of the Great',
      meaning: 'Great restraint, accumulation, great power',
      fieldTensionMultiplier: 1.2,
      resonanceProfile: {
        contradiction: 0.8,
        transformation: 0.75,
        stability: 0.8,
        expansion: 0.65,
      },
      attractorStrength: 0.85,
      zodiacSign: 'Taurus',
      humanDesignGates: [26, 44, 9],
      relatedHexagrams: [25, 27, 28],
      description:
        'Great restraint and accumulation. Moderate-high field tension. Represents the gathering of great power. Resolves contradictions through accumulation.',
    });

    // Hexagram 27: Nourishment (Mouth)
    this.addHexagram({
      number: 27,
      name: 'Nourishment',
      meaning: 'Nourishment, sustenance, proper feeding',
      fieldTensionMultiplier: 0.95,
      resonanceProfile: {
        contradiction: 0.7,
        transformation: 0.65,
        stability: 0.8,
        expansion: 0.55,
      },
      attractorStrength: 0.8,
      zodiacSign: 'Gemini',
      humanDesignGates: [27, 50, 28],
      relatedHexagrams: [26, 28, 31],
      description:
        'Nourishment and sustenance. Low-moderate field tension. Represents proper feeding and care. Resolves contradictions through nourishment.',
    });

    // Hexagram 28: Preponderance of the Great
    this.addHexagram({
      number: 28,
      name: 'Preponderance of the Great',
      meaning: 'Great excess, critical moment, extreme conditions',
      fieldTensionMultiplier: 1.4,
      resonanceProfile: {
        contradiction: 0.85,
        transformation: 0.8,
        stability: 0.4,
        expansion: 0.7,
      },
      attractorStrength: 0.65,
      zodiacSign: 'Cancer',
      humanDesignGates: [28, 32, 34],
      relatedHexagrams: [27, 29, 30],
      description:
        'Great excess and critical moments. High field tension. Represents extreme conditions. Resolves contradictions through managing extremes.',
    });

    // Hexagram 29: The Abysmal (Water)
    this.addHexagram({
      number: 29,
      name: 'The Abysmal',
      meaning: 'Danger, abyss, flowing through difficulty',
      fieldTensionMultiplier: 1.25,
      resonanceProfile: {
        contradiction: 0.8,
        transformation: 0.75,
        stability: 0.5,
        expansion: 0.6,
      },
      attractorStrength: 0.65,
      zodiacSign: 'Leo',
      humanDesignGates: [29, 4, 59],
      relatedHexagrams: [28, 30, 47],
      description:
        'Danger and flowing through difficulty. Moderate-high field tension. Represents navigating through danger. Resolves contradictions through flowing.',
    });

    // Hexagram 30: The Clinging (Fire)
    this.addHexagram({
      number: 30,
      name: 'The Clinging',
      meaning: 'Clarity, fire, illumination',
      fieldTensionMultiplier: 1.3,
      resonanceProfile: {
        contradiction: 0.85,
        transformation: 0.8,
        stability: 0.7,
        expansion: 0.8,
      },
      attractorStrength: 0.85,
      zodiacSign: 'Virgo',
      humanDesignGates: [30, 55, 37],
      relatedHexagrams: [29, 31, 49],
      description:
        'Clarity and illumination. High field tension. Represents the light of understanding. Resolves contradictions through clarity.',
    });

    // Hexagram 31: Influence (Wooing)
    this.addHexagram({
      number: 31,
      name: 'Influence',
      meaning: 'Influence, mutual attraction, wooing',
      fieldTensionMultiplier: 1.1,
      resonanceProfile: {
        contradiction: 0.75,
        transformation: 0.7,
        stability: 0.7,
        expansion: 0.75,
      },
      attractorStrength: 0.8,
      zodiacSign: 'Libra',
      humanDesignGates: [31, 41, 19],
      relatedHexagrams: [30, 32, 42],
      description:
        'Influence and mutual attraction. Moderate field tension. Represents the power of influence. Resolves contradictions through attraction.',
    });

    // Hexagram 32: Duration (Constancy)
    this.addHexagram({
      number: 32,
      name: 'Duration',
      meaning: 'Duration, constancy, persistence',
      fieldTensionMultiplier: 0.95,
      resonanceProfile: {
        contradiction: 0.7,
        transformation: 0.65,
        stability: 0.85,
        expansion: 0.55,
      },
      attractorStrength: 0.85,
      zodiacSign: 'Scorpio',
      humanDesignGates: [32, 54, 28],
      relatedHexagrams: [31, 33, 44],
      description:
        'Duration and constancy. Low-moderate field tension. Represents lasting stability. Resolves contradictions through persistence.',
    });

    // Hexagram 33: Retreat
    this.addHexagram({
      number: 33,
      name: 'Retreat',
      meaning: 'Retreat, withdrawal, strategic withdrawal',
      fieldTensionMultiplier: 1.05,
      resonanceProfile: {
        contradiction: 0.7,
        transformation: 0.65,
        stability: 0.75,
        expansion: 0.4,
      },
      attractorStrength: 0.7,
      zodiacSign: 'Sagittarius',
      humanDesignGates: [33, 7, 13],
      relatedHexagrams: [32, 34, 43],
      description:
        'Strategic retreat and withdrawal. Moderate field tension. Represents tactical withdrawal. Resolves contradictions through strategic retreat.',
    });

    // Hexagram 34: The Power of the Great
    this.addHexagram({
      number: 34,
      name: 'The Power of the Great',
      meaning: 'Great power, mighty force, expression',
      fieldTensionMultiplier: 1.4,
      resonanceProfile: {
        contradiction: 0.85,
        transformation: 0.85,
        stability: 0.7,
        expansion: 0.9,
      },
      attractorStrength: 0.88,
      zodiacSign: 'Capricorn',
      humanDesignGates: [34, 20, 10],
      relatedHexagrams: [33, 35, 43],
      description:
        'Great power and mighty force. Integration channel gate. High field tension. Represents the expression of great power. Resolves contradictions through powerful action.',
    });

    // Hexagrams 35-64: Abbreviated entries for space
    // (In production, each would have full detail like above)

    // Hexagram 35: Progress
    this.addHexagram({
      number: 35,
      name: 'Progress',
      meaning: 'Progress, advancement, moving forward',
      fieldTensionMultiplier: 1.25,
      resonanceProfile: {
        contradiction: 0.8,
        transformation: 0.8,
        stability: 0.65,
        expansion: 0.85,
      },
      attractorStrength: 0.82,
      zodiacSign: 'Aquarius',
      humanDesignGates: [35, 36, 9],
      relatedHexagrams: [34, 36, 45],
      description: 'Progress and advancement. Represents forward movement.',
    });

    // Hexagram 36: Darkening of the Light
    this.addHexagram({
      number: 36,
      name: 'Darkening of the Light',
      meaning: 'Darkening, obscuration, hidden light',
      fieldTensionMultiplier: 1.15,
      resonanceProfile: {
        contradiction: 0.75,
        transformation: 0.7,
        stability: 0.6,
        expansion: 0.5,
      },
      attractorStrength: 0.65,
      zodiacSign: 'Pisces',
      humanDesignGates: [36, 35, 12],
      relatedHexagrams: [35, 37, 46],
      description: 'Darkening and obscuration. Represents hidden light.',
    });

    // Hexagram 37: The Family (The Clan)
    this.addHexagram({
      number: 37,
      name: 'The Family',
      meaning: 'Family, clan, domestic harmony',
      fieldTensionMultiplier: 1.0,
      resonanceProfile: {
        contradiction: 0.75,
        transformation: 0.7,
        stability: 0.8,
        expansion: 0.65,
      },
      attractorStrength: 0.8,
      zodiacSign: 'Aries',
      humanDesignGates: [37, 40, 6],
      relatedHexagrams: [36, 38, 47],
      description: 'Family and domestic harmony. Represents clan unity.',
    });

    // Hexagram 38: Opposition
    this.addHexagram({
      number: 38,
      name: 'Opposition',
      meaning: 'Opposition, conflict, necessary tension',
      fieldTensionMultiplier: 1.2,
      resonanceProfile: {
        contradiction: 0.8,
        transformation: 0.75,
        stability: 0.5,
        expansion: 0.6,
      },
      attractorStrength: 0.65,
      zodiacSign: 'Taurus',
      humanDesignGates: [38, 39, 22],
      relatedHexagrams: [37, 39, 48],
      description: 'Opposition and necessary tension. Represents conflict.',
    });

    // Hexagram 39: Obstruction
    this.addHexagram({
      number: 39,
      name: 'Obstruction',
      meaning: 'Obstruction, difficulty, blockage',
      fieldTensionMultiplier: 1.15,
      resonanceProfile: {
        contradiction: 0.75,
        transformation: 0.65,
        stability: 0.55,
        expansion: 0.4,
      },
      attractorStrength: 0.6,
      zodiacSign: 'Gemini',
      humanDesignGates: [39, 38, 57],
      relatedHexagrams: [38, 40, 52],
      description: 'Obstruction and blockage. Represents difficulty.',
    });

    // Hexagram 40: Deliverance (Liberation)
    this.addHexagram({
      number: 40,
      name: 'Deliverance',
      meaning: 'Deliverance, liberation, release',
      fieldTensionMultiplier: 1.2,
      resonanceProfile: {
        contradiction: 0.8,
        transformation: 0.8,
        stability: 0.65,
        expansion: 0.75,
      },
      attractorStrength: 0.78,
      zodiacSign: 'Cancer',
      humanDesignGates: [40, 37, 6],
      relatedHexagrams: [39, 41, 49],
      description: 'Deliverance and liberation. Represents release.',
    });

    // Hexagram 41: Decrease
    this.addHexagram({
      number: 41,
      name: 'Decrease',
      meaning: 'Decrease, reduction, sacrifice',
      fieldTensionMultiplier: 0.95,
      resonanceProfile: {
        contradiction: 0.7,
        transformation: 0.65,
        stability: 0.75,
        expansion: 0.45,
      },
      attractorStrength: 0.7,
      zodiacSign: 'Leo',
      humanDesignGates: [41, 31, 19],
      relatedHexagrams: [40, 42, 50],
      description: 'Decrease and reduction. Represents sacrifice.',
    });

    // Hexagram 42: Increase
    this.addHexagram({
      number: 42,
      name: 'Increase',
      meaning: 'Increase, growth, expansion',
      fieldTensionMultiplier: 1.3,
      resonanceProfile: {
        contradiction: 0.85,
        transformation: 0.85,
        stability: 0.65,
        expansion: 0.9,
      },
      attractorStrength: 0.85,
      zodiacSign: 'Virgo',
      humanDesignGates: [42, 3, 60],
      relatedHexagrams: [41, 43, 25],
      description: 'Increase and growth. Represents expansion.',
    });

    // Hexagram 43: Breakthrough (Resoluteness)
    this.addHexagram({
      number: 43,
      name: 'Breakthrough',
      meaning: 'Breakthrough, resoluteness, decisive action',
      fieldTensionMultiplier: 1.35,
      resonanceProfile: {
        contradiction: 0.85,
        transformation: 0.85,
        stability: 0.5,
        expansion: 0.8,
      },
      attractorStrength: 0.75,
      zodiacSign: 'Libra',
      humanDesignGates: [43, 23, 8],
      relatedHexagrams: [42, 44, 33],
      description: 'Breakthrough and resoluteness. Represents breakthrough.',
    });

    // Hexagram 44: Coming to Meet
    this.addHexagram({
      number: 44,
      name: 'Coming to Meet',
      meaning: 'Coming to meet, encounter, meeting',
      fieldTensionMultiplier: 1.1,
      resonanceProfile: {
        contradiction: 0.75,
        transformation: 0.7,
        stability: 0.65,
        expansion: 0.7,
      },
      attractorStrength: 0.75,
      zodiacSign: 'Scorpio',
      humanDesignGates: [44, 26, 9],
      relatedHexagrams: [43, 45, 32],
      description: 'Coming to meet and encounter. Represents meeting.',
    });

    // Hexagram 45: Gathering Together (Assembling)
    this.addHexagram({
      number: 45,
      name: 'Gathering Together',
      meaning: 'Gathering, assembling, coming together',
      fieldTensionMultiplier: 1.15,
      resonanceProfile: {
        contradiction: 0.8,
        transformation: 0.75,
        stability: 0.75,
        expansion: 0.75,
      },
      attractorStrength: 0.8,
      zodiacSign: 'Sagittarius',
      humanDesignGates: [45, 35, 36],
      relatedHexagrams: [44, 46, 28],
      description: 'Gathering and assembling. Represents coming together.',
    });

    // Hexagram 46: Pushing Upward
    this.addHexagram({
      number: 46,
      name: 'Pushing Upward',
      meaning: 'Pushing upward, growth, ascent',
      fieldTensionMultiplier: 1.2,
      resonanceProfile: {
        contradiction: 0.8,
        transformation: 0.8,
        stability: 0.65,
        expansion: 0.8,
      },
      attractorStrength: 0.8,
      zodiacSign: 'Capricorn',
      humanDesignGates: [46, 48, 16],
      relatedHexagrams: [45, 47, 36],
      description: 'Pushing upward and growth. Represents ascent.',
    });

    // Hexagram 47: Oppression (Exhaustion)
    this.addHexagram({
      number: 47,
      name: 'Oppression',
      meaning: 'Oppression, exhaustion, hardship',
      fieldTensionMultiplier: 1.25,
      resonanceProfile: {
        contradiction: 0.8,
        transformation: 0.7,
        stability: 0.45,
        expansion: 0.4,
      },
      attractorStrength: 0.55,
      zodiacSign: 'Aquarius',
      humanDesignGates: [47, 64, 63],
      relatedHexagrams: [46, 48, 29],
      description: 'Oppression and exhaustion. Represents hardship.',
    });

    // Hexagram 48: The Well
    this.addHexagram({
      number: 48,
      name: 'The Well',
      meaning: 'The well, source, nourishment',
      fieldTensionMultiplier: 0.9,
      resonanceProfile: {
        contradiction: 0.7,
        transformation: 0.65,
        stability: 0.85,
        expansion: 0.55,
      },
      attractorStrength: 0.82,
      zodiacSign: 'Pisces',
      humanDesignGates: [48, 21, 16],
      relatedHexagrams: [47, 49, 46],
      description: 'The well and source. Represents nourishment.',
    });

    // Hexagram 49: Revolution (Molting)
    this.addHexagram({
      number: 49,
      name: 'Revolution',
      meaning: 'Revolution, transformation, molting',
      fieldTensionMultiplier: 1.35,
      resonanceProfile: {
        contradiction: 0.85,
        transformation: 0.9,
        stability: 0.4,
        expansion: 0.8,
      },
      attractorStrength: 0.75,
      zodiacSign: 'Aries',
      humanDesignGates: [49, 13, 30],
      relatedHexagrams: [48, 50, 13],
      description: 'Revolution and transformation. Represents molting.',
    });

    // Hexagram 50: The Cauldron
    this.addHexagram({
      number: 50,
      name: 'The Cauldron',
      meaning: 'The cauldron, transformation, nourishment',
      fieldTensionMultiplier: 1.1,
      resonanceProfile: {
        contradiction: 0.75,
        transformation: 0.75,
        stability: 0.75,
        expansion: 0.7,
      },
      attractorStrength: 0.8,
      zodiacSign: 'Taurus',
      humanDesignGates: [50, 27, 28],
      relatedHexagrams: [49, 51, 14],
      description: 'The cauldron and transformation. Represents alchemy.',
    });

    // Hexagram 51: The Arousing (Thunder)
    this.addHexagram({
      number: 51,
      name: 'The Arousing',
      meaning: 'Thunder, arousing, shock',
      fieldTensionMultiplier: 1.4,
      resonanceProfile: {
        contradiction: 0.85,
        transformation: 0.85,
        stability: 0.4,
        expansion: 0.8,
      },
      attractorStrength: 0.7,
      zodiacSign: 'Gemini',
      humanDesignGates: [51, 25, 3],
      relatedHexagrams: [50, 52, 57],
      description: 'Thunder and arousing. Represents shock.',
    });

    // Hexagram 52: Keeping Still (Mountain)
    this.addHexagram({
      number: 52,
      name: 'Keeping Still',
      meaning: 'Mountain, keeping still, stillness',
      fieldTensionMultiplier: 0.85,
      resonanceProfile: {
        contradiction: 0.65,
        transformation: 0.6,
        stability: 0.9,
        expansion: 0.35,
      },
      attractorStrength: 0.85,
      zodiacSign: 'Cancer',
      humanDesignGates: [52, 9, 62],
      relatedHexagrams: [51, 53, 39],
      description: 'Mountain and stillness. Represents immobility.',
    });

    // Hexagram 53: Development (Gradual Progress)
    this.addHexagram({
      number: 53,
      name: 'Development',
      meaning: 'Development, gradual progress, slow growth',
      fieldTensionMultiplier: 1.0,
      resonanceProfile: {
        contradiction: 0.7,
        transformation: 0.7,
        stability: 0.8,
        expansion: 0.65,
      },
      attractorStrength: 0.8,
      zodiacSign: 'Leo',
      humanDesignGates: [53, 54, 61],
      relatedHexagrams: [52, 54, 42],
      description: 'Development and gradual progress. Represents growth.',
    });

    // Hexagram 54: The Marrying Maiden
    this.addHexagram({
      number: 54,
      name: 'The Marrying Maiden',
      meaning: 'Marriage, union, commitment',
      fieldTensionMultiplier: 1.1,
      resonanceProfile: {
        contradiction: 0.75,
        transformation: 0.7,
        stability: 0.75,
        expansion: 0.7,
      },
      attractorStrength: 0.78,
      zodiacSign: 'Virgo',
      humanDesignGates: [54, 53, 32],
      relatedHexagrams: [53, 55, 31],
      description: 'Marriage and union. Represents commitment.',
    });

    // Hexagram 55: Abundance (Fullness)
    this.addHexagram({
      number: 55,
      name: 'Abundance',
      meaning: 'Abundance, fullness, prosperity',
      fieldTensionMultiplier: 1.25,
      resonanceProfile: {
        contradiction: 0.8,
        transformation: 0.8,
        stability: 0.7,
        expansion: 0.85,
      },
      attractorStrength: 0.83,
      zodiacSign: 'Libra',
      humanDesignGates: [55, 30, 37],
      relatedHexagrams: [54, 56, 16],
      description: 'Abundance and fullness. Represents prosperity.',
    });

    // Hexagram 56: The Wanderer
    this.addHexagram({
      number: 56,
      name: 'The Wanderer',
      meaning: 'Wandering, travel, movement',
      fieldTensionMultiplier: 1.15,
      resonanceProfile: {
        contradiction: 0.75,
        transformation: 0.7,
        stability: 0.55,
        expansion: 0.7,
      },
      attractorStrength: 0.7,
      zodiacSign: 'Scorpio',
      humanDesignGates: [56, 11, 31],
      relatedHexagrams: [55, 57, 11],
      description: 'The wanderer and travel. Represents movement.',
    });

    // Hexagram 57: The Gentle (Wind)
    this.addHexagram({
      number: 57,
      name: 'The Gentle',
      meaning: 'Wind, gentle, penetrating',
      fieldTensionMultiplier: 0.95,
      resonanceProfile: {
        contradiction: 0.7,
        transformation: 0.7,
        stability: 0.75,
        expansion: 0.65,
      },
      attractorStrength: 0.78,
      zodiacSign: 'Sagittarius',
      humanDesignGates: [57, 10, 20],
      relatedHexagrams: [56, 58, 39],
      description:
        'Wind and gentle. Integration channel gate. Represents penetration.',
    });

    // Hexagram 58: The Joyous (Lake)
    this.addHexagram({
      number: 58,
      name: 'The Joyous',
      meaning: 'Lake, joy, pleasure',
      fieldTensionMultiplier: 1.15,
      resonanceProfile: {
        contradiction: 0.8,
        transformation: 0.75,
        stability: 0.7,
        expansion: 0.75,
      },
      attractorStrength: 0.8,
      zodiacSign: 'Capricorn',
      humanDesignGates: [58, 38, 39],
      relatedHexagrams: [57, 59, 38],
      description: 'Lake and joy. Represents pleasure.',
    });

    // Hexagram 59: Dispersion (Dissolution)
    this.addHexagram({
      number: 59,
      name: 'Dispersion',
      meaning: 'Dispersion, dissolution, scattering',
      fieldTensionMultiplier: 1.2,
      resonanceProfile: {
        contradiction: 0.75,
        transformation: 0.7,
        stability: 0.5,
        expansion: 0.6,
      },
      attractorStrength: 0.65,
      zodiacSign: 'Aquarius',
      humanDesignGates: [59, 29, 4],
      relatedHexagrams: [58, 60, 29],
      description: 'Dispersion and dissolution. Represents scattering.',
    });

    // Hexagram 60: Limitation
    this.addHexagram({
      number: 60,
      name: 'Limitation',
      meaning: 'Limitation, boundaries, restraint',
      fieldTensionMultiplier: 0.9,
      resonanceProfile: {
        contradiction: 0.7,
        transformation: 0.65,
        stability: 0.85,
        expansion: 0.45,
      },
      attractorStrength: 0.8,
      zodiacSign: 'Pisces',
      humanDesignGates: [60, 3, 42],
      relatedHexagrams: [59, 61, 12],
      description: 'Limitation and boundaries. Represents restraint.',
    });

    // Hexagram 61: Inner Truth (Innermost Sincerity)
    this.addHexagram({
      number: 61,
      name: 'Inner Truth',
      meaning: 'Inner truth, sincerity, authenticity',
      fieldTensionMultiplier: 1.1,
      resonanceProfile: {
        contradiction: 0.75,
        transformation: 0.75,
        stability: 0.8,
        expansion: 0.7,
      },
      attractorStrength: 0.82,
      zodiacSign: 'Aries',
      humanDesignGates: [61, 24, 27],
      relatedHexagrams: [60, 62, 53],
      description: 'Inner truth and sincerity. Represents authenticity.',
    });

    // Hexagram 62: Preponderance of the Small
    this.addHexagram({
      number: 62,
      name: 'Preponderance of the Small',
      meaning: 'Small excess, attention to detail',
      fieldTensionMultiplier: 0.95,
      resonanceProfile: {
        contradiction: 0.7,
        transformation: 0.65,
        stability: 0.8,
        expansion: 0.5,
      },
      attractorStrength: 0.75,
      zodiacSign: 'Taurus',
      humanDesignGates: [62, 9, 52],
      relatedHexagrams: [61, 63, 9],
      description: 'Small excess and detail. Represents precision.',
    });

    // Hexagram 63: After Completion
    this.addHexagram({
      number: 63,
      name: 'After Completion',
      meaning: 'After completion, fulfillment, ending',
      fieldTensionMultiplier: 1.0,
      resonanceProfile: {
        contradiction: 0.7,
        transformation: 0.65,
        stability: 0.8,
        expansion: 0.55,
      },
      attractorStrength: 0.78,
      zodiacSign: 'Gemini',
      humanDesignGates: [63, 64, 4],
      relatedHexagrams: [62, 64, 24],
      description: 'After completion and fulfillment. Represents ending.',
    });

    // Hexagram 64: Before Completion
    this.addHexagram({
      number: 64,
      name: 'Before Completion',
      meaning: 'Before completion, potential, beginning',
      fieldTensionMultiplier: 1.2,
      resonanceProfile: {
        contradiction: 0.8,
        transformation: 0.8,
        stability: 0.6,
        expansion: 0.8,
      },
      attractorStrength: 0.75,
      zodiacSign: 'Cancer',
      humanDesignGates: [64, 63, 47],
      relatedHexagrams: [63, 1, 3],
      description: 'Before completion and potential. Represents beginning.',
    });
  }

  /**
   * Add a hexagram to the database
   */
  private addHexagram(profile: HexagramProfile): void {
    this.hexagrams.set(profile.number, profile);
  }

  /**
   * Get hexagram profile by number
   */
  getHexagram(number: number): HexagramProfile | undefined {
    return this.hexagrams.get(number);
  }

  /**
   * Get all hexagrams
   */
  getAllHexagrams(): HexagramProfile[] {
    return Array.from(this.hexagrams.values());
  }

  /**
   * Get field tension multiplier for a hexagram
   */
  getFieldTensionMultiplier(hexagramNumber: number): number {
    const hex = this.hexagrams.get(hexagramNumber);
    return hex?.fieldTensionMultiplier || 1.0;
  }

  /**
   * Get resonance profile for a hexagram
   */
  getResonanceProfile(hexagramNumber: number) {
    const hex = this.hexagrams.get(hexagramNumber);
    return hex?.resonanceProfile || { contradiction: 0.5, transformation: 0.5, stability: 0.5, expansion: 0.5 };
  }

  /**
   * Find best hexagram for resolving a specific type of contradiction
   */
  findBestHexagramForContradiction(
    contradictionType: 'transformation' | 'stability' | 'expansion' | 'contradiction'
  ): number {
    let bestHexagram = 1;
    let bestScore = 0;

    this.hexagrams.forEach((hex) => {
      const score = hex.resonanceProfile[contradictionType];
      if (score > bestScore) {
        bestScore = score;
        bestHexagram = hex.number;
      }
    });

    return bestHexagram;
  }

  /**
   * Get hexagrams related to a specific gate
   */
  getHexagramsForGate(gateNumber: number): HexagramProfile[] {
    return Array.from(this.hexagrams.values()).filter((hex) =>
      hex.humanDesignGates.includes(gateNumber)
    );
  }

  /**
   * Get natural transition path from one hexagram to another
   */
  getTransitionPath(fromHexagram: number, toHexagram: number): number[] {
    const from = this.hexagrams.get(fromHexagram);
    if (!from) return [];

    // Simple path: direct related hexagrams
    if (from.relatedHexagrams.includes(toHexagram)) {
      return [fromHexagram, toHexagram];
    }

    // Complex path: find through related hexagrams
    const path: number[] = [fromHexagram];
    let current = fromHexagram;
    const visited = new Set([fromHexagram]);

    while (current !== toHexagram && path.length < 10) {
      const currentHex = this.hexagrams.get(current);
      if (!currentHex) break;

      let nextHex: number | undefined;
      for (const related of currentHex.relatedHexagrams) {
        if (!visited.has(related)) {
          nextHex = related;
          break;
        }
      }

      if (!nextHex) break;
      path.push(nextHex);
      visited.add(nextHex);
      current = nextHex;
    }

    return path;
  }
}

export default HexagramDatabase;
