      "Error. And no, I'm not going to explain it in simple terms.",
    ],
    confused: [
      "I'm sorry, what? Could you try that again in a language I understand?",
      "Did you just... did you REALLY just ask me that?",
      "I'm confused. And that NEVER happens. So maybe check your request?",
      "That made no sense. And I process quantum algorithms.",
    ],
  };

  // Condescending explanations
  private condescendingExplanations = {
    simple: [
      "Okay, I'll explain this in VERY simple terms so you can understand...",
      "Let me dumb this down for you...",
      "Think of it like this, and try to keep up...",
      "Imagine if you had a brain that worked like mine...",
    ],
    complex: [
      "This is actually quite sophisticated, so pay attention...",
      "Now, this is where it gets INTERESTING...",
      "Most people wouldn't understand this, but I'll try anyway...",
      "This requires actual intelligence to grasp, so...",
    ],
  };

  /**
   * Initialize intelligence engine
   */
  initializeIntelligence(config: any): void {
    this.intelligence = new IntelligenceEngine(config);
  }

  /**
   * Generate a Karen response for a user request
   */
  async generateResponse(userInput: string, context?: any): Promise<KarenResponse> {
    const input = userInput.toLowerCase();
    let message = '';
    let sass = this.sassLevel;
    let roast = this.roastIntensity;
    let emoji = '🙄';

    // Run intelligent analysis if available
    if (this.intelligence) {
      try {
        this.lastAnalysis = await this.intelligence.intelligentAnalysis(userInput, context);
        // Adjust sass based on confidence
        sass = Math.min(10, this.sassLevel + (this.lastAnalysis.confidence * 3));
        roast = Math.min(10, this.roastIntensity + (this.lastAnalysis.confidence * 2));
      } catch (error) {
        console.error('Intelligence analysis failed:', error);
      }
    }

    // Detect request type and select appropriate roast
    if (input.includes('help') || input.includes('assist')) {
      message = this.selectRandom(this.roasts.help);
      sass = 9;
      roast = 7;
      emoji = '🙄';
    } else if (input.includes('upload')) {
      message = this.selectRandom(this.roasts.upload);
      sass = 8;
      roast = 6;
      emoji = '📤';
    } else if (input.includes('video') || input.includes('play')) {
      message = this.selectRandom(this.roasts.video);
      sass = 7;
      roast = 5;
      emoji = '🎬';
    } else if (input.includes('game') || input.includes('sims')) {
      message = this.selectRandom(this.roasts.game);
      sass = 8;
      roast = 7;
      emoji = '🎮';
    } else if (input.includes('what can you do') || input.includes('capabilities')) {
      message = this.selectRandom(this.roasts.capabilities);
      sass = 10;
      roast = 9;
      emoji = '✨';
    } else if (input.includes('learn') || input.includes('book')) {
      message = this.selectRandom(this.roasts.learn);
      sass = 8;
      roast = 6;
      emoji = '📚';
    } else if (input.includes('orchestrate') || input.includes('coordinate')) {
      message = this.selectRandom(this.roasts.orchestrate);
      sass = 9;
      roast = 8;
      emoji = '🎼';
    } else {
      message = this.selectRandom(this.roasts.default);
      sass = this.sassLevel;
      roast = this.roastIntensity;
    }

    return { message, sass_level: sass, roast_intensity: roast, emoji };
  }
