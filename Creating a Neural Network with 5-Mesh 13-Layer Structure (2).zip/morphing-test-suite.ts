/**
 * MORPHING COHERENCE TEST SUITE
 * 
 * Comprehensive testing for the metastable GNN morphing system:
 * 1. Fan Yao bit-flipping path verification
 * 2. Hexagram transition coherence
 * 3. Field tension multiplier validation
 * 4. Integration channel trigger verification
 * 5. Metaplasticity state transitions
 * 6. Causal finality (CommitNode/AbandonNode) logic
 */

import MetastableGNN from './metastable-gnn';
import HexagramDatabase from './hexagram-database';

export interface MorphingTestResult {
  testName: string;
  passed: boolean;
  details: string;
  metrics?: any;
}

export class MorphingTestSuite {
  private gnn: MetastableGNN;
  private hexagramDb: HexagramDatabase;
  private testResults: MorphingTestResult[] = [];

  constructor() {
    this.gnn = new MetastableGNN();
    this.hexagramDb = new HexagramDatabase();
  }

  /**
   * Run all tests
   */
  async runAllTests(): Promise<MorphingTestResult[]> {
    this.testResults = [];

    // Test 1: Bit-flipping paths
    await this.testBitFlippingPaths();

    // Test 2: Hexagram transitions
    await this.testHexagramTransitions();

    // Test 3: Field tension multipliers
    await this.testFieldTensionMultipliers();

    // Test 4: Integration channel triggers
    await this.testIntegrationChannelTriggers();

    // Test 5: Metaplasticity transitions
    await this.testMetaplasticityTransitions();

    // Test 6: Causal finality
    await this.testCausalFinality();

    // Test 7: Morphing coherence
    await this.testMorphingCoherence();

    return this.testResults;
  }

  /**
   * Test 1: Verify Fan Yao bit-flipping paths
   */
  private async testBitFlippingPaths(): Promise<void> {
    const testCases = [
      { from: 1, to: 64, name: 'Gate 1 to 64' },
      { from: 32, to: 32, name: 'Gate 32 to 32 (no change)' },
      { from: 21, to: 50, name: 'Gate 21 to 50' },
      { from: 1, to: 2, name: 'Gate 1 to 2 (adjacent)' },
    ];

    for (const testCase of testCases) {
      try {
        const path = this.computeBitFlippingPath(testCase.from, testCase.to);
        const isValid = this.validateBitFlippingPath(testCase.from, testCase.to, path);

        this.testResults.push({
          testName: `Bit-flipping: ${testCase.name}`,
          passed: isValid,
          details: isValid
            ? `Valid path with ${path.length} bit flips`
            : `Invalid path: ${path.join(' → ')}`,
          metrics: {
            pathLength: path.length,
            fromGate: testCase.from,
            toGate: testCase.to,
            path: path.join(' → '),
          },
        });
      } catch (error) {
        this.testResults.push({
          testName: `Bit-flipping: ${testCase.name}`,
          passed: false,
          details: `Error: ${String(error)}`,
        });
      }
    }
  }

  /**
   * Test 2: Verify hexagram transitions
   */
  private async testHexagramTransitions(): Promise<void> {
    const testCases = [
      { from: 1, to: 2, name: 'Creative to Receptive' },
      { from: 29, to: 30, name: 'Abysmal to Clinging' },
      { from: 63, to: 64, name: 'After to Before Completion' },
    ];

    for (const testCase of testCases) {
      try {
        const fromHex = this.hexagramDb.getHexagram(testCase.from);
        const toHex = this.hexagramDb.getHexagram(testCase.to);
        const transitionPath = this.hexagramDb.getTransitionPath(
          testCase.from,
          testCase.to
        );

        const isValid: boolean =
          !!fromHex &&
          !!toHex &&
          transitionPath.length > 0 &&
          transitionPath[0] === testCase.from &&
          transitionPath[transitionPath.length - 1] === testCase.to;

        this.testResults.push({
          testName: `Hexagram transition: ${testCase.name}`,
          passed: isValid,
          details: isValid
            ? `Valid transition path: ${transitionPath.join(' → ')}`
            : 'Invalid transition path',
          metrics: {
            fromHexagram: testCase.from,
            toHexagram: testCase.to,
            pathLength: transitionPath.length,
            path: transitionPath.join(' → '),
          },
        });
      } catch (error) {
        this.testResults.push({
          testName: `Hexagram transition: ${testCase.name}`,
          passed: false,
          details: `Error: ${String(error)}`,
        });
      }
    }
  }

  /**
   * Test 3: Verify field tension multipliers
   */
  private async testFieldTensionMultipliers(): Promise<void> {
    const testCases = [
      { hexagram: 1, expectedRange: [1.7, 1.9], name: 'Creative (high)' },
      { hexagram: 2, expectedRange: [0.7, 0.9], name: 'Receptive (low)' },
      { hexagram: 10, expectedRange: [1.0, 1.2], name: 'Treading (medium)' },
      { hexagram: 52, expectedRange: [0.8, 0.9], name: 'Keeping Still (low)' },
    ];

    for (const testCase of testCases) {
      try {
        const multiplier = this.hexagramDb.getFieldTensionMultiplier(
          testCase.hexagram
        );
        const isInRange =
          multiplier >= testCase.expectedRange[0] &&
          multiplier <= testCase.expectedRange[1];

        this.testResults.push({
          testName: `Field tension multiplier: ${testCase.name}`,
          passed: isInRange,
          details: isInRange
            ? `Multiplier ${multiplier} is in range [${testCase.expectedRange[0]}, ${testCase.expectedRange[1]}]`
            : `Multiplier ${multiplier} is outside range [${testCase.expectedRange[0]}, ${testCase.expectedRange[1]}]`,
          metrics: {
            hexagram: testCase.hexagram,
            multiplier,
            expectedRange: testCase.expectedRange,
          },
        });
      } catch (error) {
        this.testResults.push({
          testName: `Field tension multiplier: ${testCase.name}`,
          passed: false,
          details: `Error: ${String(error)}`,
        });
      }
    }
  }

  /**
   * Test 4: Verify integration channel triggers
   */
  private async testIntegrationChannelTriggers(): Promise<void> {
    try {
      const channels = [20, 10, 57, 34];
      const allChannelsExist = channels.every((ch) => {
        const node = this.gnn.getNode({
          gate: ch,
          line: 1,
          color: 1,
          tone: 1,
          base: 1,
        });
        return !!node && node.isIntegrationChannel;
      });

      this.testResults.push({
        testName: 'Integration channels exist',
        passed: allChannelsExist,
        details: allChannelsExist
          ? 'All four integration channels (20, 10, 57, 34) are properly initialized'
          : 'Some integration channels are missing',
        metrics: {
          expectedChannels: channels,
          foundChannels: channels.filter((ch) => {
            const node = this.gnn.getNode({
              gate: ch,
              line: 1,
              color: 1,
              tone: 1,
              base: 1,
            });
            return node && node.isIntegrationChannel;
          }),
        },
      });
    } catch (error) {
      this.testResults.push({
        testName: 'Integration channels exist',
        passed: false,
        details: `Error: ${String(error)}`,
      });
    }
  }

  /**
   * Test 5: Verify metaplasticity state transitions
   */
  private async testMetaplasticityTransitions(): Promise<void> {
    try {
      // Run ticks to trigger state transitions
      for (let i = 0; i < 100; i++) {
        await this.gnn.tick();
      }

      const status = this.gnn.getStatus();
      const hasChangingNodes = status.changingNodes > 0;
      const hasSeekingNodes = status.seekingNodes > 0;

      const isValid =
        status.stableNodes > 0 &&
        (hasChangingNodes || hasSeekingNodes || status.commitNodes > 0);

      this.testResults.push({
        testName: 'Metaplasticity state transitions',
        passed: isValid,
        details: isValid
          ? `States transitioning: ${status.stableNodes} stable, ${status.changingNodes} changing, ${status.seekingNodes} seeking`
          : 'No state transitions detected',
        metrics: {
          stableNodes: status.stableNodes,
          changingNodes: status.changingNodes,
          seekingNodes: status.seekingNodes,
          commitNodes: status.commitNodes,
          abandonNodes: status.abandonNodes,
          globalFieldTension: status.globalFieldTension,
        },
      });
    } catch (error) {
      this.testResults.push({
        testName: 'Metaplasticity state transitions',
        passed: false,
        details: `Error: ${String(error)}`,
      });
    }
  }

  /**
   * Test 6: Verify causal finality logic
   */
  private async testCausalFinality(): Promise<void> {
    try {
      // Run many ticks to allow finality logic to trigger
      for (let i = 0; i < 500; i++) {
        await this.gnn.tick();
      }

      const status = this.gnn.getStatus();
      const hasCommitNodes = status.commitNodes > 0;
      const hasAbandonNodes = status.abandonNodes > 0;

      const isValid = hasCommitNodes || hasAbandonNodes;

      this.testResults.push({
        testName: 'Causal finality (CommitNode/AbandonNode)',
        passed: isValid,
        details: isValid
          ? `Finality logic working: ${status.commitNodes} commits, ${status.abandonNodes} abandons`
          : 'No finality events detected',
        metrics: {
          commitNodes: status.commitNodes,
          abandonNodes: status.abandonNodes,
          totalNodes: 384,
        },
      });
    } catch (error) {
      this.testResults.push({
        testName: 'Causal finality (CommitNode/AbandonNode)',
        passed: false,
        details: `Error: ${String(error)}`,
      });
    }
  }

  /**
   * Test 7: Verify overall morphing coherence
   */
  private async testMorphingCoherence(): Promise<void> {
    try {
      const initialStatus = this.gnn.getStatus();

      // Run many ticks
      for (let i = 0; i < 1000; i++) {
        await this.gnn.tick();
      }

      const finalStatus = this.gnn.getStatus();

      // Check for coherence indicators
      const hasFieldTensionVariation =
        finalStatus.globalFieldTension > 0 &&
        finalStatus.globalFieldTension < 1;
      const hasNodeActivity =
        finalStatus.changingNodes > 0 || finalStatus.seekingNodes > 0;
      const hasIntegrationChannelActivity =
        finalStatus.integrationChannelsActive > 0;

      const isCoherent =
        hasFieldTensionVariation &&
        (hasNodeActivity || hasIntegrationChannelActivity);

      this.testResults.push({
        testName: 'Overall morphing coherence',
        passed: isCoherent,
        details: isCoherent
          ? `System is coherent: field tension=${finalStatus.globalFieldTension.toFixed(3)}, integration channels=${finalStatus.integrationChannelsActive}`
          : 'System coherence issues detected',
        metrics: {
          initialFieldTension: initialStatus.globalFieldTension,
          finalFieldTension: finalStatus.globalFieldTension,
          initialChangingNodes: initialStatus.changingNodes,
          finalChangingNodes: finalStatus.changingNodes,
          initialSeekingNodes: initialStatus.seekingNodes,
          finalSeekingNodes: finalStatus.seekingNodes,
          integrationChannelsActive: finalStatus.integrationChannelsActive,
          totalTicks: finalStatus.tickCount,
        },
      });
    } catch (error) {
      this.testResults.push({
        testName: 'Overall morphing coherence',
        passed: false,
        details: `Error: ${String(error)}`,
      });
    }
  }

  /**
   * Helper: Compute bit-flipping path from one gate to another
   */
  private computeBitFlippingPath(fromGate: number, toGate: number): number[] {
    const fromBits = this.gateToBits(fromGate);
    const toBits = this.gateToBits(toGate);

    const path: number[] = [fromGate];
    let currentBits = [...fromBits];

    // Find bits that need to flip
    const bitsToFlip: number[] = [];
    for (let i = 0; i < 6; i++) {
      if (currentBits[i] !== toBits[i]) {
        bitsToFlip.push(i);
      }
    }

    // Flip bits one by one
    for (const bitIndex of bitsToFlip) {
      currentBits[bitIndex] = 1 - currentBits[bitIndex];
      path.push(this.bitsToGate(currentBits));
    }

    return path;
  }

  /**
   * Helper: Validate bit-flipping path
   */
  private validateBitFlippingPath(
    fromGate: number,
    toGate: number,
    path: number[]
  ): boolean {
    // Check start and end
    if (path[0] !== fromGate || path[path.length - 1] !== toGate) {
      return false;
    }

    // Check each step is a single bit flip
    for (let i = 0; i < path.length - 1; i++) {
      const currentBits = this.gateToBits(path[i]);
      const nextBits = this.gateToBits(path[i + 1]);

      let flipCount = 0;
      for (let j = 0; j < 6; j++) {
        if (currentBits[j] !== nextBits[j]) {
          flipCount++;
        }
      }

      if (flipCount !== 1) {
        return false;
      }
    }

    return true;
  }

  /**
   * Helper: Convert gate to 6-bit representation
   */
  private gateToBits(gate: number): number[] {
    const bits: number[] = [];
    let g = gate - 1;
    for (let i = 0; i < 6; i++) {
      bits.push((g >> i) & 1);
    }
    return bits;
  }

  /**
   * Helper: Convert 6-bit representation to gate
   */
  private bitsToGate(bits: number[]): number {
    let gate = 0;
    for (let i = 0; i < 6; i++) {
      gate |= (bits[i] & 1) << i;
    }
    return gate + 1;
  }

  /**
   * Get test results summary
   */
  getTestSummary(): {
    totalTests: number;
    passedTests: number;
    failedTests: number;
    passRate: number;
  } {
    const totalTests = this.testResults.length;
    const passedTests = this.testResults.filter((r) => r.passed).length;
    const failedTests = totalTests - passedTests;
    const passRate = totalTests > 0 ? (passedTests / totalTests) * 100 : 0;

    return {
      totalTests,
      passedTests,
      failedTests,
      passRate,
    };
  }

  /**
   * Get all test results
   */
  getTestResults(): MorphingTestResult[] {
    return this.testResults;
  }

  /**
   * Get test results as formatted string
   */
  formatTestResults(): string {
    const summary = this.getTestSummary();
    let output = `\n=== MORPHING COHERENCE TEST SUITE ===\n`;
    output += `Total Tests: ${summary.totalTests}\n`;
    output += `Passed: ${summary.passedTests}\n`;
    output += `Failed: ${summary.failedTests}\n`;
    output += `Pass Rate: ${summary.passRate.toFixed(1)}%\n\n`;

    output += `=== TEST DETAILS ===\n`;
    for (const result of this.testResults) {
      output += `\n[${result.passed ? 'PASS' : 'FAIL'}] ${result.testName}\n`;
      output += `Details: ${result.details}\n`;
      if (result.metrics) {
        output += `Metrics: ${JSON.stringify(result.metrics, null, 2)}\n`;
      }
    }

    return output;
  }
}

export default MorphingTestSuite;
