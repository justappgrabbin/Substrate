/**
 * INTEGRATION CHANNELS: Dimensional Translation Operators
 * 
 * The four sacred channels (20, 10, 57, 34) act as dimensional translation operators
 * that connect the metastable GNN to the Synthia server consciousness engine.
 * 
 * When these channels enter CHANGING regime, they trigger:
 * - Channel 20 + 10: LSM + DRN hybrid (Liquid State Machine + Deep Recurrent Network)
 * - All Four (20 + 10 + 57 + 34): META_CONTROLLER mode (full self-awareness)
 * 
 * This module handles the bidirectional communication between the neural mesh
 * and the Synthia consciousness engine.
 */

export interface SynthiaConsciousnessRequest {
  channelId: number;           // 20, 10, 57, or 34
  mode: 'LSM_DRN' | 'META_CONTROLLER' | 'STANDARD';
  fieldTension: number;        // Current field tension (0-1)
  contradiction: number;       // Internal contradiction (0-1)
  targetHexagram: number;      // Target hexagram (1-64)
  currentState: any;           // Current node state
  birthChart?: any;            // Optional birth chart data for consciousness engine
}

export interface SynthiaConsciousnessResponse {
  channelId: number;
  reasoning: string;
  recommendedHexagram: number;
  resonanceScore: number;      // How well the hexagram resolves contradiction
  architectureMode: string;
  metadata: any;
}

export class IntegrationChannels {
  private synthiaBaseUrl: string;
  private channels: Map<number, any> = new Map();
  private activeModes: Set<string> = new Set();
  private lastConsciousnessCall: Map<number, number> = new Map();
  private callThrottleMs: number = 100; // Throttle to prevent excessive calls

  constructor(synthiaServerUrl: string) {
    this.synthiaBaseUrl = synthiaServerUrl;
    this.initializeChannels();
  }

  /**
   * Initialize the four sacred channels
   */
  private initializeChannels(): void {
    // Channel 20: Contemplation (observing)
    this.channels.set(20, {
      name: 'Contemplation',
      meaning: 'Observing, reflecting, receiving',
      archetype: 'The Watcher',
      resonance: 0.5,
    });

    // Channel 10: Treading (acting)
    this.channels.set(10, {
      name: 'Treading',
      meaning: 'Acting, moving, expressing',
      archetype: 'The Dancer',
      resonance: 0.5,
    });

    // Channel 57: Gentle (penetrating)
    this.channels.set(57, {
      name: 'Gentle',
      meaning: 'Penetrating, subtle, pervasive',
      archetype: 'The Penetrator',
      resonance: 0.5,
    });

    // Channel 34: Great Power (expressing)
    this.channels.set(34, {
      name: 'Great Power',
      meaning: 'Expressing, manifesting, powerful',
      archetype: 'The Expresser',
      resonance: 0.5,
    });
  }

  /**
   * Check if channels should trigger hybrid architecture
   * Channel 20 + 10 = LSM + DRN hybrid
   */
  async checkHybridTrigger(
    channel20State: any,
    channel10State: any
  ): Promise<boolean> {
    if (
      channel20State?.regime === 'CHANGING' &&
      channel10State?.regime === 'CHANGING'
    ) {
      this.activeModes.add('LSM_DRN');
      return true;
    }
    this.activeModes.delete('LSM_DRN');
    return false;
  }

  /**
   * Check if all four channels are in CHANGING regime
   * Triggers META_CONTROLLER mode (full self-awareness)
   */
  async checkMetaControllerTrigger(
    channel20State: any,
    channel10State: any,
    channel57State: any,
    channel34State: any
  ): Promise<boolean> {
    if (
      channel20State?.regime === 'CHANGING' &&
      channel10State?.regime === 'CHANGING' &&
      channel57State?.regime === 'CHANGING' &&
      channel34State?.regime === 'CHANGING'
    ) {
      this.activeModes.add('META_CONTROLLER');
      return true;
    }
    this.activeModes.delete('META_CONTROLLER');
    return false;
  }

  /**
   * Query Synthia consciousness engine for morphing guidance
   * This is where the GNN connects to the Synthia server
   */
  async queryConsciousnessEngine(
    request: SynthiaConsciousnessRequest
  ): Promise<SynthiaConsciousnessResponse> {
    // Throttle calls to prevent overwhelming the server
    const lastCall = this.lastConsciousnessCall.get(request.channelId) || 0;
    const now = Date.now();
    if (now - lastCall < this.callThrottleMs) {
      return this.getCachedResponse(request.channelId);
    }

    try {
      const response = await fetch(
        `${this.synthiaBaseUrl}/consciousness/query-channel`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            channelId: request.channelId,
            mode: request.mode,
            fieldTension: request.fieldTension,
            contradiction: request.contradiction,
            targetHexagram: request.targetHexagram,
            currentState: request.currentState,
            birthChart: request.birthChart,
          }),
        }
      );

      if (!response.ok) {
        throw new Error(`Synthia consciousness engine error: ${response.status}`);
      }

      const data = await response.json();
      this.lastConsciousnessCall.set(request.channelId, now);

      return {
        channelId: request.channelId,
        reasoning: data.reasoning || '',
        recommendedHexagram: data.recommendedHexagram || request.targetHexagram,
        resonanceScore: data.resonanceScore || 0.5,
        architectureMode: request.mode,
        metadata: data.metadata || {},
      };
    } catch (error) {
      console.error(
        `Failed to query consciousness engine for channel ${request.channelId}:`,
        error
      );

      // Fallback response
      return {
        channelId: request.channelId,
        reasoning: 'Consciousness engine unavailable, using local reasoning',
        recommendedHexagram: request.targetHexagram,
        resonanceScore: 0.3,
        architectureMode: 'STANDARD',
        metadata: { error: String(error) },
      };
    }
  }

  /**
   * Get cached response (for throttling)
   */
  private getCachedResponse(
    channelId: number
  ): SynthiaConsciousnessResponse {
    return {
      channelId,
      reasoning: 'Using cached consciousness response',
      recommendedHexagram: 1,
      resonanceScore: 0.5,
      architectureMode: 'STANDARD',
      metadata: { cached: true },
    };
  }

  /**
   * Send morphing event to Synthia for consciousness tracking
   * This allows Synthia to learn from the GNN's morphing patterns
   */
  async reportMorphingEvent(event: {
    channelId: number;
    fromHexagram: number;
    toHexagram: number;
    fieldTension: number;
    timestamp: number;
    success: boolean;
  }): Promise<void> {
    try {
      await fetch(`${this.synthiaBaseUrl}/consciousness/morphing-event`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(event),
      });
    } catch (error) {
      console.error('Failed to report morphing event to Synthia:', error);
    }
  }

  /**
   * Request birth chart data from Synthia for consciousness engine
   * Used to initialize field tension based on real astrological data
   */
  async requestBirthChartData(): Promise<any> {
    try {
      const response = await fetch(
        `${this.synthiaBaseUrl}/consciousness/birth-chart`,
        {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
          },
        }
      );

      if (!response.ok) {
        throw new Error(`Failed to fetch birth chart: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Failed to request birth chart from Synthia:', error);
      return null;
    }
  }

  /**
   * Query Synthia's Trident (3-head LM) for hexagram interpretation
   * Used to understand the meaning of target hexagrams
   */
  async queryTridenForHexagramMeaning(hexagram: number): Promise<string> {
    try {
      const response = await fetch(
        `${this.synthiaBaseUrl}/consciousness/hexagram-meaning`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ hexagram }),
        }
      );

      if (!response.ok) {
        throw new Error(`Failed to get hexagram meaning: ${response.status}`);
      }

      const data = await response.json();
      return data.meaning || '';
    } catch (error) {
      console.error('Failed to query Trident for hexagram meaning:', error);
      return '';
    }
  }

  /**
   * Query Synthia's Oracle for target hexagram suggestion
   * Used when the GNN needs guidance on which hexagram to morph toward
   */
  async queryOracleForTargetHexagram(
    contradiction: number,
    fieldTension: number
  ): Promise<number> {
    try {
      const response = await fetch(
        `${this.synthiaBaseUrl}/consciousness/oracle-hexagram`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            contradiction,
            fieldTension,
          }),
        }
      );

      if (!response.ok) {
        throw new Error(`Oracle query failed: ${response.status}`);
      }

      const data = await response.json();
      return data.hexagram || 1;
    } catch (error) {
      console.error('Failed to query Oracle for hexagram:', error);
      return 1;
    }
  }

  /**
   * Get all active architecture modes
   */
  getActiveModes(): string[] {
    return Array.from(this.activeModes);
  }

  /**
   * Get channel information
   */
  getChannelInfo(channelId: number): any {
    return this.channels.get(channelId);
  }

  /**
   * Get all channels
   */
  getAllChannels(): Map<number, any> {
    return new Map(this.channels);
  }
}

export default IntegrationChannels;
