
# YOU-N-I-VERSE

Synthia-centered platform with Mind/Body/Heart rings, Abundance Engine (outer ring), and **Stellar Proximology** (daily transit proximity).

## Quickstart

```bash
# from repo root
npm install
cd client && npm install && cd ..
# run dev (starts API + Vite dev server)
npm run dev
```

- Frontend: http://localhost:5173
- Backend API: http://localhost:5000

### Environment
- MongoDB local (`mongod`) or set `MONGODB_URI` in `.env`
- Optional: `PORT` for server

## Features
- Synthia home overlay
- Mind/Body/Heart rings (D3)
- Abundance Engine (/api/abundance)
- Stellar Proximology (/api/proximology)
- Resonance sentences (/api/resonance)
- Auth (signup/login)
- Offline ZIP export
- PWA (manifest + service worker)
- Marketing page (marketing/)

## Deploy
- Frontend via Vercel/Netlify (build with `npm run build`)
- Backend via Render/Fly/Heroku

