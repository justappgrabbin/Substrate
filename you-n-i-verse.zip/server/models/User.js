const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  birthData: {
    date: String,
    time: String,
    location: String,
    tzOffset: Number
  },
  traits: {
    mind: [String],
    body: [String],
    heart: [String]
  }
}, { timestamps: true });

module.exports = mongoose.model('User', userSchema);
