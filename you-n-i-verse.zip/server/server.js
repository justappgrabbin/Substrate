const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const authRoutes = require('./routes/auth');
const chartRoutes = require('./routes/chart');
const abundanceRoutes = require('./routes/abundance');
const proximologyRoutes = require('./routes/proximology');
const resonanceEngine = require('./resonanceEngine');

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 5000;
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost/you-n-i-verse';

mongoose.connect(MONGODB_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error(err));

app.use('/api/auth', authRoutes);
app.use('/api/chart', chartRoutes);
app.use('/api/abundance', abundanceRoutes);
app.use('/api/proximology', proximologyRoutes);

app.get('/api/resonance', (req, res) => {
  const sentence = resonanceEngine.generate();
  res.json({ sentence });
});

app.get('/', (req, res) => {
  res.json({ ok: true, service: 'YOU-N-I-VERSE API' });
});

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
