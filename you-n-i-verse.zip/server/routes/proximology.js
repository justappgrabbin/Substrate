const express = require('express');
const router = express.Router();

/**
 * Stellar Proximology (toy implementation)
 * Input: natal = { planet: degree0..360 }, transit = { planet: degree0..360 }
 * Output: proximity score [0..100] + hotspots by planet based on angular distance
 */
function angularDistance(a, b) {
  const d = Math.abs(((a - b) % 360 + 360) % 360);
  return Math.min(d, 360 - d);
}

function scorePair(degNatal, degTransit) {
  const d = angularDistance(degNatal, degTransit);
  // Gaussian-ish proximity; 0° exact -> 100; 10° -> ~80; 30° -> ~30; >60° -> small
  const s = Math.exp(-Math.pow(d/14, 2)) * 100;
  return Math.round(s);
}

router.post('/analyze', (req, res) => {
  const { natal = {}, transit = {} } = req.body || {};
  const planets = Array.from(new Set([...Object.keys(natal), ...Object.keys(transit)]));
  const details = planets.map(p => {
    const n = natal[p]; const t = transit[p];
    if (typeof n !== 'number' || typeof t !== 'number') {
      return { planet: p, score: null, distance: null };
    }
    const distance = angularDistance(n, t);
    const score = scorePair(n, t);
    return { planet: p, distance, score };
  });
  const valid = details.filter(d => typeof d.score === 'number');
  const agg = valid.length ? Math.round(valid.reduce((a, c) => a + c.score, 0)/valid.length) : 0;
  res.json({ proximity: agg, details });
});

module.exports = router;
