const express = require('express');
const router = express.Router();

// Super simple abundance score demo: combines ring activations and mock transit weight
function abundanceScore({ mind=0, body=0, heart=0, transit=0 }) {
  // Weighted outer-ring: heart gets slight bias
  return Math.round((mind*0.9 + body*1.0 + heart*1.1 + transit*1.2) / 4);
}

router.post('/score', (req, res) => {
  const { mind, body, heart, transit } = req.body || {};
  const score = abundanceScore({ mind, body, heart, transit });
  const tier = score > 80 ? 'harvest' : score > 60 ? 'bloom' : score > 40 ? 'sprout' : 'seed';
  res.json({ score, tier });
});

module.exports = router;
