const generate = () => {
  const starters = ['Your field resonates with', 'The cosmos aligns to', 'Your energy vibrates at'];
  const qualities = ['clarity and wisdom', 'love and harmony', 'strength and balance'];
  return `${starters[Math.floor(Math.random() * starters.length)]} ${qualities[Math.floor(Math.random() * qualities.length)]}.`;
};
module.exports = { generate };
