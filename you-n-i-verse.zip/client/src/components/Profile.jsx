import React from 'react'
import { exportToZip } from '../utils/zipExport'

export default function Profile({ user }){
  const data = user || { name: 'Guest', email: 'guest@example.com' }
  return (
    <div className="max-w-3xl mx-auto p-6 mt-10 bg-white/50 rounded-xl">
      <h2 className="text-3xl font-bold text-purple-800">Profile</h2>
      <p className="mt-2">Name: {data.name}</p>
      <p>Email: {data.email}</p>
      <button onClick={()=>exportToZip(data)} className="mt-6 bg-purple-700 text-white px-5 py-3 rounded-xl">Export ZIP</button>
    </div>
  )
}
