import React, { useState } from 'react'

export default function Feedback(){
  const [msg, setMsg] = useState('')
  const [glyph, setGlyph] = useState('⭐')
  return (
    <div className="max-w-md mx-auto p-6 mt-10 bg-white/50 rounded-xl">
      <h2 className="text-2xl font-bold text-purple-800 mb-4">Leave a Glyph</h2>
      <select className="w-full p-3 mb-3 rounded" value={glyph} onChange={e=>setGlyph(e.target.value)}>
        <option>⭐</option><option>🌙</option><option>💖</option><option>🌀</option>
      </select>
      <textarea className="w-full p-3 mb-3 rounded" rows="4" placeholder="Your resonance..." value={msg} onChange={e=>setMsg(e.target.value)} />
      <button className="bg-purple-700 text-white px-5 py-3 rounded-xl w-full">Submit</button>
    </div>
  )
}
