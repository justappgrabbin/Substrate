import React from 'react'
import { Link } from 'react-router-dom'

export default function Navbar({ user, setUser }){
  return (
    <nav className="bg-purple-800 p-4 shadow-lg">
      <div className="container mx-auto flex justify-between items-center">
        <Link to="/" className="text-white text-2xl font-bold">YOU-N-I-VERSE</Link>
        <div className="space-x-4">
          <Link to="/" className="text-white hover:text-pink-300">Home</Link>
          {user ? (
            <>
              <Link to="/profile" className="text-white hover:text-pink-300">Profile</Link>
              <Link to="/chart" className="text-white hover:text-pink-300">Chart</Link>
              <Link to="/feedback" className="text-white hover:text-pink-300">Feedback</Link>
              <button onClick={() => setUser(null)} className="text-white hover:text-pink-300">Logout</button>
            </>
          ) : (
            <>
              <Link to="/login" className="text-white hover:text-pink-300">Login</Link>
              <Link to="/signup" className="text-white hover:text-pink-300">Signup</Link>
            </>
          )}
        </div>
      </div>
    </nav>
  )
}
