import React, { useState } from 'react'
import { Routes, Route } from 'react-router-dom'
import Navbar from './components/Navbar.jsx'
import Home from './pages/Home.jsx'
import Login from './pages/Login.jsx'
import Signup from './pages/Signup.jsx'
import Profile from './components/Profile.jsx'
import Chart from './components/Chart.jsx'
import Feedback from './components/Feedback.jsx'
import Synthia from './components/Synthia.jsx'

export default function App(){
  const [user, setUser] = useState(null)
  return (
    <div className="min-h-screen">
      <Navbar user={user} setUser={setUser} />
      <Routes>
        <Route path="/" element={<Home/>} />
        <Route path="/login" element={<Login setUser={setUser}/>} />
        <Route path="/signup" element={<Signup setUser={setUser}/>} />
        <Route path="/profile" element={<Profile user={user}/>} />
        <Route path="/chart" element={<Chart/>} />
        <Route path="/feedback" element={<Feedback/>} />
      </Routes>
      <Synthia user={user} />
    </div>
  )
}
