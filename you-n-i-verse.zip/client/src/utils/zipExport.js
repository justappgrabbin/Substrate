import JSZip from 'jszip'
import { saveAs } from 'file-saver'

export async function exportToZip(userData){
  const zip = new JSZip()
  zip.file('profile.json', JSON.stringify(userData, null, 2))
  zip.file('readme.txt', 'Your YOU-N-I-VERSE profile data. Keep exploring!')
  const blob = await zip.generateAsync({ type: 'blob' })
  saveAs(blob, 'you-n-i-verse-profile.zip')
}
