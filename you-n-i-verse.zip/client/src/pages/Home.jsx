import React from 'react'
import { Link } from 'react-router-dom'

export default function Home(){
  return (
    <div className="px-6 py-16 max-w-4xl mx-auto">
      <div className="bg-white/40 rounded-2xl p-8 shadow-xl">
        <h1 className="text-4xl font-extrabold text-purple-800">Enter the YOU-N-I-VERSE</h1>
        <p className="mt-4 text-purple-900/80">Synthia greets you and the rings align. Generate your chart, read your resonance sentence, and watch the Abundance ring glow with today’s transits.</p>
        <div className="mt-6 flex gap-3">
          <Link to="/chart" className="bg-purple-700 text-white px-5 py-3 rounded-xl">Generate Chart</Link>
          <Link to="/profile" className="bg-pink-600 text-white px-5 py-3 rounded-xl">Your Profile</Link>
        </div>
      </div>
    </div>
  )
}
