import React, { useState } from 'react'
import axios from 'axios'

export default function Login({ setUser }){
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const submit = async e => {
    e.preventDefault()
    const { data } = await axios.post('http://localhost:5000/api/auth/login', { email, password })
    setUser(data.user)
  }
  return (
    <form onSubmit={submit} className="max-w-md mx-auto p-6 mt-10 bg-white/50 rounded-xl">
      <h2 className="text-2xl font-bold text-purple-800 mb-4">Login</h2>
      <input className="w-full p-3 mb-3 rounded" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
      <input className="w-full p-3 mb-3 rounded" placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
      <button className="bg-purple-700 text-white px-5 py-3 rounded-xl w-full">Login</button>
    </form>
  )
}
