import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Mic, Volume2, Square, Loader2 } from "lucide-react";
import { toast } from "sonner";

interface VoiceChatProps {
  onTranscription: (text: string) => void;
  isListening?: boolean;
  axisResponse?: string;
}

export default function VoiceChat({ onTranscription, isListening = false, axisResponse }: VoiceChatProps) {
  const [isRecording, setIsRecording] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [transcript, setTranscript] = useState("");
  const recognitionRef = useRef<any>(null);
  const synthRef = useRef<SpeechSynthesisUtterance | null>(null);

  // Initialize Speech Recognition
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = true;
      recognitionRef.current.lang = "en-US";

      recognitionRef.current.onstart = () => setIsRecording(true);
      recognitionRef.current.onend = () => setIsRecording(false);

      recognitionRef.current.onresult = (event: any) => {
        let interim = "";
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcriptSegment = event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            setTranscript((prev) => prev + transcriptSegment + " ");
            onTranscription(transcriptSegment);
          } else {
            interim += transcriptSegment;
          }
        }
      };

      recognitionRef.current.onerror = (event: any) => {
        toast.error(`Speech recognition error: ${event.error}`);
      };
    }
  }, [onTranscription]);

  // Auto-speak AXIS responses
  useEffect(() => {
    if (axisResponse && !isSpeaking) {
      speakText(axisResponse);
    }
  }, [axisResponse]);

  const startListening = () => {
    if (recognitionRef.current) {
      setTranscript("");
      recognitionRef.current.start();
    } else {
      toast.error("Speech recognition not supported in this browser");
    }
  };

  const stopListening = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }
  };

  const speakText = (text: string) => {
    if (!("speechSynthesis" in window)) {
      toast.error("Text-to-speech not supported");
      return;
    }

    // Cancel any ongoing speech
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1;
    utterance.pitch = 1;
    utterance.volume = 1;

    // Try to use a female voice (AXIS is she/her)
    const voices = window.speechSynthesis.getVoices();
    const femaleVoice = voices.find((v) => v.name.includes("Female") || v.name.includes("female"));
    if (femaleVoice) {
      utterance.voice = femaleVoice;
    }

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    synthRef.current = utterance;
    window.speechSynthesis.speak(utterance);
  };

  const stopSpeaking = () => {
    window.speechSynthesis.cancel();
    setIsSpeaking(false);
  };

  return (
    <div className="flex items-center gap-2">
      {/* Microphone Button */}
      <Button
        size="sm"
        onClick={isRecording ? stopListening : startListening}
        disabled={isSpeaking}
        className={`gap-2 font-bold tracking-widest text-xs ${
          isRecording ? "bg-[oklch(0.65_0.25_25)]" : "bg-[oklch(0.72_0.28_330)]"
        }`}
      >
        {isRecording ? (
          <>
            <Loader2 size={14} className="animate-spin" /> LISTENING...
          </>
        ) : (
          <>
            <Mic size={14} /> VOICE
          </>
        )}
      </Button>

      {/* Speaker Button */}
      {axisResponse && (
        <Button
          size="sm"
          onClick={isSpeaking ? stopSpeaking : () => speakText(axisResponse)}
          className="gap-2 font-bold tracking-widest text-xs bg-[oklch(0.75_0.2_140)]"
        >
          {isSpeaking ? (
            <>
              <Square size={12} /> STOP
            </>
          ) : (
            <>
              <Volume2 size={14} /> SPEAK
            </>
          )}
        </Button>
      )}

      {/* Transcript Display */}
      {transcript && (
        <div className="text-xs text-muted-foreground italic">
          "{transcript.substring(0, 40)}{transcript.length > 40 ? "..." : ""}"
        </div>
      )}
    </div>
  );
}
