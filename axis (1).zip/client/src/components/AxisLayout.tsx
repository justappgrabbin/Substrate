import { trpc } from "@/lib/trpc";
import { getLoginUrl } from "@/const";
import { useAuth } from "@/_core/hooks/useAuth";
import {
  Bot,
  Brain,
  Code2,
  DollarSign,
  GitBranch,
  Home,
  MessageSquare,
  Target,
  Bell,
  Users,
  BookOpen,
  Zap,
  LogOut,
  Menu,
  X,
} from "lucide-react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";

const navItems = [
  { href: "/dashboard", icon: Home, label: "DASHBOARD", color: "text-[oklch(0.65_0.22_195)]" },
  { href: "/chat", icon: MessageSquare, label: "CHAT", color: "text-[oklch(0.72_0.28_330)]" },
  { href: "/projects", icon: Code2, label: "PROJECTS", color: "text-[oklch(0.65_0.22_195)]" },
  { href: "/github", icon: GitBranch, label: "GITHUB", color: "text-[oklch(0.72_0.28_330)]" },
  { href: "/sandbox", icon: Brain, label: "SANDBOX", color: "text-[oklch(0.72_0.28_330)]" },
  { href: "/income", icon: DollarSign, label: "INCOME", color: "text-[oklch(0.75_0.2_140)]" },
  { href: "/goals", icon: Target, label: "GOALS", color: "text-[oklch(0.65_0.22_195)]" },
  { href: "/reading", icon: BookOpen, label: "READING", color: "text-[oklch(0.72_0.28_330)]" },
  { href: "/friends", icon: Users, label: "FRIENDS", color: "text-[oklch(0.65_0.22_195)]" },
  { href: "/axis-goals", icon: Brain, label: "AXIS", color: "text-[oklch(0.72_0.28_330)]" },
  { href: "/autonomous", icon: Zap, label: "AUTO", color: "text-[oklch(0.7_0.25_60)]" },
  { href: "/notifications", icon: Bell, label: "ALERTS", color: "text-[oklch(0.72_0.28_330)]" },
];

interface AxisLayoutProps {
  children: React.ReactNode;
  title?: string;
}

export default function AxisLayout({ children, title }: AxisLayoutProps) {
  const [location] = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { user, isAuthenticated, logout } = useAuth();
  const { data: unreadCount } = trpc.notifications.unreadCount.useQuery(undefined, {
    refetchInterval: 30000,
  });

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <div className="text-center space-y-6 max-w-sm" style={{ position: "relative" }}>
          {/* HUD corners */}
          <div className="absolute top-0 left-0 w-4 h-4 border-t border-l border-[oklch(0.65_0.22_195/0.7)]" />
          <div className="absolute bottom-0 right-0 w-4 h-4 border-b border-r border-[oklch(0.65_0.22_195/0.7)]" />

          <div
            className="text-4xl md:text-5xl font-black tracking-widest"
            style={{
              fontFamily: "'Orbitron', sans-serif",
              color: "oklch(0.72 0.28 330)",
              textShadow:
                "0 0 8px oklch(0.72 0.28 330 / 0.9), 0 0 20px oklch(0.72 0.28 330 / 0.6), 0 0 40px oklch(0.72 0.28 330 / 0.3)",
            }}
          >
            AXIS
          </div>
          <p className="text-muted-foreground text-xs md:text-sm tracking-widest uppercase">
            Authentication Required
          </p>
          <Button
            onClick={() => (window.location.href = getLoginUrl())}
            className="w-full bg-[oklch(0.72_0.28_330)] text-[oklch(0.06_0.01_260)] font-bold tracking-widest hover:bg-[oklch(0.78_0.28_330)]"
          >
            INITIALIZE SESSION
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col md:flex-row h-screen bg-background overflow-hidden">
      {/* Mobile Menu Button */}
      <div className="md:hidden fixed top-4 left-4 z-50">
        <Button
          size="sm"
          variant="ghost"
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="text-[oklch(0.72_0.28_330)]"
        >
          {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
        </Button>
      </div>

      {/* Sidebar - Desktop always visible, Mobile toggleable */}
      <div
        className={cn(
          "fixed md:static inset-y-0 left-0 w-56 bg-[oklch(0.08_0.01_260)] border-r border-[oklch(0.65_0.22_195/0.2)] flex flex-col z-40 transition-transform duration-200",
          sidebarOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"
        )}
      >
        {/* Logo */}
        <div className="p-4 border-b border-[oklch(0.65_0.22_195/0.2)]">
          <Link href="/dashboard">
            <a className="flex items-center gap-2 hover:opacity-80 transition-opacity">
              <div
                className="text-xl font-black tracking-wider"
                style={{
                  fontFamily: "'Orbitron', sans-serif",
                  color: "oklch(0.72 0.28 330)",
                  textShadow: "0 0 8px oklch(0.72 0.28 330 / 0.6)",
                }}
              >
                AXIS
              </div>
              <Badge variant="outline" className="text-[10px] tracking-widest">
                v2.0
              </Badge>
            </a>
          </Link>
          <p className="text-[10px] text-muted-foreground tracking-widest mt-1">ONLINE</p>
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto p-3 space-y-1">
          {navItems.map(({ href, icon: Icon, label, color }) => {
            const isActive = location === href;
            return (
              <Link key={href} href={href}>
                <a
                  onClick={() => setSidebarOpen(false)}
                  className={cn(
                    "flex items-center gap-3 px-3 py-2 rounded-sm text-xs font-bold tracking-widest transition-colors",
                    isActive
                      ? "bg-[oklch(0.15_0.02_260)] border border-[oklch(0.72_0.28_330/0.4)]"
                      : "hover:bg-[oklch(0.12_0.015_260)] border border-transparent"
                  )}
                >
                  <Icon size={16} className={color} />
                  <span className="flex-1">{label}</span>
                  {label === "ALERTS" && unreadCount && unreadCount > 0 && (
                    <Badge variant="destructive" className="text-[9px] px-1.5">
                      {unreadCount}
                    </Badge>
                  )}
                </a>
              </Link>
            );
          })}
        </nav>

        {/* User Profile & Logout */}
        <div className="p-3 border-t border-[oklch(0.65_0.22_195/0.2)] space-y-2">
          <div className="px-3 py-2 text-xs">
            <p className="text-muted-foreground tracking-widest">LOGGED IN</p>
            <p className="font-bold text-foreground truncate">{user?.name || user?.email}</p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={logout}
            className="w-full text-xs tracking-widest gap-2"
          >
            <LogOut size={14} /> LOGOUT
          </Button>
        </div>
      </div>

      {/* Mobile Overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 md:hidden z-30"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="hidden md:flex items-center justify-between px-6 py-4 border-b border-[oklch(0.65_0.22_195/0.2)] bg-[oklch(0.09_0.015_260)]">
          <h1 className="text-lg font-bold tracking-widest uppercase" style={{ color: "oklch(0.72 0.28 330)" }}>
            {title || "AXIS"}
          </h1>
        </div>

        {/* Content Area - scrollable */}
        <div className="flex-1 overflow-y-auto">
          {children}
        </div>
      </div>
    </div>
  );
}
