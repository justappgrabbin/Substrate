import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import AxisDashboard from "./pages/AxisDashboard";
import ChatPage from "./pages/ChatPage";
import GitHubPage from "./pages/GitHubPage";
import GoalsPage from "./pages/GoalsPage";
import IncomePage from "./pages/IncomePage";
import NotificationsPage from "./pages/NotificationsPage";
import ProjectsPage from "./pages/ProjectsPage";
import ReadingPage from "./pages/ReadingPage";
import FriendsPage from "./pages/FriendsPage";
import AxisGoalsPage from "./pages/AxisGoalsPage";
import AutonomousPage from "./pages/AutonomousPage";
import SandboxPage from "./pages/SandboxPage";
import LandingPage from "./pages/LandingPage";

function Router() {
  return (
    <Switch>
      <Route path="/" component={LandingPage} />
      <Route path="/dashboard" component={AxisDashboard} />
      <Route path="/chat" component={ChatPage} />
      <Route path="/github" component={GitHubPage} />
      <Route path="/projects" component={ProjectsPage} />
      <Route path="/income" component={IncomePage} />
      <Route path="/goals" component={GoalsPage} />
      <Route path="/reading" component={ReadingPage} />
      <Route path="/friends" component={FriendsPage} />
      <Route path="/axis-goals" component={AxisGoalsPage} />
      <Route path="/autonomous" component={AutonomousPage} />
      <Route path="/sandbox" component={SandboxPage} />
      <Route path="/notifications" component={NotificationsPage} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster
            theme="dark"
            toastOptions={{
              style: {
                background: "oklch(0.09 0.015 260)",
                border: "1px solid oklch(0.65 0.22 195 / 0.4)",
                color: "oklch(0.92 0.02 200)",
              },
            }}
          />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
