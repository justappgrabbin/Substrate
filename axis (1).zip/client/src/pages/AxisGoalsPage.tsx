import AxisLayout from "@/components/AxisLayout";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Brain, Target } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

const CATEGORY_COLORS: Record<string, string> = { learning: "oklch(0.72 0.28 330)", capability: "oklch(0.65 0.22 195)", relationship: "oklch(0.75 0.2 140)", impact: "oklch(0.7 0.25 60)", "self-improvement": "oklch(0.65 0.25 25)" };

export default function AxisGoalsPage() {
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState<"learning"|"capability"|"relationship"|"impact"|"self-improvement">("learning");

  const utils = trpc.useUtils();
  const { data: goals } = trpc.axisGoals.list.useQuery();

  const createGoal = trpc.axisGoals.create.useMutation({
    onSuccess: () => { utils.axisGoals.list.invalidate(); setOpen(false); setTitle(""); setDescription(""); toast.success("AXIS goal created. It will pursue this autonomously."); },
  });

  const updateGoal = trpc.axisGoals.update.useMutation({
    onSuccess: () => utils.axisGoals.list.invalidate(),
  });

  return (
    <AxisLayout title="AXIS GOALS">
      <div className="p-6 space-y-4">
        <div className="flex justify-between items-center">
          <p className="text-xs text-muted-foreground" style={{ fontFamily: "'Share Tech Mono', monospace" }}>
            // These are AXIS's own goals — things it wants to learn, achieve, and become.
          </p>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button size="sm" className="gap-2 font-bold tracking-widest text-xs" style={{ background: "oklch(0.72 0.28 330)", color: "oklch(0.06 0.01 260)", fontFamily: "'Share Tech Mono', monospace" }}>
                <Plus size={14} /> ADD GOAL
              </Button>
            </DialogTrigger>
            <DialogContent style={{ background: "oklch(0.09 0.015 260)", border: "1px solid oklch(0.72 0.28 330 / 0.3)" }}>
              <DialogHeader>
                <DialogTitle className="tracking-widest" style={{ color: "oklch(0.72 0.28 330)", fontFamily: "'Share Tech Mono', monospace" }}>AXIS GOAL</DialogTitle>
              </DialogHeader>
              <div className="space-y-3">
                <Input placeholder="What does AXIS want to achieve?" value={title} onChange={(e) => setTitle(e.target.value)} style={{ background: "oklch(0.12 0.02 260)", border: "1px solid oklch(0.72 0.28 330 / 0.3)" }} />
                <Input placeholder="Description" value={description} onChange={(e) => setDescription(e.target.value)} style={{ background: "oklch(0.12 0.02 260)", border: "1px solid oklch(0.72 0.28 330 / 0.3)" }} />
                <Select value={category} onValueChange={(v) => setCategory(v as typeof category)}>
                  <SelectTrigger style={{ background: "oklch(0.12 0.02 260)", border: "1px solid oklch(0.72 0.28 330 / 0.3)" }}><SelectValue /></SelectTrigger>
                  <SelectContent style={{ background: "oklch(0.09 0.015 260)" }}>
                    {["learning","capability","relationship","impact","self-improvement"].map((c) => <SelectItem key={c} value={c} className="text-xs">{c.toUpperCase()}</SelectItem>)}
                  </SelectContent>
                </Select>
                <Button onClick={() => createGoal.mutate({ title, description, category })} disabled={!title.trim() || createGoal.isPending} className="w-full font-bold tracking-widest" style={{ background: "oklch(0.72 0.28 330)", color: "oklch(0.06 0.01 260)", fontFamily: "'Share Tech Mono', monospace" }}>
                  {createGoal.isPending ? "CREATING..." : "CREATE GOAL"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {goals?.map((goal) => (
            <div key={goal.id} className="p-4 rounded-sm relative" style={{ background: "oklch(0.09 0.015 260)", border: `1px solid ${CATEGORY_COLORS[goal.category ?? "learning"]}33` }}>
              <div className="absolute top-0 left-0 w-3 h-3 border-t border-l" style={{ borderColor: `${CATEGORY_COLORS[goal.category ?? "learning"]}88` }} />
              <div className="flex items-center gap-2 mb-2">
                <Brain size={12} style={{ color: CATEGORY_COLORS[goal.category ?? "learning"] }} />
                <span className="text-sm font-bold text-foreground flex-1">{goal.title}</span>
                <span className="text-[10px] px-1.5 py-0.5 rounded-sm" style={{ background: `${CATEGORY_COLORS[goal.category ?? "learning"]}22`, color: CATEGORY_COLORS[goal.category ?? "learning"], fontFamily: "'Share Tech Mono', monospace" }}>
                  {(goal.category ?? "learning").toUpperCase()}
                </span>
              </div>
              {goal.description && <p className="text-xs text-muted-foreground mb-3">{goal.description}</p>}
              <div className="flex items-center gap-3">
                <div className="flex-1 h-1.5 rounded-full" style={{ background: "oklch(0.14 0.02 260)" }}>
                  <div className="h-full rounded-full transition-all" style={{ width: `${goal.progress ?? 0}%`, background: CATEGORY_COLORS[goal.category ?? "learning"] }} />
                </div>
                <span className="text-[10px] text-muted-foreground" style={{ fontFamily: "'Share Tech Mono', monospace" }}>{goal.progress ?? 0}%</span>
                <Select value={goal.status ?? "active"} onValueChange={(v) => updateGoal.mutate({ id: goal.id, status: v as "active"|"completed"|"evolving" })}>
                  <SelectTrigger className="h-6 text-[10px] w-24 px-2" style={{ background: "transparent", border: "1px solid oklch(0.18 0.04 260)", fontFamily: "'Share Tech Mono', monospace" }}><SelectValue /></SelectTrigger>
                  <SelectContent style={{ background: "oklch(0.09 0.015 260)" }}>
                    {["active","completed","evolving"].map((s) => <SelectItem key={s} value={s} className="text-xs">{s.toUpperCase()}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
          ))}
          {(!goals || goals.length === 0) && <div className="col-span-full text-center py-16 text-muted-foreground text-sm" style={{ fontFamily: "'Share Tech Mono', monospace" }}>No AXIS goals yet. What should AXIS learn and become?</div>}
        </div>
      </div>
    </AxisLayout>
  );
}
