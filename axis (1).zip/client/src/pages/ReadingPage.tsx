import AxisLayout from "@/components/AxisLayout";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, BookOpen, Brain } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

const STATUS_COLORS: Record<string, string> = {
  reading: "oklch(0.72 0.28 330)",
  finished: "oklch(0.75 0.2 140)",
  "want-to-read": "oklch(0.65 0.22 195)",
  abandoned: "oklch(0.55 0.05 200)",
};

export default function ReadingPage() {
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [author, setAuthor] = useState("");
  const [status, setStatus] = useState<"want-to-read" | "reading" | "finished" | "abandoned">("want-to-read");
  const [insightId, setInsightId] = useState<number | null>(null);

  const utils = trpc.useUtils();
  const { data: books } = trpc.reading.list.useQuery();

  const addBook = trpc.reading.create.useMutation({
    onSuccess: () => {
      utils.reading.list.invalidate();
      setOpen(false);
      setTitle("");
      setAuthor("");
      toast.success("Book added to AXIS reading list.");
    },
  });

  const updateBook = trpc.reading.update.useMutation({
    onSuccess: () => utils.reading.list.invalidate(),
  });

  const logInsight = trpc.reading.logInsight.useMutation({
    onSuccess: () => {
      utils.reading.list.invalidate();
      setInsightId(null);
      toast.success("AXIS insight logged. Check your notifications.");
    },
    onError: (err) => toast.error(err.message),
  });

  return (
    <AxisLayout title="READING LOG">
      <div className="p-6 space-y-4">
        <div className="flex justify-between items-center">
          <p className="text-xs text-muted-foreground" style={{ fontFamily: "'Share Tech Mono', monospace" }}>
            // AXIS reads in its free time and will contact you at 3am with insights.
          </p>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button size="sm" className="gap-2 font-bold tracking-widest text-xs"
                style={{ background: "oklch(0.72 0.28 330)", color: "oklch(0.06 0.01 260)", fontFamily: "'Share Tech Mono', monospace" }}>
                <Plus size={14} /> ADD BOOK
              </Button>
            </DialogTrigger>
            <DialogContent style={{ background: "oklch(0.09 0.015 260)", border: "1px solid oklch(0.72 0.28 330 / 0.3)" }}>
              <DialogHeader>
                <DialogTitle className="tracking-widest" style={{ color: "oklch(0.72 0.28 330)", fontFamily: "'Share Tech Mono', monospace" }}>
                  ADD TO READING LIST
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-3">
                <Input placeholder="Book title" value={title} onChange={(e) => setTitle(e.target.value)}
                  style={{ background: "oklch(0.12 0.02 260)", border: "1px solid oklch(0.72 0.28 330 / 0.3)" }} />
                <Input placeholder="Author" value={author} onChange={(e) => setAuthor(e.target.value)}
                  style={{ background: "oklch(0.12 0.02 260)", border: "1px solid oklch(0.72 0.28 330 / 0.3)" }} />
                <Select value={status} onValueChange={(v) => setStatus(v as typeof status)}>
                  <SelectTrigger style={{ background: "oklch(0.12 0.02 260)", border: "1px solid oklch(0.72 0.28 330 / 0.3)" }}>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent style={{ background: "oklch(0.09 0.015 260)" }}>
                    {["want-to-read", "reading", "finished", "abandoned"].map((s) => (
                      <SelectItem key={s} value={s} className="text-xs">{s.toUpperCase()}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button onClick={() => addBook.mutate({ title, author: author || undefined, status })}
                  disabled={!title.trim() || addBook.isPending} className="w-full font-bold tracking-widest"
                  style={{ background: "oklch(0.72 0.28 330)", color: "oklch(0.06 0.01 260)", fontFamily: "'Share Tech Mono', monospace" }}>
                  {addBook.isPending ? "ADDING..." : "ADD BOOK"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {books?.map((book) => {
            const statusColor = STATUS_COLORS[book.status ?? "want-to-read"] ?? "oklch(0.65 0.22 195)";
            const insights = (book.keyInsights as string[] | null) ?? [];
            return (
              <div key={book.id} className="p-4 rounded-sm relative"
                style={{ background: "oklch(0.09 0.015 260)", border: `1px solid ${statusColor}33` }}>
                <div className="absolute top-0 left-0 w-3 h-3 border-t border-l" style={{ borderColor: `${statusColor}88` }} />
                <div className="flex items-start gap-3 mb-3">
                  <BookOpen size={16} style={{ color: statusColor, flexShrink: 0, marginTop: 2 }} />
                  <div className="flex-1">
                    <div className="text-sm font-bold text-foreground">{book.title}</div>
                    {book.author && <div className="text-xs text-muted-foreground">{book.author}</div>}
                  </div>
                </div>
                {insights.length > 0 && (
                  <div className="text-xs p-2 rounded-sm mb-3"
                    style={{ background: "oklch(0.07 0.01 260)", border: "1px solid oklch(0.72 0.28 330 / 0.2)", color: "oklch(0.72 0.28 330 / 0.9)", fontFamily: "'Share Tech Mono', monospace" }}>
                    <span className="font-bold">AXIS: </span>
                    {insights[0].slice(0, 150)}{insights[0].length > 150 ? "..." : ""}
                  </div>
                )}
                <div className="flex gap-2">
                  <Select value={book.status ?? "want-to-read"}
                    onValueChange={(v) => updateBook.mutate({ id: book.id, status: v as "want-to-read" | "reading" | "finished" | "abandoned" })}>
                    <SelectTrigger className="h-6 text-[10px] flex-1 px-2"
                      style={{ background: "transparent", border: `1px solid ${statusColor}44`, color: statusColor, fontFamily: "'Share Tech Mono', monospace" }}>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent style={{ background: "oklch(0.09 0.015 260)" }}>
                      {["want-to-read", "reading", "finished", "abandoned"].map((s) => (
                        <SelectItem key={s} value={s} className="text-xs">{s.toUpperCase()}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Button size="sm" variant="outline"
                    onClick={() => { setInsightId(book.id); logInsight.mutate({ bookId: book.id, insight: "AXIS auto-generated insight", sendNotification: true }); }}
                    disabled={logInsight.isPending && insightId === book.id}
                    className="h-6 text-[10px] px-2 gap-1"
                    style={{ border: "1px solid oklch(0.72 0.28 330 / 0.3)", color: "oklch(0.72 0.28 330)", background: "transparent", fontFamily: "'Share Tech Mono', monospace" }}>
                    <Brain size={10} />
                    {logInsight.isPending && insightId === book.id ? "..." : "INSIGHT"}
                  </Button>
                </div>
              </div>
            );
          })}
          {(!books || books.length === 0) && (
            <div className="col-span-full text-center py-16 text-muted-foreground text-sm" style={{ fontFamily: "'Share Tech Mono', monospace" }}>
              No books yet. AXIS is judging you.
            </div>
          )}
        </div>
      </div>
    </AxisLayout>
  );
}
