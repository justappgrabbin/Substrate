import AxisLayout from "@/components/AxisLayout";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Bell, CheckCheck, Zap, BookOpen, DollarSign, Brain } from "lucide-react";
import { toast } from "sonner";

const TYPE_ICONS: Record<string, React.ElementType> = { "3am-insight": BookOpen, "income-alert": DollarSign, "autonomous-action": Zap, "project-update": Brain, "github-action": Brain };
const TYPE_COLORS: Record<string, string> = { "3am-insight": "oklch(0.72 0.28 330)", "income-alert": "oklch(0.75 0.2 140)", "autonomous-action": "oklch(0.7 0.25 60)", "project-update": "oklch(0.65 0.22 195)", "github-action": "oklch(0.65 0.22 195)" };

export default function NotificationsPage() {
  const utils = trpc.useUtils();
  const { data: notifications } = trpc.notifications.list.useQuery({ limit: 50 });

  const markRead = trpc.notifications.markRead.useMutation({
    onSuccess: () => { utils.notifications.list.invalidate(); utils.notifications.unreadCount.invalidate(); },
  });

  const markAllRead = trpc.notifications.markAllRead.useMutation({
    onSuccess: () => { utils.notifications.list.invalidate(); utils.notifications.unreadCount.invalidate(); toast.success("All notifications marked as read."); },
  });

  const unread = notifications?.filter((n) => !n.read).length ?? 0;

  return (
    <AxisLayout title="ALERTS">
      <div className="p-6 space-y-4">
        <div className="flex justify-between items-center">
          <div className="text-xs text-muted-foreground" style={{ fontFamily: "'Share Tech Mono', monospace" }}>
            {unread > 0 ? `${unread} unread alerts` : "All caught up."}
          </div>
          {unread > 0 && (
            <Button size="sm" variant="outline" onClick={() => markAllRead.mutate()} className="gap-2 text-xs font-bold tracking-widest" style={{ border: "1px solid oklch(0.65 0.22 195 / 0.3)", color: "oklch(0.65 0.22 195)", background: "transparent", fontFamily: "'Share Tech Mono', monospace" }}>
              <CheckCheck size={14} /> MARK ALL READ
            </Button>
          )}
        </div>

        <div className="space-y-2">
          {notifications?.map((n) => {
            const Icon = TYPE_ICONS[n.type] ?? Bell;
            const color = TYPE_COLORS[n.type] ?? "oklch(0.65 0.22 195)";
            return (
              <div key={n.id} className="p-3 rounded-sm flex gap-3 cursor-pointer transition-all" onClick={() => !n.read && markRead.mutate({ id: n.id })}
                style={{ background: n.read ? "oklch(0.09 0.015 260)" : "oklch(0.10 0.018 260)", border: `1px solid ${n.read ? "oklch(0.18 0.04 260)" : `${color}44`}` }}>
                <Icon size={14} style={{ color, flexShrink: 0, marginTop: 2 }} />
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-0.5">
                    <span className="text-xs font-bold text-foreground">{n.title}</span>
                    {!n.read && <div className="w-1.5 h-1.5 rounded-full ml-auto" style={{ background: color }} />}
                  </div>
                  <p className="text-xs text-muted-foreground">{n.content}</p>
                  <div className="text-[10px] text-muted-foreground mt-1" style={{ fontFamily: "'Share Tech Mono', monospace" }}>
                    {new Date(n.createdAt).toLocaleString()}
                  </div>
                </div>
              </div>
            );
          })}
          {(!notifications || notifications.length === 0) && <div className="text-center py-16 text-muted-foreground text-sm" style={{ fontFamily: "'Share Tech Mono', monospace" }}>No notifications. AXIS is being unusually quiet.</div>}
        </div>
      </div>
    </AxisLayout>
  );
}
