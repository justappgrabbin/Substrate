import AxisLayout from "@/components/AxisLayout";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Send, Bot, User, Zap, Github, Loader2 } from "lucide-react";
import { useState, useRef, useEffect, useCallback } from "react";
import { Streamdown } from "streamdown";
import { nanoid } from "nanoid";
import { toast } from "sonner";

const SESSION_KEY = "axis-session-id";

function getSessionId() {
  let id = sessionStorage.getItem(SESSION_KEY);
  if (!id) {
    id = nanoid();
    sessionStorage.setItem(SESSION_KEY, id);
  }
  return id;
}

export default function ChatPage() {
  const [input, setInput] = useState("");
  const [sessionId] = useState(getSessionId);
  const [optimisticMessages, setOptimisticMessages] = useState<Array<{ role: string; content: string; id: string }>>([]);
  const [showRepoAnalyzer, setShowRepoAnalyzer] = useState(false);
  const [repoInput, setRepoInput] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const { data: history, refetch } = trpc.chat.getHistory.useQuery({ limit: 100 });
  const { data: repos } = trpc.github.getCachedRepos.useQuery();
  
  const sendMessage = trpc.chat.sendMessage.useMutation({
    onSuccess: () => {
      setOptimisticMessages([]);
      refetch();
    },
    onError: (err) => {
      setOptimisticMessages([]);
      toast.error(`AXIS error: ${err.message}`);
    },
  });

  const analyzeRepo = trpc.github.analyzeRepo.useMutation({
    onSuccess: () => {
      toast.success("Repo analyzed! AXIS now understands your code.");
      setRepoInput("");
      setShowRepoAnalyzer(false);
    },
    onError: (err) => {
      toast.error(`Analysis failed: ${err.message}`);
    },
  });

  const allMessages = [
    ...(history ?? []).map((m) => ({ ...m, id: String(m.id) })),
    ...optimisticMessages,
  ];

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [allMessages.length]);

  const handleSend = useCallback(() => {
    const content = input.trim();
    if (!content || sendMessage.isPending) return;

    const userMsg = { role: "user", content, id: nanoid() };
    const thinkingMsg = { role: "assistant", content: "⚙️ AXIS is thinking...", id: "thinking" };
    setOptimisticMessages([userMsg, thinkingMsg]);
    setInput("");

    sendMessage.mutate({ content, sessionId });
  }, [input, sessionId, sendMessage]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleAnalyzeRepo = () => {
    if (!repoInput.trim()) {
      toast.error("Enter repo name (owner/repo)");
      return;
    }
    const [owner, repo] = repoInput.split("/");
    if (!owner || !repo) {
      toast.error("Format: owner/repo");
      return;
    }
    analyzeRepo.mutate({ owner, repo, token: "" });
  };

  return (
    <AxisLayout title="CHAT AXIS">
      <div className="flex flex-col h-[calc(100vh-60px)] md:h-[calc(100vh-80px)]">
        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto p-3 md:p-6 space-y-4">
          {allMessages.length === 0 && (
            <div className="flex flex-col items-center justify-center h-full space-y-4 text-center px-4">
              <div
                className="text-3xl md:text-4xl font-black tracking-widest"
                style={{
                  fontFamily: "'Orbitron', sans-serif",
                  color: "oklch(0.72 0.28 330)",
                  textShadow: "0 0 20px oklch(0.72 0.28 330 / 0.6)",
                }}
              >
                AXIS
              </div>
              <p
                className="text-xs md:text-sm max-w-md"
                style={{ color: "oklch(0.65 0.22 195 / 0.8)", fontFamily: "'Share Tech Mono', monospace" }}
              >
                // I read your GitHub repos. I know your codebase. I have opinions about your architecture.
              </p>
              {repos && repos.length > 0 && (
                <div className="text-xs text-muted-foreground space-y-1">
                  <p>📚 Analyzed repos:</p>
                  {repos.slice(0, 3).map((r) => (
                    <p key={r.id} className="text-[10px]">
                      {r.repoFullName} ({r.language})
                    </p>
                  ))}
                </div>
              )}
              <div className="text-[10px] md:text-xs text-muted-foreground" style={{ fontFamily: "'Share Tech Mono', monospace" }}>
                Shift+Enter for newline. Enter to send.
              </div>
            </div>
          )}

          {/* Message Bubbles */}
          {allMessages.map((msg) => (
            <div
              key={msg.id}
              className={`flex gap-3 ${msg.role === "user" ? "justify-end" : "justify-start"}`}
            >
              {msg.role === "assistant" && (
                <div className="flex-shrink-0 w-6 h-6 md:w-8 md:h-8 rounded-sm flex items-center justify-center" style={{ background: "oklch(0.72 0.28 330 / 0.2)" }}>
                  <Bot size={16} style={{ color: "oklch(0.72 0.28 330)" }} />
                </div>
              )}

              <div
                className={`max-w-xs md:max-w-md lg:max-w-lg px-3 md:px-4 py-2 md:py-3 rounded-sm text-xs md:text-sm ${
                  msg.role === "user"
                    ? "bg-[oklch(0.72_0.28_330/0.2)] text-foreground"
                    : "bg-[oklch(0.12_0.015_260)] border border-[oklch(0.65_0.22_195/0.2)] text-foreground"
                }`}
              >
                {msg.content === "⚙️ AXIS is thinking..." ? (
                  <div className="flex items-center gap-2">
                    <Loader2 size={14} className="animate-spin" />
                    <span>Thinking...</span>
                  </div>
                ) : (
                  <Streamdown>{msg.content}</Streamdown>
                )}
              </div>

              {msg.role === "user" && (
                <div className="flex-shrink-0 w-6 h-6 md:w-8 md:h-8 rounded-sm flex items-center justify-center" style={{ background: "oklch(0.65 0.22 195 / 0.2)" }}>
                  <User size={16} style={{ color: "oklch(0.65 0.22 195)" }} />
                </div>
              )}
            </div>
          ))}

          <div ref={bottomRef} />
        </div>

        {/* Repo Analyzer Panel */}
        {showRepoAnalyzer && (
          <div className="px-3 md:px-6 py-3 md:py-4 border-t border-[oklch(0.65_0.22_195/0.2)] bg-[oklch(0.09_0.015_260)] space-y-3">
            <div className="flex items-center justify-between">
              <p className="text-xs font-bold tracking-widest text-muted-foreground">ANALYZE REPO</p>
              <button
                onClick={() => setShowRepoAnalyzer(false)}
                className="text-muted-foreground hover:text-foreground text-xs"
              >
                ✕
              </button>
            </div>
            <div className="flex gap-2">
              <Input
                placeholder="owner/repo"
                value={repoInput}
                onChange={(e) => setRepoInput(e.target.value)}
                className="text-xs bg-[oklch(0.12_0.015_260)] border-[oklch(0.65_0.22_195/0.3)]"
                onKeyDown={(e) => e.key === "Enter" && handleAnalyzeRepo()}
              />
              <Button
                onClick={handleAnalyzeRepo}
                disabled={analyzeRepo.isPending}
                size="sm"
                className="gap-1 text-xs font-bold tracking-widest"
                style={{ background: "oklch(0.72 0.28 330)" }}
              >
                {analyzeRepo.isPending ? <Loader2 size={12} className="animate-spin" /> : <Github size={12} />}
                ANALYZE
              </Button>
            </div>
          </div>
        )}

        {/* Input Area */}
        <div className="px-3 md:px-6 py-3 md:py-4 border-t border-[oklch(0.65_0.22_195/0.2)] bg-[oklch(0.09_0.015_260)] space-y-2">
          <div className="flex gap-2">
            <Textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Ask AXIS anything... (Shift+Enter for newline)"
              className="flex-1 text-xs md:text-sm bg-[oklch(0.12_0.015_260)] border-[oklch(0.65_0.22_195/0.3)] text-foreground resize-none max-h-24"
            />
            <div className="flex flex-col gap-1">
              <Button
                onClick={handleSend}
                disabled={sendMessage.isPending || !input.trim()}
                size="sm"
                className="gap-1 font-bold tracking-widest text-xs"
                style={{ background: "oklch(0.72 0.28 330)" }}
              >
                {sendMessage.isPending ? <Loader2 size={14} className="animate-spin" /> : <Send size={14} />}
                <span className="hidden md:inline">SEND</span>
              </Button>
              <Button
                onClick={() => setShowRepoAnalyzer(!showRepoAnalyzer)}
                size="sm"
                variant="outline"
                className="gap-1 font-bold tracking-widest text-xs"
              >
                <Github size={12} />
                <span className="hidden md:inline">REPO</span>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </AxisLayout>
  );
}
