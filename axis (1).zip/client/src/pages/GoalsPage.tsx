import AxisLayout from "@/components/AxisLayout";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Target, Brain, CheckCircle2, Clock } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Streamdown } from "streamdown";

const PRIORITY_COLORS: Record<string, string> = {
  critical: "oklch(0.65 0.25 25)",
  high: "oklch(0.72 0.28 330)",
  medium: "oklch(0.7 0.25 60)",
  low: "oklch(0.65 0.22 195)",
};

export default function GoalsPage() {
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [priority, setPriority] = useState<"critical" | "high" | "medium" | "low">("medium");
  const [verdictId, setVerdictId] = useState<number | null>(null);

  const utils = trpc.useUtils();
  const { data: goals } = trpc.goals.list.useQuery();

  const createGoal = trpc.goals.create.useMutation({
    onSuccess: () => {
      utils.goals.list.invalidate();
      setOpen(false);
      setTitle("");
      setDescription("");
      toast.success("Goal set. AXIS is holding you accountable.");
    },
  });

  const updateGoal = trpc.goals.update.useMutation({
    onSuccess: () => utils.goals.list.invalidate(),
  });

  const getVerdict = trpc.goals.getAxisVerdict.useMutation({
    onSuccess: (data) => {
      utils.goals.list.invalidate();
      setVerdictId(null);
      toast.success("AXIS verdict delivered.");
    },
    onError: (err) => toast.error(err.message),
  });

  return (
    <AxisLayout title="GOALS">
      <div className="p-6 space-y-4">
        <div className="flex justify-end">
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button size="sm" className="gap-2 font-bold tracking-widest text-xs"
                style={{ background: "oklch(0.72 0.28 330)", color: "oklch(0.06 0.01 260)", fontFamily: "'Share Tech Mono', monospace" }}>
                <Plus size={14} /> NEW GOAL
              </Button>
            </DialogTrigger>
            <DialogContent style={{ background: "oklch(0.09 0.015 260)", border: "1px solid oklch(0.72 0.28 330 / 0.3)" }}>
              <DialogHeader>
                <DialogTitle className="tracking-widest" style={{ color: "oklch(0.72 0.28 330)", fontFamily: "'Share Tech Mono', monospace" }}>
                  SET A GOAL
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-3">
                <Input placeholder="Goal title" value={title} onChange={(e) => setTitle(e.target.value)}
                  style={{ background: "oklch(0.12 0.02 260)", border: "1px solid oklch(0.72 0.28 330 / 0.3)" }} />
                <Input placeholder="Description (optional)" value={description} onChange={(e) => setDescription(e.target.value)}
                  style={{ background: "oklch(0.12 0.02 260)", border: "1px solid oklch(0.72 0.28 330 / 0.3)" }} />
                <Select value={priority} onValueChange={(v) => setPriority(v as typeof priority)}>
                  <SelectTrigger style={{ background: "oklch(0.12 0.02 260)", border: "1px solid oklch(0.72 0.28 330 / 0.3)" }}>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent style={{ background: "oklch(0.09 0.015 260)" }}>
                    {["critical", "high", "medium", "low"].map((p) => (
                      <SelectItem key={p} value={p} className="text-xs">{p.toUpperCase()}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button onClick={() => createGoal.mutate({ title, description, priority })}
                  disabled={!title.trim() || createGoal.isPending} className="w-full font-bold tracking-widest"
                  style={{ background: "oklch(0.72 0.28 330)", color: "oklch(0.06 0.01 260)", fontFamily: "'Share Tech Mono', monospace" }}>
                  {createGoal.isPending ? "CREATING..." : "SET GOAL"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <div className="space-y-3">
          {goals?.map((goal) => (
            <div key={goal.id} className="p-4 rounded-sm relative"
              style={{ background: "oklch(0.09 0.015 260)", border: `1px solid ${PRIORITY_COLORS[goal.priority ?? "medium"]}33` }}>
              <div className="absolute top-0 left-0 w-3 h-3 border-t border-l" style={{ borderColor: `${PRIORITY_COLORS[goal.priority ?? "medium"]}88` }} />
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <Target size={12} style={{ color: PRIORITY_COLORS[goal.priority ?? "medium"] }} />
                    <span className="text-sm font-bold text-foreground">{goal.title}</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded-sm ml-auto" style={{
                      background: `${PRIORITY_COLORS[goal.priority ?? "medium"]}22`,
                      color: PRIORITY_COLORS[goal.priority ?? "medium"],
                      fontFamily: "'Share Tech Mono', monospace",
                    }}>{(goal.priority ?? "medium").toUpperCase()}</span>
                  </div>
                  {goal.description && <p className="text-xs text-muted-foreground mb-2">{goal.description}</p>}
                  {goal.axisVerdict && (
                    <div className="text-xs p-2 rounded-sm mb-2" style={{
                      background: "oklch(0.07 0.01 260)",
                      border: "1px solid oklch(0.72 0.28 330 / 0.2)",
                      color: "oklch(0.72 0.28 330 / 0.9)",
                      fontFamily: "'Share Tech Mono', monospace",
                    }}>
                      <span className="font-bold">AXIS: </span>{goal.axisVerdict.slice(0, 200)}{goal.axisVerdict.length > 200 ? "..." : ""}
                    </div>
                  )}
                  <div className="flex items-center gap-3">
                    <Select value={goal.status ?? "pending"} onValueChange={(v) => updateGoal.mutate({ id: goal.id, status: v as "pending" | "in-progress" | "completed" | "dropped" })}>
                      <SelectTrigger className="h-6 text-[10px] w-28 px-2" style={{ background: "transparent", border: "1px solid oklch(0.18 0.04 260)", fontFamily: "'Share Tech Mono', monospace" }}>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent style={{ background: "oklch(0.09 0.015 260)" }}>
                        {["pending", "in-progress", "completed", "dropped"].map((s) => (
                          <SelectItem key={s} value={s} className="text-xs">{s.toUpperCase()}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Button size="sm" variant="outline" onClick={() => { setVerdictId(goal.id); getVerdict.mutate({ id: goal.id }); }}
                      disabled={getVerdict.isPending && verdictId === goal.id}
                      className="h-6 text-[10px] px-2 gap-1"
                      style={{ border: "1px solid oklch(0.72 0.28 330 / 0.3)", color: "oklch(0.72 0.28 330)", background: "transparent", fontFamily: "'Share Tech Mono', monospace" }}>
                      <Brain size={10} />
                      {getVerdict.isPending && verdictId === goal.id ? "THINKING..." : "AXIS VERDICT"}
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          ))}
          {(!goals || goals.length === 0) && (
            <div className="text-center py-16 text-muted-foreground text-sm" style={{ fontFamily: "'Share Tech Mono', monospace" }}>
              No goals set. AXIS is disappointed but not surprised.
            </div>
          )}
        </div>
      </div>
    </AxisLayout>
  );
}
