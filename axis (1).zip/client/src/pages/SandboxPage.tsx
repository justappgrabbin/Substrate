import AxisLayout from "@/components/AxisLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Trash2, Play, Copy, Download, Upload } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Streamdown } from "streamdown";

interface SandboxFile {
  id: string;
  name: string;
  language: string;
  content: string;
  createdAt: Date;
}

export default function SandboxPage() {
  const [files, setFiles] = useState<SandboxFile[]>([
    {
      id: "1",
      name: "hello.js",
      language: "javascript",
      content: "console.log('AXIS is thinking...');",
      createdAt: new Date(),
    },
  ]);
  const [selectedFileId, setSelectedFileId] = useState<string>("1");
  const [newFileName, setNewFileName] = useState("");
  const [newFileLanguage, setNewFileLanguage] = useState("javascript");
  const [output, setOutput] = useState("");
  const [isRunning, setIsRunning] = useState(false);

  const selectedFile = files.find((f) => f.id === selectedFileId);

  const createFile = () => {
    if (!newFileName.trim()) {
      toast.error("File name required");
      return;
    }
    const newFile: SandboxFile = {
      id: Date.now().toString(),
      name: newFileName,
      language: newFileLanguage,
      content: "",
      createdAt: new Date(),
    };
    setFiles([...files, newFile]);
    setSelectedFileId(newFile.id);
    setNewFileName("");
    toast.success(`Created ${newFileName}`);
  };

  const updateFile = (content: string) => {
    setFiles(
      files.map((f) => (f.id === selectedFileId ? { ...f, content } : f))
    );
  };

  const deleteFile = (id: string) => {
    if (files.length === 1) {
      toast.error("Can't delete the last file");
      return;
    }
    setFiles(files.filter((f) => f.id !== id));
    if (selectedFileId === id) {
      setSelectedFileId(files[0]?.id || "");
    }
    toast.success("File deleted");
  };

  const runCode = async () => {
    if (!selectedFile) return;
    setIsRunning(true);
    setOutput("⚙️ AXIS is executing...\n");
    
    // Simulate code execution (in real app, would send to backend sandbox)
    setTimeout(() => {
      try {
        // For JavaScript, we can use eval (dangerous in production, but this is a sandbox)
        if (selectedFile.language === "javascript") {
          const logs: string[] = [];
          const originalLog = console.log;
          console.log = (...args: any[]) => {
            logs.push(args.map((a) => String(a)).join(" "));
            originalLog(...args);
          };
          
          eval(selectedFile.content);
          
          console.log = originalLog;
          setOutput(logs.join("\n") || "✓ Execution complete (no output)");
        } else {
          setOutput(`✓ ${selectedFile.language} execution not yet implemented`);
        }
      } catch (error) {
        setOutput(`✗ Error: ${error instanceof Error ? error.message : String(error)}`);
      }
      setIsRunning(false);
    }, 500);
  };

  const copyToClipboard = () => {
    if (!selectedFile) return;
    navigator.clipboard.writeText(selectedFile.content);
    toast.success("Copied to clipboard");
  };

  const downloadFile = () => {
    if (!selectedFile) return;
    const element = document.createElement("a");
    element.setAttribute("href", `data:text/plain;charset=utf-8,${encodeURIComponent(selectedFile.content)}`);
    element.setAttribute("download", selectedFile.name);
    element.style.display = "none";
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
    toast.success("Downloaded");
  };

  return (
    <AxisLayout title="AXIS SANDBOX">
      <div className="h-full flex flex-col md:flex-row gap-4 p-4 md:p-6">
        {/* File List - Left sidebar on desktop, top on mobile */}
        <div className="w-full md:w-48 flex flex-col gap-3 md:border-r md:border-[oklch(0.65_0.22_195/0.2)] md:pr-4">
          <div className="flex gap-2">
            <Dialog>
              <DialogTrigger asChild>
                <Button size="sm" className="flex-1 gap-2 font-bold tracking-widest text-xs" style={{ background: "oklch(0.72 0.28 330)" }}>
                  <Plus size={14} /> NEW
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-[oklch(0.09_0.015_260)] border-[oklch(0.65_0.22_195/0.3)]">
                <DialogHeader>
                  <DialogTitle className="text-[oklch(0.72_0.28_330)]">CREATE FILE</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <Input
                    placeholder="filename.js"
                    value={newFileName}
                    onChange={(e) => setNewFileName(e.target.value)}
                    className="bg-[oklch(0.12_0.015_260)] border-[oklch(0.65_0.22_195/0.3)] text-foreground"
                  />
                  <select
                    value={newFileLanguage}
                    onChange={(e) => setNewFileLanguage(e.target.value)}
                    className="w-full px-3 py-2 bg-[oklch(0.12_0.015_260)] border border-[oklch(0.65_0.22_195/0.3)] rounded-sm text-foreground text-sm"
                  >
                    <option>javascript</option>
                    <option>python</option>
                    <option>html</option>
                    <option>css</option>
                    <option>json</option>
                  </select>
                  <Button onClick={createFile} className="w-full font-bold tracking-widest" style={{ background: "oklch(0.72 0.28 330)" }}>
                    CREATE
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          {/* File List */}
          <div className="space-y-1 overflow-y-auto max-h-96 md:max-h-none">
            {files.map((file) => (
              <div
                key={file.id}
                className={`flex items-center gap-2 p-2 rounded-sm cursor-pointer transition-colors ${
                  selectedFileId === file.id
                    ? "bg-[oklch(0.15_0.02_260)] border border-[oklch(0.72_0.28_330/0.4)]"
                    : "hover:bg-[oklch(0.12_0.015_260)]"
                }`}
                onClick={() => setSelectedFileId(file.id)}
              >
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-bold truncate text-foreground">{file.name}</p>
                  <p className="text-[10px] text-muted-foreground">{file.language}</p>
                </div>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    deleteFile(file.id);
                  }}
                  className="text-muted-foreground hover:text-[oklch(0.65_0.25_25)]"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Editor & Output - Right side */}
        <div className="flex-1 flex flex-col gap-4 min-h-0">
          {selectedFile && (
            <>
              {/* Editor */}
              <div className="flex-1 flex flex-col gap-2 min-h-0">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs font-bold tracking-widest text-muted-foreground">EDITING</p>
                    <p className="text-sm font-bold text-foreground">{selectedFile.name}</p>
                  </div>
                  <div className="flex gap-1">
                    <Button size="sm" variant="ghost" onClick={copyToClipboard} className="text-xs gap-1">
                      <Copy size={12} /> COPY
                    </Button>
                    <Button size="sm" variant="ghost" onClick={downloadFile} className="text-xs gap-1">
                      <Download size={12} /> SAVE
                    </Button>
                  </div>
                </div>

                <Textarea
                  value={selectedFile.content}
                  onChange={(e) => updateFile(e.target.value)}
                  placeholder="Write your code here..."
                  className="flex-1 font-mono text-xs bg-[oklch(0.08_0.01_260)] border-[oklch(0.65_0.22_195/0.3)] text-foreground resize-none"
                  style={{ fontFamily: "'Share Tech Mono', monospace" }}
                />
              </div>

              {/* Run Button */}
              <Button
                onClick={runCode}
                disabled={isRunning}
                className="gap-2 font-bold tracking-widest text-sm"
                style={{ background: "oklch(0.75 0.2 140)" }}
              >
                <Play size={16} /> {isRunning ? "EXECUTING..." : "RUN CODE"}
              </Button>

              {/* Output */}
              <div className="flex-1 flex flex-col gap-2 min-h-0 md:max-h-64">
                <p className="text-xs font-bold tracking-widest text-muted-foreground">OUTPUT</p>
                <div
                  className="flex-1 p-3 rounded-sm bg-[oklch(0.08_0.01_260)] border border-[oklch(0.65_0.22_195/0.2)] overflow-y-auto"
                  style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: "12px", color: "oklch(0.72 0.28 330)" }}
                >
                  <pre className="whitespace-pre-wrap break-words">{output}</pre>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </AxisLayout>
  );
}
