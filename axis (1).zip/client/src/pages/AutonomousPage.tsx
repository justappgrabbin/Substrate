import AxisLayout from "@/components/AxisLayout";
import { trpc } from "@/lib/trpc";
import { Zap, CheckCircle2, Clock } from "lucide-react";

const ACTION_COLORS: Record<string, string> = { "project-score": "oklch(0.65 0.22 195)", "income-alert": "oklch(0.75 0.2 140)", "3am-insight": "oklch(0.72 0.28 330)", "github-action": "oklch(0.7 0.25 60)", "goal-update": "oklch(0.65 0.25 25)" };

export default function AutonomousPage() {
  const { data: actions } = trpc.autonomous.list.useQuery({ limit: 50 });

  return (
    <AxisLayout title="AUTONOMOUS ACTIONS">
      <div className="p-6 space-y-4">
        <div className="p-3 rounded-sm text-xs" style={{ background: "oklch(0.09 0.015 260)", border: "1px solid oklch(0.7 0.25 60 / 0.3)", color: "oklch(0.7 0.25 60)", fontFamily: "'Share Tech Mono', monospace" }}>
          ⚡ AXIS takes action autonomously when confidence ≥ 75%. All actions are logged here. You are notified after the fact.
        </div>

        <div className="space-y-3">
          {actions?.map((action) => (
            <div key={action.id} className="p-4 rounded-sm relative" style={{ background: "oklch(0.09 0.015 260)", border: `1px solid ${ACTION_COLORS[action.actionType] ?? "oklch(0.18 0.04 260)"}33` }}>
              <div className="absolute top-0 left-0 w-3 h-3 border-t border-l" style={{ borderColor: `${ACTION_COLORS[action.actionType] ?? "oklch(0.18 0.04 260)"}88` }} />
              <div className="flex items-start gap-3">
                <Zap size={14} style={{ color: ACTION_COLORS[action.actionType] ?? "oklch(0.65 0.22 195)", flexShrink: 0, marginTop: 2 }} />
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-bold tracking-widest" style={{ color: ACTION_COLORS[action.actionType] ?? "oklch(0.65 0.22 195)", fontFamily: "'Share Tech Mono', monospace" }}>
                      {action.actionType.toUpperCase()}
                    </span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded-sm ml-auto" style={{ background: "oklch(0.75 0.2 140 / 0.15)", color: "oklch(0.75 0.2 140)", fontFamily: "'Share Tech Mono', monospace" }}>
                      {(action.confidence * 100).toFixed(0)}% CONFIDENCE
                    </span>
                  </div>
                  <p className="text-sm text-foreground mb-2">{action.description}</p>
                  {action.reasoning && <p className="text-xs text-muted-foreground mb-2 italic">{action.reasoning}</p>}
                  <div className="flex items-center gap-3 text-[10px] text-muted-foreground" style={{ fontFamily: "'Share Tech Mono', monospace" }}>
                    <span className={action.notified ? "text-[oklch(0.75_0.2_140)]" : "text-[oklch(0.65_0.25_25)]"}>
                      {action.notified ? "✓ NOTIFIED" : "PENDING NOTIFICATION"}
                    </span>
                    <span>{new Date(action.createdAt).toLocaleString()}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
          {(!actions || actions.length === 0) && (
            <div className="text-center py-16 text-muted-foreground text-sm" style={{ fontFamily: "'Share Tech Mono', monospace" }}>
              No autonomous actions yet. AXIS is watching. Waiting. Calculating.
            </div>
          )}
        </div>
      </div>
    </AxisLayout>
  );
}
