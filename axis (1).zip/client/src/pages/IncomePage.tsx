import AxisLayout from "@/components/AxisLayout";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, DollarSign, TrendingUp, AlertTriangle, Zap } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Streamdown } from "streamdown";

export default function IncomePage() {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [amount, setAmount] = useState("");
  const [frequency, setFrequency] = useState<"daily"|"weekly"|"monthly"|"one-time"|"irregular">("monthly");
  const [opportunities, setOpportunities] = useState<string | null>(null);

  const utils = trpc.useUtils();
  const { data: streams } = trpc.income.list.useQuery();
  const { data: summary } = trpc.income.getSummary.useQuery();

  const createStream = trpc.income.create.useMutation({
    onSuccess: () => { utils.income.list.invalidate(); utils.income.getSummary.invalidate(); setOpen(false); setName(""); setAmount(""); toast.success("Income stream added."); },
  });

  const updateStream = trpc.income.update.useMutation({
    onSuccess: () => { utils.income.list.invalidate(); utils.income.getSummary.invalidate(); },
  });

  const { data: opportunitiesData, isLoading: opLoading, refetch: refetchOpportunities } = trpc.income.getOpportunities.useQuery(undefined, { enabled: false });

  const STATUS_COLORS: Record<string, string> = { active: "oklch(0.75 0.2 140)", lost: "oklch(0.55 0.05 200)", "at-risk": "oklch(0.65 0.25 25)" };

  return (
    <AxisLayout title="INCOME">
      <div className="p-6 space-y-5">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { label: "MONTHLY EST.", value: `$${(summary?.monthlyTotal ?? 0).toFixed(0)}`, color: "oklch(0.75 0.2 140)" },
            { label: "ACTIVE STREAMS", value: summary?.active ?? 0, color: "oklch(0.65 0.22 195)" },
            { label: "AT RISK", value: summary?.atRisk ?? 0, color: "oklch(0.65 0.25 25)" },
            { label: "STATUS", value: summary?.isHealthy ? "HEALTHY" : "WARNING", color: summary?.isHealthy ? "oklch(0.75 0.2 140)" : "oklch(0.65 0.25 25)" },
          ].map(({ label, value, color }) => (
            <div key={label} className="p-3 rounded-sm" style={{ background: "oklch(0.09 0.015 260)", border: `1px solid ${color}33` }}>
              <div className="text-[10px] tracking-widest text-muted-foreground mb-1" style={{ fontFamily: "'Share Tech Mono', monospace" }}>{label}</div>
              <div className="text-xl font-bold" style={{ color, fontFamily: "'Orbitron', sans-serif" }}>{value}</div>
            </div>
          ))}
        </div>

        <div className="flex gap-3">
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button size="sm" className="gap-2 font-bold tracking-widest text-xs" style={{ background: "oklch(0.75 0.2 140)", color: "oklch(0.06 0.01 260)", fontFamily: "'Share Tech Mono', monospace" }}>
                <Plus size={14} /> ADD STREAM
              </Button>
            </DialogTrigger>
            <DialogContent style={{ background: "oklch(0.09 0.015 260)", border: "1px solid oklch(0.75 0.2 140 / 0.3)" }}>
              <DialogHeader>
                <DialogTitle className="tracking-widest" style={{ color: "oklch(0.75 0.2 140)", fontFamily: "'Share Tech Mono', monospace" }}>ADD INCOME STREAM</DialogTitle>
              </DialogHeader>
              <div className="space-y-3">
                <Input placeholder="Stream name (e.g. Freelance, SaaS, Consulting)" value={name} onChange={(e) => setName(e.target.value)} style={{ background: "oklch(0.12 0.02 260)", border: "1px solid oklch(0.75 0.2 140 / 0.3)" }} />
                <Input placeholder="Monthly amount ($)" type="number" value={amount} onChange={(e) => setAmount(e.target.value)} style={{ background: "oklch(0.12 0.02 260)", border: "1px solid oklch(0.75 0.2 140 / 0.3)" }} />
                <Select value={frequency} onValueChange={(v) => setFrequency(v as typeof frequency)}>
                  <SelectTrigger style={{ background: "oklch(0.12 0.02 260)", border: "1px solid oklch(0.75 0.2 140 / 0.3)" }}><SelectValue /></SelectTrigger>
                  <SelectContent style={{ background: "oklch(0.09 0.015 260)" }}>
                    {["daily","weekly","monthly","one-time","irregular"].map((f) => <SelectItem key={f} value={f} className="text-xs">{f.toUpperCase()}</SelectItem>)}
                  </SelectContent>
                </Select>
                <Button onClick={() => createStream.mutate({ name, amount: parseFloat(amount) || 0, frequency })} disabled={!name.trim() || createStream.isPending} className="w-full font-bold tracking-widest" style={{ background: "oklch(0.75 0.2 140)", color: "oklch(0.06 0.01 260)", fontFamily: "'Share Tech Mono', monospace" }}>
                  {createStream.isPending ? "ADDING..." : "ADD STREAM"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
          <Button size="sm" variant="outline" onClick={() => refetchOpportunities()} disabled={opLoading} className="gap-2 font-bold tracking-widest text-xs" style={{ border: "1px solid oklch(0.72 0.28 330 / 0.4)", color: "oklch(0.72 0.28 330)", background: "transparent", fontFamily: "'Share Tech Mono', monospace" }}>
            <Zap size={14} />{opLoading ? "AXIS THINKING..." : "FIND OPPORTUNITIES"}
          </Button>
        </div>

        {opportunitiesData && (
          <div className="p-4 rounded-sm" style={{ background: "oklch(0.09 0.015 260)", border: "1px solid oklch(0.72 0.28 330 / 0.3)" }}>
            <div className="text-xs font-bold tracking-widest mb-3" style={{ color: "oklch(0.72 0.28 330)", fontFamily: "'Share Tech Mono', monospace" }}>AXIS OPPORTUNITIES</div>
            <div className="prose prose-invert prose-sm max-w-none"><Streamdown>{String(opportunitiesData.opportunities)}</Streamdown></div>
          </div>
        )}

        <div className="space-y-3">
          {streams?.map((s) => (
            <div key={s.id} className="p-4 rounded-sm flex items-center gap-4" style={{ background: "oklch(0.09 0.015 260)", border: `1px solid ${STATUS_COLORS[s.status ?? "active"]}33` }}>
              <DollarSign size={16} style={{ color: STATUS_COLORS[s.status ?? "active"], flexShrink: 0 }} />
              <div className="flex-1">
                <div className="text-sm font-bold text-foreground">{s.name}</div>
                <div className="text-xs text-muted-foreground" style={{ fontFamily: "'Share Tech Mono', monospace" }}>{s.frequency?.toUpperCase()} · ${s.amount?.toFixed(0)}</div>
              </div>
              <Select value={s.status ?? "active"} onValueChange={(v) => updateStream.mutate({ id: s.id, status: v as "active"|"at-risk"|"lost" })}>
                <SelectTrigger className="h-7 text-[10px] w-24 px-2" style={{ background: "transparent", border: `1px solid ${STATUS_COLORS[s.status ?? "active"]}44`, color: STATUS_COLORS[s.status ?? "active"], fontFamily: "'Share Tech Mono', monospace" }}><SelectValue /></SelectTrigger>
                <SelectContent style={{ background: "oklch(0.09 0.015 260)" }}>
                  {["active","at-risk","lost"].map((st) => <SelectItem key={st} value={st} className="text-xs">{st.toUpperCase()}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          ))}
          {(!streams || streams.length === 0) && <div className="text-center py-16 text-muted-foreground text-sm" style={{ fontFamily: "'Share Tech Mono', monospace" }}>No income streams. AXIS is concerned. Let's fix that.</div>}
        </div>
      </div>
    </AxisLayout>
  );
}
