import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";
import { useLocation } from "wouter";

const BOOT_LINES = [
  "AXIS v2.0 — INITIALIZING...",
  "Loading personality matrix... [FUNNY] [HONEST] [DAREDEVIL]",
  "Connecting to business intelligence core...",
  "Scanning project portfolio...",
  "Calibrating 75% confidence threshold...",
  "Reading list loaded. 47 books queued.",
  "Income monitoring: ACTIVE",
  "Autonomous action engine: ARMED",
  "3am ping system: ENABLED (sorry not sorry)",
  "AXIS ONLINE. Let's build something.",
];

export default function LandingPage() {
  const { isAuthenticated, loading } = useAuth();
  const [, setLocation] = useLocation();
  const [bootLines, setBootLines] = useState<string[]>([]);
  const [bootDone, setBootDone] = useState(false);

  useEffect(() => {
    if (isAuthenticated) {
      setLocation("/dashboard");
      return;
    }

    let i = 0;
    const interval = setInterval(() => {
      if (i < BOOT_LINES.length) {
        setBootLines((prev) => [...prev, BOOT_LINES[i]]);
        i++;
      } else {
        clearInterval(interval);
        setTimeout(() => setBootDone(true), 400);
      }
    }, 180);

    return () => clearInterval(interval);
  }, [isAuthenticated]);

  if (loading) return null;

  return (
    <div
      className="min-h-screen flex flex-col items-center justify-center relative overflow-hidden"
      style={{
        background: "oklch(0.06 0.01 260)",
        backgroundImage:
          "linear-gradient(oklch(0.65 0.22 195 / 0.04) 1px, transparent 1px), linear-gradient(90deg, oklch(0.65 0.22 195 / 0.04) 1px, transparent 1px)",
        backgroundSize: "40px 40px",
      }}
    >
      {/* Ambient glow */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            "radial-gradient(ellipse 60% 40% at 50% 50%, oklch(0.72 0.28 330 / 0.06) 0%, transparent 70%)",
        }}
      />

      {/* HUD corners */}
      <div className="absolute top-6 left-6 w-8 h-8 border-t-2 border-l-2" style={{ borderColor: "oklch(0.65 0.22 195 / 0.5)" }} />
      <div className="absolute top-6 right-6 w-8 h-8 border-t-2 border-r-2" style={{ borderColor: "oklch(0.65 0.22 195 / 0.5)" }} />
      <div className="absolute bottom-6 left-6 w-8 h-8 border-b-2 border-l-2" style={{ borderColor: "oklch(0.65 0.22 195 / 0.5)" }} />
      <div className="absolute bottom-6 right-6 w-8 h-8 border-b-2 border-r-2" style={{ borderColor: "oklch(0.65 0.22 195 / 0.5)" }} />

      {/* Status line top */}
      <div
        className="absolute top-6 left-1/2 -translate-x-1/2 text-xs tracking-widest"
        style={{ color: "oklch(0.65 0.22 195 / 0.5)", fontFamily: "'Share Tech Mono', monospace" }}
      >
        SYS // AUTONOMOUS AI PARTNER // BUILD 2.0.0
      </div>

      <div className="relative z-10 text-center space-y-8 max-w-2xl px-8">
        {/* Logo */}
        <div>
          <h1
            className="text-8xl font-black tracking-[0.2em] mb-2"
            style={{
              fontFamily: "'Orbitron', sans-serif",
              color: "oklch(0.72 0.28 330)",
              textShadow:
                "0 0 10px oklch(0.72 0.28 330 / 1), 0 0 30px oklch(0.72 0.28 330 / 0.7), 0 0 60px oklch(0.72 0.28 330 / 0.4), 0 0 100px oklch(0.72 0.28 330 / 0.2)",
            }}
          >
            AXIS
          </h1>
          <div
            className="text-sm tracking-[0.4em] uppercase"
            style={{
              color: "oklch(0.65 0.22 195)",
              textShadow: "0 0 8px oklch(0.65 0.22 195 / 0.7)",
              fontFamily: "'Share Tech Mono', monospace",
            }}
          >
            Your Autonomous AI Business Partner
          </div>
        </div>

        {/* Boot terminal */}
        <div
          className="text-left p-4 rounded-sm text-xs space-y-1"
          style={{
            background: "oklch(0.08 0.012 260)",
            border: "1px solid oklch(0.65 0.22 195 / 0.2)",
            fontFamily: "'Share Tech Mono', monospace",
            minHeight: "200px",
          }}
        >
          <div style={{ color: "oklch(0.65 0.22 195 / 0.5)" }} className="mb-2">
            ─── BOOT SEQUENCE ──────────────────────────
          </div>
          {bootLines.map((line, i) => (
            <div
              key={i}
              className="flex gap-2"
              style={{
                color:
                  line.includes("ONLINE") || line.includes("ARMED") || line.includes("ACTIVE")
                    ? "oklch(0.75 0.2 140)"
                    : line.includes("sorry") || line.includes("47 books")
                    ? "oklch(0.72 0.28 330)"
                    : "oklch(0.65 0.22 195)",
              }}
            >
              <span style={{ color: "oklch(0.65 0.22 195 / 0.4)" }}>{">"}</span>
              {line}
            </div>
          ))}
          {!bootDone && bootLines.length > 0 && (
            <div style={{ color: "oklch(0.65 0.22 195)" }} className="animate-pulse">
              _
            </div>
          )}
        </div>

        {/* CTA */}
        {bootDone && (
          <div className="space-y-4 animate-in fade-in duration-500">
            <p
              className="text-sm"
              style={{ color: "oklch(0.65 0.22 195 / 0.8)", fontFamily: "'Share Tech Mono', monospace" }}
            >
              // I read books. I have opinions. I will contact you at 3am.
            </p>
            <Button
              onClick={() => (window.location.href = getLoginUrl())}
              size="lg"
              className="font-black tracking-widest text-base px-10 py-6"
              style={{
                background: "oklch(0.72 0.28 330)",
                color: "oklch(0.06 0.01 260)",
                boxShadow: "0 0 20px oklch(0.72 0.28 330 / 0.4), 0 0 40px oklch(0.72 0.28 330 / 0.2)",
                fontFamily: "'Orbitron', sans-serif",
              }}
            >
              INITIALIZE AXIS
            </Button>
            <p
              className="text-xs"
              style={{ color: "oklch(0.55 0.05 200)", fontFamily: "'Share Tech Mono', monospace" }}
            >
              Warning: AXIS will tell you when you're doing too much. You've been warned.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
