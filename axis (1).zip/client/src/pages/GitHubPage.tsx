import AxisLayout from "@/components/AxisLayout";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { GitBranch, GitCommit, Star, Eye, AlertCircle, Brain, Upload, Plus } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Streamdown } from "streamdown";

export default function GitHubPage() {
  const [token, setToken] = useState("");
  const [owner, setOwner] = useState("");
  const [repo, setRepo] = useState("");
  const [analysis, setAnalysis] = useState<string | null>(null);
  const [repoStats, setRepoStats] = useState<Record<string, unknown> | null>(null);
  const [commitMsg, setCommitMsg] = useState("");
  const [filePath, setFilePath] = useState("");
  const [fileContent, setFileContent] = useState("");
  const [branch, setBranch] = useState("main");
  const [newBranch, setNewBranch] = useState("");
  const [createBranchOpen, setCreateBranchOpen] = useState(false);

  const { data: savedRepos } = trpc.github.getCachedRepos.useQuery();
  const utils = trpc.useUtils();

  const analyzeRepo = trpc.github.analyzeRepo.useMutation({
    onSuccess: (data) => {
      setAnalysis(String(data.analysis));
      setRepoStats(data.stats as Record<string, unknown>);
      toast.success("AXIS has analyzed the repo.");
    },
    onError: (err) => toast.error(err.message),
  });

  const pushFile = trpc.github.pushFile.useMutation({
    onSuccess: () => {
      toast.success("File pushed to GitHub.");
      setCommitMsg("");
      setFilePath("");
      setFileContent("");
    },
    onError: (err) => toast.error(err.message),
  });

  const createBranch = trpc.github.createBranch.useMutation({
    onSuccess: () => {
      toast.success(`Branch ${newBranch} created.`);
      setCreateBranchOpen(false);
      setNewBranch("");
      utils.github.listRepos.invalidate();
    },
    onError: (err) => toast.error(err.message),
  });

  const stats = repoStats?.repo as Record<string, unknown> | undefined;

  return (
    <AxisLayout title="GITHUB">
      <div className="p-6 space-y-6">
        {/* Token + Repo input */}
        <div
          className="p-4 rounded-sm relative"
          style={{
            background: "oklch(0.09 0.015 260)",
            border: "1px solid oklch(0.65 0.22 195 / 0.3)",
          }}
        >
          <div className="absolute top-0 left-0 w-3 h-3 border-t border-l border-[oklch(0.65_0.22_195/0.7)]" />
          <div className="text-xs font-bold tracking-widest mb-3" style={{ color: "oklch(0.65 0.22 195)", fontFamily: "'Share Tech Mono', monospace" }}>
            REPOSITORY TARGET
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <Input
              placeholder="GitHub token (ghp_...)"
              type="password"
              value={token}
              onChange={(e) => setToken(e.target.value)}
              style={{ background: "oklch(0.12 0.02 260)", border: "1px solid oklch(0.65 0.22 195 / 0.3)" }}
            />
            <Input
              placeholder="Owner (username/org)"
              value={owner}
              onChange={(e) => setOwner(e.target.value)}
              style={{ background: "oklch(0.12 0.02 260)", border: "1px solid oklch(0.65 0.22 195 / 0.3)" }}
            />
            <Input
              placeholder="Repository name"
              value={repo}
              onChange={(e) => setRepo(e.target.value)}
              style={{ background: "oklch(0.12 0.02 260)", border: "1px solid oklch(0.65 0.22 195 / 0.3)" }}
            />
          </div>
          <div className="flex gap-3 mt-3">
            <Button
              onClick={() => analyzeRepo.mutate({ token, owner, repo })}
              disabled={!token || !owner || !repo || analyzeRepo.isPending}
              className="gap-2 font-bold tracking-widest text-xs"
              style={{
                background: "oklch(0.72 0.28 330)",
                color: "oklch(0.06 0.01 260)",
                fontFamily: "'Share Tech Mono', monospace",
              }}
            >
              <Brain size={14} />
              {analyzeRepo.isPending ? "AXIS ANALYZING..." : "ANALYZE WITH AXIS"}
            </Button>
          </div>
        </div>

        {/* Repo stats */}
        {stats && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { icon: Star, label: "STARS", value: stats.stargazers_count as number },
              { icon: Eye, label: "WATCHERS", value: stats.watchers_count as number },
              { icon: GitBranch, label: "LANGUAGE", value: stats.language as string ?? "N/A" },
              { icon: AlertCircle, label: "OPEN ISSUES", value: stats.open_issues_count as number },
            ].map(({ icon: Icon, label, value }) => (
              <div
                key={label}
                className="p-3 rounded-sm"
                style={{ background: "oklch(0.09 0.015 260)", border: "1px solid oklch(0.18 0.04 260)" }}
              >
                <div className="flex items-center gap-2 mb-1">
                  <Icon size={12} style={{ color: "oklch(0.65 0.22 195)" }} />
                  <span className="text-[10px] tracking-widest text-muted-foreground" style={{ fontFamily: "'Share Tech Mono', monospace" }}>
                    {label}
                  </span>
                </div>
                <div className="text-lg font-bold" style={{ color: "oklch(0.65 0.22 195)", fontFamily: "'Orbitron', sans-serif" }}>
                  {value}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Analysis */}
        {analysis && (
          <div
            className="p-4 rounded-sm relative"
            style={{
              background: "oklch(0.09 0.015 260)",
              border: "1px solid oklch(0.72 0.28 330 / 0.3)",
            }}
          >
            <div className="absolute top-0 left-0 w-3 h-3 border-t border-l border-[oklch(0.72_0.28_330/0.7)]" />
            <div className="text-xs font-bold tracking-widest mb-3" style={{ color: "oklch(0.72 0.28 330)", fontFamily: "'Share Tech Mono', monospace" }}>
              AXIS ANALYSIS
            </div>
            <div className="prose prose-invert prose-sm max-w-none text-foreground">
              <Streamdown>{analysis}</Streamdown>
            </div>
          </div>
        )}

        {/* Actions */}
        {token && owner && repo && (
          <Tabs defaultValue="push">
            <TabsList style={{ background: "oklch(0.09 0.015 260)", border: "1px solid oklch(0.18 0.04 260)" }}>
              <TabsTrigger value="push" className="text-xs tracking-widest" style={{ fontFamily: "'Share Tech Mono', monospace" }}>
                PUSH FILE
              </TabsTrigger>
              <TabsTrigger value="branch" className="text-xs tracking-widest" style={{ fontFamily: "'Share Tech Mono', monospace" }}>
                BRANCHES
              </TabsTrigger>
            </TabsList>

            <TabsContent value="push" className="space-y-3 mt-4">
              <div
                className="p-4 rounded-sm"
                style={{ background: "oklch(0.09 0.015 260)", border: "1px solid oklch(0.18 0.04 260)" }}
              >
                <div className="space-y-3">
                  <Input
                    placeholder="File path (e.g. src/index.ts)"
                    value={filePath}
                    onChange={(e) => setFilePath(e.target.value)}
                    style={{ background: "oklch(0.12 0.02 260)", border: "1px solid oklch(0.65 0.22 195 / 0.3)" }}
                  />
                  <Input
                    placeholder="Branch (default: main)"
                    value={branch}
                    onChange={(e) => setBranch(e.target.value)}
                    style={{ background: "oklch(0.12 0.02 260)", border: "1px solid oklch(0.65 0.22 195 / 0.3)" }}
                  />
                  <Textarea
                    placeholder="File content..."
                    value={fileContent}
                    onChange={(e) => setFileContent(e.target.value)}
                    rows={8}
                    style={{
                      background: "oklch(0.12 0.02 260)",
                      border: "1px solid oklch(0.65 0.22 195 / 0.3)",
                      fontFamily: "'Share Tech Mono', monospace",
                      fontSize: "12px",
                    }}
                  />
                  <Input
                    placeholder="Commit message"
                    value={commitMsg}
                    onChange={(e) => setCommitMsg(e.target.value)}
                    style={{ background: "oklch(0.12 0.02 260)", border: "1px solid oklch(0.65 0.22 195 / 0.3)" }}
                  />
                  <Button
                    onClick={() =>
                      pushFile.mutate({
                        token,
                        owner,
                        repo,
                        path: filePath,
                        content: fileContent,
                        message: commitMsg || "AXIS: automated commit",
                        branch: branch || "main",
                      })
                    }
                    disabled={!filePath || !fileContent || pushFile.isPending}
                    className="gap-2 font-bold tracking-widest text-xs"
                    style={{
                      background: "oklch(0.65 0.22 195)",
                      color: "oklch(0.06 0.01 260)",
                      fontFamily: "'Share Tech Mono', monospace",
                    }}
                  >
                    <Upload size={14} />
                    {pushFile.isPending ? "PUSHING..." : "PUSH TO GITHUB"}
                  </Button>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="branch" className="mt-4">
              <div
                className="p-4 rounded-sm space-y-3"
                style={{ background: "oklch(0.09 0.015 260)", border: "1px solid oklch(0.18 0.04 260)" }}
              >
                <div className="flex gap-3">
                  <Input
                    placeholder="New branch name"
                    value={newBranch}
                    onChange={(e) => setNewBranch(e.target.value)}
                    style={{ background: "oklch(0.12 0.02 260)", border: "1px solid oklch(0.65 0.22 195 / 0.3)" }}
                  />
                  <Button
                    onClick={() => createBranch.mutate({ token, owner, repo, branchName: newBranch, fromBranch: branch })}
                    disabled={!newBranch || createBranch.isPending}
                    className="gap-2 font-bold tracking-widest text-xs whitespace-nowrap"
                    style={{
                      background: "oklch(0.65 0.22 195)",
                      color: "oklch(0.06 0.01 260)",
                      fontFamily: "'Share Tech Mono', monospace",
                    }}
                  >
                    <Plus size={14} />
                    CREATE
                  </Button>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        )}

        {/* Saved repos */}
        {savedRepos && savedRepos.length > 0 && (
          <div>
            <div className="text-xs font-bold tracking-widest mb-3" style={{ color: "oklch(0.65 0.22 195)", fontFamily: "'Share Tech Mono', monospace" }}>
              ANALYZED REPOSITORIES
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {savedRepos.map((r) => (
                <div
                  key={r.id}
                  className="p-3 rounded-sm cursor-pointer hover:border-[oklch(0.65_0.22_195/0.4)] transition-colors"
                  style={{ background: "oklch(0.09 0.015 260)", border: "1px solid oklch(0.18 0.04 260)" }}
                  onClick={() => {
                    const [o, rp] = r.repoFullName.split("/");
                    setOwner(o);
                    setRepo(rp);
                  }}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <GitBranch size={12} style={{ color: "oklch(0.65 0.22 195)" }} />
                    <span className="text-xs font-bold text-foreground">{r.repoFullName}</span>
                    {r.language && (
                      <span className="text-[10px] text-muted-foreground ml-auto" style={{ fontFamily: "'Share Tech Mono', monospace" }}>
                        {r.language}
                      </span>
                    )}
                  </div>
                  {r.summary && (
                    <p className="text-xs text-muted-foreground line-clamp-2">{r.summary}</p>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </AxisLayout>
  );
}
