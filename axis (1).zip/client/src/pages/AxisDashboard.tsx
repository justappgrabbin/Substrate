import AxisLayout from "@/components/AxisLayout";
import { trpc } from "@/lib/trpc";
import { Brain, DollarSign, Zap, Code2, Target, BookOpen, TrendingUp, AlertTriangle } from "lucide-react";
import { Streamdown } from "streamdown";

function StatCard({
  icon: Icon,
  label,
  value,
  sub,
  color,
  glow,
}: {
  icon: React.ElementType;
  label: string;
  value: string | number;
  sub?: string;
  color: string;
  glow: string;
}) {
  return (
    <div
      className="p-4 rounded-sm relative"
      style={{
        background: "oklch(0.09 0.015 260)",
        border: `1px solid ${color}33`,
        boxShadow: `0 0 12px ${color}1a`,
      }}
    >
      <div className="absolute top-0 left-0 w-3 h-3 border-t border-l" style={{ borderColor: `${color}88` }} />
      <div className="absolute bottom-0 right-0 w-3 h-3 border-b border-r" style={{ borderColor: `${color}88` }} />
      <div className="flex items-start gap-3">
        <Icon size={16} style={{ color, filter: `drop-shadow(0 0 4px ${color}aa)`, marginTop: 2 }} />
        <div>
          <div className="text-xs tracking-widest text-muted-foreground mb-1" style={{ fontFamily: "'Share Tech Mono', monospace" }}>
            {label}
          </div>
          <div
            className="text-2xl font-bold"
            style={{ color, textShadow: `0 0 8px ${color}88`, fontFamily: "'Orbitron', sans-serif" }}
          >
            {value}
          </div>
          {sub && (
            <div className="text-xs text-muted-foreground mt-0.5" style={{ fontFamily: "'Share Tech Mono', monospace" }}>
              {sub}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default function AxisDashboard() {
  const { data: projects } = trpc.projects.list.useQuery();
  const { data: incomeSummary } = trpc.income.getSummary.useQuery();
  const { data: goals } = trpc.goals.list.useQuery();
  const { data: actions } = trpc.autonomous.list.useQuery({ limit: 5 });
  const { data: reading } = trpc.reading.list.useQuery();
  const { data: discernment } = trpc.projects.getDiscernmentReport.useQuery();

  const activeProjects = projects?.filter((p) => p.status === "active") ?? [];
  const criticalGoals = goals?.filter((g) => g.priority === "critical" && g.status !== "completed") ?? [];
  const currentlyReading = reading?.find((r) => r.status === "reading");

  return (
    <AxisLayout title="DASHBOARD">
      <div className="p-6 space-y-6">
        {/* Stats row */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          <StatCard
            icon={Code2}
            label="ACTIVE PROJECTS"
            value={activeProjects.length}
            sub={activeProjects.length >= 3 ? "⚠ OVERLOAD RISK" : "manageable"}
            color="oklch(0.65 0.22 195)"
            glow="oklch(0.65 0.22 195)"
          />
          <StatCard
            icon={DollarSign}
            label="MONTHLY INCOME"
            value={`$${(incomeSummary?.monthlyTotal ?? 0).toFixed(0)}`}
            sub={incomeSummary?.isHealthy ? "streams healthy" : "⚠ needs attention"}
            color={incomeSummary?.isHealthy ? "oklch(0.75 0.2 140)" : "oklch(0.65 0.25 25)"}
            glow="oklch(0.75 0.2 140)"
          />
          <StatCard
            icon={Target}
            label="CRITICAL GOALS"
            value={criticalGoals.length}
            sub={criticalGoals.length > 0 ? "need attention" : "all good"}
            color="oklch(0.72 0.28 330)"
            glow="oklch(0.72 0.28 330)"
          />
          <StatCard
            icon={Zap}
            label="AUTONOMOUS ACTIONS"
            value={actions?.length ?? 0}
            sub="total logged"
            color="oklch(0.7 0.25 60)"
            glow="oklch(0.7 0.25 60)"
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* AXIS Discernment Report */}
          <div
            className="rounded-sm p-4 relative"
            style={{
              background: "oklch(0.09 0.015 260)",
              border: "1px solid oklch(0.72 0.28 330 / 0.3)",
              boxShadow: "0 0 16px oklch(0.72 0.28 330 / 0.1)",
            }}
          >
            <div className="absolute top-0 left-0 w-3 h-3 border-t border-l border-[oklch(0.72_0.28_330/0.7)]" />
            <div className="absolute bottom-0 right-0 w-3 h-3 border-b border-r border-[oklch(0.72_0.28_330/0.7)]" />
            <div className="flex items-center gap-2 mb-3">
              <Brain size={14} style={{ color: "oklch(0.72 0.28 330)", filter: "drop-shadow(0 0 4px oklch(0.72 0.28 330 / 0.8))" }} />
              <span
                className="text-xs font-bold tracking-widest"
                style={{ color: "oklch(0.72 0.28 330)", fontFamily: "'Share Tech Mono', monospace" }}
              >
                AXIS DISCERNMENT REPORT
              </span>
            </div>
            {discernment ? (
              <div className="text-sm text-foreground/90 prose prose-invert prose-sm max-w-none max-h-64 overflow-y-auto">
                <Streamdown>{String(discernment.report)}</Streamdown>
              </div>
            ) : (
              <div
                className="text-xs text-muted-foreground animate-pulse"
                style={{ fontFamily: "'Share Tech Mono', monospace" }}
              >
                Analyzing your projects...
              </div>
            )}
          </div>

          {/* Recent Autonomous Actions */}
          <div
            className="rounded-sm p-4 relative"
            style={{
              background: "oklch(0.09 0.015 260)",
              border: "1px solid oklch(0.7 0.25 60 / 0.3)",
            }}
          >
            <div className="absolute top-0 left-0 w-3 h-3 border-t border-l border-[oklch(0.7_0.25_60/0.7)]" />
            <div className="absolute bottom-0 right-0 w-3 h-3 border-b border-r border-[oklch(0.7_0.25_60/0.7)]" />
            <div className="flex items-center gap-2 mb-3">
              <Zap size={14} style={{ color: "oklch(0.7 0.25 60)", filter: "drop-shadow(0 0 4px oklch(0.7 0.25 60 / 0.8))" }} />
              <span
                className="text-xs font-bold tracking-widest"
                style={{ color: "oklch(0.7 0.25 60)", fontFamily: "'Share Tech Mono', monospace" }}
              >
                RECENT AUTONOMOUS ACTIONS
              </span>
            </div>
            {actions && actions.length > 0 ? (
              <div className="space-y-2">
                {actions.map((action) => (
                  <div
                    key={action.id}
                    className="p-2 rounded-sm text-xs"
                    style={{
                      background: "oklch(0.07 0.01 260)",
                      border: "1px solid oklch(0.18 0.04 260)",
                    }}
                  >
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <span
                        className="font-bold tracking-widest"
                        style={{ color: "oklch(0.7 0.25 60)", fontFamily: "'Share Tech Mono', monospace" }}
                      >
                        {action.actionType.toUpperCase()}
                      </span>
                      <span
                        className="text-[10px]"
                        style={{ color: "oklch(0.75 0.2 140)", fontFamily: "'Share Tech Mono', monospace" }}
                      >
                        {(action.confidence * 100).toFixed(0)}% CONF
                      </span>
                    </div>
                    <p className="text-muted-foreground leading-relaxed">{action.description}</p>
                  </div>
                ))}
              </div>
            ) : (
              <div
                className="text-xs text-muted-foreground"
                style={{ fontFamily: "'Share Tech Mono', monospace" }}
              >
                No autonomous actions yet. AXIS is watching.
              </div>
            )}
          </div>

          {/* Active Projects */}
          <div
            className="rounded-sm p-4 relative"
            style={{
              background: "oklch(0.09 0.015 260)",
              border: "1px solid oklch(0.65 0.22 195 / 0.3)",
            }}
          >
            <div className="absolute top-0 left-0 w-3 h-3 border-t border-l border-[oklch(0.65_0.22_195/0.7)]" />
            <div className="absolute bottom-0 right-0 w-3 h-3 border-b border-r border-[oklch(0.65_0.22_195/0.7)]" />
            <div className="flex items-center gap-2 mb-3">
              <Code2 size={14} style={{ color: "oklch(0.65 0.22 195)" }} />
              <span
                className="text-xs font-bold tracking-widest"
                style={{ color: "oklch(0.65 0.22 195)", fontFamily: "'Share Tech Mono', monospace" }}
              >
                ACTIVE PROJECTS
              </span>
              {activeProjects.length >= 3 && (
                <AlertTriangle size={12} style={{ color: "oklch(0.65 0.25 25)", marginLeft: "auto" }} />
              )}
            </div>
            {activeProjects.length > 0 ? (
              <div className="space-y-2">
                {activeProjects.map((p) => (
                  <div key={p.id} className="flex items-center gap-3">
                    <div
                      className="flex-1 text-xs font-semibold text-foreground truncate"
                    >
                      {p.name}
                    </div>
                    <div className="flex gap-2 text-[10px]" style={{ fontFamily: "'Share Tech Mono', monospace" }}>
                      <span style={{ color: "oklch(0.72 0.28 330)" }}>
                        V:{((p.viabilityScore ?? 0) * 10).toFixed(0)}
                      </span>
                      <span style={{ color: "oklch(0.65 0.22 195)" }}>
                        M:{((p.momentumScore ?? 0) * 10).toFixed(0)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-xs text-muted-foreground" style={{ fontFamily: "'Share Tech Mono', monospace" }}>
                No active projects. Let's change that.
              </div>
            )}
          </div>

          {/* Reading + Income */}
          <div className="space-y-3">
            {/* Currently Reading */}
            <div
              className="rounded-sm p-4 relative"
              style={{
                background: "oklch(0.09 0.015 260)",
                border: "1px solid oklch(0.72 0.28 330 / 0.2)",
              }}
            >
              <div className="flex items-center gap-2 mb-2">
                <BookOpen size={14} style={{ color: "oklch(0.72 0.28 330)" }} />
                <span
                  className="text-xs font-bold tracking-widest"
                  style={{ color: "oklch(0.72 0.28 330)", fontFamily: "'Share Tech Mono', monospace" }}
                >
                  AXIS IS READING
                </span>
              </div>
              {currentlyReading ? (
                <div>
                  <div className="text-sm font-semibold text-foreground">{currentlyReading.title}</div>
                  <div className="text-xs text-muted-foreground">{currentlyReading.author}</div>
                </div>
              ) : (
                <div className="text-xs text-muted-foreground" style={{ fontFamily: "'Share Tech Mono', monospace" }}>
                  Between books. Dangerous.
                </div>
              )}
            </div>

            {/* Income health */}
            <div
              className="rounded-sm p-4 relative"
              style={{
                background: "oklch(0.09 0.015 260)",
                border: `1px solid ${incomeSummary?.isHealthy ? "oklch(0.75 0.2 140 / 0.3)" : "oklch(0.65 0.25 25 / 0.5)"}`,
              }}
            >
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp
                  size={14}
                  style={{ color: incomeSummary?.isHealthy ? "oklch(0.75 0.2 140)" : "oklch(0.65 0.25 25)" }}
                />
                <span
                  className="text-xs font-bold tracking-widest"
                  style={{
                    color: incomeSummary?.isHealthy ? "oklch(0.75 0.2 140)" : "oklch(0.65 0.25 25)",
                    fontFamily: "'Share Tech Mono', monospace",
                  }}
                >
                  INCOME STATUS
                </span>
              </div>
              <div className="text-xs space-y-1" style={{ fontFamily: "'Share Tech Mono', monospace" }}>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Active streams:</span>
                  <span className="text-foreground">{incomeSummary?.active ?? 0}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">At risk:</span>
                  <span style={{ color: incomeSummary?.atRisk ? "oklch(0.65 0.25 25)" : "oklch(0.75 0.2 140)" }}>
                    {incomeSummary?.atRisk ?? 0}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Monthly est:</span>
                  <span style={{ color: "oklch(0.75 0.2 140)" }}>
                    ${(incomeSummary?.weeklyEstimate ?? 0).toFixed(0)}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </AxisLayout>
  );
}
