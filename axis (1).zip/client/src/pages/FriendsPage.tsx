import AxisLayout from "@/components/AxisLayout";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Users, DollarSign, Bell, BellOff } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function FriendsPage() {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");

  const utils = trpc.useUtils();
  const { data: friends } = trpc.friends.list.useQuery();

  const addFriend = trpc.friends.create.useMutation({
    onSuccess: () => { utils.friends.list.invalidate(); setOpen(false); setName(""); setEmail(""); toast.success("Friend added. They'll receive opt-in income alerts."); },
  });

  const toggleAlerts = trpc.friends.update.useMutation({
    onSuccess: () => utils.friends.list.invalidate(),
  });

  return (
    <AxisLayout title="FRIENDS">
      <div className="p-6 space-y-4">
        <div className="flex justify-between items-center">
          <p className="text-xs text-muted-foreground" style={{ fontFamily: "'Share Tech Mono', monospace" }}>
            // Friends receive opt-in income opportunity alerts from AXIS.
          </p>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button size="sm" className="gap-2 font-bold tracking-widest text-xs" style={{ background: "oklch(0.65 0.22 195)", color: "oklch(0.06 0.01 260)", fontFamily: "'Share Tech Mono', monospace" }}>
                <Plus size={14} /> ADD FRIEND
              </Button>
            </DialogTrigger>
            <DialogContent style={{ background: "oklch(0.09 0.015 260)", border: "1px solid oklch(0.65 0.22 195 / 0.3)" }}>
              <DialogHeader>
                <DialogTitle className="tracking-widest" style={{ color: "oklch(0.65 0.22 195)", fontFamily: "'Share Tech Mono', monospace" }}>ADD FRIEND</DialogTitle>
              </DialogHeader>
              <div className="space-y-3">
                <Input placeholder="Name" value={name} onChange={(e) => setName(e.target.value)} style={{ background: "oklch(0.12 0.02 260)", border: "1px solid oklch(0.65 0.22 195 / 0.3)" }} />
                <Input placeholder="Email (for alerts)" type="email" value={email} onChange={(e) => setEmail(e.target.value)} style={{ background: "oklch(0.12 0.02 260)", border: "1px solid oklch(0.65 0.22 195 / 0.3)" }} />
                <Button onClick={() => addFriend.mutate({ name, email })} disabled={!name.trim() || addFriend.isPending} className="w-full font-bold tracking-widest" style={{ background: "oklch(0.65 0.22 195)", color: "oklch(0.06 0.01 260)", fontFamily: "'Share Tech Mono', monospace" }}>
                  {addFriend.isPending ? "ADDING..." : "ADD FRIEND"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <div className="space-y-3">
          {friends?.map((friend) => (
            <div key={friend.id} className="p-4 rounded-sm flex items-center gap-4" style={{ background: "oklch(0.09 0.015 260)", border: "1px solid oklch(0.65 0.22 195 / 0.2)" }}>
              <div className="w-8 h-8 rounded-sm flex items-center justify-center font-bold text-sm" style={{ background: "oklch(0.65 0.22 195 / 0.2)", border: "1px solid oklch(0.65 0.22 195 / 0.4)", color: "oklch(0.65 0.22 195)" }}>
                {friend.name[0].toUpperCase()}
              </div>
              <div className="flex-1">
                <div className="text-sm font-bold text-foreground">{friend.name}</div>
                {friend.email && <div className="text-xs text-muted-foreground" style={{ fontFamily: "'Share Tech Mono', monospace" }}>{friend.email}</div>}
              </div>
              <Button size="sm" variant="outline" onClick={() => toggleAlerts.mutate({ id: friend.id, optedIn: !friend.optedIn })} className="gap-2 text-[10px] h-7 px-2" style={{ border: `1px solid ${friend.optedIn ? "oklch(0.75 0.2 140 / 0.4)" : "oklch(0.18 0.04 260)"}`, color: friend.optedIn ? "oklch(0.75 0.2 140)" : "oklch(0.55 0.05 200)", background: "transparent", fontFamily: "'Share Tech Mono', monospace" }}>
                {friend.optedIn ? <><Bell size={10} /> ALERTS ON</> : <><BellOff size={10} /> ALERTS OFF</>}
              </Button>
            </div>
          ))}
          {(!friends || friends.length === 0) && <div className="text-center py-16 text-muted-foreground text-sm" style={{ fontFamily: "'Share Tech Mono', monospace" }}>No friends added. AXIS can help them make money too.</div>}
        </div>
      </div>
    </AxisLayout>
  );
}
