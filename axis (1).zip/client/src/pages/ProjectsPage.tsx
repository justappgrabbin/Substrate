import AxisLayout from "@/components/AxisLayout";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Brain, GitBranch, Zap, AlertTriangle } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Streamdown } from "streamdown";

const STATUS_COLORS: Record<string, string> = {
  active: "oklch(0.75 0.2 140)",
  paused: "oklch(0.7 0.25 60)",
  archived: "oklch(0.55 0.05 200)",
  shipped: "oklch(0.65 0.22 195)",
};

export default function ProjectsPage() {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [githubRepo, setGithubRepo] = useState("");
  const [scoringId, setScoringId] = useState<number | null>(null);

  const utils = trpc.useUtils();
  const { data: projects } = trpc.projects.list.useQuery();

  const createProject = trpc.projects.create.useMutation({
    onSuccess: () => {
      utils.projects.list.invalidate();
      setOpen(false);
      setName("");
      setDescription("");
      setGithubRepo("");
      toast.success("Project created. AXIS is watching it.");
    },
  });

  const updateProject = trpc.projects.update.useMutation({
    onSuccess: () => utils.projects.list.invalidate(),
  });

  const scoreProject = trpc.projects.scoreProject.useMutation({
    onSuccess: (data) => {
      utils.projects.list.invalidate();
      setScoringId(null);
      toast.success(`AXIS verdict: ${data.verdict}`);
    },
    onError: (err) => toast.error(err.message),
  });

  const activeCount = projects?.filter((p) => p.status === "active").length ?? 0;

  return (
    <AxisLayout title="PROJECTS">
      <div className="p-6 space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            {activeCount >= 3 && (
              <div
                className="flex items-center gap-2 text-xs px-3 py-1.5 rounded-sm"
                style={{
                  background: "oklch(0.65 0.25 25 / 0.15)",
                  border: "1px solid oklch(0.65 0.25 25 / 0.4)",
                  color: "oklch(0.65 0.25 25)",
                  fontFamily: "'Share Tech Mono', monospace",
                }}
              >
                <AlertTriangle size={12} />
                AXIS WARNING: {activeCount} active projects. This is how it starts.
              </div>
            )}
          </div>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button
                size="sm"
                className="gap-2 font-bold tracking-widest text-xs"
                style={{
                  background: "oklch(0.65 0.22 195)",
                  color: "oklch(0.06 0.01 260)",
                  fontFamily: "'Share Tech Mono', monospace",
                }}
              >
                <Plus size={14} />
                NEW PROJECT
              </Button>
            </DialogTrigger>
            <DialogContent
              style={{
                background: "oklch(0.09 0.015 260)",
                border: "1px solid oklch(0.65 0.22 195 / 0.3)",
              }}
            >
              <DialogHeader>
                <DialogTitle
                  className="tracking-widest"
                  style={{ color: "oklch(0.65 0.22 195)", fontFamily: "'Share Tech Mono', monospace" }}
                >
                  NEW PROJECT
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-3">
                <Input
                  placeholder="Project name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  style={{ background: "oklch(0.12 0.02 260)", border: "1px solid oklch(0.65 0.22 195 / 0.3)" }}
                />
                <Textarea
                  placeholder="What is this? Be specific. AXIS needs context."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={3}
                  style={{ background: "oklch(0.12 0.02 260)", border: "1px solid oklch(0.65 0.22 195 / 0.3)" }}
                />
                <Input
                  placeholder="GitHub repo (owner/repo)"
                  value={githubRepo}
                  onChange={(e) => setGithubRepo(e.target.value)}
                  style={{ background: "oklch(0.12 0.02 260)", border: "1px solid oklch(0.65 0.22 195 / 0.3)" }}
                />
                <Button
                  onClick={() => createProject.mutate({ name, description, githubRepo: githubRepo || undefined })}
                  disabled={!name.trim() || createProject.isPending}
                  className="w-full font-bold tracking-widest"
                  style={{
                    background: "oklch(0.65 0.22 195)",
                    color: "oklch(0.06 0.01 260)",
                    fontFamily: "'Share Tech Mono', monospace",
                  }}
                >
                  {createProject.isPending ? "CREATING..." : "CREATE PROJECT"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Projects grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {projects?.map((project) => (
            <div
              key={project.id}
              className="rounded-sm p-4 relative"
              style={{
                background: "oklch(0.09 0.015 260)",
                border: `1px solid ${STATUS_COLORS[project.status] ?? "oklch(0.18 0.04 260)"}33`,
              }}
            >
              <div className="absolute top-0 left-0 w-3 h-3 border-t border-l" style={{ borderColor: `${STATUS_COLORS[project.status]}88` }} />
              <div className="absolute bottom-0 right-0 w-3 h-3 border-b border-r" style={{ borderColor: `${STATUS_COLORS[project.status]}88` }} />

              <div className="flex items-start justify-between gap-2 mb-2">
                <h3 className="font-bold text-sm text-foreground">{project.name}</h3>
                <Select
                  value={project.status}
                  onValueChange={(val) =>
                    updateProject.mutate({ id: project.id, status: val as "active" | "paused" | "archived" | "shipped" })
                  }
                >
                  <SelectTrigger
                    className="h-6 text-[10px] w-24 px-2"
                    style={{
                      background: "transparent",
                      border: `1px solid ${STATUS_COLORS[project.status]}44`,
                      color: STATUS_COLORS[project.status],
                      fontFamily: "'Share Tech Mono', monospace",
                    }}
                  >
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent style={{ background: "oklch(0.09 0.015 260)", border: "1px solid oklch(0.18 0.04 260)" }}>
                    {["active", "paused", "archived", "shipped"].map((s) => (
                      <SelectItem key={s} value={s} className="text-xs">
                        {s.toUpperCase()}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {project.description && (
                <p className="text-xs text-muted-foreground mb-3 leading-relaxed line-clamp-2">{project.description}</p>
              )}

              {/* Scores */}
              <div className="flex gap-4 mb-3 text-xs" style={{ fontFamily: "'Share Tech Mono', monospace" }}>
                <div>
                  <span className="text-muted-foreground">VIABILITY </span>
                  <span style={{ color: "oklch(0.72 0.28 330)" }}>
                    {((project.viabilityScore ?? 0) * 10).toFixed(1)}/10
                  </span>
                </div>
                <div>
                  <span className="text-muted-foreground">MOMENTUM </span>
                  <span style={{ color: "oklch(0.65 0.22 195)" }}>
                    {((project.momentumScore ?? 0) * 10).toFixed(1)}/10
                  </span>
                </div>
              </div>

              {/* AXIS Notes */}
              {project.axisNotes && (
                <div
                  className="text-xs p-2 rounded-sm mb-3"
                  style={{
                    background: "oklch(0.07 0.01 260)",
                    border: "1px solid oklch(0.72 0.28 330 / 0.2)",
                    color: "oklch(0.72 0.28 330 / 0.9)",
                    fontFamily: "'Share Tech Mono', monospace",
                  }}
                >
                  <span className="font-bold">AXIS: </span>
                  {project.axisNotes.slice(0, 120)}
                  {project.axisNotes.length > 120 ? "..." : ""}
                </div>
              )}

              {/* GitHub */}
              {project.githubRepo && (
                <div className="flex items-center gap-1 text-xs text-muted-foreground mb-3">
                  <GitBranch size={10} />
                  <span style={{ fontFamily: "'Share Tech Mono', monospace" }}>{project.githubRepo}</span>
                </div>
              )}

              {/* Actions */}
              <Button
                size="sm"
                variant="outline"
                onClick={() => {
                  setScoringId(project.id);
                  scoreProject.mutate({ id: project.id });
                }}
                disabled={scoreProject.isPending && scoringId === project.id}
                className="w-full gap-2 text-xs font-bold tracking-widest"
                style={{
                  border: "1px solid oklch(0.72 0.28 330 / 0.3)",
                  color: "oklch(0.72 0.28 330)",
                  background: "transparent",
                  fontFamily: "'Share Tech Mono', monospace",
                }}
              >
                <Brain size={12} />
                {scoreProject.isPending && scoringId === project.id ? "AXIS THINKING..." : "GET AXIS VERDICT"}
              </Button>
            </div>
          ))}

          {(!projects || projects.length === 0) && (
            <div
              className="col-span-full text-center py-16 text-muted-foreground text-sm"
              style={{ fontFamily: "'Share Tech Mono', monospace" }}
            >
              No projects yet. Add one. AXIS will judge it immediately.
            </div>
          )}
        </div>
      </div>
    </AxisLayout>
  );
}
