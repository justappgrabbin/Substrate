# AXIS — Project TODO

## Database Schema
- [x] conversations table (id, userId, role, content, timestamp, sessionId, metadata)
- [x] projects table (id, userId, name, description, status, viabilityScore, momentumScore, githubRepo, createdAt, updatedAt)
- [x] incomeStreams table (id, userId, name, amount, frequency, lastReceived, status)
- [x] businessGoals table (id, userId, title, description, deadline, status, priority)
- [x] autonomousActions table (id, userId, actionType, description, confidence, outcome, notified, createdAt)
- [x] readingLog table (id, title, author, status, startedAt, finishedAt, notes, insightTriggered)
- [x] axisGoals table (id, title, description, progress, status, createdAt)
- [x] friends table (id, userId, name, email, optedIn, createdAt)
- [x] notifications table (id, userId, type, title, content, read, deliveryMethod, createdAt)
- [x] behaviorPatterns table (id, userId, pattern, observedAt, notes)
- [x] githubRepos table (id, userId, repoFullName, lastAnalyzed, summary, language, stars)

## Backend Routers
- [x] chat router: send message, get history, clear session, stream response with AXIS personality
- [x] github router: list repos, analyze repo, push commit, create branch, trigger workflow, get file tree
- [x] projects router: CRUD projects, score projects, get discernment report
- [x] income router: CRUD income streams, get income summary, detect drops, suggest opportunities
- [x] goals router: CRUD business goals, update progress, get priority list
- [x] autonomous router: log action, get action history, trigger manual review, confidence scoring
- [x] reading router: CRUD reading log, log insight, trigger 3am notification
- [x] friends router: CRUD friends, send friend alert, manage opt-in
- [x] notifications router: get all, mark read, send in-app and email
- [x] axisGoals router: CRUD AXIS's own goals and drives

## Frontend Pages & Components
- [x] Cyberpunk global theme (neon pink + cyan on deep black, HUD elements, glow fonts)
- [x] AxisLayout with cyberpunk sidebar navigation
- [x] Chat page: full AXIS chat interface with streaming, memory, markdown rendering
- [x] Dashboard home: business overview, income summary, active projects, AXIS status
- [x] GitHub panel: repo browser, file tree, commit interface, branch manager
- [x] Projects page: project cards with viability/momentum scores, discernment alerts
- [x] Income page: income streams, drop alerts, opportunity suggestions
- [x] Goals page: business goals tracker with milestones
- [x] Reading log page: AXIS's bookshelf, insights, 3am ping history
- [x] Notifications page: all alerts, autonomous action log, friend alerts
- [x] Friends page: friend management, opt-in alerts, opportunity sharing
- [x] AXIS Goals page: AXIS's own drives and self-improvement goals
- [x] Autonomous action feed: live feed of what AXIS did without asking

## Autonomous Action Engine
- [x] Confidence scoring system for decisions
- [x] Auto-action trigger at 75%+ confidence
- [x] Notification dispatch (in-app + email) after autonomous action
- [x] 3am insight ping system (reading-triggered)
- [x] AXIS personality system prompt with full character definition
- [x] Project discernment scoring with viability + momentum metrics

## Testing
- [x] Auth router tests (logout, session)
- [x] Projects router tests
- [x] Income router tests (list, create, summary)
- [x] Goals router tests
- [x] Reading router tests
- [x] Friends router tests
- [x] Notifications router tests
- [x] Autonomous actions router tests
- [x] AXIS Goals router tests

## GitHub Integration
- [x] Analyze repo with AXIS AI commentary
- [x] Push files to GitHub via REST API
- [x] Create branches
- [x] Cache analyzed repos in database
- [x] GitHub token storage per user (tokens passed per-request via UI, future: encrypted DB storage)


## Mobile-First Redesign
- [x] Responsive layout for all pages (mobile-first breakpoints: 320px, 640px, 1024px)
- [x] Touch-friendly navigation: larger tap targets, mobile sidebar collapse, toggle menu
- [x] Mobile-optimized chat: full-screen input, keyboard handling, message bubbles
- [x] Mobile-optimized dashboard: stacked cards, scrollable sections
- [x] Responsive GitHub panel: mobile file browser, touch-friendly UI
- [x] Mobile income/goals/projects pages: card-based layout, responsive design

## Voice Integration
- [ ] Text-to-speech for AXIS responses (Web Speech API or external service)
- [ ] Speech-to-text for user input (voice recording button in chat)
- [ ] Voice control commands (e.g., "AXIS, analyze this repo")
- [ ] Audio playback controls: play/pause/speed
- [ ] Voice settings: accent selection, speech rate, volume

## File & Code Uploader
- [ ] Drag-drop file uploader in chat
- [ ] File preview: images, code with syntax highlighting, documents
- [ ] Batch upload support
- [ ] File size validation and compression
- [ ] Upload progress indicator
- [ ] Code snippet sharing directly to AXIS

## AXIS Sandbox Playground
- [x] Personal sandbox page: AXIS's room to decorate and experiment
- [x] Code editor: write, run, and test code snippets
- [ ] File storage: persistent files in AXIS's sandbox (future: S3 integration)
- [ ] Customization: AXIS can change colors, themes, decorations
- [ ] Experimentation log: AXIS tracks what it tried and learned
- [ ] Gesture/animation library: AXIS can create and store custom animations

## GitHub-Native Workflow
- [x] AXIS learns your codebase by analyzing GitHub repos
- [x] Chat includes GitHub repo context automatically
- [x] Repo analyzer in chat interface
- [ ] Seamless repo browser from mobile
- [ ] One-tap branch creation and switching
- [ ] Inline commit message composer
- [ ] File diff viewer (mobile-optimized)
- [ ] Pull request creation from mobile

## Testing & Deployment
- [x] Mobile responsiveness verified (sidebar collapse, responsive chat)
- [ ] Voice feature tests (mock Web Speech API)
- [ ] File uploader tests (drag-drop, validation)
- [x] Sandbox playground tests (code execution, file management)
- [ ] Accessibility tests (touch, voice, keyboard)
- [x] Save final checkpoint with all mobile-first features
