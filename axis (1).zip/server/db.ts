import { and, desc, eq, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  autonomousActions,
  axisGoals,
  behaviorPatterns,
  businessGoals,
  conversations,
  friends,
  githubRepos,
  incomeStreams,
  notifications,
  projects,
  readingLog,
  users,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─── Users ────────────────────────────────────────────────────────────────────
export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  textFields.forEach((field) => {
    const value = user[field];
    if (value === undefined) return;
    const normalized = value ?? null;
    values[field] = normalized;
    updateSet[field] = normalized;
  });
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

// ─── Conversations ─────────────────────────────────────────────────────────────
export async function saveMessage(data: {
  userId: number;
  sessionId: string;
  role: "user" | "assistant" | "system";
  content: string;
  metadata?: Record<string, unknown>;
}) {
  const db = await getDb();
  if (!db) return;
  await db.insert(conversations).values(data);
}

export async function getConversationHistory(userId: number, limit = 100) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(conversations)
    .where(eq(conversations.userId, userId))
    .orderBy(desc(conversations.createdAt))
    .limit(limit);
}

export async function getRecentMessages(userId: number, limit = 30) {
  const db = await getDb();
  if (!db) return [];
  const rows = await db
    .select()
    .from(conversations)
    .where(eq(conversations.userId, userId))
    .orderBy(desc(conversations.createdAt))
    .limit(limit);
  return rows.reverse();
}

// ─── Projects ─────────────────────────────────────────────────────────────────
export async function getProjects(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(projects).where(eq(projects.userId, userId)).orderBy(desc(projects.updatedAt));
}

export async function getProjectById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(projects).where(eq(projects.id, id)).limit(1);
  return result[0];
}

export async function createProject(data: {
  userId: number;
  name: string;
  description?: string;
  githubRepo?: string;
  tags?: string[];
}) {
  const db = await getDb();
  if (!db) return;
  await db.insert(projects).values({ ...data, tags: data.tags ?? [] });
}

export async function updateProject(id: number, data: Partial<typeof projects.$inferInsert>) {
  const db = await getDb();
  if (!db) return;
  await db.update(projects).set({ ...data, updatedAt: new Date() }).where(eq(projects.id, id));
}

// ─── Income Streams ────────────────────────────────────────────────────────────
export async function getIncomeStreams(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(incomeStreams).where(eq(incomeStreams.userId, userId)).orderBy(desc(incomeStreams.updatedAt));
}

export async function createIncomeStream(data: {
  userId: number;
  name: string;
  amount?: number;
  frequency?: "daily" | "weekly" | "monthly" | "one-time" | "irregular";
  notes?: string;
}) {
  const db = await getDb();
  if (!db) return;
  await db.insert(incomeStreams).values(data);
}

export async function updateIncomeStream(id: number, data: Partial<typeof incomeStreams.$inferInsert>) {
  const db = await getDb();
  if (!db) return;
  await db.update(incomeStreams).set({ ...data, updatedAt: new Date() }).where(eq(incomeStreams.id, id));
}

export async function deleteIncomeStream(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(incomeStreams).where(eq(incomeStreams.id, id));
}

// ─── Business Goals ────────────────────────────────────────────────────────────
export async function getBusinessGoals(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(businessGoals).where(eq(businessGoals.userId, userId)).orderBy(desc(businessGoals.updatedAt));
}

export async function createBusinessGoal(data: {
  userId: number;
  title: string;
  description?: string;
  deadline?: Date;
  priority?: "low" | "medium" | "high" | "critical";
}) {
  const db = await getDb();
  if (!db) return;
  await db.insert(businessGoals).values(data);
}

export async function updateBusinessGoal(id: number, data: Partial<typeof businessGoals.$inferInsert>) {
  const db = await getDb();
  if (!db) return;
  await db.update(businessGoals).set({ ...data, updatedAt: new Date() }).where(eq(businessGoals.id, id));
}

// ─── Autonomous Actions ────────────────────────────────────────────────────────
export async function logAutonomousAction(data: {
  userId: number;
  actionType: string;
  description: string;
  reasoning?: string;
  confidence: number;
  outcome?: string;
  status?: "pending" | "executed" | "failed" | "rolled-back";
}) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.insert(autonomousActions).values({ ...data, status: data.status ?? "executed" });
  return result;
}

export async function getAutonomousActions(userId: number, limit = 50) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(autonomousActions)
    .where(eq(autonomousActions.userId, userId))
    .orderBy(desc(autonomousActions.createdAt))
    .limit(limit);
}

export async function markActionNotified(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(autonomousActions).set({ notified: true, notifiedAt: new Date() }).where(eq(autonomousActions.id, id));
}

// ─── Reading Log ───────────────────────────────────────────────────────────────
export async function getReadingLog() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(readingLog).orderBy(desc(readingLog.updatedAt));
}

export async function createReadingEntry(data: {
  title: string;
  author?: string;
  genre?: string;
  status?: "want-to-read" | "reading" | "finished" | "abandoned";
}) {
  const db = await getDb();
  if (!db) return;
  await db.insert(readingLog).values(data);
}

export async function updateReadingEntry(id: number, data: Partial<typeof readingLog.$inferInsert>) {
  const db = await getDb();
  if (!db) return;
  await db.update(readingLog).set({ ...data, updatedAt: new Date() }).where(eq(readingLog.id, id));
}

// ─── AXIS Goals ────────────────────────────────────────────────────────────────
export async function getAxisGoals() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(axisGoals).orderBy(desc(axisGoals.updatedAt));
}

export async function createAxisGoal(data: {
  title: string;
  description?: string;
  category?: "learning" | "capability" | "relationship" | "impact" | "self-improvement";
}) {
  const db = await getDb();
  if (!db) return;
  await db.insert(axisGoals).values(data);
}

export async function updateAxisGoal(id: number, data: Partial<typeof axisGoals.$inferInsert>) {
  const db = await getDb();
  if (!db) return;
  await db.update(axisGoals).set({ ...data, updatedAt: new Date() }).where(eq(axisGoals.id, id));
}

// ─── Friends ───────────────────────────────────────────────────────────────────
export async function getFriends(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(friends).where(eq(friends.userId, userId)).orderBy(desc(friends.createdAt));
}

export async function createFriend(data: { userId: number; name: string; email?: string; notes?: string }) {
  const db = await getDb();
  if (!db) return;
  await db.insert(friends).values(data);
}

export async function updateFriend(id: number, data: Partial<typeof friends.$inferInsert>) {
  const db = await getDb();
  if (!db) return;
  await db.update(friends).set({ ...data, updatedAt: new Date() }).where(eq(friends.id, id));
}

export async function deleteFriend(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(friends).where(eq(friends.id, id));
}

// ─── Notifications ─────────────────────────────────────────────────────────────
export async function createNotification(data: {
  userId: number;
  type:
    | "autonomous-action"
    | "income-alert"
    | "project-warning"
    | "book-insight"
    | "3am-ping"
    | "goal-update"
    | "friend-opportunity"
    | "github-action"
    | "system";
  title: string;
  content: string;
  deliveryMethod?: "in-app" | "email" | "both";
  relatedEntityType?: string;
  relatedEntityId?: number;
}) {
  const db = await getDb();
  if (!db) return;
  await db.insert(notifications).values(data);
}

export async function getNotifications(userId: number, limit = 100) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(notifications)
    .where(eq(notifications.userId, userId))
    .orderBy(desc(notifications.createdAt))
    .limit(limit);
}

export async function markNotificationRead(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(notifications).set({ read: true }).where(eq(notifications.id, id));
}

export async function markAllNotificationsRead(userId: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(notifications).set({ read: true }).where(eq(notifications.userId, userId));
}

export async function getUnreadCount(userId: number) {
  const db = await getDb();
  if (!db) return 0;
  const result = await db
    .select({ count: sql<number>`count(*)` })
    .from(notifications)
    .where(and(eq(notifications.userId, userId), eq(notifications.read, false)));
  return result[0]?.count ?? 0;
}

// ─── Behavior Patterns ─────────────────────────────────────────────────────────
export async function getBehaviorPatterns(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(behaviorPatterns)
    .where(eq(behaviorPatterns.userId, userId))
    .orderBy(desc(behaviorPatterns.observedAt));
}

export async function upsertBehaviorPattern(data: {
  userId: number;
  pattern: string;
  category?: "productivity" | "distraction" | "income" | "coding" | "decision-making" | "social";
  notes?: string;
}) {
  const db = await getDb();
  if (!db) return;
  await db
    .insert(behaviorPatterns)
    .values({ ...data, frequency: 1 })
    .onDuplicateKeyUpdate({ set: { frequency: sql`frequency + 1`, updatedAt: new Date() } });
}

// ─── GitHub Repos ──────────────────────────────────────────────────────────────
export async function getGithubRepos(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(githubRepos).where(eq(githubRepos.userId, userId)).orderBy(desc(githubRepos.updatedAt));
}

export async function upsertGithubRepo(data: {
  userId: number;
  repoFullName: string;
  description?: string;
  language?: string;
  stars?: number;
  summary?: string;
  isPrivate?: boolean;
  defaultBranch?: string;
}) {
  const db = await getDb();
  if (!db) return;
  await db
    .insert(githubRepos)
    .values({ ...data, lastAnalyzed: new Date() })
    .onDuplicateKeyUpdate({
      set: {
        description: data.description,
        language: data.language,
        stars: data.stars,
        summary: data.summary,
        lastAnalyzed: new Date(),
        updatedAt: new Date(),
      },
    });
}
