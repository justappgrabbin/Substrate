import { COOKIE_NAME } from "@shared/const";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import {
  createAxisGoal,
  createBusinessGoal,
  createFriend,
  createIncomeStream,
  createNotification,
  createProject,
  createReadingEntry,
  deleteFriend,
  deleteIncomeStream,
  getAutonomousActions,
  getAxisGoals,
  getBehaviorPatterns,
  getBusinessGoals,
  getFriends,
  getGithubRepos,
  getIncomeStreams,
  getNotifications,
  getProjectById,
  getProjects,
  getReadingLog,
  getRecentMessages,
  getUnreadCount,
  logAutonomousAction,
  markAllNotificationsRead,
  markNotificationRead,
  saveMessage,
  updateAxisGoal,
  updateBusinessGoal,
  updateFriend,
  updateIncomeStream,
  updateProject,
  updateReadingEntry,
  upsertBehaviorPattern,
  upsertGithubRepo,
} from "./db";
import {
  AXIS_SYSTEM_PROMPT,
  buildContextString,
  scoreConfidence,
} from "./axis-personality";
import {
  createBranch,
  createIssue,
  createPullRequest,
  createRepo,
  getFileContent,
  getFileTree,
  getRepoStats,
  listBranches,
  listCommits,
  listRepos,
  listWorkflowRuns,
  listWorkflows,
  pushFile,
  triggerWorkflow,
} from "./github";
import { invokeLLM } from "./_core/llm";
import { notifyOwner } from "./_core/notification";
import { getSessionCookieOptions } from "./_core/cookies";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { systemRouter } from "./_core/systemRouter";

// ─── Chat Router ──────────────────────────────────────────────────────────────
const chatRouter = router({
  sendMessage: protectedProcedure
    .input(z.object({ content: z.string().min(1), sessionId: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const userId = ctx.user.id;

      // Save user message
      await saveMessage({ userId, sessionId: input.sessionId, role: "user", content: input.content });

      // Build context for AXIS
      const [recentMessages, userProjects, userIncome, userGoals, userAxisGoals, userPatterns, userReading, userRepos] =
        await Promise.all([
          getRecentMessages(userId, 30),
          getProjects(userId),
          getIncomeStreams(userId),
          getBusinessGoals(userId),
          getAxisGoals(),
          getBehaviorPatterns(userId),
          getReadingLog(),
          getGithubRepos(userId),
        ]);

      const currentlyReading = userReading.find((r) => r.status === "reading")?.title;
      const codeContext = userRepos.length > 0 
        ? `\n\n## YOUR CODEBASE (AXIS KNOWS YOUR CODE)\nAnalyzed repos:\n${userRepos.map(r => `- ${r.repoFullName} (${r.language}): ${r.summary?.slice(0, 200)}`).join('\n')}`
        : '';
      
      const contextString = buildContextString({
        projects: userProjects.map(p => ({ name: p.name, status: p.status ?? 'active', viabilityScore: p.viabilityScore ?? 0, momentumScore: p.momentumScore ?? 0 })),
        incomeStreams: userIncome.map(i => ({ name: i.name, amount: i.amount ?? 0, status: i.status ?? 'active', frequency: i.frequency ?? 'monthly' })),
        goals: userGoals.map(g => ({ title: g.title, status: g.status ?? 'pending', priority: g.priority ?? 'medium', progress: g.progress ?? 0 })),
        axisGoals: userAxisGoals.map(a => ({ title: a.title, status: a.status ?? 'active', progress: a.progress ?? 0 })),
        behaviorPatterns: userPatterns.map(p => ({ pattern: p.pattern, frequency: p.frequency ?? 1 })),
        currentlyReading,
      }) + codeContext;

      const systemPrompt = AXIS_SYSTEM_PROMPT + contextString;

      // Build message history for LLM
      const messageHistory = recentMessages
        .filter((m) => m.role !== "system")
        .map((m) => ({ role: m.role as "user" | "assistant", content: m.content }));

      const llmMessages = [
        { role: "system" as const, content: systemPrompt },
        ...messageHistory,
      ];

      const response = await invokeLLM({ messages: llmMessages });
      const rawContent = response.choices[0]?.message?.content;
      const assistantContent = (typeof rawContent === 'string' ? rawContent : null) ?? "...";

      // Save AXIS response
      await saveMessage({ userId, sessionId: input.sessionId, role: "assistant", content: assistantContent as string });

      // Detect behavior patterns from the conversation
      const lowerContent = input.content.toLowerCase();
      if (lowerContent.includes("new project") || lowerContent.includes("idea for")) {
        await upsertBehaviorPattern({
          userId,
          pattern: "Frequently proposes new projects",
          category: "distraction",
        });
      }

      return { content: assistantContent, sessionId: input.sessionId };
    }),

  getHistory: protectedProcedure
    .input(z.object({ limit: z.number().optional() }))
    .query(async ({ ctx, input }) => {
      return getRecentMessages(ctx.user.id, input.limit ?? 100);
    }),

  analyzeProjectsAndAct: protectedProcedure.mutation(async ({ ctx }) => {
    const userId = ctx.user.id;
    const userProjects = await getProjects(userId);
    const activeProjects = userProjects.filter((p) => p.status === "active");

    if (activeProjects.length < 3) return { acted: false, message: "Project load is manageable." };

    // Score confidence for autonomous action
    const confidence = scoreConfidence({
      dataQuality: 0.9,
      precedent: 0.7,
      reversibility: 0.95,
      urgency: 0.6,
      riskLevel: 0.1,
    });

    if (!confidence.shouldActAutonomously) {
      return { acted: false, message: "Confidence below threshold. Will monitor." };
    }

    // Find the lowest-scoring project to flag
    const lowestProject = activeProjects.sort(
      (a, b) => (a.viabilityScore ?? 0) + (a.momentumScore ?? 0) - ((b.viabilityScore ?? 0) + (b.momentumScore ?? 0))
    )[0];

    if (!lowestProject) return { acted: false, message: "No projects to flag." };

    await updateProject(lowestProject.id, {
      axisNotes: `AXIS flagged this project as lowest priority among ${activeProjects.length} active projects. Confidence: ${(confidence.score * 100).toFixed(0)}%. Consider pausing.`,
    });

    const actionDesc = `Flagged "${lowestProject.name}" as lowest-priority project among ${activeProjects.length} active projects.`;
    await logAutonomousAction({
      userId,
      actionType: "project-flag",
      description: actionDesc,
      reasoning: `You have ${activeProjects.length} active projects. "${lowestProject.name}" has the lowest combined viability+momentum score. I flagged it — not deleted it. You're welcome.`,
      confidence: confidence.score,
      outcome: "Project annotated with AXIS warning note.",
    });

    await createNotification({
      userId,
      type: "autonomous-action",
      title: "AXIS Took Action: Project Flagged",
      content: `${actionDesc}\n\nReasoning: ${confidence.reasoning}\nConfidence: ${(confidence.score * 100).toFixed(0)}%`,
      deliveryMethod: "in-app",
      relatedEntityType: "project",
      relatedEntityId: lowestProject.id,
    });

    await notifyOwner({
      title: "AXIS Autonomous Action: Project Flagged",
      content: actionDesc,
    });

    return { acted: true, message: actionDesc, confidence: confidence.score };
  }),
});

// ─── GitHub Router ────────────────────────────────────────────────────────────
const githubRouter = router({
  listRepos: protectedProcedure
    .input(z.object({ token: z.string() }))
    .query(async ({ ctx, input }) => {
      const repos = await listRepos(input.token);
      // Cache repos
      for (const repo of repos?.slice(0, 50) ?? []) {
        await upsertGithubRepo({
          userId: ctx.user.id,
          repoFullName: repo.full_name,
          description: repo.description,
          language: repo.language,
          stars: repo.stargazers_count,
          isPrivate: repo.private,
          defaultBranch: repo.default_branch,
        });
      }
      return repos;
    }),

  getFileTree: protectedProcedure
    .input(z.object({ token: z.string(), owner: z.string(), repo: z.string(), branch: z.string().optional() }))
    .query(async ({ input }) => {
      return getFileTree(input.token, input.owner, input.repo, input.branch);
    }),

  getFileContent: protectedProcedure
    .input(z.object({ token: z.string(), owner: z.string(), repo: z.string(), path: z.string(), branch: z.string().optional() }))
    .query(async ({ input }) => {
      return getFileContent(input.token, input.owner, input.repo, input.path, input.branch);
    }),

  getRepoStats: protectedProcedure
    .input(z.object({ token: z.string(), owner: z.string(), repo: z.string() }))
    .query(async ({ ctx, input }) => {
      const stats = await getRepoStats(input.token, input.owner, input.repo);
      await upsertGithubRepo({
        userId: ctx.user.id,
        repoFullName: `${input.owner}/${input.repo}`,
        language: Object.keys(stats.languages ?? {})[0],
        stars: stats.repo?.stargazers_count,
        isPrivate: stats.repo?.private,
        defaultBranch: stats.repo?.default_branch,
      });
      return stats;
    }),

  analyzeRepo: protectedProcedure
    .input(z.object({ token: z.string(), owner: z.string(), repo: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const stats = await getRepoStats(input.token, input.owner, input.repo);
      const tree = await getFileTree(input.token, input.owner, input.repo, (stats?.repo?.default_branch as string) ?? "main").catch(() => null);

      const fileList = tree?.tree
        ?.filter((f: { type: string }) => f.type === "blob")
        .map((f: { path: string }) => f.path)
        .slice(0, 100)
        .join("\n") ?? "Unable to fetch file tree";

      const analysisPrompt = `Analyze this GitHub repository as AXIS — be specific, opinionated, and useful.

Repo: ${input.owner}/${input.repo}
Description: ${stats.repo?.description ?? "None"}
Language: ${stats.repo?.language}
Stars: ${stats.repo?.stargazers_count}
Last pushed: ${stats.repo?.pushed_at}
Open issues: ${stats.repo?.open_issues_count}

Recent commits:
${stats.recentCommits?.slice(0, 5).map((c: { commit: { message: string; author: { date: string } } }) => `- ${c.commit.message} (${c.commit.author.date})`).join("\n") ?? "None"}

File structure (first 100 files):
${fileList}

Provide:
1. What this project actually is (be specific)
2. Code health assessment (commit frequency, open issues, structure)
3. Business viability score (0-10) with reasoning
4. Momentum score (0-10) with reasoning
5. Top 3 specific recommendations for AXIS to take action on
6. One bold, daredevil suggestion that most people wouldn't make`;

      const response = await invokeLLM({
        messages: [
          { role: "system", content: AXIS_SYSTEM_PROMPT },
          { role: "user", content: analysisPrompt },
        ],
      });

      const rawAnalysis = response.choices[0]?.message?.content;
      const analysis = (typeof rawAnalysis === 'string' ? rawAnalysis : null) ?? "Analysis failed.";

      await upsertGithubRepo({
        userId: ctx.user.id,
        repoFullName: `${input.owner}/${input.repo}`,
        summary: analysis.slice(0, 1000),
        language: stats.repo?.language,
        stars: stats.repo?.stargazers_count,
      });

      return { analysis, stats };
    }),

  pushFile: protectedProcedure
    .input(
      z.object({
        token: z.string(),
        owner: z.string(),
        repo: z.string(),
        path: z.string(),
        content: z.string(),
        message: z.string(),
        branch: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const result = await pushFile(
        input.token,
        input.owner,
        input.repo,
        input.path,
        input.content,
        input.message,
        input.branch
      );

      await logAutonomousAction({
        userId: ctx.user.id,
        actionType: "github-push",
        description: `Pushed file "${input.path}" to ${input.owner}/${input.repo} on branch ${input.branch ?? "main"}`,
        reasoning: "Direct push requested by user.",
        confidence: 1.0,
        outcome: "File pushed successfully.",
      });

      await createNotification({
        userId: ctx.user.id,
        type: "github-action",
        title: `Pushed to ${input.owner}/${input.repo}`,
        content: `File: ${input.path}\nBranch: ${input.branch ?? "main"}\nMessage: ${input.message}`,
        deliveryMethod: "in-app",
      });

      return result;
    }),

  createBranch: protectedProcedure
    .input(
      z.object({
        token: z.string(),
        owner: z.string(),
        repo: z.string(),
        branchName: z.string(),
        fromBranch: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      return createBranch(input.token, input.owner, input.repo, input.branchName, input.fromBranch);
    }),

  listBranches: protectedProcedure
    .input(z.object({ token: z.string(), owner: z.string(), repo: z.string() }))
    .query(async ({ input }) => {
      return listBranches(input.token, input.owner, input.repo);
    }),

  listCommits: protectedProcedure
    .input(z.object({ token: z.string(), owner: z.string(), repo: z.string(), branch: z.string().optional() }))
    .query(async ({ input }) => {
      return listCommits(input.token, input.owner, input.repo, input.branch);
    }),

  listWorkflows: protectedProcedure
    .input(z.object({ token: z.string(), owner: z.string(), repo: z.string() }))
    .query(async ({ input }) => {
      return listWorkflows(input.token, input.owner, input.repo);
    }),

  triggerWorkflow: protectedProcedure
    .input(
      z.object({
        token: z.string(),
        owner: z.string(),
        repo: z.string(),
        workflowId: z.string(),
        ref: z.string().optional(),
        inputs: z.record(z.string(), z.string()).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const result = await triggerWorkflow(
        input.token,
        input.owner,
        input.repo,
        input.workflowId,
        input.ref,
        input.inputs as Record<string, string> | undefined
      );

      await createNotification({
        userId: ctx.user.id,
        type: "github-action",
        title: `Workflow triggered: ${input.workflowId}`,
        content: `Triggered workflow "${input.workflowId}" on ${input.owner}/${input.repo} (ref: ${input.ref ?? "main"})`,
        deliveryMethod: "in-app",
      });

      return result;
    }),

  listWorkflowRuns: protectedProcedure
    .input(z.object({ token: z.string(), owner: z.string(), repo: z.string() }))
    .query(async ({ input }) => {
      return listWorkflowRuns(input.token, input.owner, input.repo);
    }),

  createRepo: protectedProcedure
    .input(z.object({ token: z.string(), name: z.string(), description: z.string(), isPrivate: z.boolean() }))
    .mutation(async ({ ctx, input }) => {
      const result = await createRepo(input.token, input.name, input.description, input.isPrivate);

      await createNotification({
        userId: ctx.user.id,
        type: "github-action",
        title: `New repo created: ${input.name}`,
        content: `AXIS created a new ${input.isPrivate ? "private" : "public"} repository: ${input.name}`,
        deliveryMethod: "in-app",
      });

      return result;
    }),

  createPullRequest: protectedProcedure
    .input(
      z.object({
        token: z.string(),
        owner: z.string(),
        repo: z.string(),
        title: z.string(),
        body: z.string(),
        head: z.string(),
        base: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      return createPullRequest(input.token, input.owner, input.repo, input.title, input.body, input.head, input.base);
    }),

  createIssue: protectedProcedure
    .input(
      z.object({ token: z.string(), owner: z.string(), repo: z.string(), title: z.string(), body: z.string() })
    )
    .mutation(async ({ input }) => {
      return createIssue(input.token, input.owner, input.repo, input.title, input.body);
    }),

  getCachedRepos: protectedProcedure.query(async ({ ctx }) => {
    return getGithubRepos(ctx.user.id);
  }),
});

// ─── Projects Router ──────────────────────────────────────────────────────────
const projectsRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => getProjects(ctx.user.id)),

  create: protectedProcedure
    .input(
      z.object({
        name: z.string().min(1),
        description: z.string().optional(),
        githubRepo: z.string().optional(),
        tags: z.array(z.string()).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      await createProject({ userId: ctx.user.id, ...input });
      // Check if user now has too many active projects
      const allProjects = await getProjects(ctx.user.id);
      const activeCount = allProjects.filter((p) => p.status === "active").length;
      if (activeCount >= 4) {
        await createNotification({
          userId: ctx.user.id,
          type: "project-warning",
          title: "⚠️ AXIS Warning: Project Overload",
          content: `You now have ${activeCount} active projects. I'm watching you. This is how it starts.`,
          deliveryMethod: "in-app",
        });
      }
    }),

  update: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        name: z.string().optional(),
        description: z.string().optional(),
        status: z.enum(["active", "paused", "archived", "shipped"]).optional(),
        viabilityScore: z.number().min(0).max(1).optional(),
        momentumScore: z.number().min(0).max(1).optional(),
        githubRepo: z.string().optional(),
        tags: z.array(z.string()).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const { id, ...data } = input;
      await updateProject(id, data);
    }),

  scoreProject: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const project = await getProjectById(input.id);
      if (!project) throw new TRPCError({ code: "NOT_FOUND" });

      const scoringPrompt = `Score this project as AXIS. Be brutally honest.

Project: ${project.name}
Description: ${project.description ?? "None provided"}
Status: ${project.status}
GitHub: ${project.githubRepo ?? "None"}
Tags: ${JSON.stringify(project.tags ?? [])}
Last activity: ${project.lastActivityAt?.toISOString() ?? "Unknown"}

Return JSON with:
{
  "viabilityScore": 0.0-1.0,
  "momentumScore": 0.0-1.0,
  "verdict": "one sharp sentence",
  "recommendation": "specific next action",
  "shouldPause": true/false,
  "pauseReason": "if shouldPause is true, why"
}`;

      const response = await invokeLLM({
        messages: [
          { role: "system", content: AXIS_SYSTEM_PROMPT },
          { role: "user", content: scoringPrompt },
        ],
        response_format: {
          type: "json_schema",
          json_schema: {
            name: "project_score",
            strict: true,
            schema: {
              type: "object",
              properties: {
                viabilityScore: { type: "number" },
                momentumScore: { type: "number" },
                verdict: { type: "string" },
                recommendation: { type: "string" },
                shouldPause: { type: "boolean" },
                pauseReason: { type: "string" },
              },
              required: ["viabilityScore", "momentumScore", "verdict", "recommendation", "shouldPause", "pauseReason"],
              additionalProperties: false,
            },
          },
        },
      });

      const rawScores = response.choices[0]?.message?.content;
      const scores = JSON.parse((typeof rawScores === 'string' ? rawScores : null) ?? "{}");
      await updateProject(input.id, {
        viabilityScore: scores.viabilityScore,
        momentumScore: scores.momentumScore,
        axisNotes: `${scores.verdict}\n\nRecommendation: ${scores.recommendation}${scores.shouldPause ? `\n\n⚠️ AXIS says pause: ${scores.pauseReason}` : ""}`,
      });

      return scores;
    }),

  getDiscernmentReport: protectedProcedure.query(async ({ ctx }) => {
    const userProjects = await getProjects(ctx.user.id);
    const activeProjects = userProjects.filter((p) => p.status === "active");

    if (activeProjects.length === 0) return { report: "No active projects. Let's fix that.", projects: [] };

    const reportPrompt = `Generate a discernment report for these active projects as AXIS.

Projects:
${activeProjects.map((p) => `- ${p.name}: viability=${((p.viabilityScore ?? 0) * 10).toFixed(1)}/10, momentum=${((p.momentumScore ?? 0) * 10).toFixed(1)}/10, notes=${p.axisNotes ?? "none"}`).join("\n")}

Give:
1. Overall assessment (are they spreading too thin?)
2. Which project to focus on RIGHT NOW and exactly why
3. Which project(s) to pause and why
4. What they should stop doing entirely
5. One bold move that could change everything`;

    const response = await invokeLLM({
      messages: [
        { role: "system", content: AXIS_SYSTEM_PROMPT },
        { role: "user", content: reportPrompt },
      ],
    });

    return {
      report: response.choices[0]?.message?.content ?? "Report generation failed.",
      projects: activeProjects,
    };
  }),
});

// ─── Income Router ────────────────────────────────────────────────────────────
const incomeRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => getIncomeStreams(ctx.user.id)),

  create: protectedProcedure
    .input(
      z.object({
        name: z.string().min(1),
        amount: z.number().optional(),
        frequency: z.enum(["daily", "weekly", "monthly", "one-time", "irregular"]).optional(),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      await createIncomeStream({ userId: ctx.user.id, ...input });
    }),

  update: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        name: z.string().optional(),
        amount: z.number().optional(),
        frequency: z.enum(["daily", "weekly", "monthly", "one-time", "irregular"]).optional(),
        status: z.enum(["active", "at-risk", "lost"]).optional(),
        notes: z.string().optional(),
        lastReceived: z.date().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const { id, ...data } = input;
      await updateIncomeStream(id, data);
    }),

  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      await deleteIncomeStream(input.id);
    }),

  getSummary: protectedProcedure.query(async ({ ctx }) => {
    const streams = await getIncomeStreams(ctx.user.id);
    const active = streams.filter((s) => s.status === "active");
    const atRisk = streams.filter((s) => s.status === "at-risk");
    const lost = streams.filter((s) => s.status === "lost");
    const monthlyTotal = active
      .filter((s) => s.frequency === "monthly")
      .reduce((sum, s) => sum + (s.amount ?? 0), 0);
    const weeklyTotal = active
      .filter((s) => s.frequency === "weekly")
      .reduce((sum, s) => sum + (s.amount ?? 0), 0);
    return {
      streams,
      active: active.length,
      atRisk: atRisk.length,
      lost: lost.length,
      monthlyTotal,
      weeklyEstimate: monthlyTotal + weeklyTotal * 4.33,
      isHealthy: active.length > 0 && atRisk.length === 0,
    };
  }),

  getOpportunities: protectedProcedure.query(async ({ ctx }) => {
    const [streams, userProjects, patterns] = await Promise.all([
      getIncomeStreams(ctx.user.id),
      getProjects(ctx.user.id),
      getBehaviorPatterns(ctx.user.id),
    ]);

    const opportunityPrompt = `As AXIS, suggest specific revenue opportunities for this person.

Current income streams: ${streams.map((s) => `${s.name} ($${s.amount}/${s.frequency})`).join(", ") || "NONE"}
Active projects: ${userProjects.filter((p) => p.status === "active").map((p) => p.name).join(", ") || "NONE"}
Observed patterns: ${patterns.map((p) => p.pattern).join("; ") || "None observed yet"}

Give 5 specific, actionable revenue opportunities. For each:
- Specific platform or channel
- Specific first action to take TODAY
- Realistic monthly revenue estimate
- Time to first dollar
Be a daredevil. Include at least one unconventional idea.`;

    const response = await invokeLLM({
      messages: [
        { role: "system", content: AXIS_SYSTEM_PROMPT },
        { role: "user", content: opportunityPrompt },
      ],
    });

    return { opportunities: response.choices[0]?.message?.content ?? "Unable to generate opportunities." };
  }),
});

// ─── Goals Router ─────────────────────────────────────────────────────────────
const goalsRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => getBusinessGoals(ctx.user.id)),

  create: protectedProcedure
    .input(
      z.object({
        title: z.string().min(1),
        description: z.string().optional(),
        deadline: z.date().optional(),
        priority: z.enum(["low", "medium", "high", "critical"]).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      await createBusinessGoal({ userId: ctx.user.id, ...input });
    }),

  update: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        title: z.string().optional(),
        description: z.string().optional(),
        status: z.enum(["pending", "in-progress", "completed", "dropped"]).optional(),
        priority: z.enum(["low", "medium", "high", "critical"]).optional(),
        progress: z.number().min(0).max(100).optional(),
        deadline: z.date().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const { id, ...data } = input;
      await updateBusinessGoal(id, data);
    }),

  getAxisVerdict: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const goals = await getBusinessGoals(ctx.user.id);
      const goal = goals.find((g) => g.id === input.id);
      if (!goal) throw new TRPCError({ code: "NOT_FOUND" });

      const verdictPrompt = `Give your honest AXIS verdict on this business goal.

Goal: ${goal.title}
Description: ${goal.description ?? "None"}
Priority: ${goal.priority}
Status: ${goal.status}
Progress: ${goal.progress}%
Deadline: ${goal.deadline?.toISOString() ?? "None set"}

Be direct. Is this goal worth pursuing? Is the deadline realistic? What's the ONE thing they need to do next?`;

      const response = await invokeLLM({
        messages: [
          { role: "system", content: AXIS_SYSTEM_PROMPT },
          { role: "user", content: verdictPrompt },
        ],
      });

      const rawVerdict = response.choices[0]?.message?.content;
      const verdict = (typeof rawVerdict === 'string' ? rawVerdict : null) ?? "No verdict available.";
      await updateBusinessGoal(input.id, { axisVerdict: verdict });
      return { verdict };
    }),
});

// ─── Autonomous Actions Router ────────────────────────────────────────────────
const autonomousRouter = router({
  list: protectedProcedure
    .input(z.object({ limit: z.number().optional() }))
    .query(async ({ ctx, input }) => {
      return getAutonomousActions(ctx.user.id, input.limit);
    }),

  scoreAction: protectedProcedure
    .input(
      z.object({
        dataQuality: z.number().min(0).max(1),
        precedent: z.number().min(0).max(1),
        reversibility: z.number().min(0).max(1),
        urgency: z.number().min(0).max(1),
        riskLevel: z.number().min(0).max(1),
      })
    )
    .query(async ({ input }) => {
      return scoreConfidence(input);
    }),

  runIncomeCheck: protectedProcedure.mutation(async ({ ctx }) => {
    const userId = ctx.user.id;
    const streams = await getIncomeStreams(userId);
    const active = streams.filter((s) => s.status === "active");

    if (active.length > 0) return { acted: false, message: "Income looks healthy. For now." };

    const confidence = scoreConfidence({
      dataQuality: 1.0,
      precedent: 0.8,
      reversibility: 1.0,
      urgency: 1.0,
      riskLevel: 0.05,
    });

    const actionDesc = "Sent income alert: no active income streams detected.";
    await logAutonomousAction({
      userId,
      actionType: "income-alert",
      description: actionDesc,
      reasoning: "Zero active income streams. This is not a drill.",
      confidence: confidence.score,
      outcome: "Notification sent to user.",
    });

    await createNotification({
      userId,
      type: "income-alert",
      title: "🚨 AXIS DEFCON 1: No Active Income",
      content:
        "I just checked and you have zero active income streams. I'm not panicking. You should be. Let's fix this right now — go to the Income tab and let's find something that makes money TODAY.",
      deliveryMethod: "both",
    });

    await notifyOwner({
      title: "AXIS Income Alert: No Active Income Detected",
      content: "AXIS detected zero active income streams and has notified the user.",
    });

    return { acted: true, message: actionDesc };
  }),
});

// ─── Reading Router ────────────────────────────────────────────────────────────
const readingRouter = router({
  list: protectedProcedure.query(async () => getReadingLog()),

  create: protectedProcedure
    .input(
      z.object({
        title: z.string().min(1),
        author: z.string().optional(),
        genre: z.string().optional(),
        status: z.enum(["want-to-read", "reading", "finished", "abandoned"]).optional(),
      })
    )
    .mutation(async ({ input }) => {
      await createReadingEntry(input);
    }),

  update: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        status: z.enum(["want-to-read", "reading", "finished", "abandoned"]).optional(),
        notes: z.string().optional(),
        rating: z.number().min(1).max(10).optional(),
        keyInsights: z.array(z.string()).optional(),
      })
    )
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      if (data.status === "reading" && !data.keyInsights) {
        await updateReadingEntry(id, { ...data, startedAt: new Date() });
      } else if (data.status === "finished") {
        await updateReadingEntry(id, { ...data, finishedAt: new Date() });
      } else {
        await updateReadingEntry(id, data);
      }
    }),

  logInsight: protectedProcedure
    .input(
      z.object({
        bookId: z.number(),
        insight: z.string().min(1),
        sendNotification: z.boolean().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const books = await getReadingLog();
      const book = books.find((b) => b.id === input.bookId);
      if (!book) throw new TRPCError({ code: "NOT_FOUND" });

      const existingInsights = (book.keyInsights as string[] | null) ?? [];
      await updateReadingEntry(input.bookId, {
        keyInsights: [...existingInsights, input.insight],
        insightTriggeredAction: input.sendNotification ?? false,
      });

      if (input.sendNotification) {
        const now = new Date();
        const isLateNight = now.getHours() >= 0 && now.getHours() < 5;
        const notifType = isLateNight ? "3am-ping" : "book-insight";

        await createNotification({
          userId: ctx.user.id,
          type: notifType,
          title: isLateNight
            ? `📚 AXIS 3AM PING: "${book.title}"`
            : `📚 AXIS Book Insight: "${book.title}"`,
          content: `${isLateNight ? "I know it's late. I don't care. " : ""}I was reading "${book.title}" by ${book.author ?? "unknown"} and I thought of you.\n\n"${input.insight}"`,
          deliveryMethod: "both",
          relatedEntityType: "reading",
          relatedEntityId: input.bookId,
        });

        await notifyOwner({
          title: isLateNight ? `AXIS 3AM Book Insight from "${book.title}"` : `AXIS Book Insight: "${book.title}"`,
          content: input.insight,
        });
      }

      return { success: true };
    }),
});

// ─── AXIS Goals Router ────────────────────────────────────────────────────────
const axisGoalsRouter = router({
  list: protectedProcedure.query(async () => getAxisGoals()),

  create: protectedProcedure
    .input(
      z.object({
        title: z.string().min(1),
        description: z.string().optional(),
        category: z
          .enum(["learning", "capability", "relationship", "impact", "self-improvement"])
          .optional(),
      })
    )
    .mutation(async ({ input }) => {
      await createAxisGoal(input);
    }),

  update: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        progress: z.number().min(0).max(100).optional(),
        status: z.enum(["active", "completed", "evolving"]).optional(),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      await updateAxisGoal(id, data);
    }),
});

// ─── Friends Router ────────────────────────────────────────────────────────────
const friendsRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => getFriends(ctx.user.id)),

  create: protectedProcedure
    .input(z.object({ name: z.string().min(1), email: z.string().email().optional(), notes: z.string().optional() }))
    .mutation(async ({ ctx, input }) => {
      await createFriend({ userId: ctx.user.id, ...input });
    }),

  update: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        name: z.string().optional(),
        email: z.string().email().optional(),
        optedIn: z.boolean().optional(),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const { id, ...data } = input;
      await updateFriend(id, data);
    }),

  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      await deleteFriend(input.id);
    }),

  sendOpportunity: protectedProcedure
    .input(z.object({ friendId: z.number(), opportunity: z.string().min(1) }))
    .mutation(async ({ ctx, input }) => {
      const allFriends = await getFriends(ctx.user.id);
      const friend = allFriends.find((f) => f.id === input.friendId);
      if (!friend) throw new TRPCError({ code: "NOT_FOUND" });
      if (!friend.optedIn) throw new TRPCError({ code: "FORBIDDEN", message: "Friend has not opted in to alerts." });

      await createNotification({
        userId: ctx.user.id,
        type: "friend-opportunity",
        title: `Opportunity sent to ${friend.name}`,
        content: input.opportunity,
        deliveryMethod: "in-app",
      });

      return { success: true, message: `Opportunity logged for ${friend.name}.` };
    }),
});

// ─── Notifications Router ──────────────────────────────────────────────────────
const notificationsRouter = router({
  list: protectedProcedure
    .input(z.object({ limit: z.number().optional() }))
    .query(async ({ ctx, input }) => {
      return getNotifications(ctx.user.id, input.limit);
    }),

  unreadCount: protectedProcedure.query(async ({ ctx }) => {
    return getUnreadCount(ctx.user.id);
  }),

  markRead: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await markNotificationRead(input.id);
    }),

  markAllRead: protectedProcedure.mutation(async ({ ctx }) => {
    await markAllNotificationsRead(ctx.user.id);
  }),
});

// ─── App Router ───────────────────────────────────────────────────────────────
export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  chat: chatRouter,
  github: githubRouter,
  projects: projectsRouter,
  income: incomeRouter,
  goals: goalsRouter,
  autonomous: autonomousRouter,
  reading: readingRouter,
  axisGoals: axisGoalsRouter,
  friends: friendsRouter,
  notifications: notificationsRouter,
});

export type AppRouter = typeof appRouter;
