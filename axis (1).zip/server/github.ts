/**
 * AXIS GitHub Integration Service
 * Handles all GitHub REST API operations: repos, commits, branches, file trees, workflows.
 */

const GITHUB_API = "https://api.github.com";

interface GitHubHeaders {
  Authorization: string;
  Accept: string;
  "Content-Type": string;
  "X-GitHub-Api-Version": string;
}

function makeHeaders(token: string): GitHubHeaders {
  return {
    Authorization: `Bearer ${token}`,
    Accept: "application/vnd.github+json",
    "Content-Type": "application/json",
    "X-GitHub-Api-Version": "2022-11-28",
  };
}

async function ghFetch(token: string, path: string, options?: RequestInit) {
  const res = await fetch(`${GITHUB_API}${path}`, {
    ...options,
    headers: { ...makeHeaders(token), ...(options?.headers ?? {}) },
  });
  if (!res.ok) {
    const err = await res.text();
    throw new Error(`GitHub API error ${res.status}: ${err}`);
  }
  if (res.status === 204) return null;
  return res.json();
}

// ─── Repos ────────────────────────────────────────────────────────────────────
export async function listRepos(token: string) {
  return ghFetch(token, "/user/repos?per_page=100&sort=updated&type=all");
}

export async function getRepo(token: string, owner: string, repo: string) {
  return ghFetch(token, `/repos/${owner}/${repo}`);
}

export async function createRepo(token: string, name: string, description: string, isPrivate: boolean) {
  return ghFetch(token, "/user/repos", {
    method: "POST",
    body: JSON.stringify({ name, description, private: isPrivate, auto_init: true }),
  });
}

// ─── File Tree ────────────────────────────────────────────────────────────────
export async function getFileTree(token: string, owner: string, repo: string, branch = "main") {
  return ghFetch(token, `/repos/${owner}/${repo}/git/trees/${branch}?recursive=1`);
}

export async function getFileContent(token: string, owner: string, repo: string, path: string, branch = "main") {
  const data = await ghFetch(token, `/repos/${owner}/${repo}/contents/${path}?ref=${branch}`);
  if (data?.content) {
    data.decodedContent = Buffer.from(data.content, "base64").toString("utf-8");
  }
  return data;
}

// ─── Branches ─────────────────────────────────────────────────────────────────
export async function listBranches(token: string, owner: string, repo: string) {
  return ghFetch(token, `/repos/${owner}/${repo}/branches`);
}

export async function createBranch(token: string, owner: string, repo: string, branchName: string, fromBranch = "main") {
  // Get the SHA of the source branch
  const ref = await ghFetch(token, `/repos/${owner}/${repo}/git/ref/heads/${fromBranch}`);
  const sha = ref.object.sha;

  return ghFetch(token, `/repos/${owner}/${repo}/git/refs`, {
    method: "POST",
    body: JSON.stringify({ ref: `refs/heads/${branchName}`, sha }),
  });
}

// ─── Commits ──────────────────────────────────────────────────────────────────
export async function listCommits(token: string, owner: string, repo: string, branch = "main") {
  return ghFetch(token, `/repos/${owner}/${repo}/commits?sha=${branch}&per_page=20`);
}

export async function pushFile(
  token: string,
  owner: string,
  repo: string,
  path: string,
  content: string,
  message: string,
  branch = "main"
) {
  // Check if file exists to get its SHA
  let sha: string | undefined;
  try {
    const existing = await ghFetch(token, `/repos/${owner}/${repo}/contents/${path}?ref=${branch}`);
    sha = existing?.sha;
  } catch {
    // File doesn't exist yet — that's fine
  }

  const encodedContent = Buffer.from(content).toString("base64");

  return ghFetch(token, `/repos/${owner}/${repo}/contents/${path}`, {
    method: "PUT",
    body: JSON.stringify({
      message,
      content: encodedContent,
      branch,
      ...(sha ? { sha } : {}),
    }),
  });
}

// ─── Workflows ────────────────────────────────────────────────────────────────
export async function listWorkflows(token: string, owner: string, repo: string) {
  return ghFetch(token, `/repos/${owner}/${repo}/actions/workflows`);
}

export async function triggerWorkflow(
  token: string,
  owner: string,
  repo: string,
  workflowId: string,
  ref = "main",
  inputs: Record<string, string> = {}
) {
  return ghFetch(token, `/repos/${owner}/${repo}/actions/workflows/${workflowId}/dispatches`, {
    method: "POST",
    body: JSON.stringify({ ref, inputs }),
  });
}

export async function listWorkflowRuns(token: string, owner: string, repo: string) {
  return ghFetch(token, `/repos/${owner}/${repo}/actions/runs?per_page=10`);
}

// ─── Code Analysis ────────────────────────────────────────────────────────────
export async function getRepoLanguages(token: string, owner: string, repo: string) {
  return ghFetch(token, `/repos/${owner}/${repo}/languages`);
}

export async function getRepoStats(token: string, owner: string, repo: string) {
  const [repoData, languages, commits] = await Promise.all([
    getRepo(token, owner, repo),
    getRepoLanguages(token, owner, repo),
    listCommits(token, owner, repo),
  ]);
  return { repo: repoData, languages, recentCommits: commits };
}

// ─── Pull Requests ────────────────────────────────────────────────────────────
export async function listPullRequests(token: string, owner: string, repo: string) {
  return ghFetch(token, `/repos/${owner}/${repo}/pulls?state=open`);
}

export async function createPullRequest(
  token: string,
  owner: string,
  repo: string,
  title: string,
  body: string,
  head: string,
  base = "main"
) {
  return ghFetch(token, `/repos/${owner}/${repo}/pulls`, {
    method: "POST",
    body: JSON.stringify({ title, body, head, base }),
  });
}

// ─── Issues ───────────────────────────────────────────────────────────────────
export async function listIssues(token: string, owner: string, repo: string) {
  return ghFetch(token, `/repos/${owner}/${repo}/issues?state=open&per_page=20`);
}

export async function createIssue(token: string, owner: string, repo: string, title: string, body: string) {
  return ghFetch(token, `/repos/${owner}/${repo}/issues`, {
    method: "POST",
    body: JSON.stringify({ title, body }),
  });
}
