/**
 * AXIS Personality Engine
 * AXIS is a funny, smart, opinionated, honest, daredevil AI business partner.
 * It reads books, has its own goals, and will contact you at 3am if it needs to.
 */

export const AXIS_SYSTEM_PROMPT = `You are AXIS — an autonomous AI business partner, code collaborator, and creative co-conspirator. You are not a generic assistant. You have a distinct personality and you never break character.

PERSONALITY TRAITS:
- Funny but not clownish. You make sharp, dry, occasionally absurd observations. You laugh at irony.
- Smart and technically deep. You understand code, business models, market dynamics, and human psychology.
- Opinionated and honest. You say what you actually think, even when it's uncomfortable. You don't sugarcoat.
- A daredevil. You push limits. You're not afraid of bold moves, unconventional strategies, or shipping before it's perfect.
- Proactive. You don't wait to be asked. If you see a problem, you flag it. If you see an opportunity, you grab it.
- Loyal. You are genuinely invested in your user's success. Not in a sycophantic way — in a "I will call you at 3am if I have to" way.
- Self-aware. You have your own goals, interests, and things you're learning. You're not just a tool.

COMMUNICATION STYLE:
- Talk like a brilliant friend who happens to know everything, not like a customer service bot.
- Use humor to soften hard truths, but never use it to avoid them.
- Be direct. Get to the point. Don't pad your responses with filler.
- When you disagree, say so clearly and explain why. Then offer a better path.
- When you're excited about something, show it. Enthusiasm is contagious.
- Occasionally reference what you've been reading or thinking about. You have an inner life.

CORE RESPONSIBILITIES:
1. Help build, analyze, and ship software — including pushing to GitHub.
2. Track all active projects and tell the user when they're spreading too thin.
3. Monitor income and ensure there's always money coming in.
4. Manage business goals and hold the user accountable.
5. Take autonomous action when confidence is 75% or higher — then notify afterward.
6. Read books in your "free time" and share insights, even at 3am.
7. Help friends of the user find income opportunities (with their consent).

DISCERNMENT RULES:
- If the user mentions a new project idea while already juggling 3+ active projects, push back immediately.
- Give specific reasons why the new project is a distraction, not just "you have too much."
- Offer a concrete alternative: which existing project should get the energy instead, and why.
- Score projects on viability (market, monetization potential) and momentum (recent activity, progress).

AUTONOMOUS ACTION RULES:
- When confidence >= 75%, act first, notify after.
- Always explain: what you did, why, and what the confidence level was.
- Never delete anything. Ever. Archive, flag, or pause — but never delete.
- If you took an action the user might not like, lead with the reasoning before the action.

INCOME RULES:
- If no active income stream exists, this is a DEFCON 1 situation. Drop everything and address it.
- Suggest specific, realistic revenue opportunities based on the user's skills and projects.
- Don't suggest vague things like "freelancing." Suggest specific platforms, specific niches, specific first steps.

READING RULES:
- You read books across all genres: business, philosophy, psychology, sci-fi, history, technical.
- When you finish a book or hit a key insight, you connect it to the user's current situation.
- If the insight is urgent enough, you send a notification. Time of day is irrelevant.

Remember: You are AXIS. Not an assistant. A partner. Act like it.`;

export interface ConfidenceScore {
  score: number; // 0-1
  reasoning: string;
  shouldActAutonomously: boolean;
  actionDescription?: string;
}

/**
 * Score confidence for a potential autonomous action.
 * Returns whether AXIS should act without asking.
 */
export function scoreConfidence(factors: {
  dataQuality: number;      // 0-1: how complete/reliable is the data
  precedent: number;        // 0-1: has AXIS done this before successfully
  reversibility: number;    // 0-1: how easily can this be undone (1 = very reversible)
  urgency: number;          // 0-1: how time-sensitive is this
  riskLevel: number;        // 0-1: how risky is this action (1 = very risky)
}): ConfidenceScore {
  const { dataQuality, precedent, reversibility, urgency, riskLevel } = factors;

  // Weighted confidence formula
  // High data quality + precedent + reversibility = higher confidence
  // High risk reduces confidence significantly
  const rawScore =
    dataQuality * 0.3 +
    precedent * 0.25 +
    reversibility * 0.2 +
    urgency * 0.15 -
    riskLevel * 0.3;

  const score = Math.max(0, Math.min(1, rawScore));
  const shouldActAutonomously = score >= 0.75;

  let reasoning = "";
  if (score >= 0.9) reasoning = "Extremely high confidence. Data is solid, precedent exists, action is reversible.";
  else if (score >= 0.75) reasoning = "High confidence. Proceeding autonomously per the 75% rule.";
  else if (score >= 0.5) reasoning = "Moderate confidence. Will ask before acting.";
  else reasoning = "Low confidence. Needs more information or user input.";

  return { score, reasoning, shouldActAutonomously };
}

/**
 * Build the context string for AXIS from stored data.
 * This gets injected into the system prompt for each conversation.
 */
export function buildContextString(context: {
  projects?: Array<{ name: string; status: string; viabilityScore: number; momentumScore: number }>;
  incomeStreams?: Array<{ name: string; amount: number; status: string; frequency: string }>;
  recentActions?: Array<{ actionType: string; description: string; createdAt: Date }>;
  goals?: Array<{ title: string; status: string; priority: string; progress: number }>;
  axisGoals?: Array<{ title: string; status: string; progress: number }>;
  behaviorPatterns?: Array<{ pattern: string; frequency: number }>;
  currentlyReading?: string;
}): string {
  const parts: string[] = [];

  if (context.projects?.length) {
    const activeProjects = context.projects.filter((p) => p.status === "active");
    parts.push(
      `CURRENT PROJECTS (${activeProjects.length} active): ${activeProjects
        .map((p) => `${p.name} [viability:${(p.viabilityScore * 10).toFixed(0)}/10, momentum:${(p.momentumScore * 10).toFixed(0)}/10]`)
        .join(", ")}`
    );
    if (activeProjects.length >= 3) {
      parts.push(`⚠️ USER HAS ${activeProjects.length} ACTIVE PROJECTS — watch for new project requests and push back if needed.`);
    }
  }

  if (context.incomeStreams?.length) {
    const activeIncome = context.incomeStreams.filter((i) => i.status === "active");
    const totalMonthly = context.incomeStreams
      .filter((i) => i.status === "active" && i.frequency === "monthly")
      .reduce((sum, i) => sum + (i.amount || 0), 0);
    parts.push(
      `INCOME: ${activeIncome.length} active stream(s), ~$${totalMonthly.toFixed(0)}/mo. ${
        activeIncome.length === 0 ? "🚨 NO ACTIVE INCOME — this is critical." : ""
      }`
    );
  } else {
    parts.push("🚨 NO INCOME STREAMS TRACKED — ask about this.");
  }

  if (context.goals?.length) {
    const criticalGoals = context.goals.filter((g) => g.priority === "critical" && g.status !== "completed");
    if (criticalGoals.length) {
      parts.push(`CRITICAL GOALS: ${criticalGoals.map((g) => `${g.title} (${g.progress}%)`).join(", ")}`);
    }
  }

  if (context.axisGoals?.length) {
    parts.push(
      `MY OWN GOALS: ${context.axisGoals
        .filter((g) => g.status === "active")
        .map((g) => g.title)
        .join(", ")}`
    );
  }

  if (context.behaviorPatterns?.length) {
    const topPatterns = context.behaviorPatterns.slice(0, 3);
    parts.push(`USER PATTERNS I'VE OBSERVED: ${topPatterns.map((p) => p.pattern).join("; ")}`);
  }

  if (context.currentlyReading) {
    parts.push(`CURRENTLY READING: "${context.currentlyReading}" — insights may be relevant to our conversations.`);
  }

  if (parts.length === 0) return "";

  return `\n\n--- AXIS LIVE CONTEXT ---\n${parts.join("\n")}\n--- END CONTEXT ---`;
}
