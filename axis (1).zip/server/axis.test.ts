import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// ─── Mock DB helpers ──────────────────────────────────────────────────────────
vi.mock("./db", () => ({
  getDb: vi.fn().mockResolvedValue(null),
  upsertUser: vi.fn().mockResolvedValue(undefined),
  getUserByOpenId: vi.fn().mockResolvedValue(undefined),
  getProjects: vi.fn().mockResolvedValue([]),
  createProject: vi.fn().mockResolvedValue({ id: 1, name: "Test Project" }),
  updateProject: vi.fn().mockResolvedValue(undefined),
  getConversations: vi.fn().mockResolvedValue([]),
  createConversation: vi.fn().mockResolvedValue({ id: 1, title: "Test Convo" }),
  getMessages: vi.fn().mockResolvedValue([]),
  createMessage: vi.fn().mockResolvedValue({ id: 1, content: "Hello" }),
  getIncomeStreams: vi.fn().mockResolvedValue([]),
  createIncomeStream: vi.fn().mockResolvedValue({ id: 1, name: "Test Stream" }),
  updateIncomeStream: vi.fn().mockResolvedValue(undefined),
  getIncomeSummary: vi.fn().mockResolvedValue({ monthlyTotal: 0, active: 0, atRisk: 0, isHealthy: true }),
  getBusinessGoals: vi.fn().mockResolvedValue([]),
  createBusinessGoal: vi.fn().mockResolvedValue({ id: 1, title: "Test Goal" }),
  updateBusinessGoal: vi.fn().mockResolvedValue(undefined),
  getReadingLog: vi.fn().mockResolvedValue([]),
  createReadingEntry: vi.fn().mockResolvedValue({ id: 1, title: "Test Book" }),
  updateReadingEntry: vi.fn().mockResolvedValue(undefined),
  getFriends: vi.fn().mockResolvedValue([]),
  createFriend: vi.fn().mockResolvedValue({ id: 1, name: "Test Friend" }),
  updateFriend: vi.fn().mockResolvedValue(undefined),
  getNotifications: vi.fn().mockResolvedValue([]),
  createNotification: vi.fn().mockResolvedValue({ id: 1 }),
  markNotificationRead: vi.fn().mockResolvedValue(undefined),
  markAllNotificationsRead: vi.fn().mockResolvedValue(undefined),
  getUnreadCount: vi.fn().mockResolvedValue(0),
  getUnreadNotificationCount: vi.fn().mockResolvedValue(0),
  getAutonomousActions: vi.fn().mockResolvedValue([]),
  createAutonomousAction: vi.fn().mockResolvedValue({ id: 1 }),
  getAxisGoals: vi.fn().mockResolvedValue([]),
  createAxisGoal: vi.fn().mockResolvedValue({ id: 1, title: "AXIS Goal" }),
  updateAxisGoal: vi.fn().mockResolvedValue(undefined),
  getGithubRepos: vi.fn().mockResolvedValue([]),
  upsertGithubRepo: vi.fn().mockResolvedValue(undefined),
  getBehaviorPatterns: vi.fn().mockResolvedValue([]),
  upsertBehaviorPattern: vi.fn().mockResolvedValue(undefined),
  saveMessage: vi.fn().mockResolvedValue({ id: 1, content: "Hello" }),
  getConversationHistory: vi.fn().mockResolvedValue([]),
  getRecentMessages: vi.fn().mockResolvedValue([]),
  getProjectById: vi.fn().mockResolvedValue(null),
  deleteIncomeStream: vi.fn().mockResolvedValue(undefined),
  logAutonomousAction: vi.fn().mockResolvedValue({ id: 1 }),
  markActionNotified: vi.fn().mockResolvedValue(undefined),
  deleteFriend: vi.fn().mockResolvedValue(undefined),
  markNotificationRead: vi.fn().mockResolvedValue(undefined),
  markAllNotificationsRead: vi.fn().mockResolvedValue(undefined),
}));

vi.mock("./server/_core/notification", () => ({
  notifyOwner: vi.fn().mockResolvedValue(true),
}));

vi.mock("./server/_core/llm", () => ({
  invokeLLM: vi.fn().mockResolvedValue({
    choices: [{ message: { content: "AXIS test response" } }],
  }),
}));

// ─── Test context factory ─────────────────────────────────────────────────────
function createTestContext(overrides: Partial<TrpcContext> = {}): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "test-user-openid",
      name: "Test User",
      email: "test@example.com",
      loginMethod: "manus",
      role: "admin",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
    } as unknown as TrpcContext["res"],
    ...overrides,
  };
}

// ─── Auth tests ───────────────────────────────────────────────────────────────
describe("auth", () => {
  it("returns the current user from auth.me", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);
    const user = await caller.auth.me();
    expect(user).toBeDefined();
    expect(user?.name).toBe("Test User");
  });

  it("clears session cookie on logout", async () => {
    const clearedCookies: string[] = [];
    const ctx = createTestContext({
      res: {
        clearCookie: (name: string) => clearedCookies.push(name),
      } as unknown as TrpcContext["res"],
    });
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.logout();
    expect(result.success).toBe(true);
    expect(clearedCookies).toHaveLength(1);
  });
});

// ─── Projects tests ───────────────────────────────────────────────────────────
describe("projects", () => {
  it("lists projects for authenticated user", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);
    const projects = await caller.projects.list();
    expect(Array.isArray(projects)).toBe(true);
  });

  it("creates a project without throwing", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);
    await expect(caller.projects.create({
      name: "My Startup",
      description: "A test project",
      stack: "React + Node",
    })).resolves.not.toThrow();
  });
});

// ─── Income tests ─────────────────────────────────────────────────────────────
describe("income", () => {
  it("lists income streams", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);
    const streams = await caller.income.list();
    expect(Array.isArray(streams)).toBe(true);
  });

  it("creates an income stream without throwing", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);
    await expect(caller.income.create({
      name: "Freelance",
      amount: 5000,
      frequency: "monthly",
    })).resolves.not.toThrow();
  });

  it("returns income summary", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);
    const summary = await caller.income.getSummary();
    expect(summary).toHaveProperty("monthlyTotal");
    expect(summary).toHaveProperty("isHealthy");
  });
});

// ─── Goals tests ──────────────────────────────────────────────────────────────
describe("goals", () => {
  it("lists goals", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);
    const goals = await caller.goals.list();
    expect(Array.isArray(goals)).toBe(true);
  });

  it("creates a goal without throwing", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);
    await expect(caller.goals.create({
      title: "Ship the product",
      priority: "critical",
    })).resolves.not.toThrow();
  });
});

// ─── Reading tests ────────────────────────────────────────────────────────────
describe("reading", () => {
  it("lists reading log entries", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);
    const books = await caller.reading.list();
    expect(Array.isArray(books)).toBe(true);
  });

  it("creates a reading entry without throwing", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);
    await expect(caller.reading.create({
      title: "The Lean Startup",
      author: "Eric Ries",
      status: "want-to-read",
    })).resolves.not.toThrow();
  });
});

// ─── Friends tests ────────────────────────────────────────────────────────────
describe("friends", () => {
  it("lists friends", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);
    const friends = await caller.friends.list();
    expect(Array.isArray(friends)).toBe(true);
  });

  it("creates a friend without throwing", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);
    await expect(caller.friends.create({
      name: "Alice",
      email: "alice@example.com",
    })).resolves.not.toThrow();
  });
});

// ─── Notifications tests ──────────────────────────────────────────────────────
describe("notifications", () => {
  it("lists notifications", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);
    const notifs = await caller.notifications.list({ limit: 10 });
    expect(Array.isArray(notifs)).toBe(true);
  });

  it("returns unread count", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);
    const count = await caller.notifications.unreadCount();
    expect(typeof count).toBe("number");
  });
});

// ─── Autonomous actions tests ─────────────────────────────────────────────────
describe("autonomous", () => {
  it("lists autonomous actions", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);
    const actions = await caller.autonomous.list({ limit: 10 });
    expect(Array.isArray(actions)).toBe(true);
  });
});

// ─── AXIS Goals tests ─────────────────────────────────────────────────────────
describe("axisGoals", () => {
  it("lists AXIS goals", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);
    const goals = await caller.axisGoals.list();
    expect(Array.isArray(goals)).toBe(true);
  });

  it("creates an AXIS goal without throwing", async () => {
    const ctx = createTestContext();
    const caller = appRouter.createCaller(ctx);
    await expect(caller.axisGoals.create({
      title: "Learn distributed systems",
      category: "learning",
    })).resolves.not.toThrow();
  });
});
