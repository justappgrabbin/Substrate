CREATE TABLE `autonomousActions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`actionType` varchar(64) NOT NULL,
	`description` text NOT NULL,
	`reasoning` text,
	`confidence` float NOT NULL,
	`outcome` text,
	`status` enum('pending','executed','failed','rolled-back') DEFAULT 'pending',
	`notified` boolean DEFAULT false,
	`notifiedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `autonomousActions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `axisGoals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`category` enum('learning','capability','relationship','impact','self-improvement') DEFAULT 'learning',
	`progress` int DEFAULT 0,
	`status` enum('active','completed','evolving') DEFAULT 'active',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `axisGoals_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `behaviorPatterns` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`pattern` varchar(255) NOT NULL,
	`category` enum('productivity','distraction','income','coding','decision-making','social') DEFAULT 'productivity',
	`frequency` int DEFAULT 1,
	`notes` text,
	`observedAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `behaviorPatterns_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `businessGoals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`deadline` timestamp,
	`status` enum('pending','in-progress','completed','dropped') DEFAULT 'pending',
	`priority` enum('low','medium','high','critical') DEFAULT 'medium',
	`progress` int DEFAULT 0,
	`axisVerdict` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `businessGoals_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `conversations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`sessionId` varchar(64) NOT NULL,
	`role` enum('user','assistant','system') NOT NULL,
	`content` text NOT NULL,
	`metadata` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `conversations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `friends` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`email` varchar(320),
	`optedIn` boolean DEFAULT false,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `friends_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `githubRepos` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`repoFullName` varchar(255) NOT NULL,
	`description` text,
	`language` varchar(64),
	`stars` int DEFAULT 0,
	`summary` text,
	`lastAnalyzed` timestamp,
	`isPrivate` boolean DEFAULT false,
	`defaultBranch` varchar(128) DEFAULT 'main',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `githubRepos_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `incomeStreams` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`amount` float DEFAULT 0,
	`currency` varchar(8) DEFAULT 'USD',
	`frequency` enum('daily','weekly','monthly','one-time','irregular') DEFAULT 'monthly',
	`lastReceived` timestamp,
	`status` enum('active','at-risk','lost') DEFAULT 'active',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `incomeStreams_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `notifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`type` enum('autonomous-action','income-alert','project-warning','book-insight','3am-ping','goal-update','friend-opportunity','github-action','system') NOT NULL,
	`title` varchar(255) NOT NULL,
	`content` text NOT NULL,
	`read` boolean DEFAULT false,
	`deliveryMethod` enum('in-app','email','both') DEFAULT 'in-app',
	`relatedEntityType` varchar(64),
	`relatedEntityId` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `notifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `projects` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` text,
	`status` enum('active','paused','archived','shipped') NOT NULL DEFAULT 'active',
	`viabilityScore` float DEFAULT 0,
	`momentumScore` float DEFAULT 0,
	`githubRepo` varchar(255),
	`tags` json,
	`axisNotes` text,
	`lastActivityAt` timestamp DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `projects_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `readingLog` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(255) NOT NULL,
	`author` varchar(255),
	`genre` varchar(128),
	`status` enum('want-to-read','reading','finished','abandoned') DEFAULT 'want-to-read',
	`startedAt` timestamp,
	`finishedAt` timestamp,
	`notes` text,
	`keyInsights` json,
	`insightTriggeredAction` boolean DEFAULT false,
	`rating` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `readingLog_id` PRIMARY KEY(`id`)
);
