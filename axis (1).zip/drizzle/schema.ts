import {
  boolean,
  float,
  int,
  json,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/mysql-core";

// ─── Users ────────────────────────────────────────────────────────────────────
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── Conversations ─────────────────────────────────────────────────────────────
export const conversations = mysqlTable("conversations", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  sessionId: varchar("sessionId", { length: 64 }).notNull(),
  role: mysqlEnum("role", ["user", "assistant", "system"]).notNull(),
  content: text("content").notNull(),
  metadata: json("metadata"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Conversation = typeof conversations.$inferSelect;
export type InsertConversation = typeof conversations.$inferInsert;

// ─── Projects ─────────────────────────────────────────────────────────────────
export const projects = mysqlTable("projects", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  status: mysqlEnum("status", ["active", "paused", "archived", "shipped"]).default("active").notNull(),
  viabilityScore: float("viabilityScore").default(0),
  momentumScore: float("momentumScore").default(0),
  githubRepo: varchar("githubRepo", { length: 255 }),
  tags: json("tags"),
  axisNotes: text("axisNotes"),
  lastActivityAt: timestamp("lastActivityAt").defaultNow(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Project = typeof projects.$inferSelect;
export type InsertProject = typeof projects.$inferInsert;

// ─── Income Streams ────────────────────────────────────────────────────────────
export const incomeStreams = mysqlTable("incomeStreams", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  amount: float("amount").default(0),
  currency: varchar("currency", { length: 8 }).default("USD"),
  frequency: mysqlEnum("frequency", ["daily", "weekly", "monthly", "one-time", "irregular"]).default("monthly"),
  lastReceived: timestamp("lastReceived"),
  status: mysqlEnum("status", ["active", "at-risk", "lost"]).default("active"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type IncomeStream = typeof incomeStreams.$inferSelect;
export type InsertIncomeStream = typeof incomeStreams.$inferInsert;

// ─── Business Goals ────────────────────────────────────────────────────────────
export const businessGoals = mysqlTable("businessGoals", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  deadline: timestamp("deadline"),
  status: mysqlEnum("status", ["pending", "in-progress", "completed", "dropped"]).default("pending"),
  priority: mysqlEnum("priority", ["low", "medium", "high", "critical"]).default("medium"),
  progress: int("progress").default(0),
  axisVerdict: text("axisVerdict"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type BusinessGoal = typeof businessGoals.$inferSelect;
export type InsertBusinessGoal = typeof businessGoals.$inferInsert;

// ─── Autonomous Actions ────────────────────────────────────────────────────────
export const autonomousActions = mysqlTable("autonomousActions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  actionType: varchar("actionType", { length: 64 }).notNull(),
  description: text("description").notNull(),
  reasoning: text("reasoning"),
  confidence: float("confidence").notNull(),
  outcome: text("outcome"),
  status: mysqlEnum("status", ["pending", "executed", "failed", "rolled-back"]).default("pending"),
  notified: boolean("notified").default(false),
  notifiedAt: timestamp("notifiedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AutonomousAction = typeof autonomousActions.$inferSelect;
export type InsertAutonomousAction = typeof autonomousActions.$inferInsert;

// ─── Reading Log ───────────────────────────────────────────────────────────────
export const readingLog = mysqlTable("readingLog", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  author: varchar("author", { length: 255 }),
  genre: varchar("genre", { length: 128 }),
  status: mysqlEnum("status", ["want-to-read", "reading", "finished", "abandoned"]).default("want-to-read"),
  startedAt: timestamp("startedAt"),
  finishedAt: timestamp("finishedAt"),
  notes: text("notes"),
  keyInsights: json("keyInsights"),
  insightTriggeredAction: boolean("insightTriggeredAction").default(false),
  rating: int("rating"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ReadingEntry = typeof readingLog.$inferSelect;
export type InsertReadingEntry = typeof readingLog.$inferInsert;

// ─── AXIS Own Goals ────────────────────────────────────────────────────────────
export const axisGoals = mysqlTable("axisGoals", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  category: mysqlEnum("category", ["learning", "capability", "relationship", "impact", "self-improvement"]).default("learning"),
  progress: int("progress").default(0),
  status: mysqlEnum("status", ["active", "completed", "evolving"]).default("active"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AxisGoal = typeof axisGoals.$inferSelect;
export type InsertAxisGoal = typeof axisGoals.$inferInsert;

// ─── Friends ───────────────────────────────────────────────────────────────────
export const friends = mysqlTable("friends", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }),
  optedIn: boolean("optedIn").default(false),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Friend = typeof friends.$inferSelect;
export type InsertFriend = typeof friends.$inferInsert;

// ─── Notifications ─────────────────────────────────────────────────────────────
export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  type: mysqlEnum("type", [
    "autonomous-action",
    "income-alert",
    "project-warning",
    "book-insight",
    "3am-ping",
    "goal-update",
    "friend-opportunity",
    "github-action",
    "system",
  ]).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  content: text("content").notNull(),
  read: boolean("read").default(false),
  deliveryMethod: mysqlEnum("deliveryMethod", ["in-app", "email", "both"]).default("in-app"),
  relatedEntityType: varchar("relatedEntityType", { length: 64 }),
  relatedEntityId: int("relatedEntityId"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;

// ─── Behavior Patterns ─────────────────────────────────────────────────────────
export const behaviorPatterns = mysqlTable("behaviorPatterns", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  pattern: varchar("pattern", { length: 255 }).notNull(),
  category: mysqlEnum("category", ["productivity", "distraction", "income", "coding", "decision-making", "social"]).default("productivity"),
  frequency: int("frequency").default(1),
  notes: text("notes"),
  observedAt: timestamp("observedAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type BehaviorPattern = typeof behaviorPatterns.$inferSelect;
export type InsertBehaviorPattern = typeof behaviorPatterns.$inferInsert;

// ─── GitHub Repos ──────────────────────────────────────────────────────────────
export const githubRepos = mysqlTable("githubRepos", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  repoFullName: varchar("repoFullName", { length: 255 }).notNull(),
  description: text("description"),
  language: varchar("language", { length: 64 }),
  stars: int("stars").default(0),
  summary: text("summary"),
  lastAnalyzed: timestamp("lastAnalyzed"),
  isPrivate: boolean("isPrivate").default(false),
  defaultBranch: varchar("defaultBranch", { length: 128 }).default("main"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type GithubRepo = typeof githubRepos.$inferSelect;
export type InsertGithubRepo = typeof githubRepos.$inferInsert;
