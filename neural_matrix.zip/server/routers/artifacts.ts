import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { createArtifact, getArtifactsByUser, addKnowledgeEntry, getKnowledgeByArtifact } from "../db";
import { storagePut } from "../storage";
import { parseFile, generateSummary } from "../utils/fileParser";

export const artifactsRouter = router({
  /**
   * Upload and ingest a file artifact
   */
  upload: protectedProcedure
    .input(
      z.object({
        filename: z.string(),
        fileType: z.string(),
        fileSize: z.number(),
        fileContent: z.string(), // Base64 or text content
      })
    )
    .mutation(async ({ ctx, input }) => {
      const userId = ctx.user.id;
      const fileKey = `artifacts/${userId}/${Date.now()}-${input.filename}`;

      // Upload to S3
      const { url } = await storagePut(fileKey, Buffer.from(input.fileContent, "base64"), "application/octet-stream");

      // Parse file content for metadata extraction
      let extractedText = "";
      let tags: string[] = [];
      let summary = "";
      let language = "";

      try {
        const decodedContent = Buffer.from(input.fileContent, "base64").toString("utf-8");
        const parsed = parseFile(input.filename, decodedContent);
        extractedText = parsed.text;
        tags = parsed.tags || [];
        language = parsed.language || "";
        summary = generateSummary(extractedText);
      } catch (error) {
        console.warn("[Parser] Failed to parse file:", error);
      }

      // Create artifact record with extracted metadata
      await createArtifact(userId, {
        filename: input.filename,
        fileType: input.fileType,
        fileSize: input.fileSize,
        fileKey,
        fileUrl: url,
        extractedText,
        metadata: JSON.stringify({
          uploadedAt: new Date().toISOString(),
          tags,
          language,
          summary,
        }),
      });

      return {
        success: true,
        fileUrl: url,
      };
    }),

  /**
   * Get all artifacts for the current user
   */
  list: protectedProcedure.query(async ({ ctx }) => {
    const artifacts = await getArtifactsByUser(ctx.user.id);
    return artifacts.map((a) => ({
      id: a.id,
      filename: a.filename,
      fileType: a.fileType,
      fileSize: a.fileSize,
      fileUrl: a.fileUrl,
      uploadedAt: a.uploadedAt,
      metadata: a.metadata ? JSON.parse(a.metadata) : {},
    }));
  }),

  /**
   * Get knowledge extracted from an artifact
   */
  getKnowledge: protectedProcedure
    .input(z.object({ artifactId: z.number() }))
    .query(async ({ input }) => {
      const knowledge = await getKnowledgeByArtifact(input.artifactId);
      return knowledge.map((k) => ({
        id: k.id,
        content: k.content,
        contentType: k.contentType,
        tags: k.tags ? k.tags.split(",") : [],
        summary: k.summary,
      }));
    }),

  /**
   * Add knowledge entry extracted from artifact
   */
  addKnowledge: protectedProcedure
    .input(
      z.object({
        artifactId: z.number(),
        content: z.string(),
        contentType: z.enum(["code", "text", "definition", "example"]),
        tags: z.array(z.string()).optional(),
        summary: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      await addKnowledgeEntry({
        artifactId: input.artifactId,
        userId: ctx.user.id,
        content: input.content,
        contentType: input.contentType,
        tags: input.tags?.join(","),
        summary: input.summary,
      });

      return { success: true };
    }),
});
