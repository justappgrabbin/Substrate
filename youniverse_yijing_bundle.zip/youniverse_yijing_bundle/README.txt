
YOU-N-I-VERSE × Yijing Bundle
=============================

Files:
- index.html  → Pretty UI that loads data/bundle.json
- data/bundle.json → Machine-readable content
- assets/style.css → Styles

How to use:
1) Open index.html in a browser.
2) Click "Download JSON" to get the exact data object.
3) Duplicate data/bundle.json and index.html sections to create bundles for other Gates/Hexagrams.
