/**
 * THE FORGE - Admin Panel
 * 
 * Phone-friendly control center for managing:
 * - User activations (13-placement chart)
 * - Consciousness fields (9-body system)
 * - Uploaded books/files
 * - Field tension monitoring
 * - Causal controls (CommitNode/AbandonNode)
 */

import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Settings, Upload, Eye, Zap, Lock, Unlock, BarChart3, FileText, Users } from 'lucide-react';

interface UserActivation {
  userId: string;
  gate: number;
  line: number;
  color: number;
  tone: number;
  base: number;
  consciousnessFields: {
    mind: number;
    heart: number;
    body: number;
    will: number;
    shadow: number;
    child: number;
    soul: number;
    spirit: number;
    synthesis: number;
  };
}

interface UploadedFile {
  id: string;
  name: string;
  type: 'book' | 'chart' | 'image' | 'audio';
  uploadedAt: number;
  size: number;
}

export default function ForgeAdminPanel() {
  const [activeTab, setActiveTab] = useState<'overview' | 'activations' | 'files' | 'field' | 'controls'>('overview');
  const [userActivation, setUserActivation] = useState<UserActivation>({
    userId: 'user-' + Date.now(),
    gate: 1,
    line: 1,
    color: 1,
    tone: 1,
    base: 1,
    consciousnessFields: {
      mind: 0.5,
      heart: 0.5,
      body: 0.5,
      will: 0.5,
      shadow: 0.5,
      child: 0.5,
      soul: 0.5,
      spirit: 0.5,
      synthesis: 0.5,
    },
  });

  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);
  const [fieldTension, setFieldTension] = useState(0.3);
  const [isCausalLocked, setIsCausalLocked] = useState(false);
  const [projectIntent, setProjectIntent] = useState('');

  // Tab: Overview
  const renderOverview = () => (
    <div className="space-y-4">
      <Card className="bg-slate-800 border-cyan-500 p-4">
        <h3 className="text-cyan-400 font-bold mb-3">Project Intent</h3>
        <Textarea
          value={projectIntent}
          onChange={(e) => setProjectIntent(e.target.value)}
          placeholder="Describe what this morph substrate should do..."
          className="bg-slate-700 border-cyan-500 text-cyan-300 placeholder-cyan-600 mb-3"
          rows={4}
        />
        <Button className="w-full bg-cyan-500 text-slate-950 hover:bg-cyan-400 font-bold">
          Initialize Substrate
        </Button>
      </Card>

      <Card className="bg-slate-800 border-cyan-500 p-4">
        <h3 className="text-cyan-400 font-bold mb-2">System Status</h3>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between text-cyan-300">
            <span>Active Gates:</span>
            <span className="text-cyan-400 font-bold">12/64</span>
          </div>
          <div className="flex justify-between text-cyan-300">
            <span>Field Tension:</span>
            <span className="text-cyan-400 font-bold">{fieldTension.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-cyan-300">
            <span>Uploaded Files:</span>
            <span className="text-cyan-400 font-bold">{uploadedFiles.length}</span>
          </div>
          <div className="flex justify-between text-cyan-300">
            <span>Causal State:</span>
            <span className={isCausalLocked ? 'text-red-400 font-bold' : 'text-green-400 font-bold'}>
              {isCausalLocked ? 'LOCKED' : 'OPEN'}
            </span>
          </div>
        </div>
      </Card>
    </div>
  );

  // Tab: Activations
  const renderActivations = () => (
    <div className="space-y-4">
      <Card className="bg-slate-800 border-cyan-500 p-4">
        <h3 className="text-cyan-400 font-bold mb-4">13-Placement Chart</h3>
        
        <div className="grid grid-cols-2 gap-3 mb-4">
          <div>
            <label className="text-cyan-400 text-xs font-bold block mb-1">Gate (1-64)</label>
            <input
              type="number"
              min="1"
              max="64"
              value={userActivation.gate}
              onChange={(e) => setUserActivation({ ...userActivation, gate: parseInt(e.target.value) })}
              className="w-full bg-slate-700 border border-cyan-500 rounded px-2 py-1 text-cyan-300 text-sm"
            />
          </div>
          <div>
            <label className="text-cyan-400 text-xs font-bold block mb-1">Line (1-6)</label>
            <input
              type="number"
              min="1"
              max="6"
              value={userActivation.line}
              onChange={(e) => setUserActivation({ ...userActivation, line: parseInt(e.target.value) })}
              className="w-full bg-slate-700 border border-cyan-500 rounded px-2 py-1 text-cyan-300 text-sm"
            />
          </div>
          <div>
            <label className="text-cyan-400 text-xs font-bold block mb-1">Color (1-6)</label>
            <input
              type="number"
              min="1"
              max="6"
              value={userActivation.color}
              onChange={(e) => setUserActivation({ ...userActivation, color: parseInt(e.target.value) })}
              className="w-full bg-slate-700 border border-cyan-500 rounded px-2 py-1 text-cyan-300 text-sm"
            />
          </div>
          <div>
            <label className="text-cyan-400 text-xs font-bold block mb-1">Tone (1-6)</label>
            <input
              type="number"
              min="1"
              max="6"
              value={userActivation.tone}
              onChange={(e) => setUserActivation({ ...userActivation, tone: parseInt(e.target.value) })}
              className="w-full bg-slate-700 border border-cyan-500 rounded px-2 py-1 text-cyan-300 text-sm"
            />
          </div>
        </div>

        <h4 className="text-cyan-400 text-sm font-bold mb-3">9-Body Consciousness Fields</h4>
        <div className="space-y-2">
          {Object.entries(userActivation.consciousnessFields).map(([field, value]) => (
            <div key={field}>
              <div className="flex justify-between text-xs text-cyan-300 mb-1">
                <span className="capitalize">{field}</span>
                <span className="text-cyan-400">{(value * 100).toFixed(0)}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.1"
                value={value}
                onChange={(e) =>
                  setUserActivation({
                    ...userActivation,
                    consciousnessFields: {
                      ...userActivation.consciousnessFields,
                      [field]: parseFloat(e.target.value),
                    },
                  })
                }
                className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer"
              />
            </div>
          ))}
        </div>

        <Button className="w-full mt-4 bg-cyan-500 text-slate-950 hover:bg-cyan-400 font-bold">
          Save Activation
        </Button>
      </Card>
    </div>
  );

  // Tab: Files
  const renderFiles = () => (
    <div className="space-y-4">
      <Card className="bg-slate-800 border-cyan-500 p-4">
        <h3 className="text-cyan-400 font-bold mb-3">Upload Files</h3>
        <div className="border-2 border-dashed border-cyan-500 rounded-lg p-6 text-center mb-4">
          <Upload className="w-8 h-8 text-cyan-400 mx-auto mb-2" />
          <p className="text-cyan-300 text-sm">Drag files here or click to upload</p>
          <p className="text-cyan-600 text-xs mt-1">Books, charts, images, audio</p>
        </div>
        <Button className="w-full bg-cyan-500 text-slate-950 hover:bg-cyan-400 font-bold mb-4">
          Choose Files
        </Button>
      </Card>

      {uploadedFiles.length > 0 && (
        <Card className="bg-slate-800 border-cyan-500 p-4">
          <h3 className="text-cyan-400 font-bold mb-3">Uploaded Files ({uploadedFiles.length})</h3>
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {uploadedFiles.map((file) => (
              <div key={file.id} className="flex justify-between items-center bg-slate-700 p-2 rounded text-xs">
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4 text-cyan-400" />
                  <div>
                    <p className="text-cyan-300">{file.name}</p>
                    <p className="text-cyan-600">{(file.size / 1024).toFixed(1)} KB</p>
                  </div>
                </div>
                <span className="text-cyan-500">{file.type}</span>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );

  // Tab: Field Monitor
  const renderFieldMonitor = () => (
    <div className="space-y-4">
      <Card className="bg-slate-800 border-cyan-500 p-4">
        <h3 className="text-cyan-400 font-bold mb-4">Field Tension Monitor</h3>
        
        <div className="mb-6">
          <div className="flex justify-between text-sm text-cyan-300 mb-2">
            <span>Global Field Tension</span>
            <span className="text-cyan-400 font-bold">{fieldTension.toFixed(3)}</span>
          </div>
          <div className="w-full bg-slate-700 rounded-full h-3">
            <div
              className={`h-3 rounded-full transition-all ${
                fieldTension > 0.95 ? 'bg-red-500' : fieldTension > 0.7 ? 'bg-yellow-500' : 'bg-cyan-500'
              }`}
              style={{ width: `${fieldTension * 100}%` }}
            />
          </div>
          <p className="text-cyan-600 text-xs mt-2">
            {fieldTension > 0.95 ? '🔴 REGIME FLIP TRIGGERED' : fieldTension > 0.7 ? '🟡 HIGH TENSION' : '🟢 STABLE'}
          </p>
        </div>

        <div className="space-y-3">
          <div>
            <p className="text-cyan-400 text-sm font-bold mb-2">Active Gates</p>
            <div className="grid grid-cols-8 gap-1">
              {Array.from({ length: 64 }).map((_, i) => (
                <div
                  key={i}
                  className={`w-6 h-6 rounded text-xs flex items-center justify-center font-bold ${
                    Math.random() > 0.8
                      ? 'bg-cyan-500 text-slate-950'
                      : 'bg-slate-700 text-cyan-600 border border-cyan-600'
                  }`}
                >
                  {i + 1}
                </div>
              ))}
            </div>
          </div>
        </div>

        <Button className="w-full mt-4 bg-cyan-500 text-slate-950 hover:bg-cyan-400 font-bold">
          <BarChart3 className="w-4 h-4 mr-2" /> View Detailed Report
        </Button>
      </Card>
    </div>
  );

  // Tab: Causal Controls
  const renderCausalControls = () => (
    <div className="space-y-4">
      <Card className="bg-slate-800 border-cyan-500 p-4">
        <h3 className="text-cyan-400 font-bold mb-4">Causal Controls</h3>
        
        <div className="space-y-3">
          <Button
            onClick={() => setIsCausalLocked(!isCausalLocked)}
            className={`w-full font-bold flex items-center justify-center gap-2 ${
              isCausalLocked
                ? 'bg-red-600 text-white hover:bg-red-700'
                : 'bg-green-600 text-white hover:bg-green-700'
            }`}
          >
            {isCausalLocked ? (
              <>
                <Lock className="w-4 h-4" /> UNLOCK CAUSAL CHAIN
              </>
            ) : (
              <>
                <Unlock className="w-4 h-4" /> LOCK CAUSAL CHAIN (CommitNode)
              </>
            )}
          </Button>

          <Button className="w-full bg-orange-600 text-white hover:bg-orange-700 font-bold">
            ABANDON NODE (Preserve Failure)
          </Button>

          <Button className="w-full bg-purple-600 text-white hover:bg-purple-700 font-bold">
            RESET FIELD
          </Button>
        </div>
      </Card>

      <Card className="bg-slate-800 border-cyan-500 p-4">
        <h3 className="text-cyan-400 font-bold mb-3">Recent Actions</h3>
        <div className="space-y-2 text-xs max-h-48 overflow-y-auto">
          <div className="text-cyan-300 bg-slate-700 p-2 rounded">
            <p className="text-cyan-400 font-bold">CommitNode</p>
            <p className="text-cyan-600">2 minutes ago</p>
          </div>
          <div className="text-cyan-300 bg-slate-700 p-2 rounded">
            <p className="text-cyan-400 font-bold">Field Tension: 0.87</p>
            <p className="text-cyan-600">5 minutes ago</p>
          </div>
        </div>
      </Card>
    </div>
  );

  return (
    <div className="w-full h-full bg-gradient-to-br from-slate-900 to-slate-800 flex flex-col">
      {/* Header */}
      <div className="border-b border-cyan-500 bg-slate-900 p-4">
        <div className="flex items-center gap-2 mb-4">
          <Zap className="w-6 h-6 text-cyan-400" />
          <h1 className="text-2xl font-bold text-cyan-400">The Forge</h1>
        </div>
        <p className="text-cyan-500 text-sm">Substrate Management & Causal Control</p>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 border-b border-cyan-500 bg-slate-900 px-4 py-2 overflow-x-auto">
        {(['overview', 'activations', 'files', 'field', 'controls'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-3 py-2 text-sm font-bold whitespace-nowrap rounded transition-colors ${
              activeTab === tab
                ? 'bg-cyan-500 text-slate-950'
                : 'text-cyan-400 hover:bg-slate-800'
            }`}
          >
            {tab.charAt(0).toUpperCase() + tab.slice(1)}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4">
        {activeTab === 'overview' && renderOverview()}
        {activeTab === 'activations' && renderActivations()}
        {activeTab === 'files' && renderFiles()}
        {activeTab === 'field' && renderFieldMonitor()}
        {activeTab === 'controls' && renderCausalControls()}
      </div>
    </div>
  );
}
