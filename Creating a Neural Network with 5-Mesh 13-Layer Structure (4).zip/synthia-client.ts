/**
 * SYNTHIA CLIENT
 * 
 * Connects to the Synthia Express server to:
 * - Classify user intent (Morph GNN)
 * - Generate custom components (Code Synthesizer)
 * - Retrieve personalized advice (RAG Engine)
 * - Update 3D agent state
 */

export interface UserActivationContext {
  gate: number;
  line: number;
  color: number;
  tone: number;
  base: number;
  consciousnessFields: {
    mind: number;
    heart: number;
    body: number;
    will: number;
    shadow: number;
    child: number;
    soul: number;
    spirit: number;
    synthesis: number;
  };
}

export interface IntentClassificationRequest {
  userId: string;
  input: string;
  context: {
    currentApp: string;
    lastMode: string;
    timestamp: string;
  };
}

export interface IntentClassificationResponse {
  mode: 'Bond' | 'Chart' | 'Store' | 'Generate' | 'Advice' | 'Game';
  confidence: number;
  subMode: string;
  activationContext: UserActivationContext;
  routing: {
    targetEndpoint: string;
    priority: string;
  };
}

export interface GenerateComponentRequest {
  userId: string;
  intent: {
    mode: string;
    subMode: string;
    description: string;
  };
  activationProfile: UserActivationContext;
  constraints: {
    platform: 'mobile' | 'desktop' | 'web' | 'ps5';
    framework: 'react' | 'vue' | 'vanilla' | 'unity';
    theme: string;
    interactiveElements: string[];
  };
}

export interface GenerateComponentResponse {
  componentId: string;
  generatedCode: {
    html: string;
    css: string;
    js: string;
  };
  metadata: {
    gateSignature: string;
    consciousnessAlignment: number;
    fileDependencies: string[];
    deploymentReady: boolean;
  };
  evolutionHooks: string[];
}

export interface AdviceQueryRequest {
  userId: string;
  query: string;
  contextSources: {
    chart: boolean;
    uploadedFiles: string[] | 'all';
    consciousnessState: boolean;
    recentActivations: number;
  };
  adviceFormat: 'philosophical' | 'poetic' | 'actionable' | 'code';
  outputLength: 'brief' | 'medium' | 'detailed';
}

export interface AdviceQueryResponse {
  adviceId: string;
  response: {
    mainInsight: string;
    bookCitations: Array<{
      file: string;
      chunk: string;
      relevance: number;
      gateAlignment: number;
    }>;
    chartSynthesis: {
      relevantGates: number[];
      consciousnessInsight: string;
      actionSteps: string[];
    };
    generatedArtifact: {
      type: string;
      content: string;
      suggestedHashtags: string[];
      visualSuggestion: string;
    };
  };
  confidence: number;
  followUpQuestions: string[];
}

export interface AgentStateRequest {
  userId: string;
  currentView: string;
  userState: {
    consciousnessFields: Record<string, number>;
    lastInteraction: string;
    currentApp: string;
    emotionalTone: string;
  };
  agentConfig: {
    form: 'humanoid' | 'hamster' | 'orb' | 'abstract';
    personalitySeed: string;
    animationState: string;
  };
}

export interface AgentStateResponse {
  agentUpdate: {
    mood: string;
    suggestedAction: string;
    dialogue: string;
    visualChanges: {
      colorShift: string;
      animation: string;
      particleEffect: string;
    };
    interactiveOffer: {
      type: string;
      duration: number;
      gateTheme: number;
    };
  };
}

export class SynthiaClient {
  private baseUrl: string;
  private userId: string;

  constructor(baseUrl: string = 'https://synthia-server.onrender.com', userId: string = 'default-user') {
    this.baseUrl = baseUrl;
    this.userId = userId;
  }

  /**
   * Classify user intent using Morph GNN
   */
  async classifyIntent(input: string, context?: any): Promise<IntentClassificationResponse> {
    try {
      const request: IntentClassificationRequest = {
        userId: this.userId,
        input,
        context: context || {
          currentApp: 'Paper Pal',
          lastMode: 'Chat',
          timestamp: new Date().toISOString(),
        },
      };

      const response = await fetch(`${this.baseUrl}/api/intent/classify`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(request),
      });

      if (!response.ok) {
        throw new Error(`Intent classification failed: ${response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Error classifying intent:', error);
      // Fallback response
      return {
        mode: 'Generate',
        confidence: 0.5,
        subMode: 'FALLBACK',
        activationContext: this.getDefaultActivationContext(),
        routing: {
          targetEndpoint: '/api/generate/component',
          priority: 'medium',
        },
      };
    }
  }

  /**
   * Generate custom component based on intent and activation
   */
  async generateComponent(
    intent: string,
    activation: UserActivationContext,
    subMode: string = 'CUSTOM'
  ): Promise<GenerateComponentResponse> {
    try {
      const request: GenerateComponentRequest = {
        userId: this.userId,
        intent: {
          mode: 'GENERATE',
          subMode,
          description: intent,
        },
        activationProfile: activation,
        constraints: {
          platform: 'mobile',
          framework: 'react',
          theme: `gate_${activation.gate}`,
          interactiveElements: ['breath_circle', 'frequency_bar', `gate_${activation.gate}_sigil`],
        },
      };

      const response = await fetch(`${this.baseUrl}/api/generate/component`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(request),
      });

      if (!response.ok) {
        throw new Error(`Component generation failed: ${response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Error generating component:', error);
      // Fallback response
      return {
        componentId: `comp_${Date.now()}`,
        generatedCode: {
          html: '<div class="fallback-component">Component generation pending...</div>',
          css: '.fallback-component { padding: 20px; }',
          js: 'console.log("Fallback component");',
        },
        metadata: {
          gateSignature: `${activation.gate}.${activation.line}.${activation.color}.${activation.tone}.${activation.base}`,
          consciousnessAlignment: 0.5,
          fileDependencies: [],
          deploymentReady: false,
        },
        evolutionHooks: [],
      };
    }
  }

  /**
   * Query advice engine with RAG over uploaded files + chart
   */
  async queryAdvice(
    query: string,
    activation: UserActivationContext,
    uploadedFiles: string[] = []
  ): Promise<AdviceQueryResponse> {
    try {
      const request: AdviceQueryRequest = {
        userId: this.userId,
        query,
        contextSources: {
          chart: true,
          uploadedFiles: uploadedFiles.length > 0 ? uploadedFiles : 'all',
          consciousnessState: true,
          recentActivations: 7,
        },
        adviceFormat: 'actionable',
        outputLength: 'medium',
      };

      const response = await fetch(`${this.baseUrl}/api/advice/query`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(request),
      });

      if (!response.ok) {
        throw new Error(`Advice query failed: ${response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Error querying advice:', error);
      // Fallback response
      return {
        adviceId: `adv_${Date.now()}`,
        response: {
          mainInsight: 'Gate ' + activation.gate + ' invites you to explore deeper...',
          bookCitations: [],
          chartSynthesis: {
            relevantGates: [activation.gate],
            consciousnessInsight: 'Your consciousness is awakening to new possibilities.',
            actionSteps: [
              'Reflect on your current state',
              'Take three conscious breaths',
              'Journal on what emerges',
            ],
          },
          generatedArtifact: {
            type: 'micro_post',
            content: `Gate ${activation.gate} wisdom: The answer lies within.`,
            suggestedHashtags: [`#Gate${activation.gate}`, '#HumanDesign', '#Consciousness'],
            visualSuggestion: `gate_${activation.gate}_mandala.png`,
          },
        },
        confidence: 0.6,
        followUpQuestions: [
          'Would you like a meditation for this gate?',
          'Shall I generate a post about your insight?',
        ],
      };
    }
  }

  /**
   * Update 3D agent state based on user consciousness fields
   */
  async updateAgentState(
    activation: UserActivationContext,
    currentView: string = 'home_screen'
  ): Promise<AgentStateResponse> {
    try {
      const request: AgentStateRequest = {
        userId: this.userId,
        currentView,
        userState: {
          consciousnessFields: activation.consciousnessFields,
          lastInteraction: new Date().toISOString(),
          currentApp: 'Paper Pal',
          emotionalTone: this.inferEmotionalTone(activation),
        },
        agentConfig: {
          form: 'hamster',
          personalitySeed: 'compassionate_guardian',
          animationState: 'idle',
        },
      };

      const response = await fetch(`${this.baseUrl}/api/agent/state`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(request),
      });

      if (!response.ok) {
        throw new Error(`Agent state update failed: ${response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Error updating agent state:', error);
      // Fallback response
      return {
        agentUpdate: {
          mood: 'supportive_curiosity',
          suggestedAction: 'gentle_prompt',
          dialogue: 'How are you feeling right now?',
          visualChanges: {
            colorShift: '#06b6d4 → #4ecdc4',
            animation: 'gentle_pulse',
            particleEffect: 'soft_pulses',
          },
          interactiveOffer: {
            type: 'quick_meditation',
            duration: 3,
            gateTheme: activation.gate,
          },
        },
      };
    }
  }

  /**
   * Infer emotional tone from consciousness fields
   */
  private inferEmotionalTone(activation: UserActivationContext): string {
    const fields = activation.consciousnessFields;
    const avgEnergy = Object.values(fields).reduce((a, b) => a + b) / Object.keys(fields).length;

    if (avgEnergy > 0.8) return 'joyful';
    if (avgEnergy > 0.6) return 'balanced';
    if (avgEnergy > 0.4) return 'contemplative';
    return 'introspective';
  }

  /**
   * Get default activation context
   */
  private getDefaultActivationContext(): UserActivationContext {
    return {
      gate: 1,
      line: 1,
      color: 1,
      tone: 1,
      base: 1,
      consciousnessFields: {
        mind: 0.5,
        heart: 0.5,
        body: 0.5,
        will: 0.5,
        shadow: 0.5,
        child: 0.5,
        soul: 0.5,
        spirit: 0.5,
        synthesis: 0.5,
      },
    };
  }

  /**
   * Set user ID for multi-user support
   */
  setUserId(userId: string): void {
    this.userId = userId;
  }

  /**
   * Set Synthia server URL
   */
  setBaseUrl(baseUrl: string): void {
    this.baseUrl = baseUrl;
  }
}

// Export singleton instance
export const synthiaClient = new SynthiaClient();
