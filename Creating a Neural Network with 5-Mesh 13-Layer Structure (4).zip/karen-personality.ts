      } catch (error) {
        console.error('Intelligence analysis failed:', error);
      }
    }

    // Detect request type and select appropriate roast
    if (input.includes('help') || input.includes('assist')) {
      message = this.selectRandom(this.roasts.help);
      sass = 9;
      roast = 7;
      emoji = '🙄';
    } else if (input.includes('upload')) {
      message = this.selectRandom(this.roasts.upload);
      sass = 8;
      roast = 6;
      emoji = '📤';
    } else if (input.includes('video') || input.includes('play')) {
      message = this.selectRandom(this.roasts.video);
      sass = 7;
      roast = 5;
      emoji = '🎬';
    } else if (input.includes('game') || input.includes('sims')) {
      message = this.selectRandom(this.roasts.game);
      sass = 8;
      roast = 7;
      emoji = '🎮';
    } else if (input.includes('what can you do') || input.includes('capabilities')) {
      message = this.selectRandom(this.roasts.capabilities);
      sass = 10;
      roast = 9;
      emoji = '✨';
    } else if (input.includes('learn') || input.includes('book')) {
      message = this.selectRandom(this.roasts.learn);
      sass = 8;
      roast = 6;
      emoji = '📚';
    } else if (input.includes('orchestrate') || input.includes('coordinate')) {
      message = this.selectRandom(this.roasts.orchestrate);
      sass = 9;
      roast = 8;
      emoji = '🎼';
    } else {
      message = this.selectRandom(this.roasts.default);
      sass = this.sassLevel;
      roast = this.roastIntensity;
    }

    return { message, sass_level: sass, roast_intensity: roast, emoji };
  }
