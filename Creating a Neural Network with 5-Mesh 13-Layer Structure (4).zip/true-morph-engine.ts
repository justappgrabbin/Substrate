/**
 * TRUE MORPH ENGINE
 * 
 * Implements the deterministic morphing system:
 * IntentNode → TransformNode → ArtifactNode
 * 
 * Each artifact has a Glyph ID (semantic checksum) for persistent addressing
 * in the 22-trillion coordinate space (e.g., SD5-D5(OUT)-G12-L4)
 */

import { MetastableGNN } from './metastable-gnn';

export interface HexagramState {
  gate: number;
  line: number;
  color: number;
  tone: number;
  resonanceScore: number;
  fieldTension: number;
}

export interface Glyph {
  id: string; // Semantic checksum (e.g., "SD5-D5(OUT)-G12-L4")
  hash: string; // SHA256 of content
  timestamp: number;
  resonanceSignature: number[]; // 384-element array from GNN
}

export interface IntentNode {
  id: string;
  glyph: Glyph;
  intent: string; // User's natural language request
  type: 'upload' | 'chat' | 'command';
  metadata: {
    timestamp: number;
    source: string;
    confidence: number;
  };
}

export interface TransformNode {
  id: string;
  glyph: Glyph;
  inputGlyph: string; // Reference to IntentNode glyph
  gnnState: HexagramState[]; // Final hexagram states from GNN
  fieldTension: number; // Peak tension during morphing
  morphPath: string[]; // Sequence of hexagrams traversed
  metadata: {
    timestamp: number;
    processingTime: number;
    gateSequence: number[]; // Which gates were activated
  };
}

export interface ArtifactNode {
  id: string;
  glyph: Glyph;
  transformGlyph: string; // Reference to TransformNode glyph
  type: 'game' | 'website' | 'dashboard' | 'guide' | 'experience';
  content: any; // The actual React component or data
  address: string; // Ontological address in 22-trillion space
  metadata: {
    timestamp: number;
    lineage: string[]; // [IntentNode.glyph, TransformNode.glyph, ArtifactNode.glyph]
    morphedFrom: string; // Original artifact type
    resonanceScore: number;
  };
}

export class TrueMorphEngine {
  private gnn: MetastableGNN;
  private intentNodes: Map<string, IntentNode> = new Map();
  private transformNodes: Map<string, TransformNode> = new Map();
  private artifactNodes: Map<string, ArtifactNode> = new Map();

  constructor(gnn: MetastableGNN) {
    this.gnn = gnn;
  }

  /**
   * Create a Glyph ID (semantic checksum) for an artifact
   * Format: {MESH}-{DIMENSION}({DIRECTION})-G{GATE}-L{LINE}
   */
  private createGlyph(content: any): Glyph {
    // Simple hash of content
    const hash = this.hashContent(content);
    
    // Get current GNN status to determine coordinates
    const status = this.gnn.getStatus();
    const primaryGate = (status as any).activeGates?.[0] || 1;
    const primaryLine = (status as any).activeLine || 1;
    
    // Build Glyph ID from GNN coordinates
    const glyphId = `SD5-D5(OUT)-G${primaryGate}-L${primaryLine}`;
    
    return {
      id: glyphId,
      hash,
      timestamp: Date.now(),
      resonanceSignature: [(status as any).globalFieldTension || 0],
    };
  }

  /**
   * Simple hash function for content
   */
  private hashContent(content: any): string {
    const str = JSON.stringify(content);
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32-bit integer
    }
    return Math.abs(hash).toString(16);
  }

  /**
   * Phase 1: Create IntentNode from user input
   */
  public createIntentNode(intent: string, type: 'upload' | 'chat' | 'command' = 'chat'): IntentNode {
    const glyph = this.createGlyph(intent);
    const node: IntentNode = {
      id: `intent-${Date.now()}`,
      glyph,
      intent,
      type,
      metadata: {
        timestamp: Date.now(),
        source: type,
        confidence: 0.5, // Initial confidence
      },
    };

    this.intentNodes.set(node.id, node);
    return node;
  }

  /**
   * Phase 2: Transform through GNN (deterministic open loop)
   */
  public async transformThroughGNN(intentNode: IntentNode): Promise<TransformNode> {
    const startTime = Date.now();
    
    // Run GNN morphing cycle based on intent
    const morphPath: string[] = [];
    let peakTension = 0;
    const gateSequence: number[] = [];

    // Analyze intent to seed GNN
    const seedGate = this.seedGNNFromIntent(intentNode.intent);
    gateSequence.push(seedGate);

    // Run deterministic GNN morphing
    for (let i = 0; i < 100; i++) {
      const status = this.gnn.getStatus();
      
      // Track path
      const activeGate = (status as any).activeGates?.[0] || 1;
      const activeLine = (status as any).activeLine || 1;
      morphPath.push(`G${activeGate}L${activeLine}`);
      peakTension = Math.max(peakTension, (status as any).globalFieldTension || 0);

      // Step the GNN
      await this.gnn.tick();

      // Check for convergence
      if (peakTension > 0.95) {
        break; // Regime flip triggered
      }
    }

    // Get final state
    const finalStatus = this.gnn.getStatus();
    const glyph = this.createGlyph(finalStatus);

    // Create hexagram states from status
    const gnnState: HexagramState[] = ((finalStatus as any).activeGates || []).map((gate: number) => ({
      gate,
      line: (finalStatus as any).activeLine || 1,
      color: ((gate - 1) % 6) + 1,
      tone: ((gate - 1) % 6) + 1,
      resonanceScore: (finalStatus as any).globalFieldTension || 0,
      fieldTension: (finalStatus as any).globalFieldTension || 0,
    }));

    const transformNode: TransformNode = {
      id: `transform-${Date.now()}`,
      glyph,
      inputGlyph: intentNode.glyph.id,
      gnnState,
      fieldTension: peakTension,
      morphPath,
      metadata: {
        timestamp: Date.now(),
        processingTime: Date.now() - startTime,
        gateSequence,
      },
    };

    this.transformNodes.set(transformNode.id, transformNode);
    return transformNode;
  }

  /**
   * Seed GNN based on intent keywords
   */
  private seedGNNFromIntent(intent: string): number {
    const keywords: Record<string, number> = {
      game: 59, // Gate 59 = Intimacy/Dissolution
      website: 11, // Gate 11 = Ideas/Ideation
      dashboard: 15, // Gate 15 = Diversity
      guide: 64, // Gate 64 = Completion/Confusion
      video: 20, // Gate 20 = Contemplation
      image: 10, // Gate 10 = Behavior
      organize: 34, // Gate 34 = Power/Possession
    };

    for (const [key, gate] of Object.entries(keywords)) {
      if (intent.toLowerCase().includes(key)) {
        return gate;
      }
    }

    return Math.floor(Math.random() * 64) + 1; // Random gate if no match
  }

  /**
   * Phase 3: Create ArtifactNode from transform
   */
  public createArtifactNode(transformNode: TransformNode): ArtifactNode {
    // Determine artifact type from GNN final state
    const artifactType = this.determineArtifactType(transformNode.gnnState);
    
    // Generate ontological address
    const address = this.generateOntologicalAddress(transformNode.gnnState);

    // Create content based on type
    const content = this.generateArtifactContent(artifactType, transformNode);

    const glyph = this.createGlyph(content);
    const intentNode = Array.from(this.intentNodes.values()).find(n => n.glyph.id === transformNode.inputGlyph);

    const artifactNode: ArtifactNode = {
      id: `artifact-${Date.now()}`,
      glyph,
      transformGlyph: transformNode.glyph.id,
      type: artifactType,
      content,
      address,
      metadata: {
        timestamp: Date.now(),
        lineage: [
          intentNode?.glyph.id || 'unknown',
          transformNode.glyph.id,
          glyph.id,
        ],
        morphedFrom: 'intent',
        resonanceScore: transformNode.gnnState[0]?.resonanceScore || 0,
      },
    };

    this.artifactNodes.set(artifactNode.id, artifactNode);
    return artifactNode;
  }

  /**
   * Determine artifact type from GNN state
   */
  private determineArtifactType(state: HexagramState[]): ArtifactNode['type'] {
    const primaryGate = state[0]?.gate || 0;
    
    // Map gates to artifact types
    if (primaryGate >= 1 && primaryGate <= 16) return 'website';
    if (primaryGate >= 17 && primaryGate <= 32) return 'game';
    if (primaryGate >= 33 && primaryGate <= 48) return 'dashboard';
    if (primaryGate >= 49 && primaryGate <= 64) return 'experience';
    
    return 'guide';
  }

  /**
   * Generate ontological address in 22-trillion coordinate space
   */
  private generateOntologicalAddress(state: HexagramState[]): string {
    const primary = state[0];
    if (!primary) return 'UNKNOWN';

    // Format: {MESH}-{DIMENSION}({DIRECTION})-G{GATE}-L{LINE}-C{COLOR}-T{TONE}
    return `SD5-D5(OUT)-G${primary.gate}-L${primary.line}-C${primary.color}-T${primary.tone}`;
  }

  /**
   * Generate artifact content based on type
   */
  private generateArtifactContent(type: ArtifactNode['type'], transform: TransformNode): any {
    return {
      type,
      title: `Morphed ${type}`,
      description: `Generated from GNN path: ${transform.morphPath.join(' → ')}`,
      gateSequence: transform.metadata.gateSequence,
      fieldTension: transform.fieldTension,
      timestamp: Date.now(),
    };
  }

  /**
   * Complete morph pipeline: Intent → Transform → Artifact
   */
  public async executeMorph(intent: string): Promise<ArtifactNode> {
    // Phase 1: Create IntentNode
    const intentNode = this.createIntentNode(intent);
    console.log('✓ IntentNode created:', intentNode.glyph.id);

    // Phase 2: Transform through GNN
    const transformNode = await this.transformThroughGNN(intentNode);
    console.log('✓ TransformNode created:', transformNode.glyph.id);
    console.log(`  Field tension: ${transformNode.fieldTension.toFixed(2)}`);
    console.log(`  Morph path: ${transformNode.morphPath.join(' → ')}`);

    // Phase 3: Create ArtifactNode
    const artifactNode = this.createArtifactNode(transformNode);
    console.log('✓ ArtifactNode created:', artifactNode.glyph.id);
    console.log(`  Type: ${artifactNode.type}`);
    console.log(`  Address: ${artifactNode.address}`);
    console.log(`  Lineage: ${artifactNode.metadata.lineage.join(' → ')}`);

    return artifactNode;
  }

  /**
   * Get all artifacts organized by type
   */
  public getOrganizedArtifacts(): Record<string, ArtifactNode[]> {
    const organized: Record<string, ArtifactNode[]> = {
      game: [],
      website: [],
      dashboard: [],
      guide: [],
      experience: [],
    };

    this.artifactNodes.forEach((artifact) => {
      organized[artifact.type].push(artifact);
    });

    return organized;
  }

  /**
   * Get artifact by Glyph ID
   */
  public getArtifactByGlyph(glyphId: string): ArtifactNode | undefined {
    let result: ArtifactNode | undefined;
    this.artifactNodes.forEach((artifact) => {
      if (artifact.glyph.id === glyphId) {
        result = artifact;
      }
    });
    return result;
  }

  /**
   * Get artifact lineage (trace back to original intent)
   */
  public getLineage(artifactId: string): { intent?: IntentNode; transform?: TransformNode; artifact?: ArtifactNode } {
    const artifact = this.artifactNodes.get(artifactId);
    if (!artifact) return {};

    let transform: TransformNode | undefined;
    this.transformNodes.forEach((t) => {
      if (t.glyph.id === artifact.transformGlyph) {
        transform = t;
      }
    });

    let intent: IntentNode | undefined;
    if (transform) {
      this.intentNodes.forEach((i) => {
        if (i.glyph.id === transform!.inputGlyph) {
          intent = i;
        }
      });
    }

    return { intent, transform, artifact };
  }
}
