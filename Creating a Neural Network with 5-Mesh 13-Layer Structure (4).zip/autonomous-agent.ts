    // Determine UI mode based on context
    if (this.goals.size > 0 && Array.from(this.goals.values()).some(g => g.status === 'executing')) {
      this.uiState.mode = 'planning';
    } else if (this.sensoryState.mood === 'analytical') {
      this.uiState.mode = 'explaining';
    } else {
      this.uiState.mode = 'chat';
    }

    // Morph intensity based on sensory input
    this.uiState.morphIntensity = this.sensoryState.overallIntensity;

    // Change colors based on mood
    const moodColors = {
      calm: { bg: '#0f172a', accent: '#06b6d4' },
      curious: { bg: '#0f172a', accent: '#8b5cf6' },
      focused: { bg: '#1a1f35', accent: '#06b6d4' },
      playful: { bg: '#1a2332', accent: '#ec4899' },
      analytical: { bg: '#0f172a', accent: '#10b981' },
    };

    const colors = moodColors[this.sensoryState.mood];
    this.uiState.backgroundColor = colors.bg;
    this.uiState.accentColor = colors.accent;

    return this.uiState;
  }

  /**
   * Learn from a book
   */
  public async learnFromBook(title: string, content: string): Promise<void> {
    const book = {
      title,
      content,
      learnedAt: Date.now(),
      concepts: this.extractConcepts(content),
    };

    this.books.set(title, book);
    
    // Update confidence on related topics
    this.updateConfidenceFromBook(book);
  }

  /**
   * Extract concepts from book
   */
  private extractConcepts(content: string): string[] {
    const commonWords = new Set(['the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with']);
    const words = content
      .toLowerCase()
      .split(/\s+/)
      .filter(word => word.length > 4 && !commonWords.has(word))
      .filter((word, index, arr) => arr.indexOf(word) === index);

    return words.slice(0, 50);
  }

  /**
   * Update confidence from learned book
   */
  private updateConfidenceFromBook(book: any): void {
    // Increase autonomy level as it learns
    this.autonomyLevel = Math.min(1, this.autonomyLevel + 0.05);
  }
