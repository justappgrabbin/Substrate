 * RESONANCE ORCHESTRATOR ENGINE
 * 
 * The living intelligence substrate that routes data through the 5-mesh 13-layer structure.
 * Each node is addressed by gate/line/color/tone/zodiac/house coordinates.
 * The orchestrator retrieves from the super base, personalizes via agents, and morphs visually.
 * 
 * Architecture:
 * - 5 Meshes (dimensional planes)
 * - 13 Layers per mesh (circuit families)
 * - 9 Centers per layer (body graph centers)
 * - 64 Nodes per center (hexagram states)
 * - 6 States per node (lines 1-6)
 * - 6 Modifications, 6 Senses, 6 Connecting Points per state
 * - 5 Base States (STABLE, CHANGING, RESOLVING, RESONANT, DORMANT)
 */

export interface Address {
  mesh: number; // 0-4 (Physical, Emotional, Mental, Soul, Field)
  layer: number; // 0-12 (Circuit families)
  center: number; // 0-8 (Body graph centers)
  node: number; // 0-63 (Hexagram states)
  line: number; // 1-6 (Line number)
  color: number; // 0-5 (I Ching color)
  tone: number; // 0-5 (I Ching tone)
  zodiac: number; // 0-11 (Zodiac sign)
  house: number; // 0-11 (Astrological house)
  dimension: number; // Spatial dimension
  arcDegree: number; // Time-driven arc (0-360)
}

export interface NodeState {
  address: Address;
  baseState: 'STABLE' | 'CHANGING' | 'RESOLVING' | 'RESONANT' | 'DORMANT';
  tension: number; // 0-1, proximity to flip threshold
  modifications: Modification[];
  senses: Sense[];
  connectingPoints: ConnectingPoint[];
  coherence: number; // Local coherence metric
  lastUpdated: number; // Timestamp
}

export interface Modification {
  type: 'gain' | 'noise' | 'bleed' | 'magnitude' | 'sensitivity' | 'resonance';
  value: number; // 0-1
  active: boolean;
}

export interface Sense {
  type: 'sight' | 'taste' | 'touch' | 'smell' | 'sound' | 'proprioception';
  intensity: number; // 0-1
  data: any;
}

export interface ConnectingPoint {
  type: 'input' | 'output' | 'memory' | 'lateral' | 'temporal' | 'field';
  connected: Address | null;
  strength: number; // 0-1
}

export interface SuperBaseEntry {
  id: string;
  address: Address;
  content: any;
  metadata: {
    gate?: number;
    line?: number;
    codon?: string;
    timestamp: number;
    resonanceScore?: number;
  };
}

export interface PersonalityProfile {
  userId: string;
  birthChart: any;
  preferences: Record<string, any>;
  learningHistory: any[];
  adaptationLevel: number; // 0-1
}