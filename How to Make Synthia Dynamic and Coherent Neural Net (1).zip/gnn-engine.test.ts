/**
 * SYNTHIA GNN Engine Tests
 * 
 * Vitest suite for core GNN functionality:
 * - Node creation and addressing
 * - Metastability state transitions
 * - Tension calculation
 * - Gate activation and propagation
 * - Recursive containment queries
 */

import { describe, it, expect, beforeEach } from 'vitest';
import SynthiaGNNEngine from './gnn-engine';

describe('SynthiaGNNEngine', () => {
  let engine: SynthiaGNNEngine;

  beforeEach(() => {
    engine = new SynthiaGNNEngine();
  });

  // ═══════════════════════════════════════════════════════════════
  // NODE CREATION & ADDRESSING
  // ═══════════════════════════════════════════════════════════════

  describe('Node Creation', () => {
    it('should create a node with correct 6D address', () => {
      const node = engine.createNode(1, 1, 'red', 'touch', 'Movement', 0);

      expect(node.gate).toBe(1);
      expect(node.line.line).toBe(1);
      expect(node.color).toBe('red');
      expect(node.tone).toBe('touch');
      expect(node.base).toBe('Movement');
      expect(node.house).toBe(0);
    });

    it('should assign correct center based on gate', () => {
      const node1 = engine.createNode(1, 1, 'red', 'touch', 'Movement', 0);
      expect(node1.center).toBe('G');

      const node2 = engine.createNode(21, 1, 'red', 'touch', 'Movement', 0);
      expect(node2.center).toBe('Heart');

      const node3 = engine.createNode(64, 1, 'red', 'touch', 'Movement', 0);
      expect(node3.center).toBe('Head');
    });

    it('should assign correct circuit based on gate', () => {
      const node1 = engine.createNode(1, 1, 'red', 'touch', 'Movement', 0);
      expect(node1.circuit).toBe('knowing');

      const node2 = engine.createNode(45, 1, 'red', 'touch', 'Movement', 0);
      expect(node2.circuit).toBe('ego');

      const node3 = engine.createNode(63, 1, 'red', 'touch', 'Movement', 0);
      expect(node3.circuit).toBe('understanding');
    });

    it('should initialize node in stable regime', () => {
      const node = engine.createNode(1, 1, 'red', 'touch', 'Movement', 0);

      expect(node.line.regime).toBe('stable');
      expect(node.line.tension).toBe(0);
      expect(node.activation).toBe(0);
    });
  });

  // ═══════════════════════════════════════════════════════════════
  // TENSION CALCULATION
  // ═══════════════════════════════════════════════════════════════

  describe('Tension Calculation', () => {
    it('should calculate tension as sigmoid of sum', () => {
      const tension = engine.calculateTension(0.2, 0.2, 0.2, 0.2);

      // sigmoid(0.8) ≈ 0.689
      expect(tension).toBeGreaterThan(0.6);
      expect(tension).toBeLessThan(0.8);
    });

    it('should return 0.5 when all inputs are 0', () => {
      const tension = engine.calculateTension(0, 0, 0, 0);

      // sigmoid(0) = 0.5
      expect(tension).toBeCloseTo(0.5, 2);
    });

    it('should return near 1 when inputs are high', () => {
      const tension = engine.calculateTension(1, 1, 1, 1);

      // sigmoid(4) ≈ 0.982
      expect(tension).toBeGreaterThan(0.95);
      expect(tension).toBeLessThan(1);
    });

    it('should be bounded between 0 and 1', () => {
      const tension1 = engine.calculateTension(-10, -10, -10, -10);
      const tension2 = engine.calculateTension(10, 10, 10, 10);

      expect(tension1).toBeGreaterThan(0);
      expect(tension1).toBeLessThan(1);
      expect(tension2).toBeGreaterThan(0);
      expect(tension2).toBeLessThanOrEqual(1);
    });
  });

  // ═══════════════════════════════════════════════════════════════
  // METASTABILITY & STATE TRANSITIONS
  // ═══════════════════════════════════════════════════════════════

  describe('Metastability & State Transitions', () => {
    it('should transition to changing regime when tension > 0.85', () => {
      const node = engine.createNode(1, 1, 'red', 'touch', 'Movement', 0);
      const nodeId = `1-1-red-touch-Movement-0`;

      engine.updateNodeState(nodeId, 0.9, 'internal');

      const fieldState = engine.getFieldState();
      const updatedNode = fieldState.nodes.get(nodeId);

      expect(updatedNode?.line.regime).toBe('changing');
      expect(updatedNode?.line.tension).toBeCloseTo(0.9, 1);
    });

    it('should set direction to next line when entering changing state', () => {
      const node = engine.createNode(1, 3, 'red', 'touch', 'Movement', 0);
      const nodeId = `1-3-red-touch-Movement-0`;

      engine.updateNodeState(nodeId, 0.9, 'internal');

      const fieldState = engine.getFieldState();
      const updatedNode = fieldState.nodes.get(nodeId);

      expect(updatedNode?.line.direction).toBe(4);
    });

    it('should wrap line 6 to line 1 when changing', () => {
      const node = engine.createNode(1, 6, 'red', 'touch', 'Movement', 0);
      const nodeId = `1-6-red-touch-Movement-0`;

      engine.updateNodeState(nodeId, 0.9, 'internal');

      const fieldState = engine.getFieldState();
      const updatedNode = fieldState.nodes.get(nodeId);

      expect(updatedNode?.line.direction).toBe(1);
    });

    it('should resolve to stable state when tension < 0.15', () => {
      const node = engine.createNode(1, 1, 'red', 'touch', 'Movement', 0);
      const nodeId = `1-1-red-touch-Movement-0`;

      // First enter changing state
      engine.updateNodeState(nodeId, 0.9, 'internal');
      let fieldState = engine.getFieldState();
      let updatedNode = fieldState.nodes.get(nodeId);
      expect(updatedNode?.line.regime).toBe('changing');

      // Then resolve to stable
      engine.updateNodeState(nodeId, 0.1, 'internal');
      fieldState = engine.getFieldState();
      updatedNode = fieldState.nodes.get(nodeId);

      expect(updatedNode?.line.regime).toBe('stable');
      expect(updatedNode?.line.direction).toBeUndefined();
    });

    it('should record morphing event when entering changing state', () => {
      const node = engine.createNode(1, 1, 'red', 'touch', 'Movement', 0);
      const nodeId = `1-1-red-touch-Movement-0`;

      engine.updateNodeState(nodeId, 0.9, 'internal');

      const history = engine.getMorphingHistory();
      expect(history.length).toBeGreaterThan(0);

      const lastEvent = history[history.length - 1];
      expect(lastEvent.type).toBe('line_change');
      expect(lastEvent.sourceGate).toBe(1);
    });
  });

  // ═══════════════════════════════════════════════════════════════
  // GATE ACTIVATION & PROPAGATION
  // ═══════════════════════════════════════════════════════════════

  describe('Gate Activation', () => {
    it('should activate a gate and increase node activation', () => {
      engine.createNode(1, 1, 'red', 'touch', 'Movement', 0);

      const events = engine.activateGate(1, 1.0);

      const fieldState = engine.getFieldState();
      const nodes = Array.from(fieldState.nodes.values());
      const gate1Nodes = nodes.filter(n => n.gate === 1);

      for (const node of gate1Nodes) {
        expect(node.activation).toBeGreaterThan(0);
      }
    });

    it('should propagate activation through connected gates', () => {
      // Gates 1 and 2 are connected (both in centering circuit)
      engine.createNode(1, 1, 'red', 'touch', 'Movement', 0);
      engine.createNode(2, 1, 'red', 'touch', 'Movement', 0);

      engine.activateGate(1, 1.0);

      const fieldState = engine.getFieldState();
      const nodes = Array.from(fieldState.nodes.values());
      const gate2Nodes = nodes.filter(n => n.gate === 2);

      // Gate 2 should have some activation from propagation
      for (const node of gate2Nodes) {
        expect(node.activation).toBeGreaterThanOrEqual(0);
      }
    });

    it('should trigger integration channel activation', () => {
      engine.createNode(34, 1, 'red', 'touch', 'Movement', 0);

      const events = engine.activateGate(34, 1.0);

      // Gate 34 is part of integration channels
      expect(events.some(e => e.type === 'integration_activation')).toBe(true);
    });

    it('should respect intensity parameter', () => {
      engine.createNode(1, 1, 'red', 'touch', 'Movement', 0);

      engine.activateGate(1, 0.5);

      const fieldState = engine.getFieldState();
      const nodes = Array.from(fieldState.nodes.values());
      const gate1Nodes = nodes.filter(n => n.gate === 1);

      for (const node of gate1Nodes) {
        // With intensity 0.5, activation should be 0.05 (0.5 * 0.1)
        expect(node.activation).toBeCloseTo(0.05, 1);
      }
    });
  });

  // ═══════════════════════════════════════════════════════════════
  // RECURSIVE CONTAINMENT
  // ═══════════════════════════════════════════════════════════════

  describe('Recursive Containment', () => {
    it('should query recursive containment for a node', () => {
      const node = engine.createNode(1, 1, 'red', 'touch', 'Movement', 0);
      const nodeId = `1-1-red-touch-Movement-0`;

      const containment = engine.getRecursiveContainment(nodeId);

      expect(typeof containment).toBe('object');
      expect(Object.keys(containment).length).toBeGreaterThanOrEqual(0);
    });

    it('should return empty object for non-existent node', () => {
      const containment = engine.getRecursiveContainment('non-existent');

      expect(containment).toEqual({});
    });

    it('should include activation values in containment', () => {
      engine.createNode(1, 1, 'red', 'touch', 'Movement', 0);
      engine.activateGate(1, 1.0);

      const nodeId = `1-1-red-touch-Movement-0`;
      const containment = engine.getRecursiveContainment(nodeId);

      const activationKeys = Object.keys(containment).filter(k => k.includes('activation'));
      expect(activationKeys.length).toBeGreaterThan(0);
    });
  });

  // ═══════════════════════════════════════════════════════════════
  // FIELD STATE & HISTORY
  // ═══════════════════════════════════════════════════════════════

  describe('Field State & History', () => {
    it('should track field state', () => {
      engine.createNode(1, 1, 'red', 'touch', 'Movement', 0);

      const fieldState = engine.getFieldState();

      expect(fieldState.timestamp).toBeGreaterThan(0);
      expect(fieldState.nodes.size).toBeGreaterThan(0);
      expect(fieldState.tension).toBeGreaterThanOrEqual(0);
      expect(fieldState.tension).toBeLessThanOrEqual(1);
    });

    it('should track tension history', () => {
      const node = engine.createNode(1, 1, 'red', 'touch', 'Movement', 0);
      const nodeId = `1-1-red-touch-Movement-0`;

      engine.updateNodeState(nodeId, 0.5, 'internal');
      engine.updateNodeState(nodeId, 0.6, 'external');
      engine.updateNodeState(nodeId, 0.7, 'circuit');

      const history = engine.getTensionHistory();

      expect(history.length).toBeGreaterThanOrEqual(3);
      expect(history[history.length - 1]).toBeCloseTo(0.7, 1);
    });

    it('should track morphing history', () => {
      const node = engine.createNode(1, 1, 'red', 'touch', 'Movement', 0);
      const nodeId = `1-1-red-touch-Movement-0`;

      engine.updateNodeState(nodeId, 0.9, 'internal');

      const history = engine.getMorphingHistory();

      expect(history.length).toBeGreaterThan(0);
      expect(history[0].type).toBe('line_change');
    });

    it('should limit history to 1000 entries', () => {
      const node = engine.createNode(1, 1, 'red', 'touch', 'Movement', 0);
      const nodeId = `1-1-red-touch-Movement-0`;

      // Add more than 1000 entries
      for (let i = 0; i < 1100; i++) {
        engine.updateNodeState(nodeId, Math.random(), 'internal');
      }

      const history = engine.getTensionHistory();

      expect(history.length).toBeLessThanOrEqual(1000);
    });
  });

  // ═══════════════════════════════════════════════════════════════
  // INTEGRATION TESTS
  // ═══════════════════════════════════════════════════════════════

  describe('Integration Tests', () => {
    it('should handle full activation cycle', () => {
      // Create nodes across multiple circuits
      engine.createNode(1, 1, 'red', 'touch', 'Movement', 0);
      engine.createNode(21, 1, 'red', 'touch', 'Movement', 0);
      engine.createNode(63, 1, 'red', 'touch', 'Movement', 0);

      // Activate gates
      engine.activateGate(1, 1.0);
      engine.activateGate(21, 0.8);
      engine.activateGate(63, 0.6);

      // Update tensions
      const nodeId1 = `1-1-red-touch-Movement-0`;
      engine.updateNodeState(nodeId1, 0.9, 'internal');

      // Check field state
      const fieldState = engine.getFieldState();
      expect(fieldState.nodes.size).toBeGreaterThan(0);

      // Check history
      const morphingHistory = engine.getMorphingHistory();
      expect(morphingHistory.length).toBeGreaterThan(0);
    });

    it('should maintain consistency across operations', () => {
      const node = engine.createNode(1, 1, 'red', 'touch', 'Movement', 0);
      const nodeId = `1-1-red-touch-Movement-0`;

      // Multiple state transitions
      engine.updateNodeState(nodeId, 0.3, 'internal');
      engine.updateNodeState(nodeId, 0.7, 'external');
      engine.updateNodeState(nodeId, 0.9, 'circuit');
      engine.updateNodeState(nodeId, 0.1, 'temporal');

      const fieldState = engine.getFieldState();
      const finalNode = fieldState.nodes.get(nodeId);

      expect(finalNode?.line.regime).toBe('stable');
      expect(finalNode?.line.tension).toBeCloseTo(0.1, 1);
    });
  });
});
