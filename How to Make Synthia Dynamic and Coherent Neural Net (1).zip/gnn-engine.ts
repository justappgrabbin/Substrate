/**
 * SYNTHIA GNN Engine
 * 
 * Core neural network implementation with:
 * - 5-dimensional topology (Being/Movement/Space/Design/Evolution)
 * - 13-graph I Ching house system
 * - 9-center node clusters
 * - 64 gates with 6 lines each
 * - Metastability & state-dependent computation
 * - Full cross-family morphing (CNN ↔ GNN ↔ RNN ↔ Transformer ↔ SNN)
 * - Recursive node containment via field queries
 */

// ═══════════════════════════════════════════════════════════════
// TYPE DEFINITIONS
// ═══════════════════════════════════════════════════════════════

export type Dimension = 'Being' | 'Movement' | 'Space' | 'Design' | 'Evolution';
export type Regime = 'stable' | 'changing';
export type TriggerType = 'internal' | 'external' | 'circuit' | 'temporal';
export type CircuitType = 'understanding' | 'knowing' | 'sensing' | 'ego' | 'defense' | 'centering' | 'integration';
export type NetType = 'dff' | 'rbm' | 'lsm' | 'dbn' | 'hmm' | 'mc' | 'drn' | 'esn' | 'cap' | 'cnn' | 'rnn' | 'transformer' | 'snn';
export type Color = 'red' | 'orange' | 'yellow' | 'green' | 'blue' | 'indigo';
export type Tone = 'touch' | 'smell' | 'taste' | 'outer_vision' | 'inner_vision' | 'hearing';
export type Base = 'Movement' | 'Evolution' | 'Being' | 'Design' | 'Space';

// ═══════════════════════════════════════════════════════════════
// CORE STRUCTURES
// ═══════════════════════════════════════════════════════════════

export interface FieldVector {
  [key: string]: number;
}

export interface LineState {
  line: 1 | 2 | 3 | 4 | 5 | 6;
  regime: Regime;
  direction?: 1 | 2 | 3 | 4 | 5 | 6;
  tension: number;
  trigger?: TriggerType;
  timestamp: number;
}

export interface ResonanceNode {
  // Address in 6D space
  gate: number;           // 1-64
  line: LineState;
  color: Color;
  tone: Tone;
  base: Base;
  house: number;          // 0-12 (I Ching)
  center: string;         // Head, Ajna, Throat, G, Heart, Solar, Sacral, Spleen, Root

  // State
  activation: number;     // 0-1, current signal level
  memory: FieldVector;    // Historical state
  gradient: FieldVector;  // Plasticity direction
  
  // Circuit membership
  circuit: CircuitType;
  netType: NetType;

  // Metadata
  lastUpdated: number;
  updateCount: number;
}

export interface GlobalFieldState {
  timestamp: number;
  nodes: Map<string, ResonanceNode>;
  dimensionalConfig: Record<Dimension, number>;
  circuitStates: Record<CircuitType, number>;
  activationPattern: FieldVector;
  tension: number;
  morphingActive: boolean;
}

export interface MorphingEvent {
  timestamp: number;
  type: 'line_change' | 'circuit_transition' | 'dimensional_shift' | 'integration_activation';
  sourceGate: number;
  targetGate?: number;
  circuit: CircuitType;
  tension: number;
  affectedNodes: string[];
}

// ═══════════════════════════════════════════════════════════════
// GATE & CENTER DEFINITIONS
// ═══════════════════════════════════════════════════════════════

export const CENTERS = {
  Head: { idx: 0, type: 'pressure', aware: null, motor: false, color: '#a855f7' },
  Ajna: { idx: 1, type: 'awareness', aware: 'conceptual', motor: false, color: '#7c3aed' },
  Throat: { idx: 2, type: 'expression', aware: null, motor: false, color: '#ec4899' },
  G: { idx: 3, type: 'identity', aware: null, motor: false, color: '#f59e0b' },
  Heart: { idx: 4, type: 'motor', aware: null, motor: true, color: '#ef4444' },
  Solar: { idx: 5, type: 'awareness', aware: 'emotional', motor: true, color: '#06b6d4' },
  Sacral: { idx: 6, type: 'motor', aware: null, motor: true, color: '#f97316' },
  Spleen: { idx: 7, type: 'awareness', aware: 'survival', motor: false, color: '#10b981' },
  Root: { idx: 8, type: 'pressure', aware: null, motor: true, color: '#64748b' },
};

export const GATES_TO_CENTERS: Record<number, string> = {
  61: 'Head', 63: 'Head', 64: 'Head',
  4: 'Ajna', 11: 'Ajna', 17: 'Ajna', 24: 'Ajna', 43: 'Ajna', 47: 'Ajna',
  8: 'Throat', 12: 'Throat', 16: 'Throat', 20: 'Throat', 23: 'Throat',
  31: 'Throat', 33: 'Throat', 35: 'Throat', 45: 'Throat', 56: 'Throat', 62: 'Throat',
  1: 'G', 2: 'G', 7: 'G', 10: 'G', 13: 'G', 15: 'G', 25: 'G', 46: 'G',
  21: 'Heart', 26: 'Heart', 40: 'Heart', 51: 'Heart',
  6: 'Solar', 22: 'Solar', 30: 'Solar', 36: 'Solar', 37: 'Solar', 49: 'Solar', 55: 'Solar',
  3: 'Sacral', 5: 'Sacral', 9: 'Sacral', 14: 'Sacral', 27: 'Sacral',
  29: 'Sacral', 34: 'Sacral', 42: 'Sacral', 59: 'Sacral',
  18: 'Spleen', 28: 'Spleen', 32: 'Spleen', 44: 'Spleen', 48: 'Spleen', 50: 'Spleen', 57: 'Spleen',
  19: 'Root', 38: 'Root', 39: 'Root', 41: 'Root', 52: 'Root', 53: 'Root', 54: 'Root', 58: 'Root', 60: 'Root',
};

// ═══════════════════════════════════════════════════════════════
// CIRCUIT DEFINITIONS
// ═══════════════════════════════════════════════════════════════

export const CIRCUITS: Record<CircuitType, { gates: number[]; netType: NetType; description: string }> = {
  understanding: {
    gates: [63, 4, 17, 62, 18, 58, 16, 48, 9, 52, 5, 15, 31, 7],
    netType: 'dff',
    description: 'Deductive, feedforward logic',
  },
  knowing: {
    gates: [61, 24, 43, 23, 28, 38, 39, 55, 22, 12, 3, 60, 2, 14, 1, 8, 33, 13, 20, 57],
    netType: 'lsm',
    description: 'Individual, pulsing temporal dynamics',
  },
  sensing: {
    gates: [64, 47, 11, 56, 35, 36, 41, 30, 53, 42, 29, 46],
    netType: 'dbn',
    description: 'Collective, layer-wise developmental',
  },
  ego: {
    gates: [45, 21, 26, 44, 40, 37],
    netType: 'hmm',
    description: 'Hidden state, reputation-based',
  },
  defense: {
    gates: [59, 6, 27, 50, 19, 49, 32, 54],
    netType: 'mc',
    description: 'Tribal protection, cyclical state',
  },
  centering: {
    gates: [34, 10, 25, 51],
    netType: 'drn',
    description: 'Identity persistence',
  },
  integration: {
    gates: [34, 57, 10, 20],
    netType: 'esn',
    description: 'Dzhanibekov portals, cross-circuit bridges',
  },
};

// ═══════════════════════════════════════════════════════════════
// CHANNELS (EDGES)
// ═══════════════════════════════════════════════════════════════

export const CHANNELS: [number, number][] = [
  // Understanding Circuit (DFF)
  [63, 4], [17, 62], [18, 58], [16, 48], [9, 52], [5, 15], [31, 7],
  // Knowing Circuit (LSM)
  [61, 24], [43, 23], [28, 38], [39, 55], [22, 12], [3, 60], [2, 14], [1, 8], [33, 13], [20, 57],
  // Sensing Circuit (DBN)
  [64, 47], [11, 56], [35, 36], [41, 30], [53, 42], [29, 46],
  // Ego Circuit (HMM)
  [45, 21], [26, 44], [40, 37],
  // Defense Circuit
  [59, 6], [27, 50], [19, 49], [32, 54],
  // Centering Circuit
  [34, 10], [25, 51],
  // Integration Channels (Dzhanibekov Portals)
  [34, 57], [10, 20], [57, 10], [20, 34],
];

export const INTEGRATION_CHANNELS: [number, number][] = [
  [34, 57], // Power: engine needs direction
  [10, 20], // Awakening: identity meets now
  [57, 10], // Perfected Form: intuition meets behavior
  [20, 34], // Charisma: now meets power
];

// ═══════════════════════════════════════════════════════════════
// GNN ENGINE CLASS
// ═══════════════════════════════════════════════════════════════

export class SynthiaGNNEngine {
  private fieldState: GlobalFieldState;
  private nodeIndex: Map<string, ResonanceNode> = new Map();
  private morphingHistory: MorphingEvent[] = [];
  private tensionHistory: number[] = [];

  constructor() {
    this.fieldState = {
      timestamp: Date.now(),
      nodes: new Map(),
      dimensionalConfig: {
        Being: 0,
        Movement: 0,
        Space: 0,
        Design: 0,
        Evolution: 0,
      },
      circuitStates: {
        understanding: 0,
        knowing: 0,
        sensing: 0,
        ego: 0,
        defense: 0,
        centering: 0,
        integration: 0,
      },
      activationPattern: {},
      tension: 0,
      morphingActive: false,
    };
  }

  /**
   * Create a node at a specific address in the 6D space
   */
  createNode(
    gate: number,
    line: 1 | 2 | 3 | 4 | 5 | 6,
    color: Color,
    tone: Tone,
    base: Base,
    house: number
  ): ResonanceNode {
    const center = GATES_TO_CENTERS[gate] || 'Unknown';
    const circuit = this.getCircuitForGate(gate);
    const netType = CIRCUITS[circuit]?.netType || 'dff';

    const nodeId = `${gate}-${line}-${color}-${tone}-${base}-${house}`;
    
    const node: ResonanceNode = {
      gate,
      line: {
        line,
        regime: 'stable',
        tension: 0,
        timestamp: Date.now(),
      },
      color,
      tone,
      base,
      house,
      center,
      activation: 0,
      memory: {},
      gradient: {},
      circuit,
      netType,
      lastUpdated: Date.now(),
      updateCount: 0,
    };

    this.nodeIndex.set(nodeId, node);
    this.fieldState.nodes.set(nodeId, node);

    return node;
  }

  /**
   * Determine which circuit a gate belongs to
   */
  private getCircuitForGate(gate: number): CircuitType {
    for (const [circuitName, circuitData] of Object.entries(CIRCUITS)) {
      if (circuitData.gates.includes(gate)) {
        return circuitName as CircuitType;
      }
    }
    return 'understanding';
  }

  /**
   * Calculate tension from multiple sources
   */
  calculateTension(
    localContradiction: number,
    externalPressure: number,
    circuitPressure: number,
    temporalResonance: number
  ): number {
    const raw = localContradiction + externalPressure + circuitPressure + temporalResonance;
    return this.sigmoid(raw);
  }

  /**
   * Sigmoid activation function
   */
  private sigmoid(x: number): number {
    return 1 / (1 + Math.exp(-x));
  }

  /**
   * Update a node's state based on tension
   */
  updateNodeState(nodeId: string, tension: number, trigger: TriggerType): void {
    const node = this.nodeIndex.get(nodeId);
    if (!node) return;

    // Update tension history
    this.tensionHistory.push(tension);
    if (this.tensionHistory.length > 1000) {
      this.tensionHistory.shift();
    }

    // Transition to changing regime if tension exceeds threshold
    if (tension > 0.85 && node.line.regime === 'stable') {
      this.enterChangingState(node, tension, trigger);
    }

    // Resolve to stable state if tension drops below threshold
    if (tension < 0.15 && node.line.regime === 'changing') {
      this.resolveToStableState(node);
    }

    node.line.tension = tension;
    node.lastUpdated = Date.now();
    node.updateCount++;
  }

  /**
   * Enter metastable "changing" regime
   */
  private enterChangingState(node: ResonanceNode, tension: number, trigger: TriggerType): void {
    node.line.regime = 'changing';
    node.line.trigger = trigger;
    node.line.tension = tension;

    // Determine target line (next stable state)
    const targetLine = ((node.line.line % 6) + 1) as 1 | 2 | 3 | 4 | 5 | 6;
    node.line.direction = targetLine;

    // Amplify plasticity
    const gainMultiplier = 2 + tension * 3; // 2x-5x sensitivity
    const noiseFloor = 0.1 * tension;
    const crossCircuitBleed = tension * 0.3;

    // Apply metastable computation
    this.applyMetastableComputation(node, {
      gainMultiplier,
      noiseFloor,
      crossCircuitBleed,
    });

    // Trigger morphing event
    this.recordMorphingEvent('line_change', node.gate, targetLine, node.circuit, tension, [node.gate.toString()]);
  }

  /**
   * Resolve from changing state to new stable state
   */
  private resolveToStableState(node: ResonanceNode): void {
    if (node.line.direction) {
      node.line.line = node.line.direction;
    }
    node.line.regime = 'stable';
    node.line.trigger = undefined;
    node.line.direction = undefined;
    node.line.tension = 0;
  }

  /**
   * Apply metastable computation dynamics
   */
  private applyMetastableComputation(
    node: ResonanceNode,
    params: { gainMultiplier: number; noiseFloor: number; crossCircuitBleed: number }
  ): void {
    // Amplify gradients
    for (const [key, value] of Object.entries(node.gradient)) {
      node.gradient[key] = value * params.gainMultiplier;
    }

    // Store computation parameters in memory
    node.memory.metastableGain = params.gainMultiplier;
    node.memory.noiseFloor = params.noiseFloor;
    node.memory.crossCircuitBleed = params.crossCircuitBleed;
  }

  /**
   * Activate a gate and propagate through circuit
   */
  activateGate(gate: number, intensity: number = 1.0): MorphingEvent[] {
    const events: MorphingEvent[] = [];
    const circuit = this.getCircuitForGate(gate);
    const affectedNodes: string[] = [];

    // Find all nodes for this gate
    const nodeEntries = Array.from(this.nodeIndex.entries());
    for (const [nodeId, node] of nodeEntries) {
      if (node.gate === gate) {
        node.activation = Math.min(1, node.activation + intensity * 0.1);
        affectedNodes.push(nodeId);

        // Propagate through channels
        const connectedGates = this.getConnectedGates(gate);
        for (const connectedGate of connectedGates) {
          const connectedNodes = Array.from(this.nodeIndex.values()).filter(n => n.gate === connectedGate);
          for (const connectedNode of connectedNodes) {
            connectedNode.activation = Math.min(1, connectedNode.activation + intensity * 0.05);
            affectedNodes.push(connectedNode.gate.toString());
          }
        }
      }
    }

    // Check for integration channel activation
    if (INTEGRATION_CHANNELS.some(([a, b]) => a === gate || b === gate)) {
      this.fieldState.morphingActive = true;
      events.push(this.recordMorphingEvent('integration_activation', gate, undefined, circuit, this.fieldState.tension, affectedNodes));
    }

    return events;
  }

  /**
   * Get gates connected to a given gate via channels
   */
  private getConnectedGates(gate: number): number[] {
    const connected: number[] = [];
    for (const [a, b] of CHANNELS) {
      if (a === gate) connected.push(b);
      if (b === gate) connected.push(a);
    }
    return connected;
  }

  /**
   * Record a morphing event
   */
  private recordMorphingEvent(
    type: 'line_change' | 'circuit_transition' | 'dimensional_shift' | 'integration_activation',
    sourceGate: number,
    targetGate: number | undefined,
    circuit: CircuitType,
    tension: number,
    affectedNodes: string[]
  ): MorphingEvent {
    const event: MorphingEvent = {
      timestamp: Date.now(),
      type,
      sourceGate,
      targetGate,
      circuit,
      tension,
      affectedNodes,
    };

    this.morphingHistory.push(event);
    if (this.morphingHistory.length > 1000) {
      this.morphingHistory.shift();
    }

    return event;
  }

  /**
   * Get current field state
   */
  getFieldState(): GlobalFieldState {
    return { ...this.fieldState };
  }

  /**
   * Get morphing history
   */
  getMorphingHistory(): MorphingEvent[] {
    return [...this.morphingHistory];
  }

  /**
   * Get tension history
   */
  getTensionHistory(): number[] {
    return [...this.tensionHistory];
  }

  /**
   * Query recursive containment for a node
   */
  getRecursiveContainment(nodeId: string): FieldVector {
    const node = this.nodeIndex.get(nodeId);
    if (!node) return {};

    const allNodes = Array.from(this.nodeIndex.values());
    const containedNodes = allNodes.filter(n => {
      // Nodes in same circuit and dimension
      return n.circuit === node.circuit && n.base === node.base;
    });

    const aggregated: FieldVector = {};
    for (const containedNode of containedNodes) {
      aggregated[`${containedNode.gate}-activation`] = containedNode.activation;
      aggregated[`${containedNode.gate}-tension`] = containedNode.line.tension;
    }

    return aggregated;
  }
}

export default SynthiaGNNEngine;
