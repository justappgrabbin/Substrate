/**
 * Karen AI Chat Component
 * 
 * Real-time chat interface with Karen personality
 * showing her emotional state and reasoning
 */

import React, { useState, useRef, useEffect } from 'react';
import { trpc } from '@/lib/trpc';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Loader2, Send } from 'lucide-react';

export interface ChatMessage {
  id: string;
  sender: 'user' | 'karen';
  message: string;
  personality?: {
    voice: string;
    mood: string;
    confidence: number;
  };
  reasoning?: string;
  timestamp: number;
}

interface KarenChatProps {
  className?: string;
}

export default function KarenChat({ className }: KarenChatProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [karenState, setKarenState] = useState<any>(null);

  // tRPC queries
  const personalityQuery = trpc.karen.getPersonality.useQuery(void 0, {
    refetchInterval: 2000,
  });

  const generateResponseMutation = trpc.karen.generateResponse.useMutation();

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Update Karen's state
  useEffect(() => {
    if (personalityQuery.data) {
      setKarenState(personalityQuery.data);
    }
  }, [personalityQuery.data]);

  // Initial greeting
  useEffect(() => {
    if (messages.length === 0 && karenState) {
      const greeting: ChatMessage = {
        id: 'greeting-' + Date.now(),
        sender: 'karen',
        message: `Hey there. I'm Karen. Right now I'm feeling ${karenState.mood}, and my ${karenState.dominantCircuit} circuit is active. What's on your mind?`,
        personality: {
          voice: karenState.voice,
          mood: karenState.mood,
          confidence: karenState.confidence,
        },
        timestamp: Date.now(),
      };
      setMessages([greeting]);
    }
  }, [karenState]);

  // Handle sending message
  const handleSendMessage = async () => {
    if (!inputValue.trim() || isLoading) return;

    const userMessage: ChatMessage = {
      id: 'user-' + Date.now(),
      sender: 'user',
      message: inputValue,
      timestamp: Date.now(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);

    try {
      const response = await generateResponseMutation.mutateAsync({
        message: inputValue,
      });

      const karenMessage: ChatMessage = {
        id: 'karen-' + Date.now(),
        sender: 'karen',
        message: response.message,
        personality: response.personality,
        reasoning: response.reasoning,
        timestamp: Date.now(),
      };

      setMessages(prev => [...prev, karenMessage]);
    } catch (error) {
      console.error('Failed to generate response:', error);
      const errorMessage: ChatMessage = {
        id: 'error-' + Date.now(),
        sender: 'karen',
        message: 'Hmm, something went wrong. My circuits are a bit scrambled right now.',
        timestamp: Date.now(),
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  // Handle Enter key
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className={`flex flex-col h-full ${className}`}>
      {/* Karen State Indicator */}
      {karenState && (
        <div className="bg-slate-700/30 border-b border-slate-600 p-3 mb-4">
          <div className="flex items-center justify-between text-xs">
            <div className="space-y-1">
              <div className="text-slate-300">
                <span className="text-cyan-400 font-semibold">{karenState.voice}</span>
                {' '}mode • {' '}
                <span className="text-purple-400">{karenState.mood}</span>
              </div>
              <div className="text-slate-400">
                {karenState.dominantCircuit} circuit active • {(karenState.confidence * 100).toFixed(0)}% confident
              </div>
            </div>
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-cyan-500/20 to-purple-500/20 border border-cyan-500/30 flex items-center justify-center">
              <div
                className="w-8 h-8 rounded-full bg-gradient-to-br from-cyan-400 to-purple-400"
                style={{ opacity: 0.3 + karenState.confidence * 0.7 }}
              />
            </div>
          </div>
        </div>
      )}

      {/* Messages */}
      <div className="flex-1 overflow-y-auto space-y-4 mb-4 pr-2">
        {messages.map(msg => (
          <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div
              className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                msg.sender === 'user'
                  ? 'bg-cyan-500/20 border border-cyan-500/30 text-slate-100'
                  : 'bg-purple-500/20 border border-purple-500/30 text-slate-100'
              }`}
            >
              <p className="text-sm">{msg.message}</p>
              {msg.reasoning && msg.sender === 'karen' && (
                <p className="text-xs text-slate-400 mt-2 italic">
                  ({msg.reasoning})
                </p>
              )}
              <p className="text-xs text-slate-500 mt-1">
                {new Date(msg.timestamp).toLocaleTimeString()}
              </p>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-purple-500/20 border border-purple-500/30 px-4 py-2 rounded-lg">
              <Loader2 className="w-4 h-4 animate-spin text-purple-400" />
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="flex gap-2">
        <Input
          value={inputValue}
          onChange={e => setInputValue(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder="Ask Karen something..."
          disabled={isLoading}
          className="bg-slate-700/50 border-slate-600 text-slate-100 placeholder-slate-500"
        />
        <Button
          onClick={handleSendMessage}
          disabled={isLoading || !inputValue.trim()}
          className="bg-cyan-500 hover:bg-cyan-600 text-white"
        >
          {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
        </Button>
      </div>
    </div>
  );
}
