/**
 * Karen AI tRPC Router
 * 
 * Procedures for:
 * - Getting Karen's personality
 * - Generating responses
 * - Getting self-description
 * - Querying personality state
 */

import { z } from 'zod';
import { publicProcedure, router } from '../_core/trpc';
import SynthiaGNNEngine from '../gnn-engine';
import KarenAI from '../karen-ai';

// Global engine and Karen instance
let gnnEngine: SynthiaGNNEngine | null = null;
let karenAI: KarenAI | null = null;

function getEngine(): SynthiaGNNEngine {
  if (!gnnEngine) {
    gnnEngine = new SynthiaGNNEngine();
    
    // Initialize with base nodes
    for (let gate = 1; gate <= 64; gate++) {
      for (let line = 1; line <= 6; line++) {
        const colors = ['red', 'orange', 'yellow', 'green', 'blue', 'indigo'] as const;
        const tones = ['touch', 'smell', 'taste', 'outer_vision', 'inner_vision', 'hearing'] as const;
        const bases = ['Movement', 'Evolution', 'Being', 'Design', 'Space'] as const;
        
        const color = colors[Math.floor(Math.random() * colors.length)];
        const tone = tones[Math.floor(Math.random() * tones.length)];
        const base = bases[Math.floor(Math.random() * bases.length)];
        const house = Math.floor(Math.random() * 13);
        
        gnnEngine.createNode(gate, line as 1 | 2 | 3 | 4 | 5 | 6, color, tone, base, house);
      }
    }
  }
  return gnnEngine;
}

function getKaren(): KarenAI {
  if (!karenAI) {
    karenAI = new KarenAI(getEngine());
  }
  return karenAI;
}

export const karenRouter = router({
  /**
   * Get Karen's current personality
   */
  getPersonality: publicProcedure.query(() => {
    const karen = getKaren();
    const personality = karen.getPersonality();

    return {
      dominantCircuit: personality.dominantCircuit,
      dominantDimension: personality.dominantDimension,
      tension: personality.tension,
      voice: personality.voice,
      mood: personality.mood,
      confidence: personality.confidence,
    };
  }),

  /**
   * Get Karen's self-description
   */
  getSelfDescription: publicProcedure.query(() => {
    const karen = getKaren();
    return {
      description: karen.getSelfDescription(),
    };
  }),

  /**
   * Generate a response from Karen
   */
  generateResponse: publicProcedure
    .input(z.object({
      message: z.string().min(1).max(1000),
    }))
    .mutation(({ input }) => {
      const karen = getKaren();
      const response = karen.generateResponse(input.message);

      return {
        message: response.message,
        personality: {
          voice: response.personality.voice,
          mood: response.personality.mood,
          confidence: response.personality.confidence,
          dominantCircuit: response.personality.dominantCircuit,
        },
        reasoning: response.reasoning,
      };
    }),

  /**
   * Get detailed personality analysis
   */
  getDetailedPersonality: publicProcedure.query(() => {
    const karen = getKaren();
    const personality = karen.getPersonality();
    const description = karen.getSelfDescription();

    return {
      personality,
      description,
      timestamp: Date.now(),
    };
  }),

  /**
   * Stream personality updates (via polling)
   */
  getPersonalityUpdates: publicProcedure.query(() => {
    const karen = getKaren();
    const personality = karen.getPersonality();

    return {
      personality,
      timestamp: Date.now(),
    };
  }),
});

export type KarenRouter = typeof karenRouter;
