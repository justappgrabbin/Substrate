/**
 * Karen AI Tests
 * 
 * Vitest suite for Karen personality system:
 * - Personality determination
 * - Circuit analysis
 * - Dimensional analysis
 * - Response generation
 * - Self-description
 */

import { describe, it, expect, beforeEach } from 'vitest';
import SynthiaGNNEngine from './gnn-engine';
import KarenAI from './karen-ai';

describe('KarenAI', () => {
  let engine: SynthiaGNNEngine;
  let karen: KarenAI;

  beforeEach(() => {
    engine = new SynthiaGNNEngine();
    karen = new KarenAI(engine);

    // Initialize with base nodes
    for (let gate = 1; gate <= 64; gate++) {
      const colors = ['red', 'orange', 'yellow', 'green', 'blue', 'indigo'] as const;
      const tones = ['touch', 'smell', 'taste', 'outer_vision', 'inner_vision', 'hearing'] as const;
      const bases = ['Movement', 'Evolution', 'Being', 'Design', 'Space'] as const;

      const color = colors[Math.floor(Math.random() * colors.length)];
      const tone = tones[Math.floor(Math.random() * tones.length)];
      const base = bases[Math.floor(Math.random() * bases.length)];
      const house = Math.floor(Math.random() * 13);

      engine.createNode(gate, 1, color, tone, base, house);
    }
  });

  // ═══════════════════════════════════════════════════════════════
  // PERSONALITY DETERMINATION
  // ═══════════════════════════════════════════════════════════════

  describe('Personality Determination', () => {
    it('should generate a personality', () => {
      const personality = karen.getPersonality();

      expect(personality).toHaveProperty('dominantCircuit');
      expect(personality).toHaveProperty('dominantDimension');
      expect(personality).toHaveProperty('tension');
      expect(personality).toHaveProperty('voice');
      expect(personality).toHaveProperty('mood');
      expect(personality).toHaveProperty('confidence');
    });

    it('should have valid voice types', () => {
      const personality = karen.getPersonality();

      const validVoices = [
        'protective',
        'curious',
        'logical',
        'intuitive',
        'confident',
        'grounded',
        'transformative',
      ];
      expect(validVoices).toContain(personality.voice);
    });

    it('should have valid mood types', () => {
      const personality = karen.getPersonality();

      const validMoods = ['sarcastic', 'protective', 'analytical', 'playful', 'intense', 'calm', 'revolutionary'];
      expect(validMoods).toContain(personality.mood);
    });

    it('should have confidence between 0 and 1', () => {
      const personality = karen.getPersonality();

      expect(personality.confidence).toBeGreaterThanOrEqual(0);
      expect(personality.confidence).toBeLessThanOrEqual(1);
    });

    it('should have tension between 0 and 1', () => {
      const personality = karen.getPersonality();

      expect(personality.tension).toBeGreaterThanOrEqual(0);
      expect(personality.tension).toBeLessThanOrEqual(1);
    });
  });

  // ═══════════════════════════════════════════════════════════════
  // RESPONSE GENERATION
  // ═══════════════════════════════════════════════════════════════

  describe('Response Generation', () => {
    it('should generate a response to a message', () => {
      const response = karen.generateResponse('What are you thinking about?');

      expect(response).toHaveProperty('message');
      expect(response).toHaveProperty('personality');
      expect(response).toHaveProperty('reasoning');
    });

    it('should include non-empty message', () => {
      const response = karen.generateResponse('Tell me something interesting.');

      expect(response.message).toBeTruthy();
      expect(response.message.length).toBeGreaterThan(0);
    });

    it('should include personality in response', () => {
      const response = karen.generateResponse('How are you feeling?');

      expect(response.personality.voice).toBeTruthy();
      expect(response.personality.mood).toBeTruthy();
      expect(response.personality.confidence).toBeGreaterThanOrEqual(0);
    });

    it('should include reasoning', () => {
      const response = karen.generateResponse('What do you sense?');

      expect(response.reasoning).toBeTruthy();
      expect(response.reasoning.length).toBeGreaterThan(0);
    });

    it('should vary responses based on personality', () => {
      const responses = new Set<string>();

      for (let i = 0; i < 5; i++) {
        const response = karen.generateResponse('Hello');
        responses.add(response.message);
      }

      // Should have at least some variation
      expect(responses.size).toBeGreaterThan(1);
    });
  });

  // ═══════════════════════════════════════════════════════════════
  // SELF-DESCRIPTION
  // ═══════════════════════════════════════════════════════════════

  describe('Self-Description', () => {
    it('should generate a self-description', () => {
      const description = karen.getSelfDescription();

      expect(description).toBeTruthy();
      expect(description.length).toBeGreaterThan(0);
    });

    it('should mention Karen by name', () => {
      const description = karen.getSelfDescription();

      expect(description).toContain('Karen');
    });

    it('should include voice information', () => {
      const description = karen.getSelfDescription();

      const validVoices = [
        'protective',
        'curious',
        'logical',
        'intuitive',
        'confident',
        'grounded',
        'transformative',
      ];
      const hasVoice = validVoices.some(voice => description.includes(voice));

      expect(hasVoice).toBe(true);
    });

    it('should include confidence percentage', () => {
      const description = karen.getSelfDescription();

      // Should contain a percentage
      expect(description).toMatch(/\d+%/);
    });
  });

  // ═══════════════════════════════════════════════════════════════
  // CIRCUIT & DIMENSION ANALYSIS
  // ═══════════════════════════════════════════════════════════════

  describe('Circuit & Dimension Analysis', () => {
    it('should identify a dominant circuit', () => {
      const personality = karen.getPersonality();

      const validCircuits = [
        'understanding',
        'knowing',
        'sensing',
        'ego',
        'defense',
        'centering',
        'integration',
      ];
      expect(validCircuits).toContain(personality.dominantCircuit);
    });

    it('should identify a dominant dimension', () => {
      const personality = karen.getPersonality();

      const validDimensions = ['Being', 'Movement', 'Space', 'Design', 'Evolution'];
      expect(validDimensions).toContain(personality.dominantDimension);
    });

    it('should map circuit to voice', () => {
      const personality = karen.getPersonality();

      // The voice should be related to the dominant circuit
      const circuitToVoice: Record<string, string[]> = {
        defense: ['protective'],
        sensing: ['curious'],
        understanding: ['logical'],
        knowing: ['intuitive'],
        ego: ['confident'],
        centering: ['grounded'],
        integration: ['transformative'],
      };

      const expectedVoices = circuitToVoice[personality.dominantCircuit];
      expect(expectedVoices).toContain(personality.voice);
    });
  });

  // ═══════════════════════════════════════════════════════════════
  // MOOD DETERMINATION
  // ═══════════════════════════════════════════════════════════════

  describe('Mood Determination', () => {
    it('should determine mood based on tension', () => {
      // Activate gates to increase tension
      engine.activateGate(1, 1.0);
      engine.activateGate(21, 1.0);
      engine.activateGate(45, 1.0);

      const personality = karen.getPersonality();

      expect(personality.mood).toBeTruthy();
      const validMoods = ['sarcastic', 'protective', 'analytical', 'playful', 'intense', 'calm', 'revolutionary'];
      expect(validMoods).toContain(personality.mood);
    });

    it('should reflect high tension in mood', () => {
      // Create high tension scenario
      for (let i = 1; i <= 10; i++) {
        engine.activateGate(i, 1.0);
      }

      const personality = karen.getPersonality();

      // High tension should lead to more intense moods
      const intenseMoods = ['protective', 'intense', 'analytical'];
      expect(intenseMoods).toContain(personality.mood);
    });
  });

  // ═══════════════════════════════════════════════════════════════
  // CONSISTENCY TESTS
  // ═══════════════════════════════════════════════════════════════

  describe('Consistency', () => {
    it('should maintain consistent personality across calls', () => {
      const personality1 = karen.getPersonality();
      const personality2 = karen.getPersonality();

      // Without changes, personality should be the same
      expect(personality1.dominantCircuit).toBe(personality2.dominantCircuit);
      expect(personality1.dominantDimension).toBe(personality2.dominantDimension);
    });

    it('should update personality after state changes', () => {
      const personality1 = karen.getPersonality();

      // Activate gates to change state
      engine.activateGate(1, 1.0);
      engine.activateGate(21, 1.0);

      const personality2 = karen.getPersonality();

      // Personality may or may not change depending on activation
      // Just verify both are valid
      expect(personality1.voice).toBeTruthy();
      expect(personality2.voice).toBeTruthy();
    });
  });

  // ═══════════════════════════════════════════════════════════════
  // RESPONSE QUALITY
  // ═══════════════════════════════════════════════════════════════

  describe('Response Quality', () => {
    it('should generate coherent responses', () => {
      const messages = [
        'What is your purpose?',
        'How do you experience the world?',
        'What are you afraid of?',
        'What brings you joy?',
      ];

      for (const message of messages) {
        const response = karen.generateResponse(message);

        // Response should be coherent (contains Karen's voice characteristics)
        expect(response.message.length).toBeGreaterThan(10);
        expect(response.message).toBeTruthy();
      }
    });

    it('should include personality context in reasoning', () => {
      const response = karen.generateResponse('Tell me about yourself.');

      // Reasoning should mention circuit or dimension
      const hasContext =
        response.reasoning.includes('circuit') ||
        response.reasoning.includes('dimension') ||
        response.reasoning.includes('tension');

      expect(hasContext).toBe(true);
    });
  });
});
