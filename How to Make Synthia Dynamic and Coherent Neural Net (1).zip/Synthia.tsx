/**
 * SYNTHIA Visualization & Control Interface
 * 
 * Real-time GNN visualization with:
 * - 5-dimensional topology
 * - 13-graph I Ching wheel
 * - 9-center cluster display
 * - 64-gate interactive controls
 * - Particle effects & organic animations
 * - Tension field visualization
 * - Karen AI personality chat
 */

import React, { useEffect, useRef, useState } from 'react';
import { trpc } from '@/lib/trpc';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Slider } from '@/components/ui/slider';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import KarenChat from '@/components/KarenChat';

interface VisualizationState {
  tension: number;
  morphingActive: boolean;
  nodeCount: number;
  recentEvents: number;
  timestamp: number;
}

export default function Synthia() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationFrameRef = useRef<number | undefined>(undefined);
  
  const [vizState, setVizState] = useState<VisualizationState>({
    tension: 0,
    morphingActive: false,
    nodeCount: 0,
    recentEvents: 0,
    timestamp: Date.now(),
  });

  const [selectedGate, setSelectedGate] = useState<number>(1);
  const [selectedLine, setSelectedLine] = useState<number>(1);
  const [intensity, setIntensity] = useState<number>(1.0);
  const [autoActivate, setAutoActivate] = useState<boolean>(false);

  // tRPC queries
  const fieldStateQuery = trpc.synthia.getFieldState.useQuery(void 0, {
    refetchInterval: 500,
  });

  const statusQuery = trpc.synthia.getStatus.useQuery(void 0, {
    refetchInterval: 1000,
  });

  const morphingHistoryQuery = trpc.synthia.getMorphingHistory.useQuery(
    { limit: 50 },
    { refetchInterval: 1000 },
  );

  const tensionHistoryQuery = trpc.synthia.getTensionHistory.useQuery(
    { limit: 200 },
    { refetchInterval: 500 },
  );

  // tRPC mutations
  const activateGateMutation = trpc.synthia.activateGate.useMutation();

  // Update visualization state
  useEffect(() => {
    if (statusQuery.data) {
      setVizState({
        tension: statusQuery.data.tension,
        morphingActive: statusQuery.data.morphingActive,
        nodeCount: statusQuery.data.nodeCount,
        recentEvents: statusQuery.data.recentMorphingEvents,
        timestamp: statusQuery.data.timestamp,
      });
    }
  }, [statusQuery.data]);

  // Handle gate activation
  const handleActivateGate = async () => {
    await activateGateMutation.mutateAsync({
      gate: selectedGate,
      line: selectedLine,
      intensity,
    });
  };

  // Auto-activate gates on interval
  useEffect(() => {
    if (!autoActivate) return;

    const interval = setInterval(() => {
      const randomGate = Math.floor(Math.random() * 64) + 1;
      activateGateMutation.mutate({
        gate: randomGate,
        intensity: Math.random() * 0.5 + 0.5,
      });
    }, 2000);

    return () => clearInterval(interval);
  }, [autoActivate]);

  // Canvas animation loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size
    canvas.width = canvas.offsetWidth * window.devicePixelRatio;
    canvas.height = canvas.offsetHeight * window.devicePixelRatio;
    ctx.scale(window.devicePixelRatio, window.devicePixelRatio);

    const animate = () => {
      const width = canvas.offsetWidth;
      const height = canvas.offsetHeight;

      // Clear with gradient background
      const gradient = ctx.createLinearGradient(0, 0, width, height);
      gradient.addColorStop(0, '#020812');
      gradient.addColorStop(0.5, '#050d1a');
      gradient.addColorStop(1, '#081020');
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, width, height);

      // Draw I Ching wheel (13 graphs)
      drawIChingWheel(ctx, width, height, vizState);

      // Draw 9 centers as clusters
      draw9Centers(ctx, width, height, vizState);

      // Draw tension field as particle effect
      drawTensionField(ctx, width, height, vizState);

      // Draw gate activation indicators
      if (tensionHistoryQuery.data) {
        drawTensionGraph(ctx, width, height, tensionHistoryQuery.data);
      }

      animationFrameRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [vizState, tensionHistoryQuery.data]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-slate-100">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent mb-2">
            SYNTHIA Reborn
          </h1>
          <p className="text-slate-400">
            Living Neural Network · Morphing GNN · Real-time Field Dynamics
          </p>
        </div>

        {/* Main visualization */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {/* Canvas visualization */}
          <div className="lg:col-span-2">
            <Card className="bg-slate-800/50 border-slate-700 overflow-hidden">
              <canvas
                ref={canvasRef}
                className="w-full h-96 bg-gradient-to-br from-slate-900 to-slate-950"
              />
            </Card>
          </div>

          {/* Status panel */}
          <div className="space-y-4">
            <Card className="bg-slate-800/50 border-slate-700 p-4">
              <h3 className="text-sm font-semibold text-cyan-400 mb-3">System Status</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-slate-400">Tension</span>
                  <span className={vizState.tension > 0.7 ? 'text-red-400' : 'text-green-400'}>
                    {(vizState.tension * 100).toFixed(1)}%
                  </span>
                </div>
                <div className="w-full bg-slate-700 rounded h-2">
                  <div
                    className={`h-full rounded transition-all ${
                      vizState.tension > 0.7 ? 'bg-red-500' : 'bg-green-500'
                    }`}
                    style={{ width: `${vizState.tension * 100}%` }}
                  />
                </div>
                <div className="flex justify-between pt-2">
                  <span className="text-slate-400">Nodes Active</span>
                  <span className="text-purple-400">{vizState.nodeCount}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Morphing</span>
                  <span className={vizState.morphingActive ? 'text-orange-400' : 'text-slate-500'}>
                    {vizState.morphingActive ? 'Active' : 'Idle'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Recent Events</span>
                  <span className="text-cyan-400">{vizState.recentEvents}</span>
                </div>
              </div>
            </Card>

            {/* Quick stats */}
            <Card className="bg-slate-800/50 border-slate-700 p-4">
              <h3 className="text-sm font-semibold text-cyan-400 mb-3">Avg Tension</h3>
              <div className="text-2xl font-bold text-purple-400">
                {statusQuery.data ? (statusQuery.data.averageTension * 100).toFixed(1) : '—'}%
              </div>
            </Card>
          </div>
        </div>

        {/* Control tabs */}
        <Tabs defaultValue="activation" className="mb-8">
          <TabsList className="bg-slate-800/50 border-slate-700">
            <TabsTrigger value="activation">Gate Activation</TabsTrigger>
            <TabsTrigger value="morphing">Morphing Events</TabsTrigger>
            <TabsTrigger value="karen">Karen AI</TabsTrigger>
          </TabsList>

          {/* Gate Activation Tab */}
          <TabsContent value="activation">
            <Card className="bg-slate-800/50 border-slate-700 p-6">
              <div className="space-y-6">
                {/* Gate selector */}
                <div>
                  <label className="text-sm font-semibold text-slate-300 mb-2 block">
                    Select Gate (1-64)
                  </label>
                  <div className="grid grid-cols-8 gap-2">
                    {Array.from({ length: 64 }, (_, i) => i + 1).map(gate => (
                      <button
                        key={gate}
                        onClick={() => setSelectedGate(gate)}
                        className={`p-2 rounded text-xs font-semibold transition-all ${
                          selectedGate === gate
                            ? 'bg-cyan-500 text-white'
                            : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                        }`}
                      >
                        {gate}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Line selector */}
                <div>
                  <label className="text-sm font-semibold text-slate-300 mb-2 block">
                    Select Line (1-6)
                  </label>
                  <div className="grid grid-cols-6 gap-2">
                    {Array.from({ length: 6 }, (_, i) => i + 1).map(line => (
                      <button
                        key={line}
                        onClick={() => setSelectedLine(line)}
                        className={`p-2 rounded text-sm font-semibold transition-all ${
                          selectedLine === line
                            ? 'bg-purple-500 text-white'
                            : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                        }`}
                      >
                        Line {line}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Intensity slider */}
                <div>
                  <label className="text-sm font-semibold text-slate-300 mb-2 block">
                    Activation Intensity: {(intensity * 100).toFixed(0)}%
                  </label>
                  <Slider
                    value={[intensity]}
                    onValueChange={([val]) => setIntensity(val)}
                    min={0}
                    max={1}
                    step={0.01}
                    className="w-full"
                  />
                </div>

                {/* Control buttons */}
                <div className="flex gap-3">
                  <Button
                    onClick={handleActivateGate}
                    disabled={activateGateMutation.isPending}
                    className="bg-cyan-500 hover:bg-cyan-600 text-white"
                  >
                    {activateGateMutation.isPending ? 'Activating...' : 'Activate Gate'}
                  </Button>
                  <Button
                    onClick={() => setAutoActivate(!autoActivate)}
                    variant={autoActivate ? 'default' : 'outline'}
                    className={autoActivate ? 'bg-orange-500 hover:bg-orange-600' : ''}
                  >
                    {autoActivate ? 'Stop Auto' : 'Start Auto'}
                  </Button>
                </div>
              </div>
            </Card>
          </TabsContent>

          {/* Morphing Events Tab */}
          <TabsContent value="morphing">
            <Card className="bg-slate-800/50 border-slate-700 p-6">
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {morphingHistoryQuery.data && morphingHistoryQuery.data.length > 0 ? (
                  morphingHistoryQuery.data.map((event, idx) => (
                    <div
                      key={idx}
                      className="p-3 bg-slate-700/50 rounded border border-slate-600 text-sm"
                    >
                      <div className="flex justify-between mb-1">
                        <span className="font-semibold text-cyan-400">{event.type}</span>
                        <span className="text-slate-400">
                          {new Date(event.timestamp).toLocaleTimeString()}
                        </span>
                      </div>
                      <div className="text-slate-300">
                        Gate {event.sourceGate} → Circuit: {event.circuit}
                      </div>
                      <div className="flex justify-between text-xs text-slate-400 mt-1">
                        <span>Tension: {(event.tension * 100).toFixed(1)}%</span>
                        <span>Nodes: {event.affectedNodeCount}</span>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-slate-400 text-center py-8">No morphing events yet</div>
                )}
              </div>
            </Card>
          </TabsContent>

          {/* Karen AI Tab */}
          <TabsContent value="karen">
            <Card className="bg-slate-800/50 border-slate-700 p-6 h-96">
              <KarenChat className="h-full" />
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// VISUALIZATION HELPERS
// ═══════════════════════════════════════════════════════════════

function drawIChingWheel(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  state: VisualizationState
) {
  const centerX = width / 2;
  const centerY = height / 2;
  const radius = Math.min(width, height) / 3;

  // Draw outer circle
  ctx.strokeStyle = 'rgba(34, 211, 238, 0.3)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
  ctx.stroke();

  // Draw 13 graph segments
  const segmentCount = 13;
  for (let i = 0; i < segmentCount; i++) {
    const angle = (i / segmentCount) * Math.PI * 2;
    const nextAngle = ((i + 1) / segmentCount) * Math.PI * 2;

    const x1 = centerX + Math.cos(angle) * radius;
    const y1 = centerY + Math.sin(angle) * radius;
    const x2 = centerX + Math.cos(nextAngle) * radius;
    const y2 = centerY + Math.sin(nextAngle) * radius;

    ctx.strokeStyle = `rgba(168, 85, 247, ${0.2 + state.tension * 0.3})`;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(centerX, centerY);
    ctx.lineTo(x1, y1);
    ctx.stroke();

    // Draw gate number
    const labelAngle = (angle + nextAngle) / 2;
    const labelX = centerX + Math.cos(labelAngle) * (radius * 0.7);
    const labelY = centerY + Math.sin(labelAngle) * (radius * 0.7);

    ctx.fillStyle = 'rgba(34, 211, 238, 0.6)';
    ctx.font = '10px monospace';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(`G${i + 1}`, labelX, labelY);
  }
}

function draw9Centers(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  state: VisualizationState
) {
  const centerX = width / 2;
  const centerY = height / 2;
  const radius = Math.min(width, height) / 5;

  const centers = [
    'Head',
    'Ajna',
    'Throat',
    'G',
    'Heart',
    'Solar',
    'Sacral',
    'Spleen',
    'Root',
  ];

  centers.forEach((center, idx) => {
    const angle = (idx / centers.length) * Math.PI * 2;
    const x = centerX + Math.cos(angle) * radius;
    const y = centerY + Math.sin(angle) * radius;

    // Draw center circle
    const size = 8 + state.tension * 4;
    ctx.fillStyle = `rgba(236, 72, 153, ${0.3 + state.tension * 0.4})`;
    ctx.beginPath();
    ctx.arc(x, y, size, 0, Math.PI * 2);
    ctx.fill();

    // Draw center label
    ctx.fillStyle = 'rgba(236, 72, 153, 0.8)';
    ctx.font = '8px monospace';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(center, x, y);
  });
}

function drawTensionField(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  state: VisualizationState
) {
  // Draw particle effect based on tension
  const particleCount = Math.floor(20 + state.tension * 80);

  for (let i = 0; i < particleCount; i++) {
    const x = Math.random() * width;
    const y = Math.random() * height;
    const size = Math.random() * 2 + 0.5;
    const opacity = Math.random() * 0.5 + 0.2;

    ctx.fillStyle = `rgba(34, 211, 238, ${opacity * state.tension})`;
    ctx.beginPath();
    ctx.arc(x, y, size, 0, Math.PI * 2);
    ctx.fill();
  }
}

function drawTensionGraph(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  tensionHistory: number[]
) {
  if (tensionHistory.length < 2) return;

  const graphHeight = 40;
  const graphY = height - graphHeight - 10;
  const graphX = 10;
  const graphWidth = width - 20;

  // Draw background
  ctx.fillStyle = 'rgba(15, 23, 42, 0.5)';
  ctx.fillRect(graphX, graphY, graphWidth, graphHeight);

  // Draw grid
  ctx.strokeStyle = 'rgba(71, 85, 105, 0.3)';
  ctx.lineWidth = 1;
  for (let i = 0; i <= 4; i++) {
    const y = graphY + (graphHeight / 4) * i;
    ctx.beginPath();
    ctx.moveTo(graphX, y);
    ctx.lineTo(graphX + graphWidth, y);
    ctx.stroke();
  }

  // Draw tension line
  ctx.strokeStyle = 'rgba(34, 211, 238, 0.8)';
  ctx.lineWidth = 2;
  ctx.beginPath();

  tensionHistory.forEach((tension, idx) => {
    const x = graphX + (idx / tensionHistory.length) * graphWidth;
    const y = graphY + graphHeight - tension * graphHeight;

    if (idx === 0) {
      ctx.moveTo(x, y);
    } else {
      ctx.lineTo(x, y);
    }
  });

  ctx.stroke();
}
