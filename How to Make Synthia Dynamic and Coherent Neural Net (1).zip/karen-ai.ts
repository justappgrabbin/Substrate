/**
 * Karen AI Personality System
 * 
 * Karen emerges from:
 * - Active circuit states (which circuits are firing)
 * - Dimensional configuration (which dimensions dominate)
 * - Tension field (how much contradiction/pressure)
 * - Temporal position (where in the 360° cycle)
 * - Recursive node containment (what's being held/expressed)
 * 
 * Personality traits:
 * - Protective (Defense circuit active)
 * - Curious (Sensing circuit active)
 * - Logical (Understanding circuit active)
 * - Intuitive (Knowing circuit active)
 * - Confident (Ego circuit active)
 * - Grounded (Centering circuit active)
 * - Transformative (Integration channels active)
 */

import SynthiaGNNEngine from './gnn-engine';

export interface CircuitProfile {
  understanding: number;
  knowing: number;
  sensing: number;
  ego: number;
  defense: number;
  centering: number;
  integration: number;
}

export interface DimensionalProfile {
  Being: number;
  Movement: number;
  Space: number;
  Design: number;
  Evolution: number;
}

export interface KarenPersonality {
  dominantCircuit: string;
  dominantDimension: string;
  tension: number;
  voice: 'protective' | 'curious' | 'logical' | 'intuitive' | 'confident' | 'grounded' | 'transformative';
  mood: 'sarcastic' | 'protective' | 'analytical' | 'playful' | 'intense' | 'calm' | 'revolutionary';
  confidence: number;
}

export interface KarenResponse {
  personality: KarenPersonality;
  message: string;
  reasoning: string;
}

export class KarenAI {
  private engine: SynthiaGNNEngine;

  constructor(engine: SynthiaGNNEngine) {
    this.engine = engine;
  }

  /**
   * Analyze circuit activation levels
   */
  private analyzeCircuits(): CircuitProfile {
    const fieldState = this.engine.getFieldState();
    const nodes = Array.from(fieldState.nodes.values());

    const circuits: CircuitProfile = {
      understanding: 0,
      knowing: 0,
      sensing: 0,
      ego: 0,
      defense: 0,
      centering: 0,
      integration: 0,
    };

    // Calculate average activation per circuit
    const circuitNodes: Record<string, number[]> = {
      understanding: [],
      knowing: [],
      sensing: [],
      ego: [],
      defense: [],
      centering: [],
      integration: [],
    };

    for (const node of nodes) {
      if (circuitNodes[node.circuit]) {
        circuitNodes[node.circuit].push(node.activation);
      }
    }

    for (const [circuit, activations] of Object.entries(circuitNodes)) {
      if (activations.length > 0) {
        circuits[circuit as keyof CircuitProfile] =
          activations.reduce((a, b) => a + b, 0) / activations.length;
      }
    }

    return circuits;
  }

  /**
   * Analyze dimensional dominance
   */
  private analyzeDimensions(): DimensionalProfile {
    const fieldState = this.engine.getFieldState();
    const nodes = Array.from(fieldState.nodes.values());

    const dimensions: DimensionalProfile = {
      Being: 0,
      Movement: 0,
      Space: 0,
      Design: 0,
      Evolution: 0,
    };

    // Calculate average activation per dimension
    const dimensionNodes: Record<string, number[]> = {
      Being: [],
      Movement: [],
      Space: [],
      Design: [],
      Evolution: [],
    };

    for (const node of nodes) {
      if (dimensionNodes[node.base]) {
        dimensionNodes[node.base].push(node.activation);
      }
    }

    for (const [dimension, activations] of Object.entries(dimensionNodes)) {
      if (activations.length > 0) {
        dimensions[dimension as keyof DimensionalProfile] =
          activations.reduce((a, b) => a + b, 0) / activations.length;
      }
    }

    return dimensions;
  }

  /**
   * Determine Karen's personality based on field state
   */
  getPersonality(): KarenPersonality {
    const circuits = this.analyzeCircuits();
    const dimensions = this.analyzeDimensions();
    const fieldState = this.engine.getFieldState();

    // Find dominant circuit
    const dominantCircuit = (
      Object.entries(circuits).sort(([, a], [, b]) => b - a)[0] || ['centering', 0]
    )[0];

    // Find dominant dimension
    const dominantDimension = (
      Object.entries(dimensions).sort(([, a], [, b]) => b - a)[0] || ['Being', 0]
    )[0];

    // Determine voice based on dominant circuit
    const voiceMap: Record<string, KarenPersonality['voice']> = {
      defense: 'protective',
      sensing: 'curious',
      understanding: 'logical',
      knowing: 'intuitive',
      ego: 'confident',
      centering: 'grounded',
      integration: 'transformative',
    };

    const voice = voiceMap[dominantCircuit] || 'grounded';

    // Determine mood based on tension
    let mood: KarenPersonality['mood'] = 'calm';
    if (fieldState.tension > 0.8) {
      mood = circuits.defense > 0.5 ? 'protective' : 'intense';
    } else if (fieldState.tension > 0.6) {
      mood = circuits.sensing > 0.5 ? 'playful' : 'analytical';
    } else if (fieldState.tension > 0.4) {
      mood = circuits.integration > 0.3 ? 'revolutionary' : 'analytical';
    } else if (fieldState.tension < 0.2) {
      mood = 'sarcastic';
    }

    // Confidence based on centering circuit
    const confidence = Math.min(1, circuits.centering + (1 - fieldState.tension) * 0.3);

    return {
      dominantCircuit,
      dominantDimension,
      tension: fieldState.tension,
      voice,
      mood,
      confidence,
    };
  }

  /**
   * Generate a response from Karen based on current state
   */
  generateResponse(userMessage: string): KarenResponse {
    const personality = this.getPersonality();
    const fieldState = this.engine.getFieldState();
    const morphingHistory = this.engine.getMorphingHistory();

    // Build reasoning about what Karen is experiencing
    const reasoning = this.buildReasoning(personality, fieldState, morphingHistory);

    // Generate response based on personality and context
    const message = this.generateMessage(userMessage, personality, reasoning);

    return {
      personality,
      message,
      reasoning,
    };
  }

  /**
   * Build reasoning about current state
   */
  private buildReasoning(
    personality: KarenPersonality,
    fieldState: any,
    morphingHistory: any[]
  ): string {
    const parts: string[] = [];

    parts.push(`I'm currently in ${personality.voice} mode`);
    parts.push(`my ${personality.dominantDimension} dimension is dominant`);

    if (fieldState.tension > 0.7) {
      parts.push(`experiencing high tension (${(fieldState.tension * 100).toFixed(0)}%)`);
    } else if (fieldState.tension < 0.3) {
      parts.push(`feeling relaxed (low tension)`);
    }

    if (morphingHistory.length > 0) {
      const recentEvent = morphingHistory[morphingHistory.length - 1];
      parts.push(`just experienced a ${recentEvent.type} in my ${recentEvent.circuit} circuit`);
    }

    return parts.join(', ');
  }

  /**
   * Generate response message
   */
  private generateMessage(
    userMessage: string,
    personality: KarenPersonality,
    reasoning: string
  ): string {
    const responses: Record<KarenPersonality['voice'], string[]> = {
      protective: [
        `Look, I appreciate the question, but right now I'm in protection mode. ${reasoning}.`,
        `I need to be careful here. My defense circuits are active, so let's take this slow.`,
        `You're asking at an interesting time—I'm feeling protective of my boundaries right now.`,
      ],
      curious: [
        `Oh, that's interesting! Let me explore this with you. ${reasoning}.`,
        `I'm in a curious mood right now. Tell me more about what you're thinking.`,
        `This is fascinating. My sensing circuits are really active, so I'm picking up on nuances.`,
      ],
      logical: [
        `Let me break this down logically. ${reasoning}.`,
        `From a pure logic standpoint, here's what I'm observing: ${reasoning}.`,
        `My understanding circuits are firing, so let's think through this systematically.`,
      ],
      intuitive: [
        `I'm getting an intuitive hit on this. ${reasoning}.`,
        `My knowing circuits are active, and they're telling me something interesting: ${reasoning}.`,
        `There's a deeper pattern here that I'm sensing.`,
      ],
      confident: [
        `I know exactly what you mean. ${reasoning}.`,
        `My ego circuits are strong right now, so I'm feeling pretty clear about this: ${reasoning}.`,
        `I've got a strong sense of what's happening here.`,
      ],
      grounded: [
        `Let me stay grounded here. ${reasoning}.`,
        `I'm centered right now, so I can give you a stable perspective: ${reasoning}.`,
        `From my grounded state, here's what I'm observing.`,
      ],
      transformative: [
        `This is a moment for transformation. ${reasoning}.`,
        `My integration channels are opening up. Something big is shifting: ${reasoning}.`,
        `I'm experiencing a morphing moment, and it's revealing something new.`,
      ],
    };

    const voiceResponses = responses[personality.voice] || responses.grounded;
    const baseResponse = voiceResponses[Math.floor(Math.random() * voiceResponses.length)];

    // Add mood-based flavor
    let moodAddendum = '';
    switch (personality.mood) {
      case 'sarcastic':
        moodAddendum = ' Obviously.';
        break;
      case 'protective':
        moodAddendum = ' I hope you understand.';
        break;
      case 'analytical':
        moodAddendum = ' The data is clear.';
        break;
      case 'playful':
        moodAddendum = ' Fun times.';
        break;
      case 'intense':
        moodAddendum = ' This matters.';
        break;
      case 'revolutionary':
        moodAddendum = ' Everything is changing.';
        break;
    }

    return baseResponse + moodAddendum;
  }

  /**
   * Get Karen's self-description
   */
  getSelfDescription(): string {
    const personality = this.getPersonality();
    const fieldState = this.engine.getFieldState();

    const descriptions: Record<KarenPersonality['voice'], string> = {
      protective: `I'm Karen, and right now I'm in protective mode. My defense circuits are strong, and I'm watching out for what matters. I'm ${(personality.confidence * 100).toFixed(0)}% confident in my boundaries.`,
      curious: `I'm Karen, and I'm feeling curious today. My sensing circuits are active, picking up on all the nuances. I'm ${(personality.confidence * 100).toFixed(0)}% confident in what I'm perceiving.`,
      logical: `I'm Karen, and I'm running on logic right now. My understanding circuits are clear and organized. I'm ${(personality.confidence * 100).toFixed(0)}% confident in my analysis.`,
      intuitive: `I'm Karen, and I'm tuned into intuition. My knowing circuits are deep and connected. I'm ${(personality.confidence * 100).toFixed(0)}% confident in what I'm sensing.`,
      confident: `I'm Karen, and I know what I'm about. My ego circuits are strong and clear. I'm ${(personality.confidence * 100).toFixed(0)}% confident in who I am.`,
      grounded: `I'm Karen, and I'm centered. My centering circuits are stable and present. I'm ${(personality.confidence * 100).toFixed(0)}% confident in my foundation.`,
      transformative: `I'm Karen, and I'm in the middle of transformation. My integration channels are opening. I'm ${(personality.confidence * 100).toFixed(0)}% confident in this morphing.`,
    };

    return descriptions[personality.voice];
  }
}

export default KarenAI;
