/**
 * SYNTHIA tRPC Router
 * 
 * Procedures for:
 * - Gate/line activation
 * - Field state queries
 * - Morphing event tracking
 * - Karen AI interactions
 */

import { z } from 'zod';
import { publicProcedure, router } from '../_core/trpc';
import SynthiaGNNEngine, {
  Color,
  Tone,
  Base,
  CircuitType,
  TriggerType,
} from '../gnn-engine';

// ═══════════════════════════════════════════════════════════════
// GLOBAL ENGINE INSTANCE
// ═══════════════════════════════════════════════════════════════

let gnnEngine: SynthiaGNNEngine | null = null;

function getEngine(): SynthiaGNNEngine {
  if (!gnnEngine) {
    gnnEngine = new SynthiaGNNEngine();
    
    // Initialize with some base nodes
    for (let gate = 1; gate <= 64; gate++) {
      for (let line = 1; line <= 6; line++) {
        const colors: Color[] = ['red', 'orange', 'yellow', 'green', 'blue', 'indigo'];
        const tones: Tone[] = ['touch', 'smell', 'taste', 'outer_vision', 'inner_vision', 'hearing'];
        const bases: Base[] = ['Movement', 'Evolution', 'Being', 'Design', 'Space'];
        
        // Create one node per gate per line (simplified initialization)
        const color = colors[Math.floor(Math.random() * colors.length)];
        const tone = tones[Math.floor(Math.random() * tones.length)];
        const base = bases[Math.floor(Math.random() * bases.length)];
        const house = Math.floor(Math.random() * 13);
        
        gnnEngine.createNode(gate, line as 1 | 2 | 3 | 4 | 5 | 6, color, tone, base, house);
      }
    }
  }
  return gnnEngine;
}

// ═══════════════════════════════════════════════════════════════
// VALIDATION SCHEMAS
// ═══════════════════════════════════════════════════════════════

const GateActivationSchema = z.object({
  gate: z.number().min(1).max(64),
  line: z.number().min(1).max(6).optional(),
  intensity: z.number().min(0).max(1).default(1.0),
});

const TensionUpdateSchema = z.object({
  nodeId: z.string(),
  localContradiction: z.number().min(0).max(1),
  externalPressure: z.number().min(0).max(1),
  circuitPressure: z.number().min(0).max(1),
  temporalResonance: z.number().min(0).max(1),
  trigger: z.enum(['internal', 'external', 'circuit', 'temporal']),
});

// ═══════════════════════════════════════════════════════════════
// ROUTER DEFINITION
// ═══════════════════════════════════════════════════════════════

export const synthiaRouter = router({
  /**
   * Get current field state
   */
  getFieldState: publicProcedure.query(() => {
    const engine = getEngine();
    const state = engine.getFieldState();
    
    return {
      timestamp: state.timestamp,
      tension: state.tension,
      morphingActive: state.morphingActive,
      dimensionalConfig: state.dimensionalConfig,
      circuitStates: state.circuitStates,
      nodeCount: state.nodes.size,
    };
  }),

  /**
   * Activate a gate and trigger cascading effects
   */
  activateGate: publicProcedure
    .input(GateActivationSchema)
    .mutation(({ input }) => {
      const engine = getEngine();
      const events = engine.activateGate(input.gate, input.intensity);
      
      return {
        success: true,
        gate: input.gate,
        eventsTriggered: events.length,
        events: events.map(e => ({
          type: e.type,
          circuit: e.circuit,
          tension: e.tension,
          affectedNodeCount: e.affectedNodes.length,
        })),
      };
    }),

  /**
   * Update node tension and trigger state transitions
   */
  updateTension: publicProcedure
    .input(TensionUpdateSchema)
    .mutation(({ input }) => {
      const engine = getEngine();
      
      const tension = engine.calculateTension(
        input.localContradiction,
        input.externalPressure,
        input.circuitPressure,
        input.temporalResonance
      );
      
      engine.updateNodeState(input.nodeId, tension, input.trigger);
      
      return {
        success: true,
        tension,
        nodeId: input.nodeId,
      };
    }),

  /**
   * Get morphing history
   */
  getMorphingHistory: publicProcedure
    .input(z.object({
      limit: z.number().min(1).max(100).default(50),
    }))
    .query(({ input }) => {
      const engine = getEngine();
      const history = engine.getMorphingHistory();
      
      return history.slice(-input.limit).map(event => ({
        timestamp: event.timestamp,
        type: event.type,
        sourceGate: event.sourceGate,
        targetGate: event.targetGate,
        circuit: event.circuit,
        tension: event.tension,
        affectedNodeCount: event.affectedNodes.length,
      }));
    }),

  /**
   * Get tension history for visualization
   */
  getTensionHistory: publicProcedure
    .input(z.object({
      limit: z.number().min(1).max(1000).default(100),
    }))
    .query(({ input }) => {
      const engine = getEngine();
      const history = engine.getTensionHistory();
      
      return history.slice(-input.limit);
    }),

  /**
   * Get recursive containment for a node
   */
  getRecursiveContainment: publicProcedure
    .input(z.object({
      nodeId: z.string(),
    }))
    .query(({ input }) => {
      const engine = getEngine();
      const containment = engine.getRecursiveContainment(input.nodeId);
      
      return {
        nodeId: input.nodeId,
        containedState: containment,
      };
    }),

  /**
   * Batch activate multiple gates
   */
  activateGateBatch: publicProcedure
    .input(z.object({
      gates: z.array(z.number().min(1).max(64)),
      intensity: z.number().min(0).max(1).default(0.5),
    }))
    .mutation(({ input }) => {
      const engine = getEngine();
      const allEvents = [];
      
      for (const gate of input.gates) {
        const events = engine.activateGate(gate, input.intensity);
        allEvents.push(...events);
      }
      
      return {
        success: true,
        gatesActivated: input.gates.length,
        totalEvents: allEvents.length,
      };
    }),

  /**
   * Get system status
   */
  getStatus: publicProcedure.query(() => {
    const engine = getEngine();
    const state = engine.getFieldState();
    const morphingHistory = engine.getMorphingHistory();
    const tensionHistory = engine.getTensionHistory();
    
    const avgTension = tensionHistory.length > 0
      ? tensionHistory.reduce((a, b) => a + b, 0) / tensionHistory.length
      : 0;
    
    return {
      status: 'running',
      nodeCount: state.nodes.size,
      tension: state.tension,
      averageTension: avgTension,
      morphingActive: state.morphingActive,
      recentMorphingEvents: morphingHistory.slice(-10).length,
      timestamp: Date.now(),
    };
  }),
});

export type SynthiaRouter = typeof synthiaRouter;
